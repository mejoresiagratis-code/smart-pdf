/* ═══════════════════════════════════════════════════════════
   GESTOR DE RUTAS — Service Worker v2.24.6
   Network-first para assets propios → siempre detecta updates.
   ═══════════════════════════════════════════════════════════ */

const APP_VERSION = '2.24.6';
const CACHE = `gestor-v${APP_VERSION}`;
const CACHE_CDN   = `gestor-cdn-v${APP_VERSION}`;
const BASE        = '/gestor-rutas-web';

const STATIC = [
  `${BASE}/`,
  `${BASE}/index.html`,
  `${BASE}/css/tokens.css`,
  `${BASE}/css/app.css`,
  `${BASE}/css/components.css`,
  `${BASE}/js/core.js`,
  `${BASE}/js/pages.js`,
  `${BASE}/js/map.js`,
  `${BASE}/js/stats.js`,
  `${BASE}/js/jornada.js`,
  `${BASE}/js/api.js`,
  `${BASE}/js/auth-ui.js`,
  `${BASE}/manifest.json`,
];

const CDN = [
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js',
  'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500&display=swap',
  'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js',
];

const MAP_TILE_HOSTS = [
  'nominatim', 'tile.openstreetmap', 'basemaps.cartocdn',
  'arcgisonline', 'opentopomap', 'stadiamaps',
  'tile.jawg', 'thunderforest', 'waymarkedtrails',
];

/* ── INSTALL ── */
self.addEventListener('install', e => {
  self.skipWaiting();
  e.waitUntil(
    Promise.all([
      caches.open(CACHE).then(c => c.addAll(STATIC).catch(() => {})),
      caches.open(CACHE_CDN).then(c => c.addAll(CDN).catch(() => {})),
    ])
  );
});

/* ── ACTIVATE — borrar cachés viejas ── */
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(k => k !== CACHE && k !== CACHE_CDN).map(k => caches.delete(k))
      ))
      .then(() => {
        self.clients.matchAll({ includeUncontrolled: true }).then(clients =>
          clients.forEach(c => c.postMessage({ type: 'SW_ACTIVATED', version: APP_VERSION }))
        );
        return self.clients.claim();
      })
  );
});

/* ── MENSAJES ── */
self.addEventListener('message', e => {
  if (e.data === 'SW_SKIP_WAITING') self.skipWaiting();
  if (e.data === 'GET_VERSION') {
    const reply = { type: 'SW_VERSION', version: APP_VERSION };
    /* MessageChannel: responder por el puerto transferido */
    if (e.ports && e.ports[0]) {
      e.ports[0].postMessage(reply);
    } else {
      e.source?.postMessage(reply);
    }
  }
});

/* ── FETCH ── */
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  /* Tiles de mapas — siempre red, nunca caché */
  if (MAP_TILE_HOSTS.some(h => url.hostname.includes(h))) {
    e.respondWith(fetch(e.request).catch(() => new Response('', { status: 503 })));
    return;
  }

  /* CDN (librerías) — cache-first */
  if (url.hostname.includes('cdnjs') || url.hostname.includes('fonts.google')) {
    e.respondWith(
      caches.match(e.request).then(cached =>
        cached || fetch(e.request).then(res => {
          caches.open(CACHE_CDN).then(c => c.put(e.request, res.clone()));
          return res;
        }).catch(() => new Response('', { status: 503 }))
      )
    );
    return;
  }

  /* API backend — siempre red (path real: /gestor-rutas-web/api/...) */
  if (url.pathname.includes('/gestor-rutas-web/api/')) {
    e.respondWith(fetch(e.request).catch(() => new Response(
      JSON.stringify({ error: 'Sin conexión' }),
      { status: 503, headers: { 'Content-Type': 'application/json' } }
    )));
    return;
  }

  /* Assets propios — network-first, fallback caché (detecta updates) */
  if (url.origin === self.location.origin) {
    e.respondWith(
      fetch(e.request).then(res => {
        if (res.ok) {
          const toCache = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, toCache));
        }
        return res;
      }).catch(() =>
        caches.match(e.request).then(cached =>
          cached || new Response('Sin conexión', { status: 503 })
        )
      )
    );
  }
});
