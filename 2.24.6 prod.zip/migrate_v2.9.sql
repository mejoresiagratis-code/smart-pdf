-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración v2.9.0
-- Ejecutar en cPanel → phpMyAdmin → cqvkelal_gestorrutas
-- Solo si tienes la BD de v2.8.x instalada.
-- ═══════════════════════════════════════════════════════════

-- ── Tabla platform_roles ─────────────────────────────────
-- Roles de plataforma, independientes de memberships.
-- No modifica ninguna tabla existente.

CREATE TABLE IF NOT EXISTS `platform_roles` (
  `user_id`    VARCHAR(36)  NOT NULL PRIMARY KEY,
  `role`       ENUM('god','platform_admin') NOT NULL DEFAULT 'platform_admin',
  `granted_by` VARCHAR(36)  NOT NULL,
  `granted_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `notes`      VARCHAR(200) DEFAULT NULL,
  CONSTRAINT fk_pr_user    FOREIGN KEY (user_id)    REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_pr_granted FOREIGN KEY (granted_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Tu usuario pasa a god ────────────────────────────────
-- mejoresiagratis@gmail.com → id: 16070662-5eed-4197-804b-ac85097af234

INSERT IGNORE INTO `platform_roles` (`user_id`, `role`, `granted_by`, `notes`)
VALUES (
  '16070662-5eed-4197-804b-ac85097af234',
  'god',
  '16070662-5eed-4197-804b-ac85097af234',
  'Creador de la plataforma — migración v2.9.0'
);

-- ── Verificación ─────────────────────────────────────────
SELECT u.email, u.name, pr.role AS platform_role, pr.granted_at
FROM platform_roles pr
JOIN users u ON u.id = pr.user_id;

SELECT 'Migración v2.9.0 completada' AS resultado;
