-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración incremental v2.5
-- Ejecutar SOLO si ya tienes la BD de v2.3 o v2.4 instalada.
-- Si instalas desde cero, usa migrate.sql (ya incluye esto).
-- ═══════════════════════════════════════════════════════════

-- A-01: añadir selector para refresh token lookup O(1)
ALTER TABLE refresh_tokens
  ADD COLUMN IF NOT EXISTS selector VARCHAR(32) NOT NULL DEFAULT '' AFTER user_id,
  MODIFY COLUMN token_hash VARCHAR(64) NOT NULL,
  ADD UNIQUE KEY IF NOT EXISTS idx_rt_selector (selector);

-- Revocar todos los tokens existentes (formato antiguo no compatible)
UPDATE refresh_tokens SET revoked = 1 WHERE selector = '';

SELECT 'Migración v2.5 completada' AS resultado;
