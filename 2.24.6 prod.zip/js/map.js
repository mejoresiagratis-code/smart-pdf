/* ═══════════════════════════════════════════════════════════
   GESTOR DE RUTAS — map.js v2.1
   Vista de mapa · Leaflet · Capas · Estilos · Clustering
   Depende de: State, Router (core.js) · _visitsForDay, openNav (jornada.js)
   ═══════════════════════════════════════════════════════════ */
'use strict';

/* ── Definición de capas de mapa disponibles ────────────────
   Cada capa tiene: id, label, emoji, url de tiles y attribution
   ──────────────────────────────────────────────────────────── */
const MAP_LAYERS = {

  /* ── OpenStreetMap ─────────────────────────────────── */
  osm: {
    label: 'Estándar',   emoji: '🗺️', group: 'OpenStreetMap',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attr: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    maxZoom: 19,
  },
  osm_hot: {
    label: 'Humanitario', emoji: '🤝', group: 'OpenStreetMap',
    url: 'https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
    attr: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>, Tiles: <a href="https://hot.openstreetmap.org/">HOT</a>',
    maxZoom: 19,
  },
  topo: {
    label: 'Topográfico', emoji: '⛰️', group: 'OpenStreetMap',
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    attr: '© <a href="https://opentopomap.org">OpenTopoMap</a>',
    maxZoom: 17,
  },
  cycle: {
    label: 'Ciclista',   emoji: '🚴', group: 'OpenStreetMap',
    url: 'https://tile.waymarkedtrails.org/cycling/{z}/{x}/{y}.png',
    attr: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    overlay: true,        /* Se usa sobre otra capa base */
    maxZoom: 19,
  },

  /* ── CARTO ─────────────────────────────────────────── */
  voyager: {
    label: 'Voyager',    emoji: '🧭', group: 'Carto',
    url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    attr: '© <a href="https://carto.com">CARTO</a>',
    maxZoom: 19,
  },
  light: {
    label: 'Claro',      emoji: '☀️', group: 'Carto',
    url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
    attr: '© <a href="https://carto.com">CARTO</a>',
    maxZoom: 19,
  },
  dark: {
    label: 'Oscuro',     emoji: '🌙', group: 'Carto',
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attr: '© <a href="https://carto.com">CARTO</a>',
    maxZoom: 19,
  },
  no_labels: {
    label: 'Sin nombres', emoji: '🤫', group: 'Carto',
    url: 'https://{s}.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}{r}.png',
    attr: '© <a href="https://carto.com">CARTO</a>',
    maxZoom: 19,
  },

  /* ── Esri / ArcGIS ─────────────────────────────────── */
  satellite: {
    label: 'Satélite',   emoji: '🛰️', group: 'Esri',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attr: '© <a href="https://www.esri.com">Esri</a>, Maxar, GeoEye, Earthstar Geographics',
    maxZoom: 19,
  },
  esri_street: {
    label: 'Calles',     emoji: '🏙️', group: 'Esri',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',
    attr: '© <a href="https://www.esri.com">Esri</a>',
    maxZoom: 19,
  },
  esri_topo: {
    label: 'Relieve',    emoji: '🏔️', group: 'Esri',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
    attr: '© <a href="https://www.esri.com">Esri</a>',
    maxZoom: 19,
  },
  esri_natgeo: {
    label: 'NatGeo',     emoji: '🌍', group: 'Esri',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/NatGeo_World_Map/MapServer/tile/{z}/{y}/{x}',
    attr: '© <a href="https://www.esri.com">Esri</a>, National Geographic',
    maxZoom: 16,
  },
  esri_ocean: {
    label: 'Océano',     emoji: '🌊', group: 'Esri',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/Ocean/World_Ocean_Base/MapServer/tile/{z}/{y}/{x}',
    attr: '© <a href="https://www.esri.com">Esri</a>',
    maxZoom: 13,
  },
  esri_gray: {
    label: 'Gris',       emoji: '🩶', group: 'Esri',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}',
    attr: '© <a href="https://www.esri.com">Esri</a>',
    maxZoom: 16,
  },

  /* ── Stadia ────────────────────────────────────────── */
  stadia_smooth: {
    label: 'Suave',      emoji: '🎨', group: 'Stadia',
    url: 'https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png',
    attr: '© <a href="https://stadiamaps.com/">Stadia Maps</a>',
    maxZoom: 20,
  },
  stadia_dark: {
    label: 'Oscuro',     emoji: '🖤', group: 'Stadia',
    url: 'https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png',
    attr: '© <a href="https://stadiamaps.com/">Stadia Maps</a>',
    maxZoom: 20,
  },
  stadia_outdoors: {
    label: 'Exterior',   emoji: '🌲', group: 'Stadia',
    url: 'https://tiles.stadiamaps.com/tiles/outdoors/{z}/{x}/{y}{r}.png',
    attr: '© <a href="https://stadiamaps.com/">Stadia Maps</a>',
    maxZoom: 20,
  },
  stadia_toner: {
    label: 'Tóner',      emoji: '⬛', group: 'Stadia',
    url: 'https://tiles.stadiamaps.com/tiles/stamen_toner/{z}/{x}/{y}{r}.png',
    attr: '© <a href="https://stadiamaps.com/">Stadia Maps</a>',
    maxZoom: 20,
  },
  stadia_watercolor: {
    label: 'Acuarela',   emoji: '🖌️', group: 'Stadia',
    url: 'https://tiles.stadiamaps.com/tiles/stamen_watercolor/{z}/{x}/{y}.jpg',
    attr: '© <a href="https://stadiamaps.com/">Stadia Maps</a>',
    maxZoom: 16,
  },

  /* ── Jawg ──────────────────────────────────────────── */
  jawg_streets: {
    label: 'Calles',     emoji: '🛣️', group: 'Jawg',
    url: 'https://tile.jawg.io/jawg-streets/{z}/{x}/{y}{r}.png?access-token=FcGgNz0OAUW9RgpVNIHXOB9YsM0SHqSPnQa8g0wdDjb1glVMUekVRbYBT2Xr84Hy',
    attr: '© <a href="https://www.jawg.io">Jawg Maps</a>',
    maxZoom: 22,
  },
  jawg_dark: {
    label: 'Oscuro',     emoji: '🌑', group: 'Jawg',
    url: 'https://tile.jawg.io/jawg-dark/{z}/{x}/{y}{r}.png?access-token=FcGgNz0OAUW9RgpVNIHXOB9YsM0SHqSPnQa8g0wdDjb1glVMUekVRbYBT2Xr84Hy',
    attr: '© <a href="https://www.jawg.io">Jawg Maps</a>',
    maxZoom: 22,
  },
  jawg_terrain: {
    label: 'Terreno',    emoji: '🏕️', group: 'Jawg',
    url: 'https://tile.jawg.io/jawg-terrain/{z}/{x}/{y}{r}.png?access-token=FcGgNz0OAUW9RgpVNIHXOB9YsM0SHqSPnQa8g0wdDjb1glVMUekVRbYBT2Xr84Hy',
    attr: '© <a href="https://www.jawg.io">Jawg Maps</a>',
    maxZoom: 22,
  },

  /* ── Thunderforest (demo key) ───────────────────────── */
  transport: {
    label: 'Transporte', emoji: '🚌', group: 'Thunderforest',
    url: 'https://{s}.tile.thunderforest.com/transport/{z}/{x}/{y}.png?apikey=6170aad10dfd42a38d4d8c709a536f38',
    attr: '© <a href="https://www.thunderforest.com">Thunderforest</a>',
    maxZoom: 22,
  },
  spinal: {
    label: 'SpinalMap',  emoji: '🕸️', group: 'Thunderforest',
    url: 'https://{s}.tile.thunderforest.com/spinal-map/{z}/{x}/{y}.png?apikey=6170aad10dfd42a38d4d8c709a536f38',
    attr: '© <a href="https://www.thunderforest.com">Thunderforest</a>',
    maxZoom: 22,
  },

};

/* Persistir la capa preferida del usuario */
function _getActiveLayer() {
  return State.prefs._mapLayer || 'osm';
}
function _setActiveLayer(id) {
  State.prefs._mapLayer = id;
  State.persist();
}

Router.register('map', (el, params = {}) => {
  const routeId = params.routeId || null;
  const dateStr = params.dateStr || null;
  const focusStopId = params.stopId || null; /* stopId para resaltar tramo de visita */
  const route   = routeId ? State.getRoute(routeId) : null;
  const stops   = route ? route.stops.map(id => State.getStop(id)).filter(Boolean)
                        : State.allStops();
  const withGeo = stops.filter(s => s.lat);

  const visits = (routeId && dateStr && typeof _visitsForDay === 'function')
    ? _visitsForDay(routeId, dateStr) : {};

  const title = route ? route.name : `${withGeo.length} paradas`;
  const activeLayerId = _getActiveLayer();
  const activeLayer   = MAP_LAYERS[activeLayerId];

  /* Botones de capas agrupados por proveedor */
  const groups = {};
  Object.entries(MAP_LAYERS).forEach(([id, cfg]) => {
    if (!groups[cfg.group]) groups[cfg.group] = [];
    groups[cfg.group].push({ id, ...cfg });
  });
  const layerBtns = Object.entries(groups).map(([group, layers]) => `
    <div class="map-layer-group-label">${group}</div>
    <div class="map-layer-grid">
      ${layers.map(cfg => `
        <button class="map-layer-btn ${cfg.id === activeLayerId ? 'active' : ''} ${cfg.overlay ? 'overlay-btn' : ''}"
          data-layer="${cfg.id}" onclick="_switchMapLayer('${cfg.id}')" title="${cfg.label}">
          <span class="map-layer-emoji">${cfg.emoji}</span>
          <span class="map-layer-label">${cfg.label}</span>
          ${cfg.overlay ? '<span class="map-layer-badge">+capa</span>' : ''}
        </button>`).join('')}
    </div>`).join('');

  el.innerHTML = `
  <div class="map-page-wrap">
    <div class="map-toolbar">
      <button class="btn btn-ghost btn-icon sm" onclick="history.back()">
        <i class="fa-solid fa-arrow-left"></i>
      </button>
      <span class="map-toolbar-title">${title}</span>
      <select class="form-input" style="width:auto;font-size:var(--t-xs);padding:4px 6px;max-width:120px;min-width:0;flex-shrink:1"
          onchange="Router.go('map',{routeId:this.value||undefined,dateStr:'${dateStr||''}'})">
        <option value="">Todas las rutas</option>
        ${State.routes.map(r =>
          `<option value="${r.id}" ${r.id===routeId?'selected':''}>${r.name}</option>`
        ).join('')}
      </select>
      <button class="btn btn-ghost btn-icon sm" id="map-layers-btn"
          onclick="_toggleLayerPicker()" title="Cambiar estilo de mapa">
        <i class="fa-solid fa-layer-group"></i>
      </button>
      <span class="badge badge-indigo">${withGeo.length}/${stops.length} GPS</span>
    </div>

    <div id="map-container">
      <!-- Selector de capas DENTRO del contenedor relativo -->
      <div id="map-layer-picker" class="map-layer-picker hidden">
        <div class="map-layer-picker-title">Estilo de mapa</div>
        ${layerBtns}
      </div>
      <div id="leaflet-map"></div>
      <div class="map-legend">
        <span><span class="map-legend-dot" style="background:#6366f1"></span>Pendiente</span>
        <span><span class="map-legend-dot" style="background:#22c55e"></span>Visitada</span>
        <span><span class="map-legend-dot" style="background:#94a3b8"></span>Sin GPS</span>
      </div>
      <button class="map-locate-btn" onclick="_locateMe()" title="Mi ubicación">
        <i class="fa-solid fa-location-crosshairs"></i>
      </button>
    </div>
  </div>`;

  requestAnimationFrame(() => _initLeafletMap(withGeo, visits, routeId, dateStr));
});

/* ── Toggle del selector de capas ── */
function _toggleLayerPicker() {
  const picker = document.getElementById('map-layer-picker');
  if (!picker) return;
  picker.classList.toggle('hidden');
}

/* ── Cambiar capa en caliente sin recargar la página ── */
function _switchMapLayer(layerId) {
  const cfg = MAP_LAYERS[layerId];
  if (!cfg || !window._leafletMap) return;

  if (cfg.overlay) {
    /* Las capas overlay se apilan encima de la base */
    if (window._leafletOverlay) {
      window._leafletMap.removeLayer(window._leafletOverlay);
      /* Si pulsas la misma overlay dos veces, la quita */
      if (window._leafletOverlayId === layerId) {
        window._leafletOverlay = null;
        window._leafletOverlayId = null;
        document.querySelectorAll('.map-layer-btn').forEach(btn => {
          if (btn.dataset.layer === layerId) btn.classList.remove('active');
        });
        document.getElementById('map-layer-picker')?.classList.add('hidden');
        return;
      }
    }
    window._leafletOverlay = L.tileLayer(cfg.url, {
      attribution: cfg.attr, maxZoom: cfg.maxZoom, opacity: 0.7,
    }).addTo(window._leafletMap);
    window._leafletOverlayId = layerId;
  } else {
    /* Capa base: reemplaza la anterior */
    if (window._leafletTileLayer) {
      window._leafletMap.removeLayer(window._leafletTileLayer);
    }
    window._leafletTileLayer = L.tileLayer(cfg.url, {
      attribution: cfg.attr, maxZoom: cfg.maxZoom,
    }).addTo(window._leafletMap);
    /* Si había overlay, vuelve a ponerla encima */
    if (window._leafletOverlay) {
      window._leafletOverlay.bringToFront();
    }
    _setActiveLayer(layerId);
  }

  document.querySelectorAll('.map-layer-btn:not(.overlay-btn)').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.layer === layerId);
  });
  document.getElementById('map-layer-picker')?.classList.add('hidden');
}

function _initLeafletMap(stops, visits, routeId, dateStr) {
  if (typeof L === 'undefined') {
    document.getElementById('leaflet-map').innerHTML =
      `<div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--tx-3);flex-direction:column;gap:12px">
        <i class="fa-solid fa-triangle-exclamation" style="font-size:2rem"></i>
        <span>Leaflet no disponible — comprueba la conexión</span>
      </div>`;
    return;
  }

  if (window._leafletMap) {
    try { window._leafletMap.remove(); } catch(e) {}
    window._leafletMap = null;
    window._leafletTileLayer = null;
  }

  let center = [40.4168, -3.7038];
  let zoom   = 13;
  if (stops.length === 1) {
    center = [stops[0].lat, stops[0].lng];
    zoom   = 16;
  } else if (stops.length > 1) {
    const avgLat = stops.reduce((a,s) => a + s.lat, 0) / stops.length;
    const avgLng = stops.reduce((a,s) => a + s.lng, 0) / stops.length;
    center = [avgLat, avgLng];
  }

  const map = L.map('leaflet-map', {
    center, zoom,
    zoomControl: true,
    attributionControl: true,
  });
  window._leafletMap = map;

  /* Capa activa según preferencia del usuario */
  const layerId = _getActiveLayer();
  const layerCfg = MAP_LAYERS[layerId] || MAP_LAYERS.osm;
  window._leafletTileLayer = L.tileLayer(layerCfg.url, {
    attribution: layerCfg.attr,
    maxZoom: layerCfg.maxZoom,
  }).addTo(map);

  /* Ajustar bounds */
  if (stops.length > 1) {
    const bounds = L.latLngBounds(stops.map(s => [s.lat, s.lng]));
    map.fitBounds(bounds, { padding: [50, 50] });
  }

  /* Dibujar línea de ruta planificada (orden de paradas) */
  if (routeId && stops.length > 1) {
    const latlngs = stops.map(s => [s.lat, s.lng]);
    L.polyline(latlngs, {
      color: '#6366f1',
      weight: 2.5,
      opacity: 0.5,
      dashArray: '6 5',
    }).addTo(map);
  }

  /* Dibujar recorrido GPS real de la jornada */
  if (routeId && dateStr) {
    const sess = (typeof getSession === 'function') ? getSession(routeId, dateStr) : null;
    const gpsPath = sess?.gpsPath || [];
    if (gpsPath.length > 1) {
      const trackCoords = gpsPath.map(p => [p.lat, p.lng]);
      L.polyline(trackCoords, {
        color: '#16a34a',
        weight: 3,
        opacity: 0.85,
      }).addTo(map);
      /* Punto de inicio */
      L.circleMarker(trackCoords[0], {
        radius: 7, color: '#16a34a', fillColor: '#22c55e',
        fillOpacity: 1, weight: 2,
      }).bindPopup('Inicio jornada').addTo(map);
      /* Punto final si la jornada terminó */
      if (sess?.state === 'finished') {
        const last = trackCoords[trackCoords.length - 1];
        L.circleMarker(last, {
          radius: 7, color: '#dc2626', fillColor: '#ef4444',
          fillOpacity: 1, weight: 2,
        }).bindPopup('Fin jornada').addTo(map);
      }
    }

    /* Tramo GPS específico de una visita (cuando se navega desde openVisitDetail) */
    if (focusStopId) {
      const visitsList2 = (typeof _visitsForDay === 'function') ? _visitsForDay(routeId, dateStr) : {};
      const focusVisit  = Object.values(visitsList2).find(v => v.stopId === focusStopId);
      if (focusVisit && gpsPath.length && focusVisit.checkInTs && focusVisit.checkOutTs) {
        const visitTrack = gpsPath
          .filter(p => p.ts >= focusVisit.checkInTs && p.ts <= focusVisit.checkOutTs)
          .map(p => [p.lat, p.lng]);
        if (visitTrack.length > 1) {
          L.polyline(visitTrack, { color: '#f59e0b', weight: 5, opacity: 0.95 })
            .addTo(map).bindPopup('Tramo en PDV');
        }
        if (visitTrack.length) map.setView(visitTrack[0], 17);
      }
    }

    /* Marcadores de check-in de cada visita */
    const visitsList = (typeof _visitsForDay === 'function') ? _visitsForDay(routeId, dateStr) : {};
    Object.values(visitsList).forEach(v => {
      if (v.latIn && v.lngIn) {
        const stop = State.getStop(v.stopId);
        const durMin = (v.checkOutTs && v.checkInTs)
          ? Math.round((v.checkOutTs - v.checkInTs) / 60000) : null;
        L.circleMarker([v.latIn, v.lngIn], {
          radius: 5, color: '#854d0e', fillColor: '#f59e0b',
          fillOpacity: 0.9, weight: 2,
        }).bindPopup(`
          <strong>${stop?.name || v.stopId}</strong><br>
          Check-in${durMin != null ? ` · ${durMin} min` : ''}<br>
          ${v.estado ? `<em>${v.estado}</em>` : ''}
        `).addTo(map);
      }
    });
  }

  /* Pin SVG con número */
  function _pinIcon(color, num, visited) {
    const border = visited ? '#15803d' : '#4338ca';
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 38" width="28" height="38">
      <filter id="sh"><feDropShadow dx="0" dy="1" stdDeviation="1.5" flood-opacity="0.3"/></filter>
      <path d="M14 1C8.5 1 4 5.5 4 11c0 7.5 10 24 10 24S24 18.5 24 11c0-5.5-4.5-10-10-10z"
        fill="${color}" stroke="${border}" stroke-width="1.5" filter="url(#sh)"/>
      <circle cx="14" cy="11" r="7" fill="white" opacity="0.9"/>
      <text x="14" y="15" text-anchor="middle"
        style="font-family:system-ui,sans-serif;font-size:9px;font-weight:800;fill:${color}">${num}</text>
    </svg>`;
    return L.divIcon({
      html: svg,
      iconSize:    [28, 38],
      iconAnchor:  [14, 38],
      popupAnchor: [0, -40],
      className:   '',
    });
  }

  /* Marcadores */
  stops.forEach((stop, idx) => {
    const visit   = visits[stop.id];
    const visited = !!visit;
    const color   = visited ? '#22c55e' : '#6366f1';
    const marker  = L.marker([stop.lat, stop.lng], {
      icon: _pinIcon(color, idx + 1, visited),
      title: stop.name,
    });

    const visitChip = visit
      ? `<div style="display:inline-flex;align-items:center;gap:4px;margin-top:4px;
             background:#dcfce7;color:#15803d;border-radius:6px;padding:2px 8px;font-size:11px;font-weight:600">
           <i class="fa-solid fa-circle-check"></i> ${visit.estado || 'Visitada'}
         </div>`
      : `<div style="display:inline-flex;align-items:center;gap:4px;margin-top:4px;
             background:#ede9fe;color:#4338ca;border-radius:6px;padding:2px 8px;font-size:11px;font-weight:600">
           <i class="fa-regular fa-clock"></i> Pendiente
         </div>`;

    const addr = [stop.addr, stop.town].filter(Boolean).join(', ');

    const actionBtn = (routeId && dateStr)
      ? `<button onclick="Router.go('jornada',{routeId:'${routeId}',dateStr:'${dateStr}'})"
           style="flex:1;padding:5px 8px;background:#6366f1;color:#fff;border:none;border-radius:8px;
                  font-size:12px;cursor:pointer;font-family:inherit;font-weight:700">
           <i class="fa-solid fa-play"></i> Jornada
         </button>`
      : `<button onclick="Router.go('stop-detail',{stopId:'${stop.id}'})"
           style="flex:1;padding:5px 8px;background:#6366f1;color:#fff;border:none;border-radius:8px;
                  font-size:12px;cursor:pointer;font-family:inherit;font-weight:700">
           <i class="fa-solid fa-file-lines"></i> Ficha
         </button>`;

    marker.bindPopup(`
      <div style="font-family:system-ui,sans-serif;min-width:160px;max-width:230px">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
          <span style="font-size:10px;font-family:monospace;background:#f1f5f9;color:#64748b;
                       padding:1px 5px;border-radius:4px">#${idx+1}</span>
          <div style="font-weight:800;font-size:14px;color:#0f172a;line-height:1.2">${stop.name}</div>
        </div>
        ${addr ? `<div style="font-size:12px;color:#64748b;margin-bottom:2px">${addr}</div>` : ''}
        ${stop.horario ? `<div style="font-size:11px;color:#94a3b8"><i class="fa-regular fa-clock"></i> ${stop.horario}</div>` : ''}
        ${visitChip}
        <div style="display:flex;gap:6px;margin-top:8px">
          <button onclick="openNav(${stop.lat},${stop.lng})"
            style="flex:1;padding:5px 8px;background:#0ea5e9;color:#fff;border:none;border-radius:8px;
                   font-size:12px;cursor:pointer;font-family:inherit;font-weight:700">
            <i class="fa-solid fa-diamond-turn-right"></i> Ir
          </button>
          ${actionBtn}
        </div>
      </div>
    `, { maxWidth: 240 });

    marker.addTo(map);
  });

  /* Cerrar el layer picker si se toca el mapa */
  map.on('click', () => {
    document.getElementById('map-layer-picker')?.classList.add('hidden');
  });
}

/* ── Mi ubicación ── */
function _locateMe() {
  if (!window._leafletMap) return;
  if (!navigator.geolocation) { toast('GPS no disponible', 'warning'); return; }

  const btn = document.querySelector('.map-locate-btn i');
  if (btn) btn.className = 'fa-solid fa-spinner fa-spin';

  navigator.geolocation.getCurrentPosition(pos => {
    const { latitude: lat, longitude: lng } = pos.coords;
    window._leafletMap.setView([lat, lng], 16);

    /* Punto azul de "mi posición" */
    if (window._locateMarker) window._leafletMap.removeLayer(window._locateMarker);
    window._locateMarker = L.circleMarker([lat, lng], {
      radius: 10,
      fillColor: '#3b82f6',
      fillOpacity: 0.9,
      color: 'white',
      weight: 3,
    }).addTo(window._leafletMap);

    if (btn) btn.className = 'fa-solid fa-location-crosshairs';
  }, () => {
    toast('No se pudo obtener la ubicación', 'warning');
    if (btn) btn.className = 'fa-solid fa-location-crosshairs';
  }, { timeout: 8000, enableHighAccuracy: true });
}

/* ═══════════════════════════════════════════════════════
   MAP PICKER — elegir coordenadas desde el mapa
   Se abre desde el modal de parada (botón mapa GPS)
   ═══════════════════════════════════════════════════════ */
let _pickerMap = null;
let _pickerMarker = null;

function openMapPicker() {
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.style.cssText = 'z-index:9000;padding:0';
  ov.innerHTML = `
  <div style="
    position:relative;width:100%;height:100%;max-width:100vw;max-height:100dvh;
    display:flex;flex-direction:column;background:var(--bg-1)">

    <!-- Header -->
    <div style="
      display:flex;align-items:center;gap:10px;
      padding:12px 16px;border-bottom:1px solid var(--border);
      background:var(--bg-1);flex-shrink:0;z-index:10">
      <button class="btn btn-ghost btn-icon" onclick="Overlay.pop()">
        <i class="fa-solid fa-arrow-left"></i>
      </button>
      <div style="flex:1">
        <div style="font-weight:600;font-size:var(--t-base)">Elegir ubicación</div>
        <div id="picker-hint" style="font-size:var(--t-xs);color:var(--tx-3)">
          Mantén pulsado en el mapa para marcar la ubicación
        </div>
      </div>
    </div>

    <!-- Mapa -->
    <div id="picker-map" style="flex:1;min-height:0"></div>

    <!-- Footer con coords -->
    <div id="picker-footer" style="
      padding:12px 16px;border-top:1px solid var(--border);
      background:var(--bg-1);flex-shrink:0;display:none">
      <div style="display:flex;align-items:center;gap:12px">
        <div style="flex:1">
          <div id="picker-coords" style="font-family:var(--f-mono);font-size:var(--t-sm);color:var(--tx-1)"></div>
          <div id="picker-addr" style="font-size:var(--t-xs);color:var(--tx-3);margin-top:2px"></div>
        </div>
        <button class="btn btn-primary" onclick="_confirmPickerLocation()">
          <i class="fa-solid fa-check"></i> Usar esta ubicación
        </button>
      </div>
    </div>
  </div>`;

  Overlay.push(ov);

  /* Inicializar mapa centrado en última coords conocida o España */
  requestAnimationFrame(() => {
    const latEl = document.getElementById('stop-lat');
    const lngEl = document.getElementById('stop-lng');
    const initLat = parseFloat(latEl?.value) || 40.0;
    const initLng = parseFloat(lngEl?.value) || -3.7;
    const zoom    = (latEl?.value) ? 15 : 6;

    _pickerMap = L.map('picker-map', { zoomControl: true }).setView([initLat, initLng], zoom);
    const pLayerCfg = MAP_LAYERS[_getActiveLayer()] || MAP_LAYERS.osm;
    L.tileLayer(pLayerCfg.url, { attribution: pLayerCfg.attr }).addTo(_pickerMap);

    _pickerMarker = null;

    /* Long-press en móvil = contextmenu; en desktop = mousedown largo */
    _pickerMap.on('contextmenu', _onPickerClick);

    /* Long-press táctil manual (500ms) */
    let _touchTimer = null;
    _pickerMap.on('mousedown touchstart', e => {
      _touchTimer = setTimeout(() => _onPickerClick(e), 500);
    });
    _pickerMap.on('mouseup touchend mousemove touchmove', () => {
      clearTimeout(_touchTimer);
    });

    /* Mostrar feedback visual mientras se mantiene pulsado */
    _pickerMap.getContainer().addEventListener('touchstart', () => {
      document.getElementById('picker-hint').textContent = '...';
    }, { passive: true });
    _pickerMap.getContainer().addEventListener('touchend', () => {
      document.getElementById('picker-hint').textContent =
        'Mantén pulsado en el mapa para marcar la ubicación';
    }, { passive: true });

    /* Si ya tenía coords, mostrar el marcador */
    if (latEl?.value && lngEl?.value) {
      const lat = parseFloat(latEl.value);
      const lng = parseFloat(lngEl.value);
      _addPickerMarker(lat, lng);
    }
  });
}

function _onPickerClick(e) {
  const lat = e.latlng?.lat ?? e.touches?.[0]?.clientY; /* fallback */
  const lng = e.latlng?.lng;
  if (!e.latlng) return;
  _addPickerMarker(e.latlng.lat, e.latlng.lng);
}

function _addPickerMarker(lat, lng) {
  if (_pickerMarker) _pickerMap.removeLayer(_pickerMarker);

  _pickerMarker = L.marker([lat, lng], {
    icon: L.divIcon({
      className: '',
      html: '<div style="width:28px;height:28px;background:var(--primary,#4f46e5);border:3px solid #fff;border-radius:50%;box-shadow:0 2px 8px rgba(0,0,0,.3)"></div>',
      iconSize: [28, 28],
      iconAnchor: [14, 14],
    })
  }).addTo(_pickerMap);

  const footer = document.getElementById('picker-footer');
  const coordsEl = document.getElementById('picker-coords');
  const addrEl = document.getElementById('picker-addr');

  footer.style.display = 'block';
  coordsEl.textContent = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
  addrEl.textContent = 'Buscando dirección...';
  document.getElementById('picker-hint').textContent = '✓ Ubicación marcada — ajusta o pulsa Usar esta ubicación';

  /* Guardar en el marcador para confirmación */
  _pickerMarker._pickerLat = lat;
  _pickerMarker._pickerLng = lng;

  /* Geocodificación inversa */
  fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&accept-language=es`)
    .then(r => r.json())
    .then(d => {
      if (d?.display_name) {
        _pickerMarker._pickerAddr = d;
        addrEl.textContent = d.display_name.split(',').slice(0,3).join(', ');
      }
    })
    .catch(() => { addrEl.textContent = ''; });
}

function _confirmPickerLocation() {
  if (!_pickerMarker) return;
  const lat = _pickerMarker._pickerLat;
  const lng = _pickerMarker._pickerLng;
  const addrData = _pickerMarker._pickerAddr;

  /* Rellenar campos del modal de parada */
  document.getElementById('stop-lat').value = lat.toFixed(6);
  document.getElementById('stop-lng').value = lng.toFixed(6);
  document.getElementById('coords-status').textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;

  if (addrData?.address) {
    const a = addrData.address;
    const road = [a.road, a.house_number].filter(Boolean).join(', ');
    const town = a.city || a.town || a.village || a.municipality || '';
    const zip  = a.postcode || '';
    if (road && !document.getElementById('stop-addr').value)
      document.getElementById('stop-addr').value = road;
    if (town && !document.getElementById('stop-town').value)
      document.getElementById('stop-town').value = town;
    if (zip && !document.getElementById('stop-zip').value)
      document.getElementById('stop-zip').value = zip;
  }

  /* Limpiar y cerrar */
  if (_pickerMarker) { _pickerMap.removeLayer(_pickerMarker); _pickerMarker = null; }
  if (_pickerMap)    { _pickerMap.remove(); _pickerMap = null; }
  Overlay.pop();
  toast('Ubicación añadida', 'success');
}
