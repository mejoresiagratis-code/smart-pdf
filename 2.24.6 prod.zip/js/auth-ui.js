/* ═══════════════════════════════════════════════════════════
   GESTOR DE RUTAS — auth-ui.js v1.0
   Modales de login / registro / perfil de cuenta
   Depende de: core.js · api.js
   ═══════════════════════════════════════════════════════════ */
'use strict';

/* ══════════════════════════════════════════════════════════
   PÁGINA DE AJUSTES — parcheamos la sección de cuenta
   Se llama desde pages.js cuando carga Settings
   ══════════════════════════════════════════════════════════ */
function renderAccountSection() {
  if (Auth.isLoggedIn()) {
    return `
    <div class="card">
      <div class="card-header">
        <div class="card-title"><i class="fa-solid fa-user-circle"></i> Mi cuenta</div>
      </div>
      <div>
        <div class="settings-row">
          <div class="settings-row-info">
            <div class="settings-row-title">${State.prefs._email || 'Usuario'}</div>
            <div class="settings-row-sub">
              <span class="badge badge-indigo" style="font-size:10px;margin-right:6px">${_roleLabel(State.prefs._role)}</span>
              ${State.prefs._pRole ? `<span class="badge badge-purple" style="font-size:10px;margin-right:6px">${_pRoleLabel(State.prefs._pRole)}</span>` : ''}
              <span class="badge badge-muted" style="font-size:10px">${_planLabel(State.prefs._plan)}</span>
            </div>
          </div>
          <button class="btn btn-ghost btn-sm" onclick="showAccountModal()">
            <i class="fa-solid fa-pen"></i> Perfil
          </button>
        </div>
        <div class="settings-row" style="border-bottom:none">
          <div class="settings-row-info">
            <div class="settings-row-title" style="color:var(--tx-2)">Sincronización</div>
            <div class="settings-row-sub" id="sync-status-text">${_syncStatusText()}</div>
          </div>
          <button class="btn btn-ghost btn-sm" onclick="Sync.push().then(()=>Sync.pull({silent:false}))">
            <i class="fa-solid fa-arrows-rotate"></i> Sync manual
          </button>
        </div>
      </div>
      <div class="card-footer">
        <button class="btn btn-danger btn-sm" onclick="confirmLogout()">
          <i class="fa-solid fa-arrow-right-from-bracket"></i> Cerrar sesión
        </button>
      </div>
    </div>`;
  }

  return `
  <div class="card">
    <div class="card-header">
      <div class="card-title"><i class="fa-solid fa-user-circle"></i> Cuenta</div>
    </div>
    <div class="card-body">
      <p style="font-size:var(--t-sm);color:var(--tx-2);margin-bottom:var(--sp-3)">
        Crea una cuenta gratuita para sincronizar tus datos entre dispositivos
        y acceder desde cualquier lugar.
      </p>
      <div style="display:flex;gap:var(--sp-2);flex-wrap:wrap">
        <button class="btn btn-primary" onclick="showLoginModal('register')">
          <i class="fa-solid fa-user-plus"></i> Solicitar acceso
        </button>
        <button class="btn btn-ghost" onclick="showLoginModal('login')">
          <i class="fa-solid fa-right-to-bracket"></i> Iniciar sesión
        </button>
      </div>
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════════════════
   MODAL LOGIN / REGISTRO
   ══════════════════════════════════════════════════════════ */
function showLoginModal(tab = 'login') {
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.innerHTML = `
  <div class="modal" style="max-width:420px" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title" id="auth-modal-title">
        <i class="fa-solid fa-user-circle"></i>
        ${tab === 'login' ? 'Iniciar sesión' : 'Solicitar acceso'}
      </div>
      <button class="modal-close" onclick="Overlay.pop()">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>

    <div class="modal-body">
      <!-- Tabs login / register -->
      <div style="display:flex;gap:6px;margin-bottom:var(--sp-4)">
        <button id="tab-login" class="btn ${tab==='login'?'btn-primary':'btn-ghost'} btn-sm flex-1"
          onclick="_authTab('login')">Iniciar sesión</button>
        <button id="tab-register" class="btn ${tab==='register'?'btn-primary':'btn-ghost'} btn-sm flex-1"
          onclick="_authTab('register')">Solicitar acceso</button>
      </div>

      <div id="auth-form-login" style="display:${tab==='login'?'block':'none'}">
        <div class="form-group">
          <label class="form-label">Email</label>
          <input class="form-input" id="auth-email-login" type="email"
            placeholder="tu@email.com" autocomplete="email" inputmode="email">
        </div>
        <div class="form-group" style="margin-bottom:0">
          <label class="form-label">Contraseña</label>
          <input class="form-input" id="auth-pwd-login" type="password"
            placeholder="••••••••" autocomplete="current-password"
            onkeydown="if(event.key==='Enter')_doLogin()">
        </div>
        <div style="margin-top:var(--sp-2)">
          <button class="btn btn-ghost btn-sm" onclick="_showForgotPwd()">
            ¿Olvidaste tu contraseña?
          </button>
        </div>
      </div>

      <div id="auth-form-register" style="display:${tab==='register'?'block':'none'}">
        <div class="form-group">
          <label class="form-label">Tu nombre</label>
          <input class="form-input" id="auth-name" type="text"
            placeholder="Nombre completo" autocomplete="name">
        </div>
        <div class="form-group">
          <label class="form-label">Email <sup>*</sup></label>
          <input class="form-input" id="auth-email-reg" type="email"
            placeholder="tu@email.com" autocomplete="email" inputmode="email">
        </div>
        <div class="form-group">
          <label class="form-label">Contraseña <sup>*</sup></label>
          <input class="form-input" id="auth-pwd-reg" type="password"
            placeholder="Mínimo 8 caracteres" autocomplete="new-password">
          <div class="form-hint">Al menos 8 caracteres</div>
        </div>
        <div class="form-group" style="margin-bottom:0">
          <label class="form-label">Nombre de tu empresa / equipo</label>
          <input class="form-input" id="auth-org" type="text"
            placeholder="Distribuciones García, S.L."
            onkeydown="if(event.key==='Enter')_doRegister()">
          <div class="form-hint">Puedes cambiarlo más adelante</div>
        </div>
      </div>

      <div id="auth-error" style="display:none;margin-top:var(--sp-3);padding:10px 12px;
        background:var(--red-bg);border:1px solid var(--red-bd);border-radius:var(--r-sm);
        font-size:var(--t-sm);color:var(--red)"></div>
    </div>

    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cancelar</button>
      <button class="btn btn-primary" style="flex:2" id="auth-submit-btn"
        onclick="_doAuthSubmit()">
        <i class="fa-solid fa-right-to-bracket"></i>
        ${tab === 'login' ? 'Entrar' : 'Solicitar acceso'}
      </button>
    </div>
  </div>`;

  Overlay.push(ov);
  setTimeout(() => {
    const inp = tab === 'login'
      ? document.getElementById('auth-email-login')
      : document.getElementById('auth-name');
    inp?.focus();
  }, 150);
}

function _authTab(tab) {
  const isLogin = tab === 'login';
  document.getElementById('auth-form-login').style.display    = isLogin ? 'block' : 'none';
  document.getElementById('auth-form-register').style.display = isLogin ? 'none'  : 'block';
  document.getElementById('tab-login').className    = `btn ${isLogin ? 'btn-primary' : 'btn-ghost'} btn-sm flex-1`;
  document.getElementById('tab-register').className = `btn ${isLogin ? 'btn-ghost' : 'btn-primary'} btn-sm flex-1`;
  document.getElementById('auth-modal-title').innerHTML =
    `<i class="fa-solid fa-user-circle"></i> ${isLogin ? 'Iniciar sesión' : 'Solicitar acceso'}`;
  document.getElementById('auth-submit-btn').innerHTML =
    `<i class="fa-solid fa-right-to-bracket"></i> ${isLogin ? 'Entrar' : 'Crear cuenta'}`;
  _clearAuthError();
  window._authCurrentTab = tab;
}

async function _doAuthSubmit() {
  const tab = window._authCurrentTab ||
    (document.getElementById('auth-form-login').style.display !== 'none' ? 'login' : 'register');
  if (tab === 'login') return _doLogin();
  return _doRegister();
}

async function _doLogin() {
  _clearAuthError();
  const email    = document.getElementById('auth-email-login')?.value.trim();
  const password = document.getElementById('auth-pwd-login')?.value;
  if (!email || !password) { _showAuthError('Completa todos los campos'); return; }
  const btn = document.getElementById('auth-submit-btn');
  btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Entrando…';
  try {
    await Auth.login({ email, password });
    Overlay.pop();
    Router.go(Router._current || 'dashboard');
  } catch (e) {
    _showAuthError(e.status === 401 ? 'Email o contraseña incorrectos' : (e.message || 'Error de conexión'));
    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Entrar';
  }
}

async function _doRegister() {
  _clearAuthError();
  const name     = document.getElementById('auth-name')?.value.trim();
  const email    = document.getElementById('auth-email-reg')?.value.trim();
  const password = document.getElementById('auth-pwd-reg')?.value;
  const orgName  = document.getElementById('auth-org')?.value.trim() || 'Mi equipo';
  if (!email || !password) { _showAuthError('Email y contraseña son obligatorios'); return; }
  if (password.length < 8)  { _showAuthError('La contraseña debe tener al menos 8 caracteres'); return; }
  const btn = document.getElementById('auth-submit-btn');
  btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Enviando solicitud…';
  try {
    const result = await Auth.register({ name, email, password, orgName });
    if (result.pending) {
      Overlay.pop();
      _showPendingScreen(email, result.message);
    } else {
      Overlay.pop();
      Router.go(Router._current || 'dashboard');
    }
  } catch (e) {
    _showAuthError(e.status === 409 ? 'Ya existe una cuenta con ese email' : (e.message || 'Error de conexión'));
    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Solicitar acceso';
  }
}

function _showAuthError(msg) {
  const el = document.getElementById('auth-error');
  if (el) { el.textContent = msg; el.style.display = 'block'; }
}
function _clearAuthError() {
  const el = document.getElementById('auth-error');
  if (el) el.style.display = 'none';
}

function _showForgotPwd() {
  /* Sustituir contenido del modal de login por el formulario de recuperación */
  const body   = document.querySelector('.modal .modal-body');
  const footer = document.querySelector('.modal .modal-footer');
  if (!body || !footer) return;

  body.innerHTML = `
    <div style="margin-bottom:var(--sp-4)">
      <button class="btn btn-ghost btn-sm" style="padding:0;font-size:var(--t-sm)"
        onclick="_restoreLoginModal()">
        <i class="fa-solid fa-arrow-left"></i> Volver al inicio de sesión
      </button>
    </div>
    <p style="font-size:var(--t-sm);color:var(--tx-2);margin-bottom:var(--sp-4)">
      Introduce tu email y te enviaremos un enlace para crear una nueva contraseña.
    </p>
    <div class="form-group" style="margin-bottom:0">
      <label class="form-label">Email</label>
      <input class="form-input" id="forgot-email" type="email"
        placeholder="tu@email.com" autocomplete="email" inputmode="email"
        onkeydown="if(event.key==='Enter')_doForgotPwd()">
    </div>
    <div id="forgot-msg" style="display:none;margin-top:var(--sp-3);padding:10px 12px;
      border-radius:var(--r-sm);font-size:var(--t-sm)"></div>`;

  footer.innerHTML = `
    <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cancelar</button>
    <button class="btn btn-primary" style="flex:2" id="forgot-btn" onclick="_doForgotPwd()">
      <i class="fa-solid fa-envelope"></i> Enviar enlace
    </button>`;

  document.getElementById('forgot-email')?.focus();
}

function _restoreLoginModal() {
  /* Cerrar el modal actual y abrir uno nuevo limpio en tab login */
  Overlay.pop();
  setTimeout(() => showLoginModal('login'), 50);
}

async function _doForgotPwd() {
  const email = document.getElementById('forgot-email')?.value?.trim();
  const btn   = document.getElementById('forgot-btn');
  const msg   = document.getElementById('forgot-msg');
  if (!email) { if (msg) { msg.style.display='block'; msg.style.background='var(--red-bg)'; msg.style.color='var(--red)'; msg.textContent='Introduce tu email'; } return; }

  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Enviando…'; }

  try {
    const data = await API.post('/auth/forgot', { email });
    if (msg) {
      msg.style.display = 'block';
      msg.style.background = 'var(--green-bg)';
      msg.style.color = 'var(--green)';
      msg.textContent = data.message || 'Si ese email existe, recibirás un enlace en breve.';
    }
    if (btn) btn.style.display = 'none';
  } catch(e) {
    if (msg) { msg.style.display='block'; msg.style.background='var(--red-bg)'; msg.style.color='var(--red)'; msg.textContent = e.message || 'Error al enviar. Inténtalo de nuevo.'; }
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-envelope"></i> Enviar enlace'; }
  }
}

/* Detectar token de reset en el hash de la URL al cargar la app */
function _checkResetToken() {
  const hash = location.hash;
  if (!hash.startsWith('#reset-password/')) return;
  const token = hash.slice('#reset-password/'.length);
  if (!token) return;
  /* Limpiar hash sin recargar */
  history.replaceState(null, '', location.pathname);
  _showResetModal(token);
}

function _showResetModal(token) {
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.innerHTML = `
  <div class="modal" style="max-width:400px" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title"><i class="fa-solid fa-key"></i> Nueva contraseña</div>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Nueva contraseña</label>
        <input class="form-input" id="reset-pwd1" type="password"
          placeholder="Mínimo 6 caracteres" autocomplete="new-password">
      </div>
      <div class="form-group" style="margin-bottom:0">
        <label class="form-label">Repetir contraseña</label>
        <input class="form-input" id="reset-pwd2" type="password"
          placeholder="Repite la contraseña" autocomplete="new-password"
          onkeydown="if(event.key==='Enter')_doResetPwd('${token}')">
      </div>
      <div id="reset-msg" style="display:none;margin-top:var(--sp-3);padding:10px 12px;
        border-radius:var(--r-sm);font-size:var(--t-sm)"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cancelar</button>
      <button class="btn btn-primary" style="flex:2" id="reset-btn"
        onclick="_doResetPwd('${token}')">
        <i class="fa-solid fa-lock"></i> Guardar contraseña
      </button>
    </div>
  </div>`;
  Overlay.push(ov);
  setTimeout(() => document.getElementById('reset-pwd1')?.focus(), 150);
}

async function _doResetPwd(token) {
  const p1  = document.getElementById('reset-pwd1')?.value;
  const p2  = document.getElementById('reset-pwd2')?.value;
  const btn = document.getElementById('reset-btn');
  const msg = document.getElementById('reset-msg');
  const showMsg = (text, ok) => {
    if (!msg) return;
    msg.style.display = 'block';
    msg.style.background = ok ? 'var(--green-bg)' : 'var(--red-bg)';
    msg.style.color = ok ? 'var(--green)' : 'var(--red)';
    msg.textContent = text;
  };
  if (!p1 || p1.length < 6) { showMsg('La contraseña debe tener al menos 6 caracteres', false); return; }
  if (p1 !== p2)             { showMsg('Las contraseñas no coinciden', false); return; }

  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Guardando…'; }

  try {
    const data = await API.post('/auth/reset', { token, password: p1 });
    showMsg(data.message || 'Contraseña actualizada. Ya puedes iniciar sesión.', true);
    if (btn) btn.style.display = 'none';
    setTimeout(() => { Overlay.pop(); showLoginModal('login'); }, 2000);
  } catch(e) {
    showMsg(e.message || 'El enlace no es válido o ha expirado.', false);
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-lock"></i> Guardar contraseña'; }
  }
}

/* ══════════════════════════════════════════════════════════
   LOGOUT CON CONFIRMACIÓN
   ══════════════════════════════════════════════════════════ */
function confirmLogout() {
  confirm_(
    'Se cerrará la sesión en este dispositivo. Los datos locales se conservan.',
    () => Auth.logout(),
    'Cerrar sesión'
  );
}

/* ══════════════════════════════════════════════════════════
   HELPERS UI
   ══════════════════════════════════════════════════════════ */
function _roleLabel(role) {
  return { rep: 'Comercial', supervisor: 'Supervisor', admin: 'Admin', owner: 'Propietario' }[role] || role || '—';
}
function _pRoleLabel(pRole) {
  return { god: '⚡ God', platform_admin: '🛠 Platform Admin' }[pRole] || pRole;
}
function _planLabel(plan) {
  return { free: 'Free', starter: 'Starter', pro: 'Pro', enterprise: 'Enterprise' }[plan] || plan || 'Free';
}
function _syncStatusText() {
  const ts = State.prefs._lastSyncTs;
  if (!ts) return 'Nunca sincronizado';
  const diff = Date.now() - ts;
  if (diff < 60000)  return 'Sincronizado hace un momento';
  if (diff < 3600000) return `Sincronizado hace ${Math.round(diff/60000)} min`;
  return `Último sync: ${new Date(ts).toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'})}`;
}

/* ══════════════════════════════════════════════════════════
   PLAN GUARD — bloquea funciones de planes superiores
   Uso: if (!planGuard('pro')) return;
   ══════════════════════════════════════════════════════════ */
const PLAN_LEVELS = { free: 0, starter: 1, pro: 2, enterprise: 3 };

function planGuard(requiredPlan) {
  const current = State.prefs._plan || 'free';
  if ((PLAN_LEVELS[current] || 0) >= (PLAN_LEVELS[requiredPlan] || 0)) return true;
  _showUpgradePrompt(requiredPlan);
  return false;
}

function _showUpgradePrompt(plan) {
  const labels = { starter: 'Starter (€29/mes)', pro: 'Pro (€79/mes)', enterprise: 'Enterprise' };
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.innerHTML = `
  <div class="modal" style="max-width:380px" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title"><i class="fa-solid fa-star"></i> Función premium</div>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <p style="font-size:var(--t-md);color:var(--tx-2);line-height:1.6">
        Esta función está disponible en el plan <strong>${labels[plan] || plan}</strong>.
        Actualiza tu plan para acceder a ella.
      </p>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Ahora no</button>
      <button class="btn btn-primary" style="flex:2"
        onclick="Overlay.pop();window.open('https://tudominio.com/precios','_blank')">
        <i class="fa-solid fa-arrow-up-right-from-square"></i> Ver planes
      </button>
    </div>
  </div>`;
  Overlay.push(ov);
}

/* ══════════════════════════════════════════════════════════
   PANTALLA DE SOLICITUD PENDIENTE
   ══════════════════════════════════════════════════════════ */
let _pendingPollTimer = null;

function _showPendingScreen(email, message) {
  /* Si el app-root ya existe, mostrar la pantalla de espera en él */
  const root = document.getElementById('app') || document.body;

  const el = document.createElement('div');
  el.id = 'pending-screen';
  el.style.cssText = 'position:fixed;inset:0;z-index:8000;background:var(--bg-1);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:2rem;text-align:center';
  el.innerHTML = `
    <div style="max-width:360px;width:100%">
      <div style="width:64px;height:64px;border-radius:50%;background:var(--indigo-dim);display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem">
        <i class="fa-solid fa-hourglass-half" style="font-size:28px;color:var(--indigo)"></i>
      </div>
      <h2 style="font-size:1.25rem;font-weight:700;margin-bottom:0.75rem">Solicitud enviada</h2>
      <p style="font-size:14px;color:var(--tx-2);line-height:1.6;margin-bottom:1.5rem">
        ${message || 'Revisaremos tu solicitud en breve y te avisaremos cuando esté aprobada.'}
      </p>
      <div style="background:var(--bg-2);border-radius:var(--r-lg);padding:1rem;margin-bottom:1.5rem;font-size:13px;color:var(--tx-3)">
        <i class="fa-solid fa-envelope" style="margin-right:6px"></i>${email}
      </div>
      <div id="pending-status" style="font-size:13px;color:var(--tx-3);margin-bottom:1rem">
        <i class="fa-solid fa-spinner fa-spin" style="margin-right:6px"></i>Comprobando estado…
      </div>
      <button class="btn btn-ghost btn-sm" onclick="_pendingCheckNow('${email}')">
        <i class="fa-solid fa-rotate-right"></i> Comprobar ahora
      </button>
      <div style="margin-top:2rem">
        <button class="btn btn-ghost btn-sm" style="font-size:12px;color:var(--tx-3)"
          onclick="_pendingCancel()">Volver al inicio</button>
      </div>
    </div>
  `;
  document.body.appendChild(el);
  _startPendingPoll(email);
}

function _startPendingPoll(email) {
  _stopPendingPoll();
  /* Comprobar cada 30 segundos */
  _pendingPollTimer = setInterval(() => _pendingCheckNow(email), 30000);
  /* Primera comprobación tras 5s */
  setTimeout(() => _pendingCheckNow(email), 5000);
}

function _stopPendingPoll() {
  if (_pendingPollTimer) { clearInterval(_pendingPollTimer); _pendingPollTimer = null; }
}

async function _pendingCheckNow(email) {
  const statusEl = document.getElementById('pending-status');
  try {
    const r = await Auth.checkRegistrationStatus(email);
    if (r.status === 'approved') {
      _stopPendingPoll();
      if (statusEl) statusEl.innerHTML = '<i class="fa-solid fa-check" style="color:var(--success);margin-right:6px"></i>¡Aprobado! Iniciando sesión…';
      /* Limpiar pending y hacer login automático no es posible sin contraseña en memoria */
      /* Mostrar pantalla de login con mensaje */
      setTimeout(() => {
        _pendingCancel();
        showLoginModal('login');
        toast('¡Tu cuenta ha sido aprobada! Inicia sesión.', 'success', 5000);
      }, 1500);
    } else if (r.status === 'rejected') {
      _stopPendingPoll();
      if (statusEl) statusEl.innerHTML = `<i class="fa-solid fa-xmark" style="color:var(--danger);margin-right:6px"></i>Solicitud denegada${r.reason ? ': ' + r.reason : ''}`;
      /* Limpiar pending email */
      delete State.prefs._pendingEmail;
      DB.set(DB.KEYS.prefs, State.prefs);
    } else {
      if (statusEl) statusEl.innerHTML = '<i class="fa-solid fa-hourglass-half" style="margin-right:6px"></i>Pendiente de revisión — volvemos a comprobar en 30s';
    }
  } catch(e) {
    if (statusEl) statusEl.innerHTML = '<i class="fa-solid fa-wifi" style="margin-right:6px;color:var(--tx-3)"></i>Sin conexión — reintentando…';
  }
}

function _pendingCancel() {
  _stopPendingPoll();
  const el = document.getElementById('pending-screen');
  if (el) el.remove();
  /* Limpiar pending email guardado */
  delete State.prefs._pendingEmail;
  DB.set(DB.KEYS.prefs, State.prefs);
}

/* Comprobar al arrancar si había una solicitud pendiente en curso */
document.addEventListener('DOMContentLoaded', () => {
  const pendingEmail = State.prefs._pendingEmail;
  if (pendingEmail && !Auth.isLoggedIn()) {
    /* Mostrar pantalla pendiente automáticamente */
    setTimeout(() => _showPendingScreen(pendingEmail, 'Tu solicitud sigue en revisión.'), 500);
  }
});

/* ══════════════════════════════════════════════════════════
   MODAL PERFIL / CAMBIO DE CONTRASEÑA
   ══════════════════════════════════════════════════════════ */
function showAccountModal() {
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.id = 'modal-account';
  ov.innerHTML = `
  <div class="modal" style="max-width:380px" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title"><i class="fa-solid fa-user-circle"></i> Mi perfil</div>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="display:flex;flex-direction:column;gap:var(--sp-4)">
      <div style="font-size:var(--t-sm);color:var(--tx-2)">
        <div style="font-weight:500;margin-bottom:2px">${State.prefs._email||''}</div>
        <div style="color:var(--tx-3)">${_roleLabel(State.prefs._role)} · ${_planLabel(State.prefs._plan)}</div>
      </div>
      <div style="border-top:1px solid var(--bd-0);padding-top:var(--sp-3)">
        <div style="font-size:var(--t-xs);font-weight:500;color:var(--tx-3);margin-bottom:var(--sp-3)">CAMBIAR CONTRASEÑA</div>
        <div class="form-group">
          <label class="form-label">Contraseña actual</label>
          <input type="password" id="pwd-current" class="form-input" placeholder="••••••••" autocomplete="current-password">
        </div>
        <div class="form-group">
          <label class="form-label">Nueva contraseña</label>
          <input type="password" id="pwd-new" class="form-input" placeholder="Mínimo 6 caracteres" autocomplete="new-password">
        </div>
        <div class="form-group">
          <label class="form-label">Repetir nueva contraseña</label>
          <input type="password" id="pwd-confirm" class="form-input" placeholder="••••••••" autocomplete="new-password">
        </div>
        <div id="pwd-error" style="color:var(--red);font-size:var(--t-sm);display:none;margin-top:4px"></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cancelar</button>
      <button class="btn btn-primary" style="flex:2" onclick="_doChangePassword()">
        <i class="fa-solid fa-key"></i> Cambiar contraseña
      </button>
    </div>
  </div>`;
  Overlay.push(ov);
  setTimeout(() => document.getElementById('pwd-current')?.focus(), 100);
}

async function _doChangePassword() {
  const current = document.getElementById('pwd-current')?.value;
  const newPwd  = document.getElementById('pwd-new')?.value;
  const confirm = document.getElementById('pwd-confirm')?.value;
  const errEl   = document.getElementById('pwd-error');

  errEl.style.display = 'none';
  if (!current || !newPwd || !confirm) {
    errEl.textContent = 'Completa todos los campos'; errEl.style.display = 'block'; return;
  }
  if (newPwd.length < 6) {
    errEl.textContent = 'La nueva contraseña debe tener al menos 6 caracteres'; errEl.style.display = 'block'; return;
  }
  if (newPwd !== confirm) {
    errEl.textContent = 'Las contraseñas no coinciden'; errEl.style.display = 'block'; return;
  }
  try {
    await API.patch('/auth/password', { current, new: newPwd });
    Overlay.pop();
    toast('Contraseña actualizada. Vuelve a iniciar sesión en otros dispositivos.', 'success', 4000);
  } catch(e) {
    errEl.textContent = e.message || 'Error al cambiar la contraseña';
    errEl.style.display = 'block';
  }
}
