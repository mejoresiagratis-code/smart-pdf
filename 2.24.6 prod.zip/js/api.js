/* ═══════════════════════════════════════════════════════════
   GESTOR DE RUTAS — api.js v1.0
   Módulo cliente API · Auth · Sync · Upload
   Depende de: core.js (DB, State, SyncQueue, Events, toast, Router)
   ═══════════════════════════════════════════════════════════ */
'use strict';

/* ══════════════════════════════════════════════════════════
   CONFIG — backend PHP en el mismo hosting
   El backend vive en /api/ dentro del mismo dominio.
   Si lo pones en otro subdominio, cambia ONLY esta constante.
   ══════════════════════════════════════════════════════════ */
const RAILWAY_URL = 'https://mejoresiagratis.com/gestor-rutas-web/api';

const API_BASE = (() => {
  if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
    return 'http://localhost/gestor-rutas-web/api';
  }
  return RAILWAY_URL;
})();

/* ══════════════════════════════════════════════════════════
   TOKENS — gestión de access token y refresh token
   Guardados en prefs para sobrevivir a recargas de la app
   ══════════════════════════════════════════════════════════ */
const Tokens = {
  /* AT solo en memoria (variable JS) — no persiste entre recargas, se renueva via RT.
     RT en localStorage — sobrevive a cerrar la PWA/navegador.
     El AT en memoria + RT en localStorage es el mejor balance entre seguridad y UX
     para una PWA sin acceso a HttpOnly cookies. */
  _at: null,

  _lsKey: 'gr_rt_v1',

  set(accessToken, refreshToken) {
    this._at = accessToken;
    try { localStorage.setItem(this._lsKey, refreshToken); } catch {}
    /* Limpiar formato antiguo si existía */
    delete State.prefs._auth;
    try { sessionStorage.removeItem('gr_rt_v1'); } catch {}
    DB.set(DB.KEYS.prefs, State.prefs);
  },

  clear() {
    this._at = null;
    try { localStorage.removeItem(this._lsKey); } catch {}
    try { sessionStorage.removeItem(this._lsKey); } catch {}
    delete State.prefs._auth;
    delete State.prefs._userId;
    delete State.prefs._orgId;
    delete State.prefs._role;
    delete State.prefs._plan;
    delete State.prefs._pRole;
    /* NO borrar _lastSyncTs — lo necesitamos para el pull incremental al re-login */
    DB.set(DB.KEYS.prefs, State.prefs);
  },

  accessToken()  { return this._at || null; },
  refreshToken() {
    try {
      /* Leer de localStorage (nueva ubicación) o sessionStorage (legacy) */
      return localStorage.getItem(this._lsKey)
          || sessionStorage.getItem(this._lsKey)
          || null;
    } catch { return null; }
  },
  isLoggedIn()   { return !!this._at || !!this.refreshToken(); },

  /* Migración desde el almacenamiento antiguo (localStorage via State.prefs._auth) */
  migrateFromLegacy() {
    const legacy = State.prefs._auth;
    if (legacy?.rt && !this.refreshToken()) {
      try { localStorage.setItem(this._lsKey, legacy.rt); } catch {}
    }
    /* El AT no se recupera del legacy — se obtendrá vía refresh al arrancar */
    delete State.prefs._auth;
    DB.set(DB.KEYS.prefs, State.prefs);
  },
};

/* ══════════════════════════════════════════════════════════
   API — wrapper fetch con auth, retry y error handling
   ══════════════════════════════════════════════════════════ */
const API = {
  _refreshing: null, // Promise única para evitar race de refresh paralelos

  /* ── Petición base ─────────────────────────────────── */
  async _request(method, path, body, opts = {}) {
    const url  = `${API_BASE}${path}`;
    const hdrs = { 'Content-Type': 'application/json' };

    const at = Tokens.accessToken();
    if (at) hdrs['Authorization'] = `Bearer ${at}`;

    const res = await fetch(url, {
      method,
      headers: hdrs,
      body: body ? JSON.stringify(body) : undefined,
      signal: opts.signal,
    });

    /* 401 → intentar refresh una sola vez */
    if (res.status === 401 && !opts._retry && Tokens.refreshToken()) {
      const refreshed = await this._doRefresh();
      if (refreshed) return this._request(method, path, body, { ...opts, _retry: true });
      /* Refresh falló → logout */
      await Auth.logout();
      return null;
    }

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
      throw new APIError(err.error || `HTTP ${res.status}`, res.status);
    }

    return res.status === 204 ? null : res.json();
  },

  async get(path, opts)      { return this._request('GET',    path, null, opts); },
  async post(path, body)     { return this._request('POST',   path, body); },
  async patch(path, body)    { return this._request('PATCH',  path, body); },
  async del(path)            { return this._request('DELETE', path); },

  /* ── Refresh token — serializado para evitar duplicados ─ */
  async _doRefresh() {
    if (this._refreshing) return this._refreshing;
    this._refreshing = (async () => {
      try {
        const rt = Tokens.refreshToken();
        if (!rt) return false;
        /* Timeout propio de 8s — no depende del AbortController de _request */
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 15000);
        let data = null;
        try {
          const res = await fetch(`${API_BASE}/auth/refresh`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ refresh_token: rt }),
            signal: controller.signal,
          });
          data = res.ok ? await res.json() : null;
        } catch { data = null; }
        finally { clearTimeout(timer); }
        if (!data?.access_token) return false;
        Tokens.set(data.access_token, data.refresh_token);
        return true;
      } catch {
        return false;
      } finally {
        this._refreshing = null;
      }
    })();
    return this._refreshing;
  },
};

class APIError extends Error {
  constructor(msg, status) { super(msg); this.status = status; }
}

/* ══════════════════════════════════════════════════════════
   AUTH — registro, login, logout, perfil
   ══════════════════════════════════════════════════════════ */
const Auth = {

  isLoggedIn() { return Tokens.isLoggedIn(); },

  /* ── Registro — crea usuario + organización ─────────── */
  async register({ name, email, password, orgName }) {
    const data = await API.post('/auth/register', { name, email, password, orgName });
    /* Si el servidor devuelve pending:true, NO hay sesión — guardar email para polling */
    if (data.pending) {
      State.prefs._pendingEmail = email;
      DB.set(DB.KEYS.prefs, State.prefs);
      return { pending: true, message: data.message };
    }
    /* Aprobación instantánea (si en el futuro se desactiva el sistema de solicitudes) */
    this._applySession(data);
    toast('Cuenta creada. Bienvenido/a.', 'success', 3000);
    return data;
  },

  /* ── Polling de estado de solicitud ─────────────────── */
  async checkRegistrationStatus(email) {
    return await API.get(`/auth/register/status?email=${encodeURIComponent(email)}`);
  },

  /* ── Login ──────────────────────────────────────────── */
  async login({ email, password }) {
    const data = await API.post('/auth/login', { email, password });
    this._applySession(data);
    /* Disparar migración + primer pull en background */
    Sync.initialSync().catch(e => console.warn('initialSync error:', e));
    toast('Sesión iniciada', 'success', 2000);
    return data;
  },

  /* ── Logout ─────────────────────────────────────────── */
  async logout() {
    try {
      await API.post('/auth/logout', { refresh_token: Tokens.refreshToken() });
    } catch { /* silencioso — limpiar local igualmente */ }
    Tokens.clear();
    SyncQueue.clear();
    Events.emit('auth:logout');
    toast('Sesión cerrada', 'info', 2000);
    Router.go('dashboard', {}, { replace: true });
  },

  /* ── Guarda sesión en State.prefs ───────────────────── */
  _applySession(data) {
    Tokens.set(data.access_token, data.refresh_token);
    State.prefs._userId = data.user.id;
    State.prefs._orgId  = data.user.orgId;
    State.prefs._role   = data.user.role;
    State.prefs._plan   = data.org?.plan || 'free';
    State.prefs._pRole  = data.user.pRole || null;
    State.prefs._name   = data.user.name  || null;
    State.prefs._email  = data.user.email || null;

    /* Aplicar settings del servidor al hacer login */
    if (data.user.settings && typeof data.user.settings === 'object') {
      if (data.user.settings.theme        !== undefined) State.prefs.theme        = data.user.settings.theme;
      if (data.user.settings.notifEnabled !== undefined) State.prefs.notifEnabled = data.user.settings.notifEnabled;
      if (data.user.settings.notifTime    !== undefined) State.prefs.notifTime    = data.user.settings.notifTime;
      if (typeof _applyTheme === 'function') _applyTheme(State.prefs.theme || 'auto');
    }

    /* Limpiar datos demo del localStorage antes de sincronizar */
    State.routes = State.routes.filter(r => !r._isDemo);
    State.stops  = Object.fromEntries(Object.entries(State.stops).filter(([,s]) => !s._isDemo));
    DB.set(DB.KEYS.routes, State.routes);
    DB.set(DB.KEYS.stops,  State.stops);
    DB.set(DB.KEYS.prefs, State.prefs);
    Events.emit('auth:login', { user: data.user, org: data.org });
    _updateAuthUI();
  },

  /* ── Restaurar sesión al arrancar (si hay tokens guardados) ─ */
  async restoreSession() {
    /* Migrar RT del antiguo localStorage/sessionStorage si existe */
    Tokens.migrateFromLegacy();

    /* AT no persiste entre recargas — usar RT para obtener uno nuevo */
    if (!Tokens.refreshToken()) return false;

    /* Arrancar UI con datos locales inmediatamente — no bloquear */
    _updateAuthUI();
    Events.emit('auth:restored', { user: { id: State.prefs._userId } });

    /* Intentar refresh silencioso en background */
    const refreshed = await API._doRefresh();

    if (!refreshed) {
      if (navigator.onLine) {
        /* Red disponible pero refresh falló — puede ser token expirado o servidor lento.
           Esperar 2s y reintentar una vez antes de hacer logout definitivo. */
        await new Promise(r => setTimeout(r, 2000));
        const retry = await API._doRefresh();
        if (!retry) {
          Tokens.clear();
          Events.emit('auth:logout');
          return false;
        }
      } else {
        /* Sin red → mantener sesión con datos locales, intentar al volver online */
        window.addEventListener('online', () => Auth.restoreSession(), { once: true });
        return true;
      }
    }

    try {
      const me = await API.get('/auth/me');
      if (!me) return true; /* Fallo de red — mantener sesión local */
      State.prefs._userId = me.id;
      State.prefs._orgId  = me.orgId;
      State.prefs._role   = me.role;
      State.prefs._plan   = me.plan;
      State.prefs._pRole  = me.pRole || null;
      State.prefs._name   = me.name  || null;
      State.prefs._email  = me.email || null;
      /* Aplicar settings del servidor — tienen prioridad sobre localStorage */
      if (me.settings && typeof me.settings === 'object') {
        if (me.settings.theme       !== undefined) State.prefs.theme       = me.settings.theme;
        if (me.settings.notifEnabled !== undefined) State.prefs.notifEnabled = me.settings.notifEnabled;
        if (me.settings.notifTime   !== undefined) State.prefs.notifTime   = me.settings.notifTime;
        if (typeof _applyTheme === 'function') _applyTheme(State.prefs.theme || 'auto');
      }
      DB.set(DB.KEYS.prefs, State.prefs);
      Events.emit('auth:restored', { user: me });
      _updateAuthUI();
      /* Pull incremental silencioso + push de cola pendiente */
      Sync.pull({ silent: true }).catch(() => {});
      if (SyncQueue.getAll().length > 0) Sync.push().catch(() => {});
      return true;
    } catch {
      /* Error de red → mantener sesión con datos locales */
      return true;
    }
  },
};

/* ══════════════════════════════════════════════════════════
   SYNC — push (SyncQueue → servidor) y pull (servidor → local)
   ══════════════════════════════════════════════════════════ */
const Sync = {
  _pushDebounceTimer: null,
  _retryTimer: null,
  _retryCount: 0,
  _retryDelays: [500, 1000, 2000, 5000, 15000], /* 0.5s→1s→2s→5s→15s */
  _isSyncing: false,

  /* ── Push: envía SyncQueue al servidor ──────────────── */
  async push() {
    if (!Auth.isLoggedIn() || !navigator.onLine) return;
    if (this._isSyncing) return;
    const q = SyncQueue.getAll();
    if (!q.length) return;

    /* S-02: requestId único por batch — evita duplicados si la respuesta se pierde */
    const requestId = (typeof crypto !== 'undefined' && crypto.randomUUID)
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`;

    this._isSyncing = true;
    try {
      const res = await API.post('/sync/push', { changes: q, requestId });
      if (!res) return;

      /* Aplicar conflictos ganados por el servidor */
      if (res.conflicts?.length) {
        res.conflicts.forEach(c => _applyServerRecord(c.collection, c.serverWins));
        if (res.conflicts.length) {
          toast(`${res.conflicts.length} conflicto${res.conflicts.length > 1 ? 's' : ''} resuelto${res.conflicts.length > 1 ? 's' : ''}`, 'warning', 3000);
        }
      }

      SyncQueue.clear();
      Events.emit('sync:pushed', { sent: res.applied });
    } catch (e) {
      /* Red caída — cola persiste para el próximo intento */
      Events.emit('sync:failed', { pending: q.length });
    } finally {
      this._isSyncing = false;
    }
  },

  /* ── Push debounced — agrupa cambios rápidos ─────────── */
  pushDebounced(ms = 2000) {
    clearTimeout(this._pushDebounceTimer);
    this._pushDebounceTimer = setTimeout(() => this._pushWithRetry(), ms);
  },

  /* ── Push con retry exponencial en caso de fallo ──────── */
  async _pushWithRetry() {
    clearTimeout(this._retryTimer);
    try {
      await this.push();
      /* Éxito — resetear contador de reintentos */
      this._retryCount = 0;
    } catch {
      /* push() ya maneja el error internamente; aquí manejamos el retry */
    }
    /* Si aún quedan pendientes después del push → programar reintento */
    const pending = SyncQueue.getAll().length;
    if (pending > 0 && Auth.isLoggedIn()) {
      const delay = this._retryDelays[Math.min(this._retryCount, this._retryDelays.length - 1)];
      this._retryCount++;
      this._retryTimer = setTimeout(() => this._pushWithRetry(), delay);
      Events.emit('sync:retry', { attempt: this._retryCount, delay, pending });
    }
  },

  /* ── Pull: descarga cambios del servidor ─────────────── */
  async pull({ silent = false } = {}) {
    if (!Auth.isLoggedIn()) return;
    /* Limpiar demos residuales del localStorage antes de cada pull */
    const hadDemos = State.routes.some(r=>r._isDemo) ||
      Object.values(State.stops).some(s=>s._isDemo);
    if (hadDemos) {
      State.routes = State.routes.filter(r => !r._isDemo);
      State.stops  = Object.fromEntries(Object.entries(State.stops).filter(([,s])=>!s._isDemo));
      DB.set(DB.KEYS.routes, State.routes);
      DB.set(DB.KEYS.stops,  State.stops);
    }
    const since = State.prefs._lastSyncTs || 0;
    try {
      const delta = await API.get(`/sync/pull?since=${since}`);
      if (!delta) return;
      _mergeDelta(delta);
      State.prefs._lastSyncTs = delta.serverTs || Date.now();
      DB.set(DB.KEYS.prefs, State.prefs);
      Events.emit('sync:pulled', { since });
      if (!silent && delta.hasChanges) {
        toast('Datos actualizados', 'info', 1500);
      }
    } catch { /* silencioso en pull */ }
  },

  /* ── Migración inicial: sube localStorage + pull completo ─ */
  async initialSync() {
    const localData = DB.exportAll();

    /* Filtrar datos de demo (_isDemo:true) antes de importar al servidor */
    const realRoutes = (localData.routes || []).filter(r => !r._isDemo);
    const realStops  = Object.fromEntries(
      Object.entries(localData.stops || {}).filter(([, s]) => !s._isDemo)
    );
    const hasRealData = realRoutes.length + Object.keys(realStops).length > 0;

    if (hasRealData) {
      try {
        await API.post('/sync/import', { ...localData, routes: realRoutes, stops: realStops });
      } catch (e) {
        console.warn('Import failed:', e.message);
        /* No es fatal — el pull traerá el estado del servidor */
      }
    }

    /* Pull completo (since=0) — reemplaza localStorage con datos del servidor */
    const full = await API.get('/sync/pull?since=0');
    if (!full) return;

    _mergeDelta(full, { fullReplace: true });
    State.prefs._lastSyncTs = full.serverTs || Date.now();
    DB.set(DB.KEYS.prefs, State.prefs);
    Events.emit('sync:initial', { routes: State.routes.length });
  },
};

/* ══════════════════════════════════════════════════════════
   UPLOADS — fotos directamente a R2 via presigned URL
   Reemplaza el guardado base64 en localStorage
   ══════════════════════════════════════════════════════════ */
const Uploads = {
  /* ── Sube un File y devuelve la URL pública permanente ─ */
  async uploadPhoto(file, visitId) {
    if (file.size > 8 * 1024 * 1024) {
      toast('Foto demasiado grande (máx 8 MB)', 'error');
      return null;
    }

    /* Comprimir antes de subir */
    const compressed = await _compressImage(file, 1200, 0.75);

    /* Pedir URL firmada al backend */
    const { uploadUrl, publicUrl } = await API.post('/uploads/presign', {
      filename:    file.name,
      contentType: compressed.type,
      visitId,
    });

    /* Subir directamente a R2 — sin pasar por el backend */
    await fetch(uploadUrl, {
      method:  'PUT',
      headers: { 'Content-Type': compressed.type },
      body:    compressed,
    });

    return publicUrl;
  },

  /* ── Si no hay sesión → guardar en base64 local (fallback) */
  async uploadOrFallback(file, visitId) {
    if (Auth.isLoggedIn() && navigator.onLine) {
      return this.uploadPhoto(file, visitId);
    }
    /* Modo offline/sin cuenta — base64 como hasta ahora */
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = e => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  },
};

/* ══════════════════════════════════════════════════════════
   HELPERS PRIVADOS
   ══════════════════════════════════════════════════════════ */

/* Aplica el delta del servidor sobre State + localStorage */
function _mergeDelta(delta, { fullReplace = false } = {}) {
  let changed = false;

  if (delta.routes) {
    if (fullReplace) {
      State.routes = delta.routes;
    } else {
      delta.routes.forEach(r => {
        const idx = State.routes.findIndex(x => x.id === r.id);
        if (r.deleted) {
          if (idx >= 0) { State.routes.splice(idx, 1); changed = true; }
        } else if (idx >= 0) {
          if ((r.updatedAt || 0) > (State.routes[idx].updatedAt || 0)) {
            State.routes[idx] = r; changed = true;
          }
        } else {
          State.routes.push(r); changed = true;
        }
      });
    }
    DB.set(DB.KEYS.routes, State.routes);
  }

  if (delta.stops) {
    if (fullReplace) {
      State.stops = delta.stops;
    } else {
      Object.entries(delta.stops).forEach(([id, s]) => {
        if (s.deleted) {
          delete State.stops[id]; changed = true;
        } else if (!(State.stops[id]) || (s.updatedAt || 0) > (State.stops[id].updatedAt || 0)) {
          State.stops[id] = s; changed = true;
        }
      });
    }
    DB.set(DB.KEYS.stops, State.stops);
  }

  if (delta.schedule) {
    /* Extraer _all (schedules de todos los reps para supervisor) antes de mergear */
    const allSchedules = delta.schedule._all || null;
    const ownSchedule  = Object.fromEntries(
      Object.entries(delta.schedule).filter(([k]) => k !== '_all')
    );
    if (fullReplace) {
      State.schedule = ownSchedule;
    } else {
      Object.assign(State.schedule, ownSchedule);
    }
    /* Guardar schedules de equipo para el calendario del supervisor */
    if (allSchedules) {
      if (fullReplace) {
        State.scheduleAll = allSchedules;
      } else {
        if (!State.scheduleAll) State.scheduleAll = {};
        Object.entries(allSchedules).forEach(([date, entries]) => {
          State.scheduleAll[date] = entries;
        });
      }
      DB.set('gr_schedule_all_v1', State.scheduleAll);
    }
    DB.set(DB.KEYS.schedule, State.schedule);
  }

  if (delta.forms)    { DB.setForms(delta.forms); }
  if (delta.kpi_defs) { DB.setKpis(delta.kpi_defs); }

  if (delta.sessions) {
    const all = DB.getJornadas();
    Object.entries(delta.sessions).forEach(([k, v]) => {
      if (!all[k] || (v.updatedAt || 0) > (all[k].updatedAt || 0)) {
        all[k] = v; changed = true;
      }
    });
    DB.set(DB.KEYS.jornadas, all);
  }

  if (delta.visits) {
    const all = DB.getVisits();
    Object.entries(delta.visits).forEach(([serverId, v]) => {
      /* Clave local: routeId_dateStr_stopId (compatibilidad con jornada.js)
         Si la visita del servidor trae sessionId+stopId construimos la clave local.
         Si no, usamos el id del servidor como fallback. */
      const localKey = (v.sessionId && v.stopId)
        ? `${v.sessionId}_${v.stopId}`
        : serverId;
      const existing = all[localKey];
      if (!existing || (v.updatedAt || 0) > (existing.updatedAt || 0)) {
        /* Fusionar fotos si ambas versiones tienen */
        if (existing?.photos?.length && v.photos?.length) {
          v.photos = [...new Set([...existing.photos, ...v.photos])];
        }
        all[localKey] = { ...v, _serverId: serverId };
        changed = true;
      }
    });
    DB.set(DB.KEYS.visits, all);
  }

  if (changed && !fullReplace) {
    /* Re-renderizar solo si el usuario NO está navegando activamente.
       Router._navigating se activa durante Router.go() y se limpia al terminar. */
    if (Router._current && Router._pages[Router._current] && !Router._navigating) {
      requestAnimationFrame(() => {
        if (!Router._navigating) {
          Router._render(Router._current, Router._params || {});
        }
      });
    }
  }
}

/* Aplica un registro individual ganado por el servidor (conflicto) */
function _applyServerRecord(collection, record) {
  if (collection === 'routes') {
    const idx = State.routes.findIndex(r => r.id === record.id);
    if (idx >= 0) State.routes[idx] = record;
    DB.set(DB.KEYS.routes, State.routes);
  } else if (collection === 'stops') {
    State.stops[record.id] = record;
    DB.set(DB.KEYS.stops, State.stops);
  }
}

/* Comprime imagen antes de subir */
async function _compressImage(file, maxDim = 1200, quality = 0.75) {
  return new Promise(resolve => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let { width, height } = img;
      if (width > maxDim || height > maxDim) {
        const ratio = Math.min(maxDim / width, maxDim / height);
        width  = Math.round(width  * ratio);
        height = Math.round(height * ratio);
      }
      const canvas = document.createElement('canvas');
      canvas.width  = width;
      canvas.height = height;
      canvas.getContext('2d').drawImage(img, 0, 0, width, height);
      canvas.toBlob(blob => resolve(blob || file), 'image/jpeg', quality);
    };
    img.onerror = () => resolve(file);
    img.src = url;
  });
}

/* Actualiza elementos de UI que dependen del estado de auth */
function _updateAuthUI() {
  const role = State.prefs._role || '';
  const plan = State.prefs._plan || 'free';
  /* Ocultar/mostrar menú de ajustes según rol */
  document.querySelectorAll('[data-min-role]').forEach(el => {
    const LEVELS = { rep: 1, supervisor: 2, admin: 3, owner: 4 };
    const required = LEVELS[el.dataset.minRole] || 1;
    const current  = LEVELS[role] || 0;
    el.style.display = current >= required ? '' : 'none';
  });
  /* Badge de plan en sidebar */
  const planBadge = document.getElementById('plan-badge');
  if (planBadge) {
    planBadge.textContent = plan;
    planBadge.style.display = Auth.isLoggedIn() ? '' : 'none';
  }
}

/* ══════════════════════════════════════════════════════════
   REESCRIBIR SyncQueue.flush() para usar API real
   Parchea el objeto existente de core.js
   ══════════════════════════════════════════════════════════ */
SyncQueue.flush = async function() {
  return Sync.push();
};

/* ══════════════════════════════════════════════════════════
   WIRING — conectar eventos de la app con sync automático
   ══════════════════════════════════════════════════════════ */

/* Tras cada persist → push debounced 300ms */
const _origPersist = State.persist.bind(State);
State.persist = function() {
  _origPersist();
  if (Auth.isLoggedIn()) Sync.pushDebounced(300);
};

/* Push inmediato para operaciones críticas — sin esperar debounce */
function syncNow() {
  if (!Auth.isLoggedIn()) return;
  clearTimeout(Sync._pushDebounceTimer);
  Sync._pushWithRetry();
}

/* Volver online → push + pull */
window.addEventListener('online', async () => {
  if (!Auth.isLoggedIn()) return;
  await Sync.push();
  await Sync.pull({ silent: true });
});

/* Volver a la pestaña → pull silencioso con cooldown de 10s */
let _lastVisibilityPull = 0;
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && Auth.isLoggedIn()) {
    const now = Date.now();
    if (now - _lastVisibilityPull > 10_000) {
      _lastVisibilityPull = now;
      Sync.pull({ silent: true });
    }
  }
});

/* Polling de seguridad cada 3 min */
setInterval(() => {
  if (Auth.isLoggedIn() && navigator.onLine) {
    Sync.pull({ silent: true });
  }
}, 3 * 60 * 1000);

/* Indicador de sync en topbar */
Events.on('sync:pushed',  ({ sent }) => {
  if (sent > 0) _updateSyncIndicator(0);
});
Events.on('syncqueue:changed', ({ pending }) => {
  _updateSyncIndicator(pending);
});
Events.on('sync:failed', ({ pending }) => {
  _updateSyncIndicator(pending);
});
Events.on('sync:retry', ({ attempt, delay, pending }) => {
  const secs = Math.round(delay / 1000);
  const label = secs >= 60 ? `${Math.round(secs/60)}min` : `${secs}s`;
  _updateSyncIndicator(pending, `Reintentando en ${label} (intento ${attempt})`);
});

function _updateSyncIndicator(pending, tooltip = null) {
  const el = document.getElementById('sync-indicator');
  if (!el) return;
  /* Solo mostrar si hay AT real (no solo RT) — evita badge fantasma al arrancar */
  const reallyLoggedIn = !!Tokens._at;
  const show = reallyLoggedIn && pending > 0;
  el.style.display = show ? 'flex' : 'none';
  if (show) {
    el.title = tooltip || `${pending} cambio${pending !== 1 ? 's' : ''} pendiente${pending !== 1 ? 's' : ''}`;
  }
}

/* ══════════════════════════════════════════════════════════
   RESTAURAR SESIÓN AL ARRANCAR
   Se inyecta al final del DOMContentLoaded de core.js
   ══════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  /* Pequeño delay para que core.js termine su init primero */
  setTimeout(async () => {
    /* Detectar enlace de reset de contraseña antes de cualquier otra cosa */
    if (typeof _checkResetToken === 'function') _checkResetToken();

    const restored = await Auth.restoreSession();
    /* Si no hay sesión → abrir modal de login automáticamente */
    if (!restored && typeof showLoginModal === 'function') {
      /* No abrir login si ya se abrió el modal de reset */
      if (!location.hash.startsWith('#reset-password/')) {
        showLoginModal('login');
      }
    }
  }, 100);
}, { once: true });


/* Actualizar label del botón cuenta en sidebar */
function _updateSidebarAccountLabel() {
  const el = document.getElementById('sidebar-account-label');
  if (!el) return;
  if (Auth.isLoggedIn()) {
    const email = State.prefs._email || State.prefs._userId?.slice(0,8) || 'Mi cuenta';
    el.textContent = email.length > 18 ? email.slice(0,16) + '…' : email;
  } else {
    el.textContent = 'Cuenta';
  }
}
Events.on('auth:login',    _updateSidebarAccountLabel);
Events.on('auth:restored', _updateSidebarAccountLabel);
Events.on('auth:logout',   _updateSidebarAccountLabel);

/* Mostrar/ocultar el item de nav God según pRole */
function _updateGodNav() {
  const el = document.getElementById('nav-god');
  if (!el) return;
  const pRole = State.prefs._pRole;
  el.style.display = (pRole === 'god' || pRole === 'platform_admin') ? '' : 'none';
}
Events.on('auth:login',    _updateGodNav);
Events.on('auth:restored', _updateGodNav);
Events.on('auth:logout',   _updateGodNav);

/* Al cerrar sesión (manual o por token expirado) → abrir modal de login */
Events.on('auth:logout', () => {
  setTimeout(() => {
    if (typeof showLoginModal === 'function' && !Auth.isLoggedIn()) {
      showLoginModal('login');
    }
  }, 300); /* pequeño delay para que el router termine de navegar */
});

/* ══════════════════════════════════════════════════════════
   NAV ADAPTATIVO POR ROL
   rep=0 · supervisor=1 · admin=2 · owner=3
   ══════════════════════════════════════════════════════════ */
const _ROLE_ORDER = { rep: 0, supervisor: 1, admin: 2, owner: 3 };

function _updateNavByRole() {
  const role  = State.prefs._role || 'rep';
  const level = _ROLE_ORDER[role] ?? 0;
  const loggedIn = Auth.isLoggedIn();

  /* ── Sidebar: ocultar items por data-role-min ── */
  document.querySelectorAll('[data-role-min]').forEach(el => {
    const min = _ROLE_ORDER[el.dataset.roleMin] ?? 0;
    el.style.display = (loggedIn && level >= min) ? '' : 'none';
  });

  /* ── Grupo de gestión — solo supervisor+ ── */
  const groupGestion = document.getElementById('nav-group-gestion');
  if (groupGestion) {
    groupGestion.style.display = (loggedIn && level >= 1) ? '' : 'none';
  }

  /* ── Labels duales: "Mis PDVs" vs "PDVs", "Mi actividad" vs "Informes" ── */
  document.querySelectorAll('.nav-label-rep').forEach(el => {
    el.style.display = level === 0 ? '' : 'none';
  });
  document.querySelectorAll('.nav-label-sup').forEach(el => {
    el.style.display = level >= 1 ? '' : 'none';
  });

  /* ── Sidebar footer: botón "Nueva Ruta" solo supervisor+ ── */
  const btnNewRoute = document.querySelector('.sidebar-footer .btn-primary');
  if (btnNewRoute) {
    btnNewRoute.style.display = (loggedIn && level >= 1) ? '' : 'none';
  }

  /* ── Header: botones Nueva Ruta y Nueva Parada solo supervisor+ ── */
  document.querySelectorAll('.btn-header-new-route').forEach(b => {
    b.style.display = (loggedIn && level >= 1) ? '' : 'none';
  });
  document.querySelectorAll('.btn-header-new-stop').forEach(b => {
    b.style.display = (loggedIn && level >= 1) ? '' : 'none';
  });

  /* ── Label del grupo principal según rol ── */
  const labelPrincipal = document.getElementById('nav-label-principal');
  if (labelPrincipal) {
    const labels = { rep: 'Mi trabajo', supervisor: 'Mi zona', admin: 'Administración', owner: 'Gestión' };
    labelPrincipal.textContent = labels[role] || 'Principal';
  }

  /* ── Bottom nav: Jornada solo para rep, label Cal/Equipo ── */
  const bnJornada = document.getElementById('bn-jornada');
  if (bnJornada) bnJornada.style.display = (loggedIn && level === 0) ? '' : 'none';

  const bnCalendar = document.getElementById('bn-calendar');
  if (bnCalendar) {
    bnCalendar.querySelectorAll('.bn-label-rep').forEach(el => {
      el.style.display = level === 0 ? '' : 'none';
    });
    bnCalendar.querySelectorAll('.bn-label-sup').forEach(el => {
      el.style.display = level >= 1 ? '' : 'none';
    });
  }

  /* ── Ajustes: ocultar secciones según rol ── */
  /* "Borrar todos los datos" solo owner */
  document.querySelectorAll('.settings-owner-only').forEach(el => {
    el.style.display = (loggedIn && level >= 3) ? '' : 'none';
  });
  /* Exportar/Importar solo supervisor+ */
  document.querySelectorAll('.settings-supervisor-only').forEach(el => {
    el.style.display = (loggedIn && level >= 1) ? '' : 'none';
  });
  /* Notificaciones de jornada solo para comercial */
  document.querySelectorAll('.settings-rep-only').forEach(el => {
    el.style.display = (loggedIn && level === 0) ? '' : 'none';
  });

  /* ── Redirigir si el usuario está en una página que no debería ver ── */
  if (loggedIn && level === 0) {
    const forbidden = ['routes', 'stats', 'form-editor'];
    if (forbidden.includes(Router._current)) {
      Router.go('dashboard');
    }
  }
  /* supervisor+ no debería estar en jornada directamente (solo lectura) */
  if (loggedIn && level >= 1 && Router._current === 'jornada') {
    /* No redirigir — pueden ver jornadas de sus reps */
  }
}

Events.on('auth:login',    _updateNavByRole);
Events.on('auth:restored', _updateNavByRole);
Events.on('auth:logout',   _updateNavByRole);

/* Pull inmediato al restaurar sesión — datos siempre frescos al abrir la app */
Events.on('auth:restored', () => {
  setTimeout(() => Sync.pull({ silent: true }), 500);
});

/* Precargar miembros del equipo para manager roles — evita dashboard en blanco */
Events.on('auth:restored', () => {
  const role = State.prefs._role || 'rep';
  if (['supervisor','admin','owner'].includes(role) && Auth.isLoggedIn()) {
    setTimeout(() => {
      API.get('/users').then(members => {
        if (members?.length) window._calAssignReps = members;
      }).catch(() => {});
    }, 800);
  }
});
