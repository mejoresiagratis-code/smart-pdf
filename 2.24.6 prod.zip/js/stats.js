/* ═══════════════════════════════════════════════════════════
   GESTOR DE RUTAS — stats.js v1.5
   Estadísticas · Gráficas CSS · Exportación CSV
   Depende de: State, Router, DB, toast, _localDate (core.js)
   ═══════════════════════════════════════════════════════════ */
'use strict';

Router.register('stats',(el)=>{
  if (({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0) < 1) { Router.go('dashboard'); return; }
  const role = State.prefs._role || 'supervisor';
  const statsTitle = role==='supervisor' ? 'Estadísticas de mi zona'
    : role==='admin' ? 'Estadísticas del equipo' : 'Estadísticas globales';

  /* Rep: usa localStorage propio. Supervisor+: carga de la API para ver a su equipo */
  if (({rep:0,supervisor:1,admin:2,owner:3}[role]??0) >= 1 && Auth.isLoggedIn()) {
    _loadStatsFromAPI(el, role, statsTitle);
    return;
  }

  const allVisits  = DB.getVisits();
  const kpiDefs    = DB.getKpis();
  const jornadas   = DB.getJornadas();
  const visits     = Object.entries(allVisits).map(([k,v])=>{
    const dStr    = k.slice(-17, -7);
    const after   = k.indexOf('_' + dStr + '_');
    const routeId = after >= 0 ? k.slice(0, after) : k.split('_')[0];
    const stopId  = after >= 0 ? k.slice(after + dStr.length + 2) : k.split('_')[2];
    return { routeId, dateStr: dStr, stopId, ...v };
  }).filter(v=>v.dateStr && /^\d{4}-\d{2}-\d{2}$/.test(v.dateStr)).sort((a,b)=>b.dateStr.localeCompare(a.dateStr));

  if(!visits.length){
    el.innerHTML=`
    <div class="page-header mb-4">
      <div><h1 class="page-h1">${statsTitle}</h1><p class="page-sub">Análisis de KPIs y visitas</p></div>
    </div>
    <div class="empty-state">
      <div class="empty-icon"><i class="fa-solid fa-chart-bar"></i></div>
      <div class="empty-title">Sin datos todavía</div>
      <div class="empty-sub">Realiza visitas con check-in para ver estadísticas</div>
      <button class="btn btn-primary mt-3" onclick="openTodayJornada()">
        <i class="fa-solid fa-play"></i> Iniciar jornada
      </button>
    </div>`;
    return;
  }

  /* ── Calcular semanas para el gráfico (últimas 8) ── */
  const weeks = _statsWeeks(visits, 8);

  /* ── KPI totales ── */
  const kpiTotals = {};
  const kpiByWeek = {};
  kpiDefs.forEach(k=>{ kpiTotals[k.id]=0; kpiByWeek[k.id]=weeks.map(()=>0); });
  visits.forEach(v=>{
    kpiDefs.forEach(k=>{
      const val = Number(v['kpi_'+k.id]||0);
      if(!val) return;
      kpiTotals[k.id] += val;
      const wi = weeks.findIndex(w=>v.dateStr>=w.from&&v.dateStr<=w.to);
      if(wi>=0) kpiByWeek[k.id][wi] += val;
    });
  });

  /* ── Visitas por semana ── */
  const visitsByWeek = weeks.map(w=>
    visits.filter(v=>v.dateStr>=w.from&&v.dateStr<=w.to).length
  );

  /* ── Jornadas stats ── */
  const jorList = Object.entries(jornadas)
    .filter(([,s])=>s.elapsed>0)
    .map(([,s])=>s);
  const totalKm   = jorList.reduce((a,s)=>a+(s.distance||0),0);
  const totalHrs  = jorList.reduce((a,s)=>a+(s.elapsed||0),0)/3600;
  const avgVisit  = visits.length && jorList.length ? (visits.length/jorList.length).toFixed(1) : '—';

  /* ── Stops más visitados ── */
  const visitsByStop = {};
  visits.forEach(v=>{
    visitsByStop[v.stopId]=(visitsByStop[v.stopId]||0)+1;
  });
  const topStops = Object.entries(visitsByStop)
    .sort((a,b)=>b[1]-a[1]).slice(0,5)
    .map(([id,n])=>({ stop:State.getStop(id), n }))
    .filter(x=>x.stop);

  el.innerHTML=`
  <div class="page-header mb-4">
    <div><h1 class="page-h1">Estadísticas</h1><p class="page-sub">${visits.length} visitas registradas</p></div>
    <button class="btn btn-primary btn-sm" onclick="exportCSV()">
      <i class="fa-solid fa-file-csv"></i> CSV
    </button>
  </div>

  <!-- Stats resumen -->
  <div class="grid-4 mb-4">
    <div class="stat-card accent-indigo">
      <i class="fa-solid fa-clipboard-check stat-card-icon"></i>
      <div class="stat-card-label">Visitas totales</div>
      <div class="stat-card-value">${visits.length}</div>
    </div>
    <div class="stat-card accent-blue">
      <i class="fa-solid fa-road stat-card-icon"></i>
      <div class="stat-card-label">Km recorridos</div>
      <div class="stat-card-value">${totalKm.toFixed(0)}</div>
    </div>
    <div class="stat-card accent-green">
      <i class="fa-solid fa-clock stat-card-icon"></i>
      <div class="stat-card-label">Horas en ruta</div>
      <div class="stat-card-value">${totalHrs.toFixed(0)}</div>
    </div>
    <div class="stat-card">
      <i class="fa-solid fa-map-pin stat-card-icon"></i>
      <div class="stat-card-label">Visitas / jornada</div>
      <div class="stat-card-value">${avgVisit}</div>
    </div>
  </div>

  <!-- KPI totales -->
  ${kpiDefs.length ? `
  <div class="card mb-4">
    <div class="card-header">
      <div class="card-title"><i class="fa-solid fa-chart-bar"></i> KPIs acumulados</div>
    </div>
    <div class="card-body">
      <div class="kpi-summary-grid">
        ${kpiDefs.map(k=>`
        <div class="kpi-summary-cell">
          <div class="kpi-summary-val">${kpiTotals[k.id]||0}${k.unit?`<span style="font-size:.7em;font-weight:400"> ${k.unit}</span>`:''}</div>
          <div class="kpi-summary-label">${k.label}</div>
        </div>`).join('')}
      </div>
    </div>
  </div>` : ''}

  <!-- Gráfico visitas por semana -->
  <div class="card mb-4">
    <div class="card-header">
      <div class="card-title"><i class="fa-solid fa-chart-line"></i> Visitas por semana</div>
    </div>
    <div class="card-body" style="padding-bottom:var(--sp-2)">
      <div class="stats-chart" id="chart-visits"></div>
      <div class="stats-chart-labels">
        ${weeks.map(w=>`<span>${_statsWeekLabel(w)}</span>`).join('')}
      </div>
    </div>
  </div>

  ${kpiDefs.length ? kpiDefs.map(k=>`
  <div class="card mb-4">
    <div class="card-header">
      <div class="card-title"><i class="fa-solid fa-chart-bar"></i> ${k.label} por semana${k.unit?' ('+k.unit+')':''}</div>
    </div>
    <div class="card-body" style="padding-bottom:var(--sp-2)">
      <div class="stats-chart" id="chart-kpi-${k.id}"></div>
      <div class="stats-chart-labels">
        ${weeks.map(w=>`<span>${_statsWeekLabel(w)}</span>`).join('')}
      </div>
    </div>
  </div>`).join('') : ''}

  <!-- Top paradas -->
  ${topStops.length ? `
  <div class="card mb-4">
    <div class="card-header">
      <div class="card-title"><i class="fa-solid fa-trophy"></i> Paradas más visitadas</div>
    </div>
    <div class="card-body">
      ${topStops.map((x,i)=>{
        const pct = Math.round(x.n/topStops[0].n*100);
        return `<div style="margin-bottom:var(--sp-3)">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <span style="font-size:var(--t-sm);font-weight:600;color:var(--tx-1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;min-width:0">${i+1}. ${x.stop.name}</span>
            <span style="font-size:var(--t-xs);color:var(--tx-3);flex-shrink:0;margin-left:var(--sp-2)">${x.n} visitas</span>
          </div>
          <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
        </div>`;
      }).join('')}
    </div>
  </div>` : ''}

  <!-- Historial reciente -->
  <div class="card">
    <div class="card-header">
      <div class="card-title"><i class="fa-solid fa-clock-rotate-left"></i> Visitas recientes</div>
      <button class="btn btn-ghost btn-sm" onclick="exportCSV()">
        <i class="fa-solid fa-download"></i> Exportar CSV
      </button>
    </div>
    <div>
      ${visits.slice(0,20).map(v=>{
        const stop  = State.getStop(v.stopId);
        const route = State.getRoute(v.routeId);
        const dur   = v.checkInTs&&v.checkOutTs ? Math.round((v.checkOutTs-v.checkInTs)/60000) : null;
        return `<div class="list-item" onclick="Router.go('stop-detail',{stopId:'${v.stopId}'})">
          <div style="width:38px;min-width:32px;text-align:center;flex-shrink:0">
            <div style="font-size:1rem;font-weight:800;color:var(--indigo);line-height:1">${new Date(v.dateStr+'T12:00').getDate()}</div>
            <div style="font-size:var(--t-xs);color:var(--tx-3);text-transform:uppercase">${new Date(v.dateStr+'T12:00').toLocaleDateString('es-ES',{month:'short'})}</div>
          </div>
          <div class="list-item-info">
            <div class="list-item-name">${stop?.name||v.stopId}</div>
            <div class="list-item-sub">${route?.name||''} ${dur?'· '+dur+' min':''} ${v.estado?'· '+v.estado:''}</div>
          </div>
          <i class="fa-solid fa-chevron-right" style="color:var(--tx-3);font-size:var(--t-xs);flex-shrink:0"></i>
        </div>`;
      }).join('')}
    </div>
  </div>`;

  /* ── Renderizar gráficos ── */
  requestAnimationFrame(()=>{
    _renderBarChart('chart-visits', visitsByWeek, 'var(--indigo)');
    kpiDefs.forEach(k=>{
      _renderBarChart('chart-kpi-'+k.id, kpiByWeek[k.id], 'var(--green)');
    });
  });
});

/* ── Helpers de estadísticas ── */
function _statsWeeks(visits, n){
  const weeks = [];
  const today = new Date(); today.setHours(0,0,0,0);
  // Semana actual empieza el lunes
  const dow   = today.getDay()===0?6:today.getDay()-1;
  const monThis = new Date(today); monThis.setDate(today.getDate()-dow);
  for(let i=n-1;i>=0;i--){
    const mon = new Date(monThis); mon.setDate(monThis.getDate()-i*7);
    const sun = new Date(mon);     sun.setDate(mon.getDate()+6);
    weeks.push({
      from: _localDate(mon),
      to:   _localDate(sun),
      mon,
    });
  }
  return weeks;
}
function _statsWeekLabel(w){
  return w.mon.toLocaleDateString('es-ES',{day:'numeric',month:'short'}).replace(' ','<br>');
}
function _renderBarChart(id, data, color){
  const el = document.getElementById(id);
  if(!el) return;
  const max = Math.max(...data, 1);
  el.innerHTML = data.map(v=>{
    const pct = Math.round(v/max*100);
    return `<div class="stats-bar-wrap">
      <div class="stats-bar-val">${v||''}</div>
      <div class="stats-bar" style="height:${Math.max(pct,2)}%;background:${color}"></div>
    </div>`;
  }).join('');
}

/* ── Exportación CSV ── */
function exportCSV(){
  const allVisits = DB.getVisits();
  const kpiDefs   = DB.getKpis();
  const formDefs  = DB.getForms();

  /* Campos de formulario dinámicos — deduplicados por id */
  const _seenFf = new Set();
  const formFields = formDefs.flatMap(f => f.fields || []).filter(f => {
    if (_seenFf.has(f.id)) return false;
    _seenFf.add(f.id); return true;
  });

  const visits = Object.entries(allVisits).map(([k,v])=>{
    const dStr  = k.slice(-17, -7);
    const after = k.indexOf('_' + dStr + '_');
    const routeId = after >= 0 ? k.slice(0, after) : k.split('_')[0];
    const stopId  = after >= 0 ? k.slice(after + dStr.length + 2) : k.split('_')[2];
    return { routeId, dateStr: dStr, stopId, ...v };
  }).filter(v=>v.dateStr && /^\d{4}-\d{2}-\d{2}$/.test(v.dateStr)).sort((a,b)=>b.dateStr.localeCompare(a.dateStr));

  if(!visits.length){ toast('Sin visitas para exportar','error'); return; }

  /* Cabecera: columnas fijas + KPIs + campos de formulario */
  const kpiCols  = kpiDefs.map(k=>`${k.label}${k.unit?' ('+k.unit+')':''}`);
  const formCols = formFields.map(f => f.label || f.id);
  const headers = ['Fecha','Ruta','Parada','ID Parada','Dirección','Ciudad','CP','Contacto','Teléfono','Móvil','Email','Estado','Duración (min)',...kpiCols,...formCols,'Notas','Fotos','Tags'];

  /* Filas */
  const rows = visits.map(v=>{
    const stop  = State.getStop(v.stopId);
    const route = State.getRoute(v.routeId);
    const dur   = v.checkInTs&&v.checkOutTs ? Math.round((v.checkOutTs-v.checkInTs)/60000) : '';
    const kpiVals  = kpiDefs.map(k=>v['kpi_'+k.id]??'');
    const formVals = formFields.map(f => {
      const val = v[f.id];
      if (val === null || val === undefined) return '';
      if (f.type === 'checkbox') return val ? 'Sí' : 'No';
      return String(val).replace(/\n/g, ' ');
    });
    return [
      v.dateStr,
      route?.name||v.routeId,
      stop?.name||v.stopId,
      v.stopId,
      stop?.addr||'',
      stop?.town||'',
      stop?.zip||'',
      stop?.contact||'',
      stop?.phone||'',
      stop?.mobile||'',
      stop?.email||'',
      v.estado||'',
      dur,
      ...kpiVals,
      ...formVals,
      (v.notas||'').replace(/\n/g,' '),
      (v.photos||[]).length,
      (stop?.tags||[]).join(', '),
    ];
  });

  const csv = [headers,...rows]
    .map(r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(','))
    .join('\n');

  const bom  = '\uFEFF'; // BOM para Excel
  const blob = new Blob([bom+csv],{type:'text/csv;charset=utf-8'});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `visitas-${_localDate(new Date())}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  toast(`${visits.length} visitas exportadas ✓`,'success',3000);
}


/* ── Stats del equipo vía API (supervisor/admin/owner) ───── */
async function _loadStatsFromAPI(el, role, statsTitle) {
  el.innerHTML = `
  <div class="page-header mb-4">
    <div><h1 class="page-h1">${statsTitle}</h1><p class="page-sub">Cargando datos del equipo…</p></div>
  </div>
  <div class="empty-state"><i class="fa-solid fa-spinner fa-spin" style="font-size:1.5rem"></i></div>`;

  try {
    const [dataWeek, dataMonth] = await Promise.all([
      API.get('/stats/dashboard?period=week'),
      API.get('/stats/dashboard?period=month'),
    ]);
    if (!dataWeek) throw new Error('Sin datos');

    const kpiDefs = DB.getKpis();
    const agg     = dataMonth?.aggregated || dataMonth?.kpis || {};
    const aggW    = dataWeek?.aggregated  || dataWeek?.kpis  || {};

    /* Construir lista plana de reps para stats */
    let reps = [];
    if (role === 'supervisor') {
      reps = dataMonth?.team || [];
    } else if (role === 'admin') {
      reps = (dataMonth?.supervisors || []).flatMap(s => s.team || []);
    } else {
      reps = (dataMonth?.members || []).filter(m => m.role === 'rep');
    }

    const totalVisits  = agg.total_visits  ?? 0;
    const totalSess    = agg.total_sessions ?? 0;
    const doneSess     = agg.sessions_done  ?? 0;
    const totalKm      = agg.distance_km    ?? 0;
    const gaps         = (dataMonth?.coverage_gaps || []).length;
    const visitsWeek   = aggW.total_visits  ?? 0;

    /* Top paradas: desde coverage_gaps inverso (las más cubiertas) */
    /* Para ranking real necesitaríamos endpoint dedicado; usamos reps data */
    const topReps = [...reps].sort((a,b) => b.visits - a.visits).slice(0,5);

    el.innerHTML = `
    <div class="page-header mb-4">
      <div><h1 class="page-h1">${statsTitle}</h1>
        <p class="page-sub">${totalVisits} visitas este mes · ${reps.length} comercial${reps.length!==1?'es':''}</p>
      </div>
      <button class="btn btn-primary btn-sm" onclick="exportTeamCSV()">
        <i class="fa-solid fa-file-csv"></i> CSV
      </button>
    </div>

    <div class="grid-4 mb-4">
      <div class="stat-card accent-indigo">
        <div class="stat-card-label">Visitas (mes)</div>
        <div class="stat-card-value">${totalVisits}</div>
      </div>
      <div class="stat-card accent-blue">
        <div class="stat-card-label">Visitas (semana)</div>
        <div class="stat-card-value">${visitsWeek}</div>
      </div>
      <div class="stat-card accent-green">
        <div class="stat-card-label">Jornadas completas</div>
        <div class="stat-card-value">${doneSess}/${totalSess}</div>
      </div>
      <div class="stat-card accent-amber">
        <div class="stat-card-label">PDVs sin cubrir</div>
        <div class="stat-card-value">${gaps}</div>
      </div>
    </div>

    <!-- Ranking comerciales -->
    ${topReps.length ? `
    <div class="card mb-4">
      <div class="card-header">
        <div class="card-title"><i class="fa-solid fa-ranking-star"></i> Ranking comerciales (mes)</div>
      </div>
      <div class="card-body">
        ${topReps.map((r,i) => {
          const pct = topReps[0].visits > 0 ? Math.round(r.visits/topReps[0].visits*100) : 0;
          const barColor = pct >= 80 ? 'var(--green)' : pct >= 50 ? 'var(--indigo)' : 'var(--amber)';
          const activeLabel = r.active_now ? '<span class="badge badge-green" style="font-size:10px">Activo</span>' : '';
          return '<div style="margin-bottom:var(--sp-3)">' +
            '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">' +
              '<span style="font-size:var(--t-sm);font-weight:600;color:var(--tx-1)">' +
                (i+1) + '. ' + esc(r.name||r.email) + ' ' + activeLabel +
              '</span>' +
              '<span style="font-size:var(--t-xs);color:var(--tx-3);flex-shrink:0;margin-left:8px">' +
                r.visits + ' vis · ' + r.sessions_done + '/' + r.sessions + ' jorn' +
              '</span>' +
            '</div>' +
            '<div style="height:6px;background:var(--color-background-secondary);border-radius:3px;overflow:hidden">' +
              '<div style="width:' + pct + '%;height:100%;background:' + barColor + ';border-radius:3px"></div>' +
            '</div>' +
          '</div>';
        }).join('')}
      </div>
    </div>` : ''}

    <!-- PDVs sin cobertura -->
    ${gaps > 0 ? `
    <div class="card mb-4">
      <div class="card-header">
        <div class="card-title"><i class="fa-solid fa-triangle-exclamation" style="color:var(--amber)"></i> PDVs sin visitar (30 días)</div>
      </div>
      <div>
        ${(dataMonth.coverage_gaps||[]).slice(0,10).map(s =>
          '<div class="list-item">' +
            '<div class="list-item-icon" style="background:var(--amber-bg);color:var(--amber)"><i class="fa-solid fa-store-slash"></i></div>' +
            '<div class="list-item-info">' +
              '<div class="list-item-name">' + esc(s.name) + '</div>' +
              '<div class="list-item-sub">' + esc(s.town||'') + (s.addr?' · '+esc(s.addr):'') + '</div>' +
            '</div>' +
          '</div>'
        ).join('')}
        ${gaps > 10 ? '<div class="card-body" style="font-size:var(--t-xs);color:var(--tx-3)">Y ' + (gaps-10) + ' más…</div>' : ''}
      </div>
    </div>` : ''}`;

  } catch(e) {
    console.error('[stats API]', e);
    el.innerHTML = `
    <div class="page-header mb-4">
      <div><h1 class="page-h1">${statsTitle}</h1></div>
    </div>
    <div class="empty-state">
      <div class="empty-icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
      <div class="empty-title">Error al cargar estadísticas</div>
      <div class="empty-sub">Comprueba la conexión</div>
      <button class="btn btn-primary mt-3" onclick="Router.go('stats')">
        <i class="fa-solid fa-rotate"></i> Reintentar
      </button>
    </div>`;
  }
}

/* ── Exportar CSV del equipo — visitas individuales con form_data ── */
async function exportTeamCSV() {
  try {
    toast('Descargando visitas del equipo…', 'info', 3000);

    /* Calcular rango del mes actual */
    const now   = new Date();
    const from  = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-01`;
    const to    = _localDate(now);

    /* Traer visitas del equipo completo */
    const visits = await API.get(`/visits?team=1&from=${from}&to=${to}`);
    if (!visits?.length) { toast('Sin visitas del equipo este mes', 'error'); return; }

    /* Traer definiciones de formularios y KPIs */
    const formDefs = DB.getForms();
    const kpiDefs  = DB.getKpis();

    /* Campos dinámicos deduplicados */
    const _seen = new Set();
    const formFields = formDefs.flatMap(f => f.fields || []).filter(f => {
      if (_seen.has(f.id)) return false;
      _seen.add(f.id); return true;
    });

    /* Cabecera */
    const kpiCols  = kpiDefs.map(k => `${k.label}${k.unit?' ('+k.unit+')':''}`);
    const formCols = formFields.map(f => f.label || f.id);
    const headers  = [
      'Fecha','Comercial','Parada','ID Parada','Dirección','Ciudad','CP',
      'Estado','Duración (min)',
      ...kpiCols, ...formCols,
      'Notas','Fotos'
    ];

    /* Construir mapa userId → nombre desde el árbol local */
    const members = await API.get('/users').catch(() => []);
    const nameMap = {};
    (members || []).forEach(m => { nameMap[m.id] = m.name || m.email; });

    /* Filas */
    const rows = visits.map(v => {
      const stop   = State.getStop(v.stopId);
      const dateStr = v.checkInAt ? v.checkInAt.slice(0, 10) : '';
      const dur    = (v.checkInAt && v.checkOutAt)
        ? Math.round((new Date(v.checkOutAt) - new Date(v.checkInAt)) / 60000) : '';
      /* kpi_data almacena los valores con prefijo 'kpi_'+id */
      const kpiVals  = kpiDefs.map(k => v.kpiData?.['kpi_'+k.id] ?? v.kpiData?.[k.id] ?? '');
      const formVals = formFields.map(f => {
        const val = v.formData?.[f.id];
        if (val === null || val === undefined) return '';
        if (f.type === 'checkbox') return val ? 'Sí' : 'No';
        return String(val).replace(/\n/g, ' ');
      });
      return [
        dateStr,
        nameMap[v.userId] || v.userId || '',
        stop?.name || v.stopId || '',
        v.stopId || '',
        stop?.addr || '',
        stop?.town || '',
        stop?.zip  || '',
        v.estado   || '',
        dur,
        ...kpiVals,
        ...formVals,
        (v.notas || '').replace(/\n/g, ' '),
        (v.photoUrls || []).length,
      ];
    });

    const csv  = [headers, ...rows]
      .map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(','))
      .join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url;
    a.download = `visitas-equipo-${from.slice(0,7)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast(`${visits.length} visitas exportadas ✓`, 'success', 3000);
  } catch(e) {
    console.error('[exportTeamCSV]', e);
    toast('Error al exportar visitas del equipo', 'error');
  }
}