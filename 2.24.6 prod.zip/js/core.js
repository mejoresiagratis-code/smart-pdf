/* ═══════════════════════════════════════════════════════════
   GESTOR DE RUTAS — Core v1.2
   DB · State · Router · Hash · Overlay · Toast · Utils
   ═══════════════════════════════════════════════════════════ */
'use strict';

/* ══════════════════════════════════════════════════════════
   DB — Capa unificada de persistencia
   ══════════════════════════════════════════════════════════ */
const DB = {
  KEYS: {
    routes:'gr_routes_v2', stops:'gr_stops_v2',
    schedule:'gr_schedule_v2', prefs:'gr_prefs_v2',
    jornadas:'gr_jornada_v1', visits:'gr_visits_v1',
    forms:'gr_forms_v1', kpis:'gr_kpis_v1',
    syncqueue:'gr_syncqueue_v1',
  },
  get(key, fallback=null){
    try{const r=localStorage.getItem(key);return r?JSON.parse(r):fallback;}catch{return fallback;}
  },
  set(key,value){
    try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}
  },
  del(key){
    try{localStorage.removeItem(key);return true;}catch{return false;}
  },
  exportAll(){
    const out={exportedAt:new Date().toISOString(),version:'1.2'};
    Object.entries(this.KEYS).forEach(([name,key])=>{
      const v=this.get(key); if(v!==null) out[name]=v;
    });
    return out;
  },
  importAll(data){
    const map=this.KEYS; let count=0;
    Object.entries(data).forEach(([name,value])=>{
      if(map[name]){this.set(map[name],value);count++;}
    });
    return count;
  },

  /* ── Accesores operacionales — punto único de acceso a datos de jornada ── */

  getJornadas()    { return this.get(this.KEYS.jornadas, {}); },
  setJornadas(d) {
    const res = this.set(this.KEYS.jornadas, d);
    const cutoff = Date.now() - 5000;
    Object.entries(d).forEach(([key, val]) => {
      if (val && val.updatedAt && val.updatedAt >= cutoff) {
        /* key = routeId_dateStr — el backend espera routeId y dateStr separados */
        const parts = key.split('_');
        const dateStr = parts[parts.length - 1];
        const routeId = parts.slice(0, -1).join('_');
        SyncQueue.push('upsert', 'sessions', key, {
          ...val,
          routeId,
          dateStr,
        });
      }
    });
    return res;
  },

  getVisits()      { return this.get(this.KEYS.visits, {}); },
  setVisits(d) {
    const res = this.set(this.KEYS.visits, d);
    /* Encolar visitas modificadas en los últimos 5s para sync */
    const cutoff = Date.now() - 5000;
    Object.entries(d).forEach(([key, v]) => {
      if (v && v.updatedAt && v.updatedAt >= cutoff) {
        SyncQueue.push('upsert', 'visits', key, v);
      }
    });
    return res;
  },

  getForms()       { return this.get(this.KEYS.forms, []); },
  setForms(d) {
    const res = this.set(this.KEYS.forms, d);
    SyncQueue.push('upsert', 'forms', 'all', d);
    return res;
  },

  getKpis()        { return this.get(this.KEYS.kpis, []); },
  setKpis(d) {
    const res = this.set(this.KEYS.kpis, d);
    SyncQueue.push('upsert', 'kpis', 'all', d);
    return res;
  },
};

/* ══════════════════════════════════════════════════════════
   STATE — Datos maestros
   ══════════════════════════════════════════════════════════ */
const State = {
  routes:   DB.get(DB.KEYS.routes,   []),
  stops:    DB.get(DB.KEYS.stops,    {}),
  schedule:    DB.get(DB.KEYS.schedule,     {}),
  scheduleAll: DB.get('gr_schedule_all_v1', {}),
  prefs:    DB.get(DB.KEYS.prefs,    {}),

  persist(){
    DB.set(DB.KEYS.routes,   this.routes);
    DB.set(DB.KEYS.stops,    this.stops);
    DB.set(DB.KEYS.schedule, this.schedule);
    DB.set(DB.KEYS.prefs,    this.prefs);
    /* Encolar rutas/paradas modificadas recientemente — nunca datos demo */
    const cutoff = Date.now() - 5000;
    this.routes.forEach(r => {
      if (r._isDemo) return;
      if (r.updatedAt && r.updatedAt >= cutoff) SyncQueue.push('upsert','routes',r.id,r);
    });
    Object.values(this.stops).forEach(s => {
      if (s._isDemo) return;
      if (s.updatedAt && s.updatedAt >= cutoff) SyncQueue.push('upsert','stops',s.id,s);
    });
    updateTopStats();
  },

  seedDemo(){
    if(this.routes.length) return;
    const list=[
      {id:'C001',name:'Cliente Martínez',    addr:'C/ Gran Vía, 14',          town:'Madrid',zip:'28013',lat:40.4200,lng:-3.7050,horario:'L-V 9:00-14:00 / 16:00-20:00',notes:'',_isDemo:true},
      {id:'C002',name:'Distribuciones López',addr:'Av. de la Constitución, 3',town:'Madrid',zip:'28008',lat:40.4180,lng:-3.7100,horario:'L-V 8:30-14:30',notes:'',_isDemo:true},
      {id:'C003',name:'Grupo Hernández',     addr:'C/ Alcalá, 55',            town:'Madrid',zip:'28014',lat:40.4215,lng:-3.6940,horario:'L-S 10:00-21:00',notes:'',_isDemo:true},
      {id:'C004',name:'Comercial Ruiz',      addr:'Paseo del Prado, 28',      town:'Madrid',zip:'28014',lat:40.4140,lng:-3.6920,horario:'L-V 9:00-18:00',notes:'',_isDemo:true},
      {id:'C005',name:'Almacenes García',    addr:'C/ Fuencarral, 88',        town:'Madrid',zip:'28004',lat:40.4260,lng:-3.7020,horario:'L-S 9:30-21:00',notes:'',_isDemo:true},
      {id:'C006',name:'Punto Norte',         addr:'Av. Bravo Murillo, 40',    town:'Madrid',zip:'28020',lat:40.4420,lng:-3.7020,horario:'L-V 10:00-14:00',notes:'',_isDemo:true},
      {id:'C007',name:'Sur Distribución',    addr:'C/ Atocha, 20',            town:'Madrid',zip:'28012',lat:40.4110,lng:-3.7000,horario:'L-D 8:00-23:00',notes:'',_isDemo:true},
      {id:'C008',name:'Comercios Reunidos',  addr:'C/ Serrano, 60',           town:'Madrid',zip:'28001',lat:40.4260,lng:-3.6870,horario:'L-S 10:00-21:00',notes:'',_isDemo:true},
      {id:'C009',name:'La Casa del Cliente', addr:'C/ Princesa, 10',          town:'Madrid',zip:'28008',lat:null,   lng:null,   horario:'L-V 9:00-14:00',notes:'Sin coords — pendiente geocodificar',_isDemo:true},
    ];
    list.forEach(s=>{this.stops[s.id]=s;});
    this.routes=[
      {id:'R1',name:'ZONA CENTRO',stops:['C001','C003','C004','C009'],createdAt:Date.now()-86400000*5,_isDemo:true},
      {id:'R2',name:'ZONA NORTE', stops:['C006','C008'],              createdAt:Date.now()-86400000*2,_isDemo:true},
      {id:'R3',name:'ZONA SUR',   stops:['C002','C005','C007'],       createdAt:Date.now()-86400000,  _isDemo:true},
    ];
    const today=new Date();
    [-2,-1,0,1,3,5].forEach((d,i)=>{
      const dt=new Date(today); dt.setDate(dt.getDate()+d);
      this.schedule[_localDate(dt)]=this.routes[i%3].id;
    });
    this.persist();
  },

  getRoute(id){return this.routes.find(r=>r.id===id);},
  getStop(id){return this.stops[id];},
  allStops(){return Object.values(this.stops);},

  addRoute(name){
    const id=`R${Date.now()}`;
    const now=Date.now();
    this.routes.push({id,name:name.toUpperCase().trim(),stops:[],createdAt:now,updatedAt:now,userId:this.prefs._userId||null});
    this.persist(); return id;
  },
  updateRoute(id,data){const r=this.getRoute(id);if(!r)return;Object.assign(r,data,{updatedAt:Date.now()});this.persist();},
  deleteRoute(id){
    SyncQueue.push('delete','routes',id,null);
    this.routes=this.routes.filter(r=>r.id!==id);this.persist();
  },

  upsertStop(data){
    const oldId=data._oldId||data.id;
    if(oldId&&oldId!==data.id){
      delete this.stops[oldId];
      this.routes.forEach(r=>{const i=r.stops.indexOf(oldId);if(i!==-1)r.stops[i]=data.id;});
    }
    this.stops[data.id]={...data,updatedAt:Date.now(),userId:this.prefs._userId||null};
    delete this.stops[data.id]._oldId;
    this.persist();
  },
  deleteStop(id){
    /* Marcar como eliminado para sync (soft-delete) antes de borrar */
    SyncQueue.push('delete','stops',id,null);
    delete this.stops[id];
    this.routes.forEach(r=>{r.stops=r.stops.filter(s=>s!==id);});
    this.persist();
  },

  addStopToRoute(routeId,stopId){
    const r=this.getRoute(routeId);if(!r||r.stops.includes(stopId))return;
    r.stops.push(stopId);this.persist();
  },
  removeStopFromRoute(routeId,stopId){
    const r=this.getRoute(routeId);if(!r)return;
    r.stops=r.stops.filter(s=>s!==stopId);this.persist();
  },
  moveStop(routeId,from,to){
    const r=this.getRoute(routeId);if(!r)return;
    const[item]=r.stops.splice(from,1);r.stops.splice(to,0,item);this.persist();
  },

  routeStats(id){
    const r=this.getRoute(id);if(!r)return{total:0,geo:0,pct:0};
    const total=r.stops.length;
    const geo=r.stops.filter(s=>this.stops[s]?.lat).length;
    return{total,geo,pct:total?Math.round(geo/total*100):0};
  },
  globalStats(){
    const stops=Object.keys(this.stops).length;
    const routes=this.routes.length;
    const noGeo=Object.values(this.stops).filter(s=>!s.lat).length;
    const scheduled=Object.keys(this.schedule).length;
    return{stops,routes,noGeo,withGeo:stops-noGeo,scheduled};
  },
};

/* ══════════════════════════════════════════════════════════
   ROUTER — Hash routing SPA
   ══════════════════════════════════════════════════════════ */
const Router={
  _pages:{},_current:null,_params:{},

  register(name,fn){this._pages[name]=fn;},

  go(name,params={},{replace=false}={}){
    if(!this._pages[name]){console.warn('Router: unknown page',name);return;}
    this._navigating=true;
    this._current=name; this._params=params;
    const hash=_buildHash(name,params);
    if(replace) history.replaceState({name,params},'',hash);
    else        history.pushState({name,params},'',hash);
    this._render(name,params);
    /* Limpiar flag tras dos frames para que el pull no interrumpa el render */
    requestAnimationFrame(()=>requestAnimationFrame(()=>{this._navigating=false;}));
  },

  _render(name,params){
    this._current=name; this._params=params;
    document.querySelectorAll('[data-page]').forEach(el=>{
      el.classList.toggle('active',el.dataset.page===name);
    });
    // Sync bottom nav jornada (no tiene data-page, usa onclick)
    const bnJornada=document.getElementById('bn-jornada');
    if(bnJornada) bnJornada.classList.toggle('active',name==='jornada');
    // Ocultar barra de jornada si no estamos en la página de jornada
    const jornadaBar=document.getElementById('jornada-bar');
    if(jornadaBar && name!=='jornada') jornadaBar.classList.remove('visible');
    const TITLES={
      dashboard:'Inicio',routes:'Mis Rutas',stops:'Paradas',map:'Mapa',
      calendar:'Calendario',reports:'Informes',settings:'Ajustes',
      jornada:'Jornada','form-editor':'Formularios & KPIs',changelog:'Novedades','stop-detail':'Ficha de parada',stats:'Estadísticas',
    };
    const t=document.getElementById('topbar-title');
    if(t) t.textContent=TITLES[name]||name;
    const el=document.getElementById('page-content');
    if(!el)return;
    // Scroll to top en el contenedor de la página
    const pageBody=document.getElementById('page-body');
    if(pageBody) pageBody.scrollTop=0;
    window.scrollTo(0,0);
    el.style.opacity='0';el.style.transform='translateY(6px)';el.style.transition='none';
    requestAnimationFrame(()=>{
      this._pages[name](el,params);
      requestAnimationFrame(()=>{
        el.style.transition='opacity .18s ease,transform .18s ease';
        el.style.opacity='1';el.style.transform='none';
      });
    });
    if(window.innerWidth<900) closeSidebar();
  },

  back(){history.back();},
};

function _buildHash(name,params={}){
  let h='#'+name;
  if(params.routeId) h+='/'+params.routeId;
  if(params.dateStr) h+='/'+params.dateStr;
  return h;
}
function _parseHash(hash){
  const parts=(hash||'#dashboard').replace('#','').split('/');
  const name=parts[0]||'dashboard';
  const params={};
  if(parts[1]) params.routeId=parts[1];
  if(parts[2]) params.dateStr=parts[2];
  return{name,params};
}
window.addEventListener('popstate',e=>{
  const{name,params}=e.state||_parseHash(location.hash);
  if(Router._pages[name]) Router._render(name,params);
});

/* ══════════════════════════════════════════════════════════
   OVERLAY MANAGER
   ══════════════════════════════════════════════════════════ */
const Overlay={
  _stack:[],
  push(el){
    this._stack.push(el);
    document.body.appendChild(el);
    document.body.style.overflow='hidden';
    el.addEventListener('click',e=>{if(e.target===el)this.pop();});
    // Reset scroll de cualquier elemento scrollable dentro
    requestAnimationFrame(()=>{
      el.querySelectorAll('[style*="overflow-y"],[class*="body"],[class*="scroll"]')
        .forEach(s=>{ s.scrollTop=0; });
    });
  },
  pop(){
    const el=this._stack.pop();
    el?.remove();
    if(!this._stack.length) document.body.style.overflow='';
    return el;
  },
  popAll(){while(this._stack.length)this.pop();},
  top(){return this._stack[this._stack.length-1]||null;},
  count(){return this._stack.length;},
};
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&Overlay.count()) Overlay.pop();
});

/* ══════════════════════════════════════════════════════════
   SIDEBAR MOBILE
   ══════════════════════════════════════════════════════════ */
function openSidebar(){
  document.querySelector('.sidebar')?.classList.add('open');
  document.querySelector('.sidebar-overlay')?.classList.add('open');
  document.body.style.overflow='hidden';
}
function closeSidebar(){
  document.querySelector('.sidebar')?.classList.remove('open');
  document.querySelector('.sidebar-overlay')?.classList.remove('open');
  if(!Overlay.count()) document.body.style.overflow='';
}

/* ══════════════════════════════════════════════════════════
   TOAST
   ══════════════════════════════════════════════════════════ */
function toast(msg,type='info',ms=3000){
  const s=document.getElementById('toast-stack');if(!s)return;
  const el=document.createElement('div');
  el.className=`toast ${type}`;
  const icons={success:'✓',error:'✕',info:'ℹ',warning:'⚠'};
  el.innerHTML=`<span style="opacity:.7">${icons[type]||'·'}</span><span>${msg}</span>`;
  s.appendChild(el);
  setTimeout(()=>{el.classList.add('out');setTimeout(()=>el.remove(),250);},ms);
}

/* ══════════════════════════════════════════════════════════
   MODAL LEGACY (HTML estáticos en index.html)
   ══════════════════════════════════════════════════════════ */
function openModal(id){
  const m=document.getElementById(id);
  if(!m) return;
  m.classList.add('open');
  document.body.style.overflow='hidden';
  // Reset scroll de modal-body y listas internas
  m.querySelectorAll('.modal-body,[style*="overflow-y"]').forEach(el=>{ el.scrollTop=0; });
}
function closeModal(id){
  document.getElementById(id)?.classList.remove('open');
  if(!Overlay.count()) document.body.style.overflow='';
}

/* ══════════════════════════════════════════════════════════
   CONFIRM
   ══════════════════════════════════════════════════════════ */
let _cfn=null;
function confirm_(msg,cb,title='¿Confirmar?'){
  document.getElementById('confirm-title').textContent=title;
  document.getElementById('confirm-msg').textContent=msg;
  _cfn=cb; openModal('modal-confirm');
}
function _doConfirm(){if(_cfn){_cfn();}_cfn=null;closeModal('modal-confirm');}

/* ══════════════════════════════════════════════════════════
   UTILS
   ══════════════════════════════════════════════════════════ */
function uid(){return Math.random().toString(36).slice(2,9).toUpperCase();}
function debounce(fn,ms=320){let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms);};}
function fmtDate(s){
  if(!s)return'—';
  return new Date(s+'T12:00').toLocaleDateString('es-ES',{day:'2-digit',month:'short',year:'numeric'});
}
function _localDate(d){
  return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
async function geocodeAddr(q){
  if(q.length<4)return[];
  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q)}&limit=5&countrycodes=es`);
    return await r.json();
  }catch{return[];}
}
function updateTopStats(){
  const s=State.globalStats();
  const el=document.getElementById('header-stats');
  if(el) el.textContent=`${s.routes} rutas · ${s.stops} paradas`;
}
function openTodayJornada(){
  const today=_localDate(new Date());
  const routeId=State.schedule[today];
  if(!routeId){
    toast('No hay ruta asignada para hoy — ve al calendario para planificar','error',3500);
    Router.go('calendar');
    return;
  }
  Router.go('jornada',{routeId,dateStr:today});
}



/* ══════════════════════════════════════════════════════════
   SYNCQUEUE — Cola offline de cambios pendientes
   Estructura: [{id, op, collection, key, data, ts, userId}]
   op: 'upsert' | 'delete'
   En v2.0: SyncQueue.flush() enviará al servidor y vaciará la cola
   ══════════════════════════════════════════════════════════ */
const SyncQueue = {
  _KEY: 'gr_syncqueue_v1',

  _load() {
    try { return JSON.parse(localStorage.getItem(this._KEY) || '[]'); } catch { return []; }
  },
  _save(q) {
    try { localStorage.setItem(this._KEY, JSON.stringify(q)); } catch {}
  },

  push(op, collection, key, data) {
    /* No encolar si no hay userId — datos locales puros sin cuenta */
    const userId = DB?.get?.(DB?.KEYS?.prefs, {})._userId || null;
    if (!userId) return;

    const q = this._load();
    /* Deduplicar: si ya hay un upsert del mismo key, sustituir */
    const idx = q.findIndex(e => e.key === key && e.collection === collection && e.op === op);
    const entry = { id: `sq_${Date.now()}_${Math.random().toString(36).slice(2,6)}`,
                    op, collection, key, data, ts: Date.now(), userId };
    if (idx >= 0) q[idx] = entry;
    else q.push(entry);
    this._save(q);
    Events.emit('syncqueue:changed', { pending: q.length });
  },

  count() { return this._load().length; },

  /* Llamado en v2.0 cuando hay conexión y token válido */
  async flush(apiFn) {
    const q = this._load();
    if (!q.length) return { sent: 0, failed: 0 };
    let sent = 0, failed = 0, remaining = [];
    for (const entry of q) {
      try {
        await apiFn(entry);
        sent++;
      } catch {
        failed++;
        remaining.push(entry);
      }
    }
    this._save(remaining);
    Events.emit('syncqueue:flushed', { sent, failed, pending: remaining.length });
    return { sent, failed };
  },

  clear() { this._save([]); },

  getAll() { return this._load(); },
};

/* ══════════════════════════════════════════════════════════
   EVENTBUS — Desacoplamiento entre módulos
   Uso: Events.on('visit:saved', fn) · Events.emit('visit:saved', data)
   ══════════════════════════════════════════════════════════ */
const Events = {
  _listeners: {},

  on(event, fn) {
    if (!this._listeners[event]) this._listeners[event] = [];
    this._listeners[event].push(fn);
    /* Devuelve función para desuscribirse */
    return () => this.off(event, fn);
  },

  off(event, fn) {
    if (!this._listeners[event]) return;
    this._listeners[event] = this._listeners[event].filter(f => f !== fn);
  },

  emit(event, data) {
    (this._listeners[event] || []).forEach(fn => {
      try { fn(data); } catch(e) { console.warn('EventBus error:', event, e); }
    });
  },

  once(event, fn) {
    const unsub = this.on(event, data => { fn(data); unsub(); });
  },
};



/* ── Migración de datos existentes al añadir userId en v1.7 ──
   Se ejecuta una sola vez. En v2.0 se completará con el userId real al hacer login. */
function _migrateToV17() {
  if (State.prefs._v17migrated) return;
  /* Añadir updatedAt a rutas y paradas que no lo tienen */
  const now = Date.now();
  let changed = false;
  State.routes.forEach(r => {
    if (!r.updatedAt) { r.updatedAt = r.createdAt || now; changed = true; }
  });
  Object.values(State.stops).forEach(s => {
    if (!s.updatedAt) { s.updatedAt = now; changed = true; }
  });
  if (changed) {
    DB.set(DB.KEYS.routes, State.routes);
    DB.set(DB.KEYS.stops,  State.stops);
  }
  State.prefs._v17migrated = true;
  DB.set(DB.KEYS.prefs, State.prefs);
}

/* ── Tema oscuro/claro ── */
function _applyTheme(mode) {
  const html = document.documentElement;
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const dark = mode === 'dark' || (mode === 'auto' && prefersDark);
  html.classList.toggle('dark', dark);
  /* Actualizar meta theme-color */
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = dark ? '#1a1d27' : '#4f46e5';
}
function setTheme(mode) {
  State.prefs.theme = mode;
  State.persist();
  _applyTheme(mode);
  Events.emit('theme:changed', { mode });
  if (typeof Auth !== 'undefined' && Auth.isLoggedIn()) {
    API.patch('/auth/settings', { theme: mode }).catch(() => {});
  }
}

/* Reaccionar a cambio del sistema en tiempo real */
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
  if ((State.prefs.theme || 'auto') === 'auto') _applyTheme('auto');
});

/* ══════════════════════════════════════════════════════════
   INIT
   ══════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded',()=>{
  /* Aplicar tema guardado antes de renderizar */
  _applyTheme(State.prefs.theme || 'auto');
  _migrateToV17();

  State.seedDemo();
  document.querySelector('.topbar-burger')?.addEventListener('click',openSidebar);
  document.querySelector('.sidebar-overlay')?.addEventListener('click',closeSidebar);
  document.querySelectorAll('[data-page]').forEach(el=>{
    el.addEventListener('click',()=>Router.go(el.dataset.page));
  });
  document.getElementById('confirm-ok-btn')?.addEventListener('click',_doConfirm);
  document.querySelectorAll('.modal-backdrop').forEach(bd=>{
    bd.addEventListener('click',e=>{if(e.target===bd)closeModal(bd.id);});
  });
  updateTopStats();
  const hash=location.hash;
  if(hash&&hash.length>1){
    const{name,params}=_parseHash(hash);
    if(Router._pages[name]){
      history.replaceState({name,params},'',hash);
      Router._render(name,params);
      return;
    }
  }
  Router.go('dashboard',{},{replace:true});
});
