/* ═══════════════════════════════════════════════════════════
   JORNADA — Timer · KM · Visitas · Check-in · Formularios
   ═══════════════════════════════════════════════════════════ */
'use strict';

/* ── CONSTANTES ───────────────────────────────────────── */

/* ── ESTADO DE JORNADA ───────────────────────────────── */
let _jornadaInterval = null;
let _jornadaActive   = null; // { routeId, dateStr }
let _hCalStopId = null, _hCalRouteId = null, _hCalVisitedDates = null;
let _hCalYear = null, _hCalMonth = null;

function _loadJornadas(){ return DB.getJornadas(); }
function _saveJornadas(d){ DB.setJornadas(d); }
function _jKey(routeId, dateStr){ return `${routeId}_${dateStr}`; }

function getSession(routeId, dateStr){
  return _loadJornadas()[_jKey(routeId,dateStr)] || {
    state:'idle', elapsed:0, startTs:null, distance:0, lastGps:null, gpsPath:[]
  };
}
function setSession(routeId, dateStr, s){
  const all = _loadJornadas();
  all[_jKey(routeId,dateStr)] = { ...s, updatedAt: Date.now(), userId: State.prefs._userId || null };
  _saveJornadas(all);
}

/* ── GPS / KM TRACKING ────────────────────────────────── */
let _gpsWatcher = null;
let _gpsActive  = false;

function _haversine(lat1,lon1,lat2,lon2){
  const R=6371, dLat=(lat2-lat1)*Math.PI/180, dLon=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

function _startGPS(routeId, dateStr){
  if(!navigator.geolocation) return;
  _gpsActive = true;
  _gpsWatcher = navigator.geolocation.watchPosition(pos=>{
    const {latitude:lat,longitude:lng} = pos.coords;
    const s = getSession(routeId, dateStr);
    if(s.state !== 'running') return;
    if(s.lastGps){
      const d = _haversine(s.lastGps.lat, s.lastGps.lng, lat, lng);
      if(d < 0.005) return; // filtrar ruido <5m
      s.distance = (s.distance||0) + d;
    }
    s.lastGps = {lat,lng};
    if(!s.gpsPath) s.gpsPath=[];
    s.gpsPath.push({lat,lng,ts:Date.now()});
    setSession(routeId, dateStr, s);
    _renderTimerBar(routeId, dateStr);
  }, ()=>{}, {enableHighAccuracy:true, maximumAge:3000});
}

function _stopGPS(){
  if(_gpsWatcher !== null){
    navigator.geolocation.clearWatch(_gpsWatcher);
    _gpsWatcher = null;
  }
  _gpsActive = false;
}

/* ── TIMER BAR ────────────────────────────────────────── */
function _renderTimerBar(routeId, dateStr){
  const bar = document.getElementById('jornada-bar');
  if(!bar) return;
  const s = getSession(routeId, dateStr);
  const route = State.getRoute(routeId);
  if(!route) return;

  let el = s.elapsed;
  if(s.state==='running' && s.startTs) el += Math.floor((Date.now()-s.startTs)/1000);

  const hh = String(Math.floor(el/3600)).padStart(2,'0');
  const mm = String(Math.floor((el%3600)/60)).padStart(2,'0');
  const ss = String(el%60).padStart(2,'0');

  const visits = _visitsForDay(routeId, dateStr);
  const visitedCount = route.stops.filter(id => visits[id]).length;

  bar.innerHTML = `
    <div class="jornada-bar-inner">
      <div class="jornada-stat">
        <i class="fa-solid fa-clock"></i>
        <span id="jornada-time">${hh}:${mm}:${ss}</span>
      </div>
      <div class="jornada-stat">
        <i class="fa-solid fa-road"></i>
        <span>${(s.distance||0).toFixed(1)} km</span>
      </div>
      <div class="jornada-stat">
        <i class="fa-solid fa-map-pin"></i>
        <span>${visitedCount}/${route.stops.length}</span>
      </div>
      <div class="jornada-actions">
        ${_jornadaBtns(s, dateStr)}
      </div>
    </div>`;
  bar.classList.add('visible');
  _bindBarBtns(routeId, dateStr);
}

function _jornadaBtns(s, dateStr){
  const today = _localDate(new Date());
  const isToday = dateStr === today;
  if(s.state === 'finished'){
    return `<span class="jornada-badge done"><i class="fa-solid fa-circle-check"></i> Completada</span>
            <button class="jornada-btn reset" onclick="jornadaReset()"><i class="fa-solid fa-rotate-left"></i></button>`;
  }
  if(s.state === 'running'){
    return `<button class="jornada-btn pause" onclick="jornadaPause()"><i class="fa-solid fa-pause"></i></button>
            <button class="jornada-btn stop"  onclick="jornadaStop()"><i class="fa-solid fa-stop"></i> Finalizar</button>`;
  }
  // idle / paused
  const canStart = isToday;
  return `${canStart ? `<button class="jornada-btn start" onclick="jornadaStart()">
    <i class="fa-solid fa-play"></i> ${s.state==='paused'?'Reanudar':'Iniciar'}
  </button>` : `<span class="jornada-badge muted">Día anterior</span>`}
  ${s.state==='paused' ? `<button class="jornada-btn stop" onclick="jornadaStop()"><i class="fa-solid fa-stop"></i> Finalizar</button>` : ''}`;
}

function _bindBarBtns(routeId, dateStr){
  // botones inline con onclick — ya funciona
}

/* ── CONTROLES PÚBLICOS ───────────────────────────────── */
function jornadaStart(){
  if(!_jornadaActive) return;
  const {routeId,dateStr} = _jornadaActive;
  const s = getSession(routeId, dateStr);
  if(s.state==='finished') return;
  s.state = 'running';
  s.startTs = Date.now();
  setSession(routeId, dateStr, s);
  if(_jornadaInterval) clearInterval(_jornadaInterval);
  _jornadaInterval = setInterval(()=>_renderTimerBar(routeId,dateStr), 1000);
  _startGPS(routeId, dateStr);
  _renderTimerBar(routeId, dateStr);
  if (typeof syncNow === 'function') syncNow();
  toast('Jornada iniciada ▶','success',2000);
}

function jornadaPause(){
  if(!_jornadaActive) return;
  const {routeId,dateStr} = _jornadaActive;
  const s = getSession(routeId, dateStr);
  if(s.state !== 'running') return;
  s.elapsed += Math.floor((Date.now()-s.startTs)/1000);
  s.startTs = null; s.state = 'paused';
  setSession(routeId, dateStr, s);
  clearInterval(_jornadaInterval); _jornadaInterval = null;
  _stopGPS();
  _renderTimerBar(routeId, dateStr);
  if (typeof syncNow === 'function') syncNow();
  toast('Jornada pausada ⏸','warning',2000);
}

function jornadaStop(){
  if(!_jornadaActive) return;
  const {routeId,dateStr} = _jornadaActive;
  const s = getSession(routeId, dateStr);
  if(s.state==='running'){ s.elapsed += Math.floor((Date.now()-s.startTs)/1000); s.startTs=null; }
  s.state = 'finished';
  setSession(routeId, dateStr, s);
  clearInterval(_jornadaInterval); _jornadaInterval = null;
  _stopGPS();
  _renderTimerBar(routeId, dateStr);
  const h=Math.floor(s.elapsed/3600), m=Math.floor((s.elapsed%3600)/60);
  if (typeof syncNow === 'function') syncNow();
  toast(`Jornada finalizada ✓  ${h}h ${m}m · ${(s.distance||0).toFixed(1)} km`,'success',4000);
}

function jornadaReset(){
  if(!_jornadaActive) return;
  const {routeId,dateStr} = _jornadaActive;
  // Sheet de opciones
  const overlay = document.createElement('div');
  overlay.id = 'jornada-reset-overlay';
  overlay.className = 'overlay-backdrop';
  overlay.innerHTML = `
    <div class="bottom-sheet">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <i class="fa-solid fa-rotate-left" style="color:var(--red)"></i>
        <span>Reiniciar jornada</span>
        <button class="modal-close" onclick="Overlay.pop()">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
      <div class="sheet-body">
        <button class="sheet-option" onclick="_doJornadaReset('counters')">
          <div class="sheet-opt-icon indigo"><i class="fa-solid fa-stopwatch"></i></div>
          <div><strong>Solo contadores</strong><p>Resetea tiempo y km. Las visitas del día se conservan.</p></div>
        </button>
        <button class="sheet-option" onclick="_doJornadaReset('visits')">
          <div class="sheet-opt-icon orange"><i class="fa-solid fa-file-circle-xmark"></i></div>
          <div><strong>Solo visitas del día</strong><p>Elimina todos los check-ins de hoy. Los contadores se conservan.</p></div>
        </button>
        <button class="sheet-option danger" onclick="_doJornadaReset('all')">
          <div class="sheet-opt-icon red"><i class="fa-solid fa-trash"></i></div>
          <div><strong>Reiniciar todo</strong><p>Elimina visitas y resetea contadores.</p></div>
        </button>
      </div>
    </div>`;
  Overlay.push(overlay);
}

function _doJornadaReset(mode){
  Overlay.pop();
  if(!_jornadaActive) return;
  const {routeId,dateStr} = _jornadaActive;
  if(mode==='counters'||mode==='all'){
    clearInterval(_jornadaInterval); _jornadaInterval=null;
    _stopGPS();
    setSession(routeId,dateStr,{state:'idle',elapsed:0,startTs:null,distance:0,lastGps:null,gpsPath:[]});
  }
  if(mode==='visits'||mode==='all'){
    const all = _loadVisits();
    const prefix = `${routeId}_${dateStr}_`;
    Object.keys(all).forEach(k=>{ if(k.startsWith(prefix)) delete all[k]; });
    _saveVisits(all);
  }
  _renderTimerBar(routeId, dateStr);
  // re-render la lista de paradas
  const content = document.getElementById('page-content');
  if(content && Router._current==='jornada') Router.go('jornada', Router._params||{});
  const msgs={counters:'Contadores reseteados',visits:'Visitas del día eliminadas',all:'Jornada reiniciada'};
  if (typeof syncNow === 'function') syncNow();
  toast(msgs[mode],'warning',2500);
}

/* ── INICIALIZAR JORNADA EN UNA RUTA/DÍA ─────────────── */
function initJornada(routeId, dateStr){
  _jornadaActive = {routeId, dateStr};
  // Si había interval corriendo para otra jornada, limpiar
  if(_jornadaInterval){ clearInterval(_jornadaInterval); _jornadaInterval=null; }
  const s = getSession(routeId, dateStr);
  if(s.state==='running'){
    _jornadaInterval = setInterval(()=>_renderTimerBar(routeId,dateStr),1000);
    if(!_gpsActive) _startGPS(routeId,dateStr);
  }
  _renderTimerBar(routeId, dateStr);
}

/* ── VISITAS ──────────────────────────────────────────── */
function _loadVisits(){ return DB.getVisits(); }
function _saveVisits(d){ DB.setVisits(d); }
function _vKey(routeId,dateStr,stopId){ return `${routeId}_${dateStr}_${stopId}`; }

function _visitsForDay(routeId, dateStr){
  const all = _loadVisits();
  const result = {};
  const prefix = `${routeId}_${dateStr}_`;
  Object.entries(all).forEach(([k,v])=>{ if(k.startsWith(prefix)) result[k.slice(prefix.length)]=v; });
  return result;
}

function getVisit(routeId, dateStr, stopId){
  return _loadVisits()[_vKey(routeId,dateStr,stopId)] || null;
}

function saveVisit(routeId, dateStr, stopId, data){
  const all = _loadVisits();
  const key = _vKey(routeId,dateStr,stopId);
  /* Generar id único si es una visita nueva — el backend lo necesita como PK */
  const existingId = all[key]?.id;
  const visitId = existingId || (
    typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`
  );
  all[key] = {
    ...data,
    id: visitId,
    stopId,
    routeId,
    dateStr,
    updatedAt: Date.now(),
    userId: State.prefs._userId || null,
  };
  _saveVisits(all);
}

function deleteVisit(routeId, dateStr, stopId){
  const all = _loadVisits();
  delete all[_vKey(routeId,dateStr,stopId)];
  _saveVisits(all);
  if (typeof syncNow === 'function') syncNow();
}

/* ── FORMULARIOS PERSONALIZABLES ─────────────────────── */
function _loadForms(){ return DB.getForms(); }
function _saveForms(d){ DB.setForms(d); }

function getForms(){ return _loadForms(); }

// Formulario por defecto (genérico) si no hay ninguno
function _ensureDefaultForm(){
  const forms = _loadForms();
  if(forms.length) return;
  _saveForms([{
    id:'form_default',
    name:'Visita estándar',
    icon:'fa-clipboard-check',
    fields:[
      {id:'f1',type:'select',label:'Estado visita',required:true,
       options:['Realizada','Cliente ausente','Cerrado','No interesado']},
      {id:'f2',type:'textarea',label:'Notas de visita',required:false,placeholder:'Observaciones, incidencias...'},
      {id:'f3',type:'text',label:'Persona de contacto',required:false,placeholder:'Nombre del contacto'},
      {id:'f4',type:'text',label:'Teléfono',required:false,placeholder:'+34 ...'},
      {id:'f5',type:'number',label:'Duración estimada (min)',required:false},
    ],
    createdAt: Date.now()
  }]);
}

/* ── KPIs PERSONALIZABLES ─────────────────────────────── */
function _loadKpis(){ return DB.getKpis(); }
function _saveKpis(d){ DB.setKpis(d); }

function getKpis(){ return _loadKpis(); }

/* ── PÁGINA JORNADA ───────────────────────────────────── */
Router.register('jornada',(el,params={})=>{
  const {routeId, dateStr} = params;
  if(!routeId||!dateStr){ el.innerHTML=`<div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-calendar-xmark"></i></div><div class="empty-title">Sin jornada activa</div><div class="empty-sub">Ve al calendario y selecciona un día</div></div>`; return; }

  _ensureDefaultForm();
  const route  = State.getRoute(routeId);
  if(!route){ el.innerHTML=`<div class="empty-state"><div class="empty-title">Ruta no encontrada</div></div>`; return; }

  const sess   = getSession(routeId, dateStr);
  const visits = _visitsForDay(routeId, dateStr);
  const today  = _localDate(new Date());
  const isToday= dateStr === today;
  const dateDisplay = new Date(dateStr+'T12:00').toLocaleDateString('es-ES',{weekday:'long',day:'numeric',month:'long'});

  initJornada(routeId, dateStr);

  el.innerHTML = `
  <div class="jornada-page">

    <!-- Cabecera -->
    <div class="jornada-header">
      <button class="btn btn-ghost btn-icon" onclick="history.back()">
        <i class="fa-solid fa-arrow-left"></i>
      </button>
      <div class="jornada-header-info">
        <div class="jornada-title">${esc(route.name)}</div>
        <div class="jornada-subtitle">${dateDisplay}</div>
      </div>
      <div class="jornada-header-actions">
        ${isToday ? `<span class="badge badge-indigo">Hoy</span>` : ''}
        <button class="btn btn-ghost btn-icon sm"
            onclick="Router.go('map',{routeId:'${routeId}',dateStr:'${dateStr}'})"
            title="Ver en mapa">
          <i class="fa-solid fa-map"></i>
        </button>
      </div>
    </div>

    <!-- Lista de paradas -->
    <div class="jornada-stops" id="jornada-stops-list">
      ${route.stops.length===0
        ? `<div class="empty-state">
             <div class="empty-icon"><i class="fa-solid fa-map-pin"></i></div>
             <div class="empty-title">Sin paradas</div>
             <div class="empty-sub">Añade paradas a esta ruta</div>
           </div>`
        : route.stops.map((stopId,i) => _stopCard(routeId,dateStr,stopId,i,visits[stopId],sess)).join('')
      }
    </div>

  </div>`;

  _renderTimerBar(routeId, dateStr);
});

function _stopCard(routeId, dateStr, stopId, idx, visit, sess){
  const stop  = State.getStop(stopId);
  if(!stop) return '';
  const isVisited = !!visit;
  const status    = visit?.estado || '';
  const isOpen    = sess.state === 'running';
  const today     = _localDate(new Date());
  const isToday   = dateStr === today;

  /* Botones secundarios: sólo los que aplican */
  const secBtns = [
    stop.lat ? `<button class="btn btn-ghost btn-icon xs" title="Navegar" onclick="openNav(${stop.lat},${stop.lng})"><i class="fa-solid fa-diamond-turn-right"></i></button>` : '',
    (stop.phone||stop.mobile) ? `<button class="btn btn-ghost btn-icon xs" title="Contacto" onclick="openStopContact('${stopId}')"><i class="fa-solid fa-phone"></i></button>` : '',
    `<button class="btn btn-ghost btn-icon xs" title="Historial" onclick="openVisitHistory('${stopId}','${routeId}')"><i class="fa-solid fa-clock-rotate-left"></i></button>`,
  ].filter(Boolean).join('');

  return `
  <div class="stop-card ${isVisited?'visited':''}" id="sc-${stopId}">
    <div class="stop-card-num">${idx+1}</div>
    <div class="stop-card-info" style="flex:1;min-width:0">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px">
        <div style="min-width:0;flex:1">
          <div class="stop-card-name">${esc(stop.name)}</div>
          <div class="stop-card-meta">${[esc(stop.addr), esc(stop.town)].filter(Boolean).join(' · ')||'—'}</div>
          ${isVisited ? `<div class="stop-card-status">
            <i class="fa-solid fa-circle-check" style="color:var(--green)"></i>
            <span>${status||'Visitada'}</span>
            ${visit.checkInTs ? `<span class="visit-time">${_fmtTime(visit.checkInTs)}</span>` : ''}
          </div>` : ''}
        </div>
        <button class="btn ${isVisited?'btn-ghost':'btn-primary'} btn-sm"
            style="white-space:nowrap;flex-shrink:0;margin-top:1px"
            onclick="openVisit('${routeId}','${dateStr}','${stopId}')">
          ${isVisited ? `<i class="fa-solid fa-pen"></i>` : `<i class="fa-solid fa-clipboard-check"></i>`}
          ${isVisited ? 'Editar' : 'Check-in'}
        </button>
      </div>
      ${secBtns ? `<div class="stop-card-sec-btns">${secBtns}</div>` : ''}
    </div>
  </div>`;
}

function _fmtTime(ts){
  return new Date(ts).toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'});
}

function openNav(lat,lng){
  window.open(`https://maps.google.com/maps?daddr=${lat},${lng}&dirflg=d`,'_blank');
}

/* ── VISTA VISITA / CHECK-IN ──────────────────────────── */
function openVisit(routeId, dateStr, stopId){
  const stop   = State.getStop(stopId);
  const visit  = getVisit(routeId,dateStr,stopId) || {};
  const forms  = getForms();
  const kpis   = getKpis();
  const sess   = getSession(routeId,dateStr);

  const overlay = document.createElement('div');
  overlay.id = 'visit-overlay';
  overlay.className = 'overlay-backdrop';

  const formsHtml = forms.map(form=>`
    <div class="visit-section">
      <div class="visit-section-title"><i class="fa-solid ${form.icon||'fa-clipboard'}"></i> ${form.name}</div>
      ${form.fields.map(f=>_renderField(f, visit[f.id])).join('')}
    </div>`).join('');

  const kpisHtml = kpis.length ? `
    <div class="visit-section">
      <div class="visit-section-title"><i class="fa-solid fa-chart-bar"></i> KPIs</div>
      ${kpis.map(k=>`
        <div class="form-group">
          <label class="form-label">${esc(k.label)} ${k.unit?`<span class="form-unit">(${k.unit})</span>`:''}</label>
          <input class="form-input" type="number" id="kpi-${k.id}"
            value="${visit['kpi_'+k.id]||''}" placeholder="0"
            ${k.min!==undefined?`min="${k.min}"`:''}
            ${k.max!==undefined?`max="${k.max}"`:''}
          >
        </div>`).join('')}
    </div>` : '';

  overlay.innerHTML = `
    <div class="bottom-sheet visit-sheet">
      <div class="sheet-handle"></div>
      <div class="visit-sheet-header">
        <div>
          <div class="visit-sheet-name">${esc(stop.name)}</div>
          <div class="visit-sheet-addr">${[stop.addr,stop.town].filter(Boolean).join(' · ')||'—'}</div>
        </div>
        <button class="modal-close" onclick="Overlay.pop()">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <!-- Contacto rápido -->
      <div class="visit-contact-bar">
        ${stop.contact ? `<div class="contact-chip"><i class="fa-solid fa-user"></i> ${esc(stop.contact)}</div>` : ''}
        ${stop.horario ? `<div class="contact-chip"><i class="fa-solid fa-clock"></i> ${esc(stop.horario)}</div>` : ''}
        ${stop.phone   ? `<a class="contact-chip btn-link" href="tel:${stop.phone}"><i class="fa-solid fa-phone"></i> ${stop.phone}</a>` : ''}
        ${stop.mobile  ? `<a class="contact-chip btn-link" href="tel:${stop.mobile}"><i class="fa-solid fa-mobile-screen"></i> ${stop.mobile}</a>` : ''}
        ${stop.notes   ? `<div class="contact-chip"><i class="fa-solid fa-note-sticky"></i> ${esc(stop.notes)}</div>` : ''}
        ${stop.lat     ? `<button class="contact-chip btn-link" onclick="openNav(${stop.lat},${stop.lng})">
          <i class="fa-solid fa-diamond-turn-right"></i> Navegar</button>` : ''}
      </div>

      <div class="visit-body" id="visit-body-scroll">
        <!-- Formularios -->
        ${formsHtml || `<div class="visit-section">
          <div class="visit-section-title"><i class="fa-solid fa-clipboard-check"></i> Visita estándar</div>
          <div class="form-group">
            <label class="form-label">Estado</label>
            <select class="form-input" id="visit-estado">
              ${['Realizada','Cliente ausente','Cerrado','No interesado'].map(o=>
                `<option ${(visit.estado||''===o)?'selected':''}>${o}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Notas</label>
            <textarea class="form-input" id="visit-notas" rows="3" placeholder="Observaciones...">${visit.notas||''}</textarea>
          </div>
        </div>`}

        <!-- KPIs -->
        ${kpisHtml}

        <!-- Fotos -->
        <div class="visit-section">
          <div class="visit-section-title"><i class="fa-solid fa-camera"></i> Fotos
            <span class="form-hint" style="margin-left:8px;font-weight:400">opcional</span>
          </div>
          <div class="photos-grid" id="photos-grid-${stopId}">
            ${(visit.photos||[]).map((p,i)=>`
              <div class="photo-thumb" onclick="_removePhoto('${stopId}',${i})">
                <img src="${p}" alt="">
                <div class="photo-del"><i class="fa-solid fa-xmark"></i></div>
              </div>`).join('')}
            <label class="photo-add">
              <i class="fa-solid fa-plus"></i>
              <input type="file" accept="image/*" multiple style="display:none"
                onchange="_addPhotos(this,'${stopId}','${routeId}','${dateStr}')">
            </label>
          </div>
        </div>
      </div>

      <div class="visit-footer">
        <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">
          Cancelar
        </button>
        <button class="btn btn-primary" style="flex:2"
            onclick="_saveVisitForm('${routeId}','${dateStr}','${stopId}')">
          <i class="fa-solid fa-floppy-disk"></i> Guardar visita
        </button>
      </div>
    </div>`;

  Overlay.push(overlay);

  /* Reset scroll del visit-body — diferido está bien para scroll */
  requestAnimationFrame(()=>{
    const vb = overlay.querySelector('#visit-body-scroll,.visit-body');
    if(vb) vb.scrollTop = 0;
  });

  /* Rellenar campos dinámicos AHORA, en el mismo frame del push
     (no diferido: si el usuario cierra el overlay antes del rAF, document.getElementById
     ya no encuentra los elementos y los campos aparecen vacíos) */
  if(forms.length){
    forms.forEach(form=>{
      form.fields.forEach(f=>{
        const fieldEl = overlay.querySelector(`#ff-${f.id}`);
        if(fieldEl && visit[f.id]!==undefined) fieldEl.value = visit[f.id];
      });
    });
    kpis.forEach(k=>{
      const kpiEl = overlay.querySelector(`#kpi-${k.id}`);
      if(kpiEl && visit['kpi_'+k.id]!==undefined) kpiEl.value = visit['kpi_'+k.id];
    });
  }

  /* Contexto del overlay para _saveVisitForm */
  overlay.dataset.stopId  = stopId;
  overlay.dataset.routeId = routeId;
  overlay.dataset.dateStr = dateStr;
}

function _renderField(f, value=''){
  const id = `ff-${f.id}`;
  const req = f.required ? ` <sup>*</sup>` : '';

  if(f.type==='select') return `
    <div class="form-group">
      <label class="form-label">${f.label}${req}</label>
      <select class="form-input" id="${id}">
        <option value="">— Seleccionar —</option>
        ${(f.options||[]).map(o=>`<option value="${o}" ${value===o?'selected':''}>${o}</option>`).join('')}
      </select>
    </div>`;

  if(f.type==='textarea') return `
    <div class="form-group">
      <label class="form-label">${f.label}${req}</label>
      <textarea class="form-input" id="${id}" rows="3" placeholder="${f.placeholder||''}">${value||''}</textarea>
    </div>`;

  if(f.type==='checkbox') return `
    <div class="form-group form-check">
      <input type="checkbox" id="${id}" ${value?'checked':''}>
      <label for="${id}" class="form-label">${f.label}</label>
    </div>`;

  if(f.type==='yesno') return `
    <div class="form-group">
      <label class="form-label">${f.label}${req}</label>
      <div class="field-yesno">
        <button type="button" class="yesno-btn ${value==='si'?'active':''}"
          onclick="_setYesNo('${id}',this,'si')">
          <i class="fa-solid fa-check"></i> Sí
        </button>
        <button type="button" class="yesno-btn ${value==='no'?'active':''}"
          onclick="_setYesNo('${id}',this,'no')">
          <i class="fa-solid fa-xmark"></i> No
        </button>
      </div>
      <input type="hidden" id="${id}" value="${value||''}">
    </div>`;

  if(f.type==='rating') return `
    <div class="form-group">
      <label class="form-label">${f.label}${req}</label>
      <div class="field-rating" id="${id}-stars">
        ${[1,2,3,4,5].map(n=>`
          <button type="button" class="rating-star ${Number(value)>=n?'active':''}"
            onclick="_setRating('${id}',${n})">
            <i class="fa-solid fa-star"></i>
          </button>`).join('')}
      </div>
      <input type="hidden" id="${id}" value="${value||''}">
    </div>`;

  return `
    <div class="form-group">
      <label class="form-label">${f.label}${req}</label>
      <input class="form-input" type="${f.type||'text'}" id="${id}" value="${value||''}" placeholder="${f.placeholder||''}">
    </div>`;
}

function _setYesNo(id, btn, val) {
  document.getElementById(id).value = val;
  btn.closest('.field-yesno').querySelectorAll('.yesno-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
}
function _setRating(id, n) {
  document.getElementById(id).value = n;
  const stars = document.querySelectorAll(`#${id}-stars .rating-star`);
  stars.forEach((s,i) => s.classList.toggle('active', i < n));
}

function _saveVisitForm(routeId, dateStr, stopId){
  const forms = getForms();
  const kpis  = getKpis();
  const existing = getVisit(routeId,dateStr,stopId) || {};
  /* Capturar posición GPS en check-in si no se había guardado antes */
  const _sessNow = getSession(routeId, dateStr);
  const _gpsNow  = _sessNow?.lastGps || null;
  const data  = {
    ...existing,
    checkInTs: existing.checkInTs || Date.now(),
    latIn:  existing.latIn  ?? (_gpsNow?.lat  ?? null),
    lngIn:  existing.lngIn  ?? (_gpsNow?.lng  ?? null),
  };

  // Leer formularios dinámicos
  if(forms.length){
    forms.forEach(form=>{
      form.fields.forEach(f=>{
        const el = document.getElementById(`ff-${f.id}`);
        if(!el) return;
        if(f.required && !el.value.trim()){ toast(`"${f.label}" es obligatorio`,'error'); throw new Error('validation'); }
        data[f.id] = f.type==='checkbox' ? el.checked : el.value;
      });
    });
    // Tomar estado del primer campo select de cada form si existe
    const firstSelect = forms[0]?.fields.find(f=>f.type==='select');
    if(firstSelect){ data.estado = data[firstSelect.id] || ''; }
  } else {
    // Formulario inline
    const est  = document.getElementById('visit-estado');
    const nota = document.getElementById('visit-notas');
    if(est)  data.estado = est.value;
    if(nota) data.notas  = nota.value;
  }

  // Leer KPIs
  kpis.forEach(k=>{
    const el = document.getElementById(`kpi-${k.id}`);
    if(el) data['kpi_'+k.id] = el.value ? Number(el.value) : null;
  });

  data.checkOutTs = Date.now();
  /* Capturar posición GPS en check-out */
  const _sessCO = getSession(routeId, dateStr);
  const _gpsCO  = _sessCO?.lastGps || null;
  if (_gpsCO) { data.latOut = _gpsCO.lat; data.lngOut = _gpsCO.lng; }
  saveVisit(routeId, dateStr, stopId, data);
  if (typeof syncNow === 'function') syncNow();
  Overlay.pop();
  toast('Visita guardada ✓','success',2000);

  // Actualizar card en la lista
  const card = document.getElementById(`sc-${stopId}`);
  if(card){
    const route = State.getRoute(routeId);
    const sess  = getSession(routeId,dateStr);
    const idx   = route.stops.indexOf(stopId);
    card.outerHTML = _stopCard(routeId,dateStr,stopId,idx,data,sess);
  }
  _renderTimerBar(routeId,dateStr);
}

async function _addPhotos(input, stopId, routeId, dateStr){
  const files = Array.from(input.files);
  if(!files.length) return;
  const existing = getVisit(routeId,dateStr,stopId) || {};
  const photos   = [...(existing.photos || [])];

  toast('Subiendo fotos…', 'info', 0); /* spinner hasta completar */

  for (const f of files) {
    if(f.size > 5*1024*1024){ toast('Foto demasiado grande (máx 5MB)','error'); continue; }

    /* Intentar subir al servidor si hay sesión activa */
    if (typeof Tokens !== 'undefined' && Tokens.isLoggedIn()) {
      try {
        const fd = new FormData();
        fd.append('file', f);
        const res = await fetch(API_BASE + '/uploads/photo', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + (Tokens.accessToken?.() || '') },
          body: fd,
        });
        if (res.ok) {
          const data = await res.json();
          if (data.url) { photos.push(data.url); continue; }
        }
      } catch(e) { /* fallback a base64 */ }
    }

    /* Fallback: base64 local */
    await new Promise(resolve => {
      const reader = new FileReader();
      reader.onload = e => { photos.push(e.target.result); resolve(); };
      reader.readAsDataURL(f);
    });
  }

  saveVisit(routeId,dateStr,stopId,{...existing,photos});
  if (typeof syncNow === 'function') syncNow();

  /* Refresh grid */
  const grid = document.getElementById(`photos-grid-${stopId}`);
  if(grid) grid.innerHTML = photos.map((p,i)=>`
    <div class="photo-thumb" onclick="_removePhoto('${stopId}',${i})">
      <img src="${p}" alt="" loading="lazy">
      <div class="photo-del"><i class="fa-solid fa-xmark"></i></div>
    </div>`).join('') +
    `<label class="photo-add"><i class="fa-solid fa-plus"></i>
      <input type="file" accept="image/*" multiple style="display:none"
        onchange="_addPhotos(this,'${stopId}','${routeId}','${dateStr}')">
    </label>`;
  toast(`${photos.length} foto${photos.length>1?'s':''} guardada${photos.length>1?'s':''}✓`,'success',1800);
}

function _removePhoto(stopId, idx){
  // Obtener contexto desde el overlay
  const ov = document.getElementById('visit-overlay');
  if(!ov) return;
  const {routeId,dateStr} = ov.dataset;
  const existing = getVisit(routeId,dateStr,stopId) || {};
  const photos = [...(existing.photos||[])];
  photos.splice(idx,1);
  saveVisit(routeId,dateStr,stopId,{...existing,photos});
  const grid = document.getElementById(`photos-grid-${stopId}`);
  if(grid) grid.querySelectorAll('.photo-thumb')[idx]?.remove();
  toast('Foto eliminada','info',1500);
}

/* ── PÁGINA: EDITOR DE FORMULARIOS ───────────────────── */
Router.register('form-editor',(el)=>{
  if (({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0) < 1) { Router.go('dashboard'); return; }
  _ensureDefaultForm();
  const forms = getForms();

  el.innerHTML = `
  <div class="page-header mb-4">
    <div>
      <h1 class="page-h1">Formularios de visita</h1>
      <p class="page-sub">Personaliza los campos de cada visita</p>
    </div>
    <button class="btn btn-primary" onclick="showNewForm()">
      <i class="fa-solid fa-plus"></i> Nuevo formulario
    </button>
  </div>

  <div class="forms-list">
    ${forms.map(f=>_formCard(f)).join('')}
    ${forms.length===0 ? `<div class="empty-state">
      <div class="empty-icon"><i class="fa-solid fa-clipboard"></i></div>
      <div class="empty-title">Sin formularios</div>
      <div class="empty-sub">Crea tu primer formulario de visita</div>
    </div>` : ''}
  </div>

  <!-- KPIs -->
  <div class="page-header mt-5 mb-3">
    <div>
      <h2 class="page-h1" style="font-size:var(--t-xl)">KPIs personalizados</h2>
      <p class="page-sub">Métricas numéricas que se registran en cada visita</p>
    </div>
    <button class="btn btn-primary" onclick="showNewKpi()">
      <i class="fa-solid fa-plus"></i> Nuevo KPI
    </button>
  </div>
  <div class="kpis-list" id="kpis-list">
    ${_renderKpiList()}
  </div>`;
});

function _formCard(f){
  return `
  <div class="form-card">
    <div class="form-card-head">
      <div class="form-card-icon"><i class="fa-solid ${f.icon||'fa-clipboard'}"></i></div>
      <div>
        <div class="form-card-name">${esc(f.name)}</div>
        <div class="form-card-meta">${f.fields.length} campo${f.fields.length!==1?'s':''}</div>
      </div>
      <div class="form-card-btns" onclick="event.stopPropagation()">
        <button class="btn btn-ghost btn-icon sm" onclick="editForm('${f.id}')"><i class="fa-solid fa-pen"></i></button>
        <button class="btn btn-danger btn-icon sm" onclick="confirmDeleteForm('${f.id}')"><i class="fa-solid fa-trash"></i></button>
      </div>
    </div>
    <div class="form-fields-preview">
      ${f.fields.slice(0,4).map(fld=>`
        <div class="field-chip"><i class="fa-solid ${_fieldIcon(fld.type)}"></i> ${fld.label}</div>`).join('')}
      ${f.fields.length>4?`<div class="field-chip muted">+${f.fields.length-4} más</div>`:''}
    </div>
  </div>`;
}

function _fieldIcon(t){
  const m={text:'fa-font',textarea:'fa-align-left',number:'fa-hashtag',select:'fa-list',checkbox:'fa-square-check',date:'fa-calendar'};
  return m[t]||'fa-circle-dot';
}

function _renderKpiList(){
  const kpis = getKpis();
  if(!kpis.length) return `<div class="empty-state" style="padding:var(--sp-4)">
    <div class="empty-sub">Sin KPIs creados — las visitas no tendrán métricas numéricas</div></div>`;
  return `<div class="kpis-grid">${kpis.map(k=>`
    <div class="kpi-chip-card">
      <div class="kpi-chip-name">${esc(k.label)}</div>
      ${k.unit?`<div class="kpi-chip-unit">${k.unit}</div>`:''}
      <div class="kpi-chip-btns">
        <button class="btn btn-ghost btn-icon xs" onclick="deleteKpi('${k.id}')">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
    </div>`).join('')}</div>`;
}

/* ── ACCIONES FORMULARIOS ─────────────────────────────── */
function showNewForm(){
  _openFormEditor(null);
}
function editForm(id){
  const form = getForms().find(f=>f.id===id);
  if(form) _openFormEditor(form);
}
function confirmDeleteForm(id){
  confirm_('¿Eliminar este formulario?',()=>{
    const forms = getForms().filter(f=>f.id!==id);
    _saveForms(forms);
    toast('Formulario eliminado','info');
    Router.go('form-editor');
  },'Eliminar formulario');
}

function _openFormEditor(form){
  const isNew = !form;
  const fields = form?.fields || [];
  const overlay = document.createElement('div');
  overlay.id='form-editor-overlay';
  overlay.className='overlay-backdrop';
  /* Construir HTML de campos fuera del template para evitar backticks anidados */
  const _feFieldsHtml = fields.map((f,i)=>_feFieldRow(f,i)).join('');
  overlay.innerHTML=`
    <div class="bottom-sheet form-editor-sheet">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <i class="fa-solid fa-clipboard-list"></i>
        <span>${isNew?'Nuevo formulario':'Editar formulario'}</span>
        <button class="modal-close" onclick="Overlay.pop()">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
      <div class="visit-body" style="max-height:65vh;overflow-y:auto;overflow-x:hidden;padding:var(--sp-4)">
        <div class="form-group">
          <label class="form-label">Nombre del formulario <sup>*</sup></label>
          <input class="form-input" id="fe-name" value="${_esc(form?.name)}" placeholder="Ej: Visita comercial">
        </div>
        <div class="form-group">
          <label class="form-label">Icono</label>
          <input type="hidden" id="fe-icon" value="${form?.icon||'fa-clipboard-check'}">
          <div class="fe-icon-grid">
            ${[
              ['fa-clipboard-check','Visita'],['fa-file-alt','Informe'],['fa-chart-bar','Métricas'],
              ['fa-handshake','Reunión'],['fa-store','Tienda'],['fa-boxes-stacked','Stock'],
              ['fa-truck','Entrega'],['fa-star','Especial'],['fa-camera','Foto'],
              ['fa-euro-sign','Pedido'],['fa-wrench','Incidencia'],['fa-comments','Feedback'],
            ].map(([ic,lb])=>`
              <button type="button" class="fe-icon-btn ${(form?.icon||'fa-clipboard-check')===ic?'active':''}"
                onclick="_feSelectIcon(this,'${ic}')" title="${lb}">
                <i class="fa-solid ${ic}"></i>
                <span>${lb}</span>
              </button>`).join('')}
          </div>
        </div>
        <div style="font-size:var(--t-sm);font-weight:700;color:var(--tx-2);margin-bottom:var(--sp-3)">Campos</div>
        <div id="fe-fields-list">
          ${_feFieldsHtml}
        </div>
        <button class="btn btn-ghost btn-sm mt-2" onclick="_feAddField()">
          <i class="fa-solid fa-plus"></i> Añadir campo
        </button>
      </div>
      <div class="visit-footer">
        <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cancelar</button>
        <button class="btn btn-primary" style="flex:2" onclick="_saveForm('${form?.id||''}')">
          <i class="fa-solid fa-floppy-disk"></i> Guardar
        </button>
      </div>
    </div>`;
  Overlay.push(overlay);
}

let _feFieldCounter = 100;
function _feAddField(){
  const list = document.getElementById('fe-fields-list');
  if(!list) return;
  const idx = list.children.length;
  const f = {id:`nf${_feFieldCounter++}`,type:'text',label:'',required:false,placeholder:'',options:[]};
  list.insertAdjacentHTML('beforeend',_feFieldRow(f,idx));
}

function _feSelectIcon(btn, icon) {
  document.getElementById('fe-icon').value = icon;
  document.querySelectorAll('.fe-icon-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

function _feOnTypeChange(sel) {
  const row = sel.closest('.fe-field-row');
  const wrap = row?.querySelector('.fe-options-wrap');
  if (wrap) wrap.style.display = sel.value === 'select' ? 'block' : 'none';
}


/* Escapar comillas dobles para atributos HTML */
function _esc(s){ return String(s||'').replace(/"/g,'&quot;'); }

function _feFieldRow(f,i){
  const FIELD_TYPES = {
    text:     'Texto corto',
    textarea: 'Texto largo',
    number:   'Número',
    select:   'Lista opciones',
    yesno:    'Sí / No',
    rating:   'Valoración ★',
    time:     'Hora',
    date:     'Fecha',
  };
  const optionsHtml = f.type === 'select'
    ? `<div class="fe-options-wrap" style="margin-top:6px">
        <input class="form-input fe-field-options" placeholder="Opciones separadas por coma (Ej: Pendiente, Visitado, Cerrado)"
          value="${_esc((f.options||[]).join(', '))}" style="font-size:var(--t-xs)">
        <div class="form-hint">Separa las opciones con coma</div>
       </div>`
    : `<div class="fe-options-wrap" style="display:none"></div>`;

  return `<div class="fe-field-row" id="fe-field-${f.id}" data-field-id="${f.id}">
    <div style="display:flex;gap:8px;align-items:center;margin-bottom:4px">
      <input class="form-input fe-field-label" placeholder="Nombre del campo" value="${_esc(f.label)}" style="flex:1">
      <select class="form-input fe-field-type" style="width:130px;min-width:110px;flex-shrink:0"
        onchange="_feOnTypeChange(this)">
        ${Object.entries(FIELD_TYPES).map(([v,l])=>
          `<option value="${v}" ${f.type===v?'selected':''}>${l}</option>`).join('')}
      </select>
      <button class="btn btn-danger btn-icon sm" onclick="this.closest('.fe-field-row').remove()">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>
    <div style="display:flex;gap:8px;align-items:center">
      <input class="form-input fe-field-placeholder" placeholder="Texto de ayuda (opcional)" value="${_esc(f.placeholder)}" style="flex:1;font-size:var(--t-xs)">
      <label style="display:flex;align-items:center;gap:4px;font-size:var(--t-xs);color:var(--tx-3);flex-shrink:0;white-space:nowrap">
        <input type="checkbox" class="fe-field-required" ${f.required?'checked':''}> Obligatorio
      </label>
    </div>
    ${optionsHtml}
  </div>`;
}

function _saveForm(editId){
  const name = document.getElementById('fe-name').value.trim();
  if(!name){ toast('El nombre es obligatorio','error'); return; }
  const icon = document.getElementById('fe-icon').value;
  const fieldRows = document.querySelectorAll('#fe-fields-list .fe-field-row');
  const fields = Array.from(fieldRows).map(row=>{
    const type = row.querySelector('.fe-field-type').value;
    const optRaw = row.querySelector('.fe-field-options')?.value || '';
    const options = type === 'select'
      ? optRaw.split(',').map(o=>o.trim()).filter(Boolean)
      : [];
    return {
      id:          row.dataset.fieldId,
      label:       row.querySelector('.fe-field-label').value.trim(),
      type,
      placeholder: row.querySelector('.fe-field-placeholder').value.trim(),
      required:    row.querySelector('.fe-field-required').checked,
      options,
    };
  }).filter(f=>f.label);

  const forms = getForms();
  if(editId){
    const idx = forms.findIndex(f=>f.id===editId);
    if(idx!==-1) forms[idx] = {...forms[idx],name,icon,fields};
    else forms.push({id:editId,name,icon,fields,createdAt:Date.now()});
  } else {
    forms.push({id:`form_${uid()}`,name,icon,fields,createdAt:Date.now()});
  }
  _saveForms(forms);
  Overlay.pop();
  toast('Formulario guardado ✓','success',2000);
  Router.go('form-editor');
}

/* ── ACCIONES KPIs ────────────────────────────────────── */
function showNewKpi(){
  const overlay = document.createElement('div');
  overlay.id='kpi-new-overlay';
  overlay.className='overlay-backdrop';
  overlay.innerHTML=`
    <div class="bottom-sheet" style="padding-bottom:max(var(--sp-6),env(safe-area-inset-bottom))">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <i class="fa-solid fa-chart-bar"></i>
        <span>Nuevo KPI</span>
        <button class="modal-close" onclick="Overlay.pop()">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
      <div class="sheet-body">
        <div class="form-group">
          <label class="form-label">Nombre del KPI <sup>*</sup></label>
          <input class="form-input" id="kpi-new-label" placeholder="Ej: Ventas, Pedidos, Activaciones...">
        </div>
        <div class="form-group">
          <label class="form-label">Unidad <span style="color:var(--tx-3);font-weight:400">(opcional)</span></label>
          <input class="form-input" id="kpi-new-unit" placeholder="€, uds, %...">
        </div>
        <div class="form-row" style="gap:8px">
          <div class="form-group">
            <label class="form-label">Mínimo</label>
            <input class="form-input" id="kpi-new-min" type="number" placeholder="0">
          </div>
          <div class="form-group">
            <label class="form-label">Máximo</label>
            <input class="form-input" id="kpi-new-max" type="number" placeholder="">
          </div>
        </div>
      </div>
      <div class="visit-footer">
        <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cancelar</button>
        <button class="btn btn-primary" style="flex:2" onclick="_createKpi()">
          <i class="fa-solid fa-floppy-disk"></i> Crear KPI
        </button>
      </div>
    </div>`;
  Overlay.push(overlay);
  setTimeout(()=>document.getElementById('kpi-new-label')?.focus(),200);
}

function _createKpi(){
  const label = document.getElementById('kpi-new-label').value.trim();
  if(!label){ toast('El nombre es obligatorio','error'); return; }
  const unit  = document.getElementById('kpi-new-unit').value.trim();
  const minV  = document.getElementById('kpi-new-min').value;
  const maxV  = document.getElementById('kpi-new-max').value;
  const kpis  = getKpis();
  kpis.push({id:`kpi_${uid()}`,label,unit,min:minV?Number(minV):undefined,max:maxV?Number(maxV):undefined});
  _saveKpis(kpis);
  Overlay.pop();
  toast('KPI creado ✓','success',2000);
  const kl = document.getElementById('kpis-list');
  if(kl) kl.innerHTML = _renderKpiList();
}

function deleteKpi(id){
  confirm_('¿Eliminar este KPI?',()=>{
    _saveKpis(getKpis().filter(k=>k.id!==id));
    const kl = document.getElementById('kpis-list');
    if(kl) kl.innerHTML=_renderKpiList();
    toast('KPI eliminado','info');
  },'Eliminar KPI');
}

/* _localDate definida en core.js */

/* ── VISIBILITYCHANGE: relanzar timer ─────────────────── */
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='visible' && _jornadaActive){
    const {routeId,dateStr} = _jornadaActive;
    const s = getSession(routeId,dateStr);
    if(s.state==='running'){
      if(_jornadaInterval) clearInterval(_jornadaInterval);
      _jornadaInterval = setInterval(()=>_renderTimerBar(routeId,dateStr),1000);
      _renderTimerBar(routeId,dateStr);
      // resetear lastGps para no acumular km de la pausa
      if(s.lastGps){ s.lastGps=null; setSession(routeId,dateStr,s); }
    }
  } else if(document.visibilityState==='hidden'){
    if(_jornadaInterval){ clearInterval(_jornadaInterval); _jornadaInterval=null; }
  }
});

/* ═══════════════════════════════════════════════════════
   CONTACTO RÁPIDO DE PARADA
   ═══════════════════════════════════════════════════════ */
function openStopContact(stopId) {
  const stop = State.getStop(stopId);
  if (!stop) return;

  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.innerHTML = `
  <div class="modal" style="max-width:360px" onclick="event.stopPropagation()">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-address-card"></i> ${esc(stop.name)}</h3>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="display:flex;flex-direction:column;gap:10px">
      ${stop.contact ? `
        <div style="display:flex;align-items:center;gap:10px;padding:10px;background:var(--bg-surface);border-radius:var(--r-sm)">
          <i class="fa-solid fa-user" style="color:var(--tx-3);width:16px;text-align:center"></i>
          <span style="font-size:var(--t-sm)">${esc(stop.contact)}</span>
        </div>` : ''}
      ${stop.phone ? `
        <a href="tel:${stop.phone}" style="display:flex;align-items:center;gap:10px;padding:12px;background:var(--green-bg);border:1px solid var(--green-bd);border-radius:var(--r-sm);text-decoration:none">
          <i class="fa-solid fa-phone" style="color:var(--green);width:16px;text-align:center"></i>
          <div>
            <div style="font-size:var(--t-xs);color:var(--tx-3)">Teléfono</div>
            <div style="font-weight:600;color:var(--green)">${stop.phone}</div>
          </div>
        </a>` : ''}
      ${stop.mobile ? `
        <a href="tel:${stop.mobile}" style="display:flex;align-items:center;gap:10px;padding:12px;background:var(--blue-bg);border:1px solid var(--blue-bd);border-radius:var(--r-sm);text-decoration:none">
          <i class="fa-solid fa-mobile-screen" style="color:var(--blue);width:16px;text-align:center"></i>
          <div>
            <div style="font-size:var(--t-xs);color:var(--tx-3)">Móvil</div>
            <div style="font-weight:600;color:var(--blue)">${stop.mobile}</div>
          </div>
        </a>` : ''}
      ${stop.email ? `
        <a href="mailto:${stop.email}" style="display:flex;align-items:center;gap:10px;padding:12px;background:var(--bg-surface);border:1px solid var(--bd-0);border-radius:var(--r-sm);text-decoration:none">
          <i class="fa-solid fa-envelope" style="color:var(--tx-2);width:16px;text-align:center"></i>
          <div>
            <div style="font-size:var(--t-xs);color:var(--tx-3)">Email</div>
            <div style="font-weight:600;color:var(--tx-1)">${stop.email}</div>
          </div>
        </a>` : ''}
      ${stop.horario ? `
        <div style="display:flex;align-items:center;gap:10px;padding:10px;background:var(--bg-surface);border-radius:var(--r-sm)">
          <i class="fa-regular fa-clock" style="color:var(--tx-3);width:16px;text-align:center"></i>
          <span style="font-size:var(--t-sm);color:var(--tx-2)">${esc(stop.horario)}</span>
        </div>` : ''}
    </div>
  </div>`;
  Overlay.push(ov);
}

/* ═══════════════════════════════════════════════════════
   HISTORIAL DE VISITAS — calendario + lista
   ═══════════════════════════════════════════════════════ */
function openVisitHistory(stopId, currentRouteId) {
  const stop = State.getStop(stopId);
  if (!stop) return;

  const allVisits = DB.getVisits();
  const history = Object.entries(allVisits)
    .filter(([k]) => k.endsWith('_' + stopId))
    .map(([k, v]) => {
      const parts = k.split('_');
      return { routeId: parts[0], dateStr: parts[1], stopId: parts[2], ...v };
    })
    .sort((a, b) => b.dateStr.localeCompare(a.dateStr));

  const visitedDates = new Set(history.map(h => h.dateStr));

  /* Inicializar estado del calendario al mes actual */
  const today = new Date();
  _hCalStopId = stopId;
  _hCalRouteId = currentRouteId;
  _hCalVisitedDates = visitedDates;
  _hCalYear = today.getFullYear();
  _hCalMonth = today.getMonth();

  const listHtml = _buildHistoryList(history);

  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.innerHTML = `
  <div class="modal" style="max-width:480px;max-height:92vh;display:flex;flex-direction:column" onclick="event.stopPropagation()">
    <div class="modal-header">
      <h3 class="modal-title">
        <i class="fa-solid fa-clock-rotate-left"></i> ${esc(stop.name)}
        <span style="font-weight:400;color:var(--tx-3);font-size:var(--t-sm)"> · ${history.length} visita${history.length!==1?'s':''}</span>
      </h3>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="overflow-y:auto;flex:1;padding:16px">
      <div style="font-size:var(--t-xs);font-weight:700;color:var(--tx-3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Días visitados</div>
      <div id="visit-cal-wrap">
        ${_buildVisitCalendar(_hCalYear, _hCalMonth, visitedDates)}
      </div>
      <div style="font-size:var(--t-xs);font-weight:700;color:var(--tx-3);text-transform:uppercase;letter-spacing:.06em;margin:16px 0 8px">
        Historial
      </div>
      ${listHtml}
    </div>
  </div>`;
  Overlay.push(ov);
}

function _buildHistoryList(history) {
  if (!history.length) return `
    <div style="text-align:center;padding:32px 0;color:var(--tx-3)">
      <i class="fa-solid fa-clock-rotate-left" style="font-size:2rem;display:block;margin-bottom:8px;opacity:.25"></i>
      <span style="font-size:var(--t-sm)">Sin visitas registradas</span>
    </div>`;

  const kpis = DB.getKpis();
  return history.slice(0, 30).map(h => {
    const route   = State.getRoute(h.routeId);
    const durMs   = (h.checkOutTs && h.checkInTs) ? h.checkOutTs - h.checkInTs : null;
    const durStr  = durMs ? `${Math.floor(durMs/60000)}min` : null;
    const kpiItems = kpis.filter(k => h['kpi_'+k.id] != null && h['kpi_'+k.id] !== '');
    const hasPhotos = (h.photos||[]).length > 0;

    /* Color del estado */
    const estadoColor = {
      'Realizada':'var(--green)','Visitado':'var(--green)',
      'Cliente ausente':'var(--amber)','No interesado':'var(--red)',
      'Cerrado':'var(--red)'
    }[h.estado] || 'var(--indigo)';

    return `
    <div class="visit-history-card" onclick="openVisitDetail('${h.routeId}','${h.dateStr}','${h.stopId}')">
      <!-- Cabecera -->
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
        <div>
          <div style="font-weight:700;font-size:var(--t-md)">${_fmtDateShort(h.dateStr)}</div>
          <div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:1px">${route?.name||h.routeId}</div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
          ${h.estado ? `<span style="font-size:11px;font-weight:600;padding:2px 8px;border-radius:20px;background:${estadoColor}22;color:${estadoColor}">${h.estado}</span>` : ''}
          ${durStr ? `<span style="font-size:var(--t-xs);color:var(--tx-3)"><i class="fa-regular fa-clock" style="margin-right:3px"></i>${durStr}</span>` : ''}
        </div>
      </div>
      <!-- Horario check-in/out -->
      ${h.checkInTs ? `<div style="font-size:var(--t-xs);color:var(--tx-3);margin-bottom:6px">
        <i class="fa-solid fa-right-to-bracket" style="color:var(--green);margin-right:4px"></i>${_fmtTime(h.checkInTs)}
        ${h.checkOutTs ? ` &nbsp;→&nbsp; <i class="fa-solid fa-right-from-bracket" style="color:var(--amber)"></i> ${_fmtTime(h.checkOutTs)}` : ''}
      </div>` : ''}
      <!-- Notas -->
      ${h.notas ? `<div style="font-size:var(--t-sm);color:var(--tx-2);margin-bottom:6px;padding:6px 8px;background:var(--bg-surface);border-radius:var(--r-xs)">${esc(h.notas)}</div>` : ''}
      <!-- KPIs -->
      ${kpiItems.length ? `<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:6px">
        ${kpiItems.map(k=>`<span class="field-chip"><b>${esc(k.label)}:</b> ${h['kpi_'+k.id]}${k.unit?' '+k.unit:''}</span>`).join('')}
      </div>` : ''}
      <!-- Fotos miniatura -->
      ${hasPhotos ? `<div style="display:flex;gap:4px;flex-wrap:wrap">
        ${(h.photos||[]).slice(0,4).map(p=>`<img src="${p}" style="width:44px;height:44px;object-fit:cover;border-radius:4px;border:1px solid var(--bd-0)">`).join('')}
        ${(h.photos||[]).length > 4 ? `<div style="width:44px;height:44px;border-radius:4px;background:var(--bg-surface);display:flex;align-items:center;justify-content:center;font-size:var(--t-xs);color:var(--tx-3)">+${(h.photos||[]).length-4}</div>` : ''}
      </div>` : ''}
      <!-- Flecha detalle -->
      <div style="text-align:right;margin-top:6px">
        <span style="font-size:var(--t-xs);color:var(--indigo)">Ver detalle <i class="fa-solid fa-chevron-right" style="font-size:10px"></i></span>
      </div>
    </div>`;
  }).join('');
}

/* Estado del mini-calendario navegable */
function _buildVisitCalendar(year, month, visitedDates) {
  const y = year, m = month;
  const daysInMonth = new Date(y, m+1, 0).getDate();
  const firstDay = (new Date(y, m, 1).getDay() + 6) % 7;
  const monthName = new Date(y, m, 1).toLocaleDateString('es-ES', {month:'long', year:'numeric'});
  let cells = '';
  for (let i = 0; i < firstDay; i++) cells += `<div></div>`;
  for (let d = 1; d <= daysInMonth; d++) {
    const ds = `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const isVisited = visitedDates.has(ds);
    const isToday = ds === _localDate(new Date());
    cells += `<div class="visit-cal-day ${isVisited?'visited':''} ${isToday?'today':''}" title="${ds}">${d}</div>`;
  }
  return `
  <div class="visit-cal-nav">
    <button class="btn btn-ghost btn-icon sm" onclick="_calNav(-1)">
      <i class="fa-solid fa-chevron-left"></i>
    </button>
    <span style="font-size:var(--t-sm);font-weight:600;color:var(--tx-1);text-transform:capitalize;flex:1;text-align:center">${monthName}</span>
    <button class="btn btn-ghost btn-icon sm" onclick="_calNav(1)">
      <i class="fa-solid fa-chevron-right"></i>
    </button>
  </div>
  <div class="visit-cal-grid" style="margin-top:6px">
    ${['L','M','X','J','V','S','D'].map(d=>`<div class="visit-cal-head">${d}</div>`).join('')}
    ${cells}
  </div>`;
}

function _calNav(dir) {
  _hCalMonth += dir;
  if (_hCalMonth > 11) { _hCalMonth = 0; _hCalYear++; }
  if (_hCalMonth < 0)  { _hCalMonth = 11; _hCalYear--; }
  const wrap = document.getElementById('visit-cal-wrap');
  if (wrap) wrap.innerHTML = _buildVisitCalendar(_hCalYear, _hCalMonth, _hCalVisitedDates);
}

function _fmtDateShort(s) {
  if (!s) return '—';
  return new Date(s + 'T12:00').toLocaleDateString('es-ES', {day:'numeric', month:'short', year:'numeric'});
}

/* ═══════════════════════════════════════════════════════
   VISTA ÚNICA DE VISITA COMPLETADA
   Resumen de solo lectura + mapa del recorrido GPS
   ═══════════════════════════════════════════════════════ */
function openVisitDetail(routeId, dateStr, stopId) {
  const stop  = State.getStop(stopId);
  const visit = getVisit(routeId, dateStr, stopId);
  if (!stop || !visit) return;

  const route  = State.getRoute(routeId);
  const kpis   = DB.getKpis();
  const forms  = getForms();
  const sess   = getSession(routeId, dateStr);
  const gpsPath = sess?.gpsPath || [];

  const durMs  = (visit.checkOutTs && visit.checkInTs) ? visit.checkOutTs - visit.checkInTs : null;
  const durStr = durMs ? `${Math.floor(durMs/60000)} min` : '—';

  const estadoColor = {
    'Realizada':'var(--green)','Visitado':'var(--green)',
    'Cliente ausente':'var(--amber)','No interesado':'var(--red)',
    'Cerrado':'var(--red)'
  }[visit.estado] || 'var(--indigo)';

  /* KPIs con valor */
  const kpiItems = kpis.filter(k => visit['kpi_'+k.id] != null && visit['kpi_'+k.id] !== '');

  /* Campos de formularios con valor */
  const formFields = forms.flatMap(f => f.fields.filter(field => visit[field.id] != null && visit[field.id] !== ''));

  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.innerHTML = `
  <div class="modal" style="max-width:520px;max-height:92vh;display:flex;flex-direction:column" onclick="event.stopPropagation()">
    <div class="modal-header">
      <h3 class="modal-title">
        <i class="fa-solid fa-clipboard-check" style="color:var(--green)"></i>
        Visita completada
      </h3>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="overflow-y:auto;flex:1;padding:16px;display:flex;flex-direction:column;gap:12px">

      <!-- Hero parada -->
      <div style="background:var(--bg-surface);border-radius:var(--r-md);padding:14px">
        <div style="font-weight:700;font-size:var(--t-lg);margin-bottom:2px">${esc(stop.name)}</div>
        <div style="font-size:var(--t-xs);color:var(--tx-3)">${[stop.addr,stop.town].filter(Boolean).join(' · ')||'—'}</div>
        <div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:8px;align-items:center">
          ${visit.estado ? `<span style="font-size:12px;font-weight:700;padding:3px 10px;border-radius:20px;background:${estadoColor}22;color:${estadoColor}">${esc(visit.estado)}</span>` : ''}
          <span style="font-size:var(--t-xs);color:var(--tx-3)">${_fmtDateShort(dateStr)}</span>
          <span style="font-size:var(--t-xs);color:var(--tx-3)">${route?.name||routeId}</span>
        </div>
      </div>

      <!-- Tiempos -->
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
        <div style="background:var(--green-bg);border:1px solid var(--green-bd);border-radius:var(--r-sm);padding:10px;text-align:center">
          <div style="font-size:var(--t-xs);color:var(--tx-3);margin-bottom:2px">Entrada</div>
          <div style="font-weight:700;color:var(--green)">${visit.checkInTs ? _fmtTime(visit.checkInTs) : '—'}</div>
        </div>
        <div style="background:var(--amber-bg);border:1px solid var(--amber-bd);border-radius:var(--r-sm);padding:10px;text-align:center">
          <div style="font-size:var(--t-xs);color:var(--tx-3);margin-bottom:2px">Salida</div>
          <div style="font-weight:700;color:var(--amber)">${visit.checkOutTs ? _fmtTime(visit.checkOutTs) : '—'}</div>
        </div>
        <div style="background:var(--bg-surface);border:1px solid var(--bd-0);border-radius:var(--r-sm);padding:10px;text-align:center">
          <div style="font-size:var(--t-xs);color:var(--tx-3);margin-bottom:2px">Duración</div>
          <div style="font-weight:700;color:var(--tx-1)">${durStr}</div>
        </div>
      </div>

      <!-- Tramo GPS de la visita -->
      ${(visit.latIn && visit.lngIn) ? `
      <div style="background:var(--green-bg);border:1px solid var(--green-bd);border-radius:var(--r-sm);padding:10px;display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-size:var(--t-xs);color:var(--tx-3);margin-bottom:2px">Posición registrada</div>
          <div style="font-size:var(--t-sm);color:var(--green);font-weight:500">
            <i class="fa-solid fa-location-dot"></i>
            ${visit.latIn.toFixed(5)}, ${visit.lngIn.toFixed(5)}
          </div>
        </div>
        <button class="btn btn-ghost btn-sm"
          onclick="Overlay.pop();Router.go('map',{routeId:'${routeId}',dateStr:'${dateStr}',stopId:'${stopId}'})">
          <i class="fa-solid fa-map-location-dot"></i> Ver tramo
        </button>
      </div>` : ''}

      <!-- Notas -->
      ${visit.notas ? `
      <div style="background:var(--bg-surface);border-radius:var(--r-sm);padding:12px">
        <div style="font-size:var(--t-xs);font-weight:700;color:var(--tx-3);text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">Notas</div>
        <div style="font-size:var(--t-sm);color:var(--tx-1);line-height:1.5">${esc(visit.notas)}</div>
      </div>` : ''}

      <!-- Campos de formulario -->
      ${formFields.length ? `
      <div style="background:var(--bg-surface);border-radius:var(--r-sm);padding:12px">
        <div style="font-size:var(--t-xs);font-weight:700;color:var(--tx-3);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">Formulario</div>
        <div style="display:flex;flex-direction:column;gap:6px">
          ${formFields.map(f=>`
          <div style="display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid var(--bd-0)">
            <span style="font-size:var(--t-sm);color:var(--tx-3)">${f.label}</span>
            <span style="font-size:var(--t-sm);font-weight:600;color:var(--tx-1);text-align:right">${visit[f.id]}</span>
          </div>`).join('')}
        </div>
      </div>` : ''}

      <!-- KPIs -->
      ${kpiItems.length ? `
      <div style="background:var(--bg-surface);border-radius:var(--r-sm);padding:12px">
        <div style="font-size:var(--t-xs);font-weight:700;color:var(--tx-3);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">KPIs</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px">
          ${kpiItems.map(k=>`
          <div style="background:var(--indigo-dim);border-radius:var(--r-sm);padding:10px;text-align:center">
            <div style="font-size:1.2rem;font-weight:800;color:var(--indigo)">${visit['kpi_'+k.id]}${k.unit?' '+k.unit:''}</div>
            <div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:2px">${esc(k.label)}</div>
          </div>`).join('')}
        </div>
      </div>` : ''}

      <!-- Fotos -->
      ${(visit.photos||[]).length ? `
      <div>
        <div style="font-size:var(--t-xs);font-weight:700;color:var(--tx-3);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">Fotos</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:6px">
          ${(visit.photos||[]).map(p=>`<img src="${p}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:var(--r-sm);border:1px solid var(--bd-0)">`).join('')}
        </div>
      </div>` : ''}

      <!-- Mapa del recorrido -->
      <div>
        <div style="font-size:var(--t-xs);font-weight:700;color:var(--tx-3);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">
          Recorrido de la jornada
          ${gpsPath.length ? `<span style="font-weight:400;text-transform:none;margin-left:6px">${gpsPath.length} puntos · ${(sess.distance||0).toFixed(1)} km</span>` : ''}
        </div>
        ${gpsPath.length >= 2 ? `
        <div id="visit-detail-map" style="height:200px;border-radius:var(--r-md);overflow:hidden;border:1px solid var(--bd-0)"></div>
        ` : `
        <div style="height:80px;border-radius:var(--r-md);border:1px solid var(--bd-0);background:var(--bg-surface);display:flex;align-items:center;justify-content:center;color:var(--tx-3);font-size:var(--t-sm)">
          <i class="fa-solid fa-route" style="margin-right:6px;opacity:.4"></i> Sin datos de GPS para esta jornada
        </div>`}
      </div>

    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cerrar</button>
      <button class="btn btn-outline" onclick="openVisit('${routeId}','${dateStr}','${stopId}');Overlay.pop()">
        <i class="fa-solid fa-pen"></i> Editar visita
      </button>
    </div>
  </div>`;

  Overlay.push(ov);

  /* Renderizar mapa del recorrido si hay GPS */
  if (gpsPath.length >= 2) {
    requestAnimationFrame(() => {
      const mapEl = document.getElementById('visit-detail-map');
      if (!mapEl || typeof L === 'undefined') return;

      const detailMap = L.map(mapEl, { zoomControl: false, attributionControl: false });
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(detailMap);

      /* Polilínea del recorrido */
      const latlngs = gpsPath.map(p => [p.lat, p.lng]);
      const poly = L.polyline(latlngs, {
        color: '#4f46e5', weight: 4, opacity: .85,
        dashArray: null,
      }).addTo(detailMap);

      /* Marcador inicio (verde) */
      L.circleMarker(latlngs[0], {
        radius: 7, fillColor: '#16a34a', color: '#fff',
        weight: 2, fillOpacity: 1
      }).bindTooltip('Inicio').addTo(detailMap);

      /* Marcador fin (rojo) */
      L.circleMarker(latlngs[latlngs.length - 1], {
        radius: 7, fillColor: '#dc2626', color: '#fff',
        weight: 2, fillOpacity: 1
      }).bindTooltip('Fin').addTo(detailMap);

      /* Si la parada tiene coords, marcarla */
      if (stop.lat) {
        L.marker([stop.lat, stop.lng], {
          icon: L.divIcon({
            className: '',
            html: `<div style="width:20px;height:20px;background:#4f46e5;border:2px solid #fff;border-radius:50%;box-shadow:0 2px 4px rgba(0,0,0,.3)"></div>`,
            iconSize: [20,20], iconAnchor: [10,10]
          })
        }).bindTooltip(stop.name).addTo(detailMap);
      }

      detailMap.fitBounds(poly.getBounds(), { padding: [12, 12] });
    });
  }
}
