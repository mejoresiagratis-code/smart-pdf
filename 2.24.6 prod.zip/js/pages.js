/* ═══════════════════════════════════════════════════════════
   GESTOR DE RUTAS — Páginas v2
   Dashboard · Rutas · Paradas · Calendario · Informes · Ajustes
   ═══════════════════════════════════════════════════════════ */

/* ─── helpers ──────────────────────────────────────────── */
function esc(s){
  if(s==null) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
function _empty(title,sub,btnLabel,btnFn){
  return `<div class="empty-state">
    <div class="empty-icon"><i class="fa-solid fa-inbox"></i></div>
    <div class="empty-title">${title}</div>
    <div class="empty-sub">${sub}</div>
    ${btnLabel?`<button class="btn btn-primary mt-3" onclick="${btnFn}">${btnLabel}</button>`:''}
  </div>`;
}

/* ═══════════════════════════════════════════════════════
   DASHBOARD
   ═══════════════════════════════════════════════════════ */
Router.register('dashboard',(el)=>{
  const role = State.prefs._role || 'rep';
  const g    = State.globalStats();
  const today = _localDate(new Date());

  /* ── Enrutar al dashboard correcto según rol ── */
  if (role === 'rep') {
    _dashboardRep(el, g, today);
  } else {
    _dashboardManager(el, g, today, role);
  }
});

/* ════════════════════════════════════════════════════════
   DASHBOARD REP — jornada de hoy + próximas rutas propias
   ════════════════════════════════════════════════════════ */
function _dashboardRep(el, g, today) {
  const todayRoute = State.schedule[today] ? State.getRoute(State.schedule[today]) : null;

  /* Renderizado inmediato con datos locales */
  el.innerHTML=`
  <div class="today-card mb-4">
    <div class="today-inner">
      <div class="today-left">
        <div class="today-date">${new Date().toLocaleDateString('es-ES',{weekday:'long',day:'numeric',month:'long'})}</div>
        ${todayRoute
          ? `<div class="today-route">${todayRoute.name}</div>
             <div class="today-sub">${State.routeStats(todayRoute.id).total} paradas planificadas</div>`
          : `<div class="today-route" style="opacity:.5">Sin ruta asignada hoy</div>
             <div class="today-sub">Tu jefe de zona asignará rutas próximamente</div>`
        }
      </div>
      <div class="today-actions">
        ${todayRoute ? `<div style="display:flex;gap:var(--sp-2);flex-wrap:wrap" id="today-btns"></div>` : ''}
      </div>
    </div>
  </div>

  <div class="grid-4 mb-4" id="rep-kpis">
    <div class="stat-card accent-blue">
      <div class="stat-card-label">Visitas hoy</div>
      <div class="stat-card-value" id="kpi-visits-today">—</div>
    </div>
    <div class="stat-card accent-green">
      <div class="stat-card-label">Cobertura hoy</div>
      <div class="stat-card-value" id="kpi-coverage-today">—</div>
    </div>
    <div class="stat-card accent-indigo">
      <div class="stat-card-label">Visitas semana</div>
      <div class="stat-card-value" id="kpi-visits-week">—</div>
    </div>
    <div class="stat-card">
      <div class="stat-card-label">PDVs sin visitar (30d)</div>
      <div class="stat-card-value" id="kpi-unvisited">—</div>
    </div>
  </div>

  <div class="grid-2 mb-4">
    <div class="card">
      <div class="card-header">
        <div class="card-title"><i class="fa-solid fa-calendar-check"></i> Esta semana</div>
        <div style="display:flex;gap:6px">
          <button class="btn btn-ghost btn-sm active" id="period-today" onclick="_repPeriod('today')">Hoy</button>
          <button class="btn btn-ghost btn-sm" id="period-week" onclick="_repPeriod('week')">Semana</button>
          <button class="btn btn-ghost btn-sm" id="period-month" onclick="_repPeriod('month')">Mes</button>
        </div>
      </div>
      <div id="rep-period-detail" class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">
        <i class="fa-solid fa-spinner fa-spin"></i> Cargando…
      </div>
      <div id="rep-target-bar" class="card-body" style="display:none;padding-top:0"></div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-calendar-days"></i> Próximas rutas</div></div>
      ${_renderUpcoming()}
    </div>
  </div>`;

  /* Botón jornada */
  requestAnimationFrame(()=>{
    const r2=State.schedule[today]?State.getRoute(State.schedule[today]):null;
    const btn=document.getElementById('today-btns');
    if(!btn||!r2) return;
    const s=typeof getSession==='function'?getSession(r2.id,today):null;
    const running=s&&s.state==='running', finished=s&&s.state==='finished';
    btn.innerHTML=`<button class="btn ${running?'btn-outline':'btn-primary'}"
      onclick="Router.go('jornada',{routeId:'${r2.id}',dateStr:'${today}'})">
      <i class="fa-solid ${running?'fa-location-dot':finished?'fa-eye':'fa-play'}"></i>
      ${running?'Ver jornada':finished?'Ver resumen':'Iniciar jornada'}
    </button>`;
  });

  /* Cargar KPIs desde API */
  if (Auth.isLoggedIn()) _loadRepDashboard('today');
}

async function _loadRepDashboard(period='today') {
  try {
    const data = await API.get(`/stats/dashboard?period=${period}`);
    if (!data) return;
    const kpis = data.kpis || {};

    /* KPIs header */
    const todayVisits = (data.visits||[]).filter(v => {
      const d = new Date(v.checkInAt||0);
      return d.toDateString() === new Date().toDateString();
    }).length;
    const todayStops = (() => {
      const today = _localDate(new Date());
      const rId = State.schedule[today];
      if (!rId) return 0;
      return State.routeStats(rId).total || 0;
    })();

    const el = (id) => document.getElementById(id);
    if (el('kpi-visits-today')) el('kpi-visits-today').textContent = period === 'today' ? (kpis.total_visits ?? '—') : '—';
    if (el('kpi-coverage-today')) el('kpi-coverage-today').textContent =
      kpis.coverage_pct != null ? `${kpis.coverage_pct}%` : '—';
    if (el('kpi-visits-week')) el('kpi-visits-week').textContent = kpis.total_visits ?? '—';
    if (el('kpi-unvisited')) el('kpi-unvisited').textContent = kpis.unvisited_stops ?? '—';

    /* Detalle periodo */
    const detail = document.getElementById('rep-period-detail');
    if (!detail) return;

    const prev = data.comparison?.visits ?? null;
    const curr = kpis.total_visits ?? 0;
    const diff = prev != null ? curr - prev : null;
    const diffColor = diff != null ? (diff>=0 ? 'var(--green)' : 'var(--red)') : '';
    const diffArrow = diff != null ? (diff>=0 ? '▲' : '▼') : '';
    const diffHtml  = diff != null
      ? `<span style="color:${diffColor};font-size:var(--t-xs)">${diffArrow} ${Math.abs(diff)} vs periodo anterior</span>`
      : '';

    const sessions = data.sessions || [];
    const finished = sessions.filter(s => s.state === 'finished').length;
    const distKm   = sessions.reduce((a,s) => a + parseFloat(s.distance_km||0), 0).toFixed(1);
    const elapsedH = Math.floor(sessions.reduce((a,s) => a + parseInt(s.elapsed_s||0), 0) / 3600);

    detail.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:8px">
      <div style="display:flex;justify-content:space-between">
        <span style="color:var(--tx-2)">Visitas registradas</span>
        <strong>${curr}</strong>
      </div>
      <div style="display:flex;justify-content:space-between">
        <span style="color:var(--tx-2)">Jornadas completadas</span>
        <strong>${finished} / ${sessions.length}</strong>
      </div>
      <div style="display:flex;justify-content:space-between">
        <span style="color:var(--tx-2)">Distancia recorrida</span>
        <strong>${distKm} km</strong>
      </div>
      <div style="display:flex;justify-content:space-between">
        <span style="color:var(--tx-2)">Tiempo en campo</span>
        <strong>${elapsedH}h</strong>
      </div>
      ${diff != null ? `<div style="margin-top:4px">${diffHtml}</div>` : ''}
      ${(data.visits||[]).length === 0 && period === 'today' ?
        '<div style="color:var(--tx-3);font-size:var(--t-xs);margin-top:4px">Sin visitas registradas hoy</div>' : ''}
    </div>`;

    /* Activar botón periodo correcto */
    ['today','week','month'].forEach(p => {
      const b = document.getElementById(`period-${p}`);
      if (b) b.classList.toggle('active', p === period);
    });

    /* Barra de objetivo del rep (si tiene targets configurados) */
    const tgtEl = document.getElementById('rep-target-bar');
    if (tgtEl) {
      const tgt = data.targets?.visits_week ?? null;
      if (tgt > 0 && period === 'week') {
        const visits = kpis.total_visits ?? 0;
        const pct = Math.min(100, Math.round(visits / tgt * 100));
        const col = pct >= 100 ? 'var(--green)' : pct >= 60 ? 'var(--indigo)' : pct >= 30 ? 'var(--amber)' : 'var(--red)';
        const msg = pct >= 100 ? '¡Objetivo alcanzado!' : `${pct}% del objetivo semanal`;
        tgtEl.innerHTML = `
          <div style="display:flex;align-items:center;gap:8px;padding:10px 0;border-top:1px solid var(--bd-0);margin-top:8px">
            <i class="fa-solid fa-bullseye" style="color:${col};font-size:12px;flex-shrink:0"></i>
            <div style="flex:1">
              <div style="display:flex;justify-content:space-between;margin-bottom:4px">
                <span style="font-size:var(--t-xs);color:var(--tx-3)">Objetivo semanal</span>
                <span style="font-size:var(--t-xs);font-weight:600;color:${col}">${visits} / ${tgt} visitas</span>
              </div>
              <div style="height:6px;background:var(--color-background-secondary);border-radius:3px;overflow:hidden">
                <div style="width:${pct}%;height:100%;background:${col};border-radius:3px;transition:width .4s"></div>
              </div>
              <div style="font-size:10px;color:${col};margin-top:3px">${msg}</div>
            </div>
          </div>`;
        tgtEl.style.display = '';
      } else {
        tgtEl.style.display = 'none';
      }
    }

  } catch(e) {
    const detail = document.getElementById('rep-period-detail');
    if (detail) detail.innerHTML = `<span style="color:var(--tx-3)">Sin datos disponibles</span>`;
  }
}

function _repPeriod(period) {
  const detail = document.getElementById('rep-period-detail');
  if (detail) detail.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Cargando…';
  _loadRepDashboard(period);
}

/* ════════════════════════════════════════════════════════
   DASHBOARD MANAGER — supervisor / admin / owner
   ════════════════════════════════════════════════════════ */
function _dashboardManager(el, g, today, role) {
  const roleTitle = {supervisor:'Mi zona',admin:'Mi equipo',owner:'Toda la organización'}[role]||'Resumen';

  el.innerHTML = `
  <div class="page-header mb-4">
    <div>
      <h1 class="page-h1">${roleTitle}</h1>
      <p class="page-sub">${new Date().toLocaleDateString('es-ES',{weekday:'long',day:'numeric',month:'long'})}</p>
    </div>
    <div style="display:flex;gap:6px">
      <button class="btn btn-ghost btn-sm active" id="mgr-period-today"  onclick="_mgrPeriod('today')">Hoy</button>
      <button class="btn btn-ghost btn-sm"         id="mgr-period-week"   onclick="_mgrPeriod('week')">Semana</button>
      <button class="btn btn-ghost btn-sm"         id="mgr-period-month"  onclick="_mgrPeriod('month')">Mes</button>
    </div>
  </div>

  <div class="grid-4 mb-4">
    <div class="stat-card accent-blue">
      <div class="stat-card-label">Visitas del equipo</div>
      <div class="stat-card-value" id="mgr-kpi-visits">—</div>
      <div class="stat-card-sub" id="mgr-kpi-visits-diff"></div>
    </div>
    <div class="stat-card accent-green">
      <div class="stat-card-label">Jornadas activas</div>
      <div class="stat-card-value" id="mgr-kpi-active">—</div>
    </div>
    <div class="stat-card accent-indigo">
      <div class="stat-card-label">Cobertura media</div>
      <div class="stat-card-value" id="mgr-kpi-coverage">—</div>
    </div>
    <div class="stat-card accent-amber">
      <div class="stat-card-label">PDVs sin cobertura</div>
      <div class="stat-card-value" id="mgr-kpi-gaps">—</div>
    </div>
  </div>

  <div id="mgr-team-list" class="card mb-4">
    <div class="card-header">
      <div class="card-title"><i class="fa-solid fa-users"></i> Estado del equipo</div>
      <button class="btn btn-ghost btn-sm" onclick="showTeamJornadas()">
        <i class="fa-solid fa-list-check"></i> Jornadas hoy
      </button>
    </div>
    <div class="card-body" style="color:var(--tx-3);text-align:center">
      <i class="fa-solid fa-spinner fa-spin"></i> Cargando…
    </div>
  </div>

  ${role === 'owner' ? `
  <div id="mgr-by-admin" class="card mb-4">
    <div class="card-header"><div class="card-title"><i class="fa-solid fa-sitemap"></i> Por director</div></div>
    <div class="card-body" style="color:var(--tx-3);text-align:center">
      <i class="fa-solid fa-spinner fa-spin"></i>
    </div>
  </div>` : ''}`;

  if (Auth.isLoggedIn()) _loadMgrDashboard('today');
}

async function _loadMgrDashboard(period='today') {
  try {
    const data = await API.get(`/stats/dashboard?period=${period}`);
    if (!data) {
      const t = document.getElementById('mgr-team-list');
      if (t) t.innerHTML = `<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">
        <i class="fa-solid fa-rotate" style="color:var(--amber)"></i>
        Sesión caducada o sin conexión.
        <button class="btn btn-ghost btn-sm" onclick="_loadMgrDashboard('today')" style="margin-left:8px">Reintentar</button>
      </div>`;
      return;
    }

    const role = State.prefs._role;
    const agg  = data.aggregated || data.kpis || {};

    /* KPIs header */
    const el = (id) => document.getElementById(id);
    const visits = agg.total_visits ?? data.kpis?.total_visits ?? 0;
    const prev   = data.comparison?.visits ?? null;
    const diff   = prev != null ? visits - prev : null;

    if (el('mgr-kpi-visits')) el('mgr-kpi-visits').textContent = visits;
        if (el('mgr-kpi-visits-diff') && diff != null) {
      const mc = diff>=0 ? 'var(--green)' : 'var(--red)';
      const ma = diff>=0 ? '▲' : '▼';
      el('mgr-kpi-visits-diff').innerHTML =
        `<span style="color:${mc};font-size:11px">${ma} ${Math.abs(diff)} vs ant.</span>`;
    }

    const active = data.active_sessions?.length ?? agg.active_count ?? data.kpis?.active_now ?? 0;
    if (el('mgr-kpi-active')) el('mgr-kpi-active').textContent = active;

    const coverage = agg.coverage_pct ?? data.kpis?.coverage_pct;
    if (el('mgr-kpi-coverage')) el('mgr-kpi-coverage').textContent =
      coverage != null ? `${coverage}%` : '—';

    const gaps = (data.coverage_gaps || []).length;
    if (el('mgr-kpi-gaps')) el('mgr-kpi-gaps').textContent = gaps;

    /* Lista del equipo */
    const teamEl = el('mgr-team-list');
    if (teamEl) {
      let rows = [];

      if (role === 'supervisor') {
        /* Ranking: activos primero, luego por visitas desc */
        const sorted = [...(data.team || [])].sort((a,b) =>
          (b.active_now ? 1 : 0) - (a.active_now ? 1 : 0) || b.visits - a.visits
        );
        if (sorted.length === 0) {
          rows = [`<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">
            <i class="fa-solid fa-users-slash"></i> Tu equipo no tiene actividad en este periodo.
            Asegúrate de que tienes comerciales asignados a tu árbol con el botón Invitar en Ajustes.
          </div>`];
        } else {
          rows = sorted.map(rep => _repRow(rep));
        }
      } else if (role === 'admin') {
        rows = (data.supervisors || []).flatMap(sup => [
          _supRow(sup),
          ...(sup.team || []).map(rep => _repRow(rep, true))
        ]);
      } else if (role === 'owner') {
        /* owner: activeSessions en primer plano */
        rows = (data.active_sessions || []).map(s => `
          <div class="settings-row">
            <div class="settings-row-info">
              <div class="settings-row-title" style="display:flex;align-items:center;gap:8px">
                ${s.user_name||s.user_id}
                <span class="badge badge-green" style="font-size:10px">En jornada</span>
              </div>
              <div class="settings-row-sub">${s.route_name||'—'} · ${s.visits_today||0} visitas hoy</div>
            </div>
            <button class="btn btn-ghost btn-sm" onclick="Router.go('jornada',{routeId:'${s.route_id}',dateStr:'${s.date}'})">
              <i class="fa-solid fa-eye"></i>
            </button>
          </div>`);
        if (!rows.length) {
          rows = ['<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">Sin jornadas activas ahora mismo</div>'];
        }
      }

      teamEl.innerHTML = `
        <div class="card-header"><div class="card-title"><i class="fa-solid fa-users"></i> Estado del equipo</div></div>
        <div>${rows.join('')}</div>`;
    }

    /* Owner: desglose por director */
    if (role === 'owner') {
      const byAdminEl = el('mgr-by-admin');
      if (byAdminEl && data.by_admin?.length) {
        const maxV = Math.max(...data.by_admin.map(a => a.visits||0), 1);
        byAdminEl.innerHTML = `
          <div class="card-header"><div class="card-title"><i class="fa-solid fa-sitemap"></i> Por director</div></div>
          <div>${data.by_admin.map(a => {
            const pct = Math.round((a.visits||0)/maxV*100);
            const barColor = pct >= 80 ? 'var(--green)' : pct >= 40 ? 'var(--indigo)' : 'var(--amber)';
            return `
            <div class="settings-row node" style="cursor:pointer" onclick="_drillDownAdmin('${a.id}','${esc(a.name||a.email)}')">
              <div class="settings-row-info" style="flex:1;min-width:0">
                <div class="settings-row-title" style="display:flex;align-items:center;gap:8px">
                  ${esc(a.name||a.email)}
                  <i class="fa-solid fa-chevron-right" style="font-size:10px;color:var(--tx-3)"></i>
                </div>
                <div style="display:flex;align-items:center;gap:8px;margin-top:4px">
                  <div style="flex:1;height:5px;background:var(--color-background-secondary);border-radius:3px;overflow:hidden">
                    <div style="width:${pct}%;height:100%;background:${barColor};border-radius:3px"></div>
                  </div>
                  <span style="font-size:11px;color:var(--tx-3);white-space:nowrap">${a.visits} visitas</span>
                </div>
              </div>
            </div>`;
          }).join('')}
          </div>`;
      }
    }

    /* Activar botón periodo */
    ['today','week','month'].forEach(p => {
      const b = el(`mgr-period-${p}`);
      if (b) b.classList.toggle('active', p === period);
    });

  } catch(e) {
    console.error('[dashboard]', e);
    const t = document.getElementById('mgr-team-list');
    if (t) t.innerHTML = `<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">
      <i class="fa-solid fa-triangle-exclamation" style="color:var(--amber)"></i>
      Error al cargar datos del equipo. <button class="btn btn-ghost btn-sm" onclick="_loadMgrDashboard('today')">Reintentar</button>
    </div>`;
  }
}

function _mgrPeriod(period) {
  document.getElementById('mgr-team-list').innerHTML =
    '<div class="card-header"><div class="card-title"><i class="fa-solid fa-users"></i> Estado del equipo</div></div>' +
    '<div class="card-body" style="color:var(--tx-3);text-align:center"><i class="fa-solid fa-spinner fa-spin"></i></div>';
  _loadMgrDashboard(period);
}

function _repRow(rep, indent=false) {
  const statusColor = rep.active_now ? 'var(--green)' : 'var(--tx-3)';
  const statusIcon  = rep.active_now ? 'fa-circle' : 'fa-circle-dot';
  const lastAct = rep.last_activity
    ? new Date(rep.last_activity).toLocaleDateString('es-ES',{day:'numeric',month:'short'})
    : 'Sin actividad';
  /* Barra de cobertura individual */
  const covPct = rep.coverage_pct ?? null;
  const covColor = covPct == null ? 'var(--indigo)'
    : covPct >= 80 ? 'var(--green)' : covPct >= 50 ? 'var(--amber)' : 'var(--red)';
  const covBar = covPct != null ? `
    <div style="display:flex;align-items:center;gap:6px;margin-top:4px">
      <div style="flex:1;height:4px;background:var(--color-background-secondary);border-radius:2px;overflow:hidden">
        <div style="width:${Math.min(100,covPct)}%;height:100%;background:${covColor};border-radius:2px"></div>
      </div>
      <span style="font-size:10px;color:${covColor};min-width:30px">${covPct}%</span>
    </div>` : '';
  /* Alerta si lleva más de 2h en jornada sin visitas */
  const stuckAlert = (rep.active_now && rep.visits === 0)
    ? '<span style="font-size:10px;color:var(--amber)"><i class="fa-solid fa-triangle-exclamation"></i> Sin check-ins</span>'
    : '';

  /* Barra de objetivo de visitas semanales */
  const tgt = rep.targets?.visits_week ?? null;
  const targetBar = tgt > 0 ? (() => {
    const pct = Math.min(100, Math.round(rep.visits / tgt * 100));
    const col = pct >= 100 ? 'var(--green)' : pct >= 60 ? 'var(--indigo)' : pct >= 30 ? 'var(--amber)' : 'var(--red)';
    return `<div style="display:flex;align-items:center;gap:6px;margin-top:4px">
      <div style="flex:1;height:4px;background:var(--color-background-secondary);border-radius:2px;overflow:hidden">
        <div style="width:${pct}%;height:100%;background:${col};border-radius:2px;transition:width .3s"></div>
      </div>
      <span style="font-size:10px;color:${col};min-width:52px;white-space:nowrap">${rep.visits}/${tgt} obj.</span>
    </div>`;
  })() : '';

  return `
  <div class="settings-row" style="${indent?'padding-left:2rem':''}">
    <div class="settings-row-info" style="flex:1;min-width:0">
      <div class="settings-row-title" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <i class="fa-solid ${statusIcon}" style="font-size:8px;color:${statusColor}"></i>
        ${esc(rep.name||rep.email)}
        ${rep.active_now ? '<span class="badge badge-green" style="font-size:10px">Activo</span>' : ''}
        ${stuckAlert}
      </div>
      <div class="settings-row-sub">${rep.visits} visitas · ${rep.sessions_done}/${rep.sessions} jornadas · ${rep.distance_km}km</div>
      ${covBar}
      ${targetBar}
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0">
      <span style="font-size:11px;color:var(--tx-3);white-space:nowrap">${lastAct}</span>
      ${({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0) >= 1 ? `
      <button class="btn btn-ghost btn-icon sm" title="Editar objetivo"
        onclick="showTargetsModal('${rep.id}','${esc(rep.name||rep.email).replace(/'/g,'\\')}',${JSON.stringify(rep.targets||{})})">
        <i class="fa-solid fa-bullseye" style="font-size:11px"></i>
      </button>` : ''}
    </div>
  </div>`;
}

function _supRow(sup) {
  const agg = sup.aggregated || {};
  return `
  <div class="settings-row" style="background:var(--color-background-secondary)">
    <div class="settings-row-info">
      <div class="settings-row-title" style="font-weight:500">
        <i class="fa-solid fa-user-tie" style="font-size:11px;color:var(--indigo);margin-right:4px"></i>
        ${esc(sup.supervisor?.name||sup.supervisor?.email||'Supervisor')}
        ${sup.active_now ? `<span class="badge badge-green" style="font-size:10px">${sup.active_now} activos</span>` : ''}
      </div>
      <div class="settings-row-sub">${agg.total_visits||0} visitas · ${sup.team?.length||0} comerciales</div>
    </div>
  </div>`;
}

async function _drillDownAdmin(adminId, adminName) {
  /* Owner hace clic en un director → panel lateral con sus supervisores y equipo */
  const overlay = document.createElement('div');
  overlay.className = 'overlay-backdrop';
  overlay.innerHTML = `
    <div class="bottom-sheet" style="max-height:85vh;display:flex;flex-direction:column">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <i class="fa-solid fa-sitemap" style="color:var(--indigo)"></i>
        <span>${esc(adminName)}</span>
        <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="sheet-body" id="drilldown-body" style="overflow-y:auto;flex:1">
        <div style="text-align:center;padding:2rem;color:var(--tx-3)">
          <i class="fa-solid fa-spinner fa-spin"></i> Cargando…
        </div>
      </div>
    </div>`;
  Overlay.push(overlay);

  try {
    const data = await API.get('/stats/dashboard?userId=' + adminId);
    const body = document.getElementById('drilldown-body');
    if (!body || !data) return;
    const sups = data.supervisors || [];
    if (!sups.length) {
      body.innerHTML = '<div style="padding:1rem;color:var(--tx-3);font-size:var(--t-sm)">Sin supervisores configurados bajo este director.</div>';
      return;
    }
    body.innerHTML = sups.map(sup => {
      const agg = sup.aggregated || {};
      const sorted = [...(sup.team || [])].sort((a,b) => b.visits - a.visits);
      return `
        <div style="padding:var(--sp-3) var(--sp-4);border-bottom:1px solid var(--bd-0)">
          <div style="font-weight:500;font-size:var(--t-sm);color:var(--tx-1);margin-bottom:6px;display:flex;align-items:center;gap:8px">
            <i class="fa-solid fa-user-tie" style="color:var(--indigo);font-size:11px"></i>
            ${esc(sup.supervisor?.name||sup.supervisor?.email||'Supervisor')}
            ${sup.active_now ? `<span class="badge badge-green" style="font-size:10px">${sup.active_now} activos</span>` : ''}
          </div>
          <div style="font-size:var(--t-xs);color:var(--tx-3);margin-bottom:8px">
            ${agg.total_visits||0} visitas · ${agg.sessions_done||0}/${agg.total_sessions||0} jornadas · ${agg.distance_km||0}km
          </div>
          ${sorted.map(rep => _repRow(rep, true)).join('')}
        </div>`;
    }).join('');
  } catch(e) {
    console.error('[drilldown]', e);
    const body = document.getElementById('drilldown-body');
    if (body) body.innerHTML = `<div style="padding:1rem;text-align:center">
      <div style="color:var(--tx-3);font-size:var(--t-sm);margin-bottom:8px">
        <i class="fa-solid fa-triangle-exclamation" style="color:var(--amber)"></i>
        Error al cargar datos del director
      </div>
      <button class="btn btn-ghost btn-sm" onclick="_drillDownAdmin('${adminId}','${adminName}')">
        <i class="fa-solid fa-rotate"></i> Reintentar
      </button>
    </div>`;
  }
}

function _renderUpcomingTeam() {
  const today = new Date(); today.setHours(0,0,0,0);
  if (!State.scheduleAll) return `<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">Sin planificación próxima</div>`;

  const entries = Object.entries(State.scheduleAll)
    .map(([d, reps]) => ({ dateStr: d, date: new Date(d+'T12:00'), reps }))
    .filter(e => e.date >= today)
    .sort((a,b) => a.date - b.date)
    .slice(0, 7);

  if (!entries.length) return `<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">
    Sin asignaciones próximas. <a onclick="Router.go('calendar')" style="color:var(--indigo);cursor:pointer">Planificar →</a>
  </div>`;

  return `<div>${entries.map(e => {
    const isToday = e.dateStr === _localDate(new Date());
    return `<div class="list-item" onclick="Router.go('calendar')">
      <div style="width:38px;min-width:32px;text-align:center;flex-shrink:0">
        <div style="font-size:1.2rem;font-weight:800;color:${isToday?'var(--indigo)':'var(--tx-1)'};line-height:1">${e.date.getDate()}</div>
        <div style="font-size:var(--t-xs);color:var(--tx-3);text-transform:uppercase">${e.date.toLocaleDateString('es-ES',{month:'short'})}</div>
      </div>
      <div class="list-item-info">
        <div class="list-item-name">${e.reps.length} rep${e.reps.length!==1?'s':''} asignado${e.reps.length!==1?'s':''}</div>
        <div class="list-item-sub">${[...new Set(e.reps.map(r=>State.getRoute(r.routeId)?.name).filter(Boolean))].join(', ')||'—'}</div>
      </div>
      ${isToday?`<span class="badge badge-indigo">Hoy</span>`:''}
    </div>`;
  }).join('')}</div>
  <div class="card-footer">
    <button class="btn btn-outline btn-sm" onclick="Router.go('calendar')">
      <i class="fa-solid fa-calendar-plus"></i> Planificar
    </button>
  </div>`;
}


/* ═══════════════════════════════════════════════════════
   RUTAS
   ═══════════════════════════════════════════════════════ */
Router.register('routes',(el,params={})=>{
  if ((_ROLE_ORDER[State.prefs._role]??0) < 1) {
    el.innerHTML = `<div class="empty-state">
      <div class="empty-icon"><i class="fa-solid fa-lock"></i></div>
      <div class="empty-title">Sin acceso</div>
      <div class="empty-sub">Las rutas las gestiona tu jefe de zona</div>
    </div>`;
    return;
  }
  if(params.routeId){ _renderRouteDetail(el,params.routeId); return; }

  el.innerHTML=`
  <div class="page-header mb-4">
    <div>
      <h1 class="page-h1">${State.routes.length} Rutas</h1>
      <p class="page-sub">${State.allStops().length} paradas en base de datos</p>
    </div>
    <button class="btn btn-primary" onclick="showModalNewRoute()">
      <i class="fa-solid fa-plus"></i> Nueva ruta
    </button>
  </div>

  ${State.routes.length===0
    ? `<div class="card"><div class="card-body">${_empty('Sin rutas creadas','Crea tu primera ruta y añade paradas a ella','+ Crear primera ruta','showModalNewRoute()')}</div></div>`
    : `<div class="routes-grid">${State.routes.map(r=>_routeCard(r)).join('')}</div>`
  }`;
});

function _routeCard(r){
  const s=State.routeStats(r.id);
  const preview=r.stops.slice(0,3).map(id=>{
    const st=State.stops[id]; if(!st) return '';
    return `<div style="display:flex;align-items:center;gap:6px;padding:3px 0">
      <span style="width:5px;height:5px;border-radius:50%;background:var(--indigo);opacity:.5;flex-shrink:0"></span>
      <span style="font-size:var(--t-xs);color:var(--tx-2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${st.name}</span>
    </div>`;}).join('');

  return `<div class="route-card" onclick="Router.go('routes',{routeId:'${r.id}'})">
    <div class="route-card-head">
      <div class="route-card-icon"><i class="fa-solid fa-route"></i></div>
      <div style="flex:1;min-width:0">
        <div class="route-card-name">${esc(r.name)}</div>
        <div class="route-card-meta">${s.total} paradas · ${s.pct}% GPS</div>
      </div>
      <div style="display:flex;gap:4px" onclick="event.stopPropagation()">
        <button class="btn btn-ghost btn-icon sm" onclick="showRenameRoute('${r.id}')" title="Renombrar">
          <i class="fa-solid fa-pen"></i>
        </button>
        <button class="btn btn-danger btn-icon sm" onclick="confirmDeleteRoute('${r.id}')" title="Eliminar">
          <i class="fa-solid fa-trash"></i>
        </button>
      </div>
    </div>
    <div class="route-card-stops">${preview||`<span style="font-size:var(--t-xs);color:var(--tx-3);font-style:italic">Sin paradas</span>`}
      ${s.total>3?`<div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:2px">+${s.total-3} más</div>`:''}
    </div>
    <div style="padding:0 var(--sp-4) var(--sp-3)">
      <div class="progress-track"><div class="progress-fill" style="width:${s.pct}%"></div></div>
      <div style="display:flex;justify-content:space-between;margin-top:4px">
        <span style="font-size:var(--t-xs);color:var(--tx-3)">${s.geo} geolocalizadas</span>
        <span style="font-size:var(--t-xs);color:var(--tx-3)">${s.pct}%</span>
      </div>
    </div>
  </div>`;
}

function _renderRouteDetail(el,routeId){
  const r=State.getRoute(routeId); if(!r){Router.go('routes');return;}
  if((_ROLE_ORDER[State.prefs._role]??0) < 1){Router.go('dashboard');return;} /* rep no accede */
  const _canEditRoute = (_ROLE_ORDER[State.prefs._role]??0) >= 1; /* supervisor+ */
  const _canDeleteStop = (_ROLE_ORDER[State.prefs._role]??0) >= 1;
  const s=State.routeStats(routeId);
  const unassigned=State.allStops().filter(st=>!r.stops.includes(st.id));

  el.innerHTML=`
  <div class="flex items-center gap-3 mb-4">
    <button class="btn btn-ghost btn-sm" onclick="Router.go('routes')">
      <i class="fa-solid fa-arrow-left"></i> Rutas
    </button>
    <div style="flex:1;min-width:0">
      <h1 class="page-h1" style="font-size:var(--t-xl)">${esc(r.name)}</h1>
      <p class="page-sub">${s.total} paradas · ${s.pct}% con GPS</p>
    </div>
    ${(unassigned.length && _canEditRoute)?`<button class="btn btn-primary btn-sm" onclick="showAddStopToRoute('${routeId}')">
      <i class="fa-solid fa-plus"></i> Añadir
    </button>`:''}
  </div>

  ${r.stops.length===0
    ? `<div class="card"><div class="card-body">${_empty('Sin paradas asignadas','Añade paradas de la base de datos a esta ruta','+ Añadir parada',`showAddStopToRoute('${routeId}')`)}</div></div>`
    : `<div class="card">
        <div class="card-header">
          <div class="card-title"><i class="fa-solid fa-list-ol"></i> Paradas en orden</div>
          <span class="badge badge-indigo">${s.total}</span>
        </div>
        <div id="route-stops-list">
          ${r.stops.map((sid,i)=>{
            const st=State.stops[sid]; if(!st) return '';
            return `<div class="route-stop-row">
              <div class="stop-num-badge">${i+1}</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:var(--t-md);font-weight:600;color:var(--tx-1)">${st.name}</div>
                <div style="font-size:var(--t-xs);color:var(--tx-3);font-family:var(--f-mono)">${[st.addr,st.zip,st.town].filter(Boolean).join(' · ')}</div>
                ${st.horario?`<div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:2px"><i class="fa-regular fa-clock" style="margin-right:4px"></i>${st.horario}</div>`:''}
              </div>
              <div style="display:flex;align-items:center;gap:6px;flex-shrink:0">
                <span class="badge ${st.lat?'badge-green':'badge-muted'}" style="font-size:10px">${st.lat?'GPS':'—'}</span>
                <button class="btn btn-ghost btn-icon sm" onclick="Router.go('stop-detail',{stopId:'${sid}'})" title="Ver ficha">
                  <i class="fa-solid fa-circle-info"></i>
                </button>
                <button class="btn btn-ghost btn-icon sm" onclick="editStop('${sid}')" title="Editar">
                  <i class="fa-solid fa-pen"></i>
                </button>
                <button class="btn btn-danger btn-icon sm" onclick="confirmRemoveFromRoute('${routeId}','${sid}')" title="Quitar">
                  <i class="fa-solid fa-xmark"></i>
                </button>
              </div>
            </div>`;}).join('')}
        </div>
        <div class="card-footer">
          ${unassigned.length?`<button class="btn btn-outline btn-sm" onclick="showAddStopToRoute('${routeId}')">
            <i class="fa-solid fa-plus"></i> Añadir parada
          </button>`:'<span style="font-size:var(--t-xs);color:var(--tx-3)">Todas las paradas ya están asignadas</span>'}
        </div>
      </div>`
  }`;
}

/* ═══════════════════════════════════════════════════════
   PARADAS
   ═══════════════════════════════════════════════════════ */
Router.register('stops',(el)=>{
  const all=State.allStops();
  const allTags = [...new Set(all.flatMap(s=>s.tags||[]))].sort();
  const role = State.prefs._role || 'rep';
  const roleLevel = {rep:0,supervisor:1,admin:2,owner:3}[role]??0;
  const pageTitle = role==='rep' ? 'Mis PDVs' : 'PDVs';
  el.innerHTML=`
  <div class="page-header mb-4">
    <div>
      <h1 class="page-h1">${all.length} ${pageTitle}</h1>
      <p class="page-sub">${all.filter(s=>s.lat).length} con GPS · ${all.filter(s=>!s.lat).length} sin coordenadas</p>
    </div>
    <div style="display:flex;gap:var(--sp-2)">
      ${(({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0) >= 1) ? `
      <button class="btn btn-ghost btn-sm" onclick="document.getElementById('import-xlsx').click()">
        <i class="fa-solid fa-file-import"></i><span class="hide-mobile"> Importar</span>
      </button>
      <input type="file" id="import-xlsx" accept=".xlsx,.xls,.csv" style="display:none" onchange="handleImportXLS(event)">
      <button class="btn btn-primary" onclick="showModalNewStop()">
        <i class="fa-solid fa-plus"></i> Nueva parada
      </button>` : ''}
    </div>
  </div>

  <div class="card">
    <div class="card-header" style="flex-wrap:wrap;gap:var(--sp-2)">
      <div class="search-wrap" style="flex:1;min-width:0;width:100%">
        <i class="fa-solid fa-magnifying-glass search-icon"></i>
        <input id="stops-search" placeholder="Buscar nombre, ID, CP, ciudad..."
          oninput="filterStopsTable(this.value)">
      </div>
      <div style="display:flex;gap:var(--sp-2)">
        <span class="badge badge-muted">${all.length} total</span>
        ${all.filter(s=>!s.lat).length?`<span class="badge badge-muted" style="color:var(--red)">${all.filter(s=>!s.lat).length} sin GPS</span>`:''}
      </div>
    </div>

    <!-- Mobile cards -->
    <div id="stops-cards-mobile" class="stops-cards">
      ${_renderStopCards(all)}
    </div>

    <!-- Desktop table -->
    <div class="table-wrap hide-mobile-block" id="stops-table-wrap">
      <table><thead><tr>
        <th>ID</th><th>Nombre</th><th>Dirección</th><th>CP · Ciudad</th><th>Horario</th><th>GPS</th><th></th>
      </tr></thead>
      <tbody id="stops-tbody">${_renderStopRows(all)}</tbody></table>
    </div>
  </div>`;
});

function _renderStopCards(list){
  if(!list.length) return `<div style="padding:var(--sp-5)">${_empty('Sin resultados','Prueba con otro término de búsqueda','')}</div>`;
  return list.map(s=>`
    <div class="stop-mobile-card">
      <div style="display:flex;align-items:flex-start;gap:10px">
        <div class="list-item-icon" style="flex-shrink:0;margin-top:2px">
          <i class="fa-solid fa-store"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-size:var(--t-md);font-weight:700;color:var(--tx-1)">${s.name}
            <span style="font-size:var(--t-xs);font-weight:400;color:var(--tx-3);margin-left:4px;font-family:var(--f-mono)">#${s.id}</span>
          </div>
          ${s.addr?`<div style="font-size:var(--t-xs);color:var(--tx-2);margin-top:2px">${s.addr}</div>`:''}
          <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap;align-items:center">
            ${s.zip?`<span class="badge badge-muted">${s.zip}</span>`:''}
            ${s.town?`<span style="font-size:var(--t-xs);color:var(--tx-3)">${s.town}</span>`:''}
            <span class="badge ${s.lat?'badge-green':'badge-muted'}" style="${s.lat?'':'color:var(--tx-3)'}">
              ${s.lat?'<i class="fa-solid fa-location-dot"></i> GPS':'Sin GPS'}
            </span>
          </div>
          ${s.horario?`<div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:4px"><i class="fa-regular fa-clock" style="margin-right:3px"></i>${s.horario}</div>`:''}
        </div>
        <div style="display:flex;flex-direction:column;gap:4px">
          <button class="btn btn-ghost btn-icon sm" onclick="Router.go('stop-detail',{stopId:'${s.id}'})" title="Ficha"><i class="fa-solid fa-circle-info"></i></button>
          ${(({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0) >= 1) ? `
          <button class="btn btn-ghost btn-icon sm" onclick="editStop('${s.id}')" title="Editar"><i class="fa-solid fa-pen"></i></button>
          <button class="btn btn-ghost btn-icon sm" onclick="assignStopToRoute('${s.id}')" title="Asignar a ruta"><i class="fa-solid fa-route"></i></button>` : ''}
          ${(({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0) >= 2) ? `
          <button class="btn btn-danger btn-icon sm" onclick="confirmDeleteStop('${s.id}')" title="Eliminar"><i class="fa-solid fa-trash"></i></button>` : ''}
        </div>
      </div>
    </div>`).join('');
}

function _renderStopRows(list){
  if(!list.length) return `<tr><td colspan="7" style="text-align:center;padding:var(--sp-5);color:var(--tx-3)">Sin resultados</td></tr>`;
  return list.map(s=>`<tr>
    <td class="td-mono">${s.id}</td>
    <td class="td-primary">${s.name}</td>
    <td>${s.addr||'—'}</td>
    <td class="td-mono">${[s.zip,s.town].filter(Boolean).join(' ')}</td>
    <td style="font-size:var(--t-xs)">${s.horario||'—'}</td>
    <td><span class="badge ${s.lat?'badge-green':'badge-muted'}">${s.lat?'✓':'✗'}</span></td>
    <td class="td-actions">
      <div style="display:flex;gap:4px">
        <button class="btn btn-ghost btn-icon sm" onclick="Router.go('stop-detail',{stopId:'${s.id}'})" title="Ficha"><i class="fa-solid fa-circle-info"></i></button>
        ${(({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0) >= 1) ? `
        <button class="btn btn-ghost btn-icon sm" onclick="editStop('${s.id}')" title="Editar"><i class="fa-solid fa-pen"></i></button>
        <button class="btn btn-ghost btn-icon sm" onclick="assignStopToRoute('${s.id}')" title="Asignar"><i class="fa-solid fa-route"></i></button>` : ''}
        ${(({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0) >= 2) ? `
        <button class="btn btn-danger btn-icon sm" onclick="confirmDeleteStop('${s.id}')" title="Eliminar"><i class="fa-solid fa-trash"></i></button>` : ''}
      </div>
    </td></tr>`).join('');
}

let _activeTag = '';
function filterByTag(btn, tag) {
  _activeTag = tag;
  document.querySelectorAll('.stop-tag-filter').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  filterStopsTable(document.getElementById('stops-search')?.value || '');
}

function filterStopsTable(q){
  const lower=q.toLowerCase();
  const f=q?State.allStops().filter(s=>
    s.name.toLowerCase().includes(lower)||(s.id||'').toLowerCase().includes(lower)||
    (s.addr||'').toLowerCase().includes(lower)||(s.zip||'').toLowerCase().includes(lower)||
    (s.town||'').toLowerCase().includes(lower)):State.allStops();
  document.getElementById('stops-tbody').innerHTML=_renderStopRows(f);
  document.getElementById('stops-cards-mobile').innerHTML=_renderStopCards(f);
}

/* ═══════════════════════════════════════════════════════
   CALENDARIO
   ═══════════════════════════════════════════════════════ */
let _calMonth=null;
Router.register('calendar',(el)=>{
  if(!_calMonth) _calMonth=new Date();
  _renderCal(el);
});
function _renderCal(el){
  const y=_calMonth.getFullYear(),m=_calMonth.getMonth();
  const firstDow=new Date(y,m,1).getDay();
  const days=new Date(y,m+1,0).getDate();
  const offset=firstDow===0?6:firstDow-1;
  const MN=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  const DN=['L','M','X','J','V','S','D'];
  const todayStr=_localDate(new Date());

  let cells='';
  for(let i=0;i<Math.ceil((offset+days)/7)*7;i++){
    const d=i-offset+1;
    const ok=d>=1&&d<=days;
    const ds=ok?`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`:'';
    const isToday=ds===todayStr;
    const rId=State.schedule[ds];
    const rName=rId?State.getRoute(rId)?.name:'';
    /* Detectar jornada completada ese día (para marcar en verde) */
    const role=State.prefs._role||'rep';
    const sessToday = (ds && rId && typeof getSession==='function') ? getSession(rId,ds) : null;
    const isDone = sessToday?.state === 'finished';
    /* Para supervisor+: mostrar chips de todos los reps asignados ese día */
    const allForDay=(role!=='rep'&&State.scheduleAll&&ds)?State.scheduleAll[ds]||[]:[];
    const hasAnyRoute = rName || allForDay.length > 0;
    const repCount = allForDay.length;
    /* Construir tooltip con detalle de reps y rutas */
    const tooltipLines = allForDay.map(e=>{
      const r=State.getRoute(e.routeId);
      const rLabel=r?r.name:'?';
      return rLabel;
    });
    const chipTooltip = tooltipLines.join(', ');
    cells+=`<div class="cal-cell ${ok?'':'cal-void'} ${isToday?'cal-today':''} ${isDone?'cal-done':hasAnyRoute?'cal-has-route':''}"
      ${ok?`onclick="calClick('${ds}')"`:''}
      ${chipTooltip?`title="${chipTooltip}"`:''}>
      <span class="cal-num">${ok?d:''}</span>
      ${rName
        ?`<div class="cal-chip">${rName}</div>`
        :(repCount>0?`<div class="cal-chip" style="background:var(--indigo-dim);color:var(--indigo);font-size:9px">${repCount} rep${repCount>1?'s':''}</div>`:'')
      }
    </div>`;
  }

  el.innerHTML=`
  <div class="card">
    <div class="card-header">
      <button class="btn btn-ghost btn-icon" onclick="calNav(-1)"><i class="fa-solid fa-chevron-left"></i></button>
      <div class="card-title" style="flex:1;justify-content:center;font-size:var(--t-lg)">
        ${MN[m]} ${y}
      </div>
      <button class="btn btn-ghost btn-icon" onclick="calNav(1)"><i class="fa-solid fa-chevron-right"></i></button>
    </div>
    <div class="cal-head-row">${DN.map(d=>`<div class="cal-dname">${d}</div>`).join('')}</div>
    <div class="cal-grid">${cells}</div>
  </div>

  <!-- Leyenda -->
  <div style="display:flex;gap:var(--sp-3);margin-top:var(--sp-3);flex-wrap:wrap;align-items:center">
    <div style="display:flex;align-items:center;gap:6px;font-size:var(--t-xs);color:var(--tx-3)">
      <span style="width:10px;height:10px;border-radius:2px;background:var(--indigo-dim);border:1.5px solid var(--indigo);display:inline-block"></span>Hoy
    </div>
    <div style="display:flex;align-items:center;gap:6px;font-size:var(--t-xs);color:var(--tx-3)">
      <span style="width:10px;height:10px;border-radius:2px;background:var(--indigo);display:inline-block"></span>Con ruta
    </div>
    <div style="display:flex;align-items:center;gap:6px;font-size:var(--t-xs);color:var(--tx-3)">
      <span style="width:10px;height:10px;border-radius:2px;background:var(--green-bg);border:1.5px solid var(--green);display:inline-block"></span>Completada
    </div>
    <div style="font-size:var(--t-xs);color:var(--tx-3);margin-left:auto">
      ${role==='rep' ? 'Toca un día para ver tu jornada' : 'Toca un día para planificar'}
    </div>
  </div>
  </div>

  <!-- Resumen de jornadas recientes (solo rep) -->
  ${role==='rep' ? _renderCalJornadaSummary() : ''}`;
}
function calNav(d){_calMonth=new Date(_calMonth.getFullYear(),_calMonth.getMonth()+d,1);_renderCal(document.getElementById('page-content'));}
/* Estado del modal calendario */
let _calAssignDs   = null;
let _calAssignReps = [];

function calClick(ds){
  const role = State.prefs._role || 'rep';
  const cur  = State.schedule[ds];
  const d    = new Date(ds+'T12:00');

  /* Rep: solo puede ver/iniciar la jornada del día, no asignar rutas */
  if(role === 'rep'){
    if(cur){
      Router.go('jornada',{routeId:cur,dateStr:ds});
    } else {
      toast('No tienes ruta asignada para este día','info');
    }
    return;
  }

  /* Supervisor+ pueden asignar rutas */
  if(!State.routes.length){toast('Crea una ruta primero','error');return;}

  _calAssignDs = ds;
  document.getElementById('cal-date-label').textContent=
    d.toLocaleDateString('es-ES',{weekday:'long',day:'numeric',month:'long'});

  /* Cargar miembros del equipo para el selector de rep */
  _calLoadReps(ds, cur);
  openModal('modal-cal-assign');
}

async function _calLoadReps(ds, curRouteId) {
  const _crl = document.getElementById('cal-route-list');
  if(_crl) _crl.scrollTop = 0;

  /* Cargar miembros visibles */
  try {
    _calAssignReps = await API.get('/users');
  } catch(e) {
    _calAssignReps = [];
  }

  /* Solo reps — el supervisor asigna rutas a sus comerciales, nunca a supervisores */
  const reps = (_calAssignReps || []).filter(m => m.active != 0 && m.role === 'rep');

  /* Preseleccionar rep que ya tiene asignación ese día */
  const schedAllDay = (State.scheduleAll && State.scheduleAll[ds]) || [];
  const curAssignedTo = schedAllDay.length > 0 ? schedAllDay[0].assignedTo : null;

  /* Botón ir a jornada solo si el propio usuario tiene ruta ese día */
  const myRouteToday = State.schedule[ds];
  const jornadaBtn = (myRouteToday === curRouteId && curRouteId) ? `
    <div style="padding:var(--sp-3) var(--sp-4);border-top:1px solid var(--bd-0)">
      <button class="btn btn-primary w-full" onclick="closeModal('modal-cal-assign');Router.go('jornada',{routeId:'${curRouteId}',dateStr:'${ds}'})">
        <i class="fa-solid fa-play"></i> Ir a jornada del día
      </button>
    </div>` : '';

  /* Selector de rep — siempre visible con todos los reps del árbol */
  let repSelector = '';
  if(reps.length === 0){
    repSelector = '<div style="padding:var(--sp-3) var(--sp-4);font-size:var(--t-xs);color:var(--tx-3)">' +
      '<i class="fa-solid fa-triangle-exclamation"></i> No tienes comerciales asignados a tu equipo todavía.' +
      '</div>';
  } else {
    const opts = reps.map(m =>
      '<option value="' + m.id + '"' + (curAssignedTo===m.id?' selected':'') + '>' +
      esc(m.name || m.email.split('@')[0]) + '</option>'
    ).join('');
    repSelector = '<div style="padding:var(--sp-3) var(--sp-4) 0">' +
      '<label style="font-size:var(--t-xs);color:var(--tx-3);font-weight:500">Asignar a</label>' +
      '<select id="cal-rep-select" style="width:100%;margin-top:4px">' + opts + '</select>' +
      '</div>';
  }

  _crl.innerHTML =
    repSelector +
    `<div style="padding:var(--sp-2) var(--sp-4) var(--sp-1)">
       <p style="font-size:var(--t-xs);color:var(--tx-3);font-weight:500">Ruta</p>
     </div>` +
    State.routes.map(r=>`<div class="list-item ${curRouteId===r.id?'active':''}" onclick="assignCal('${ds}','${r.id}')">
      <div class="list-item-icon"><i class="fa-solid fa-route"></i></div>
      <div class="list-item-info">
        <div class="list-item-name">${esc(r.name)}</div>
        <div class="list-item-sub">${State.routeStats(r.id).total} paradas</div>
      </div>
      ${curRouteId===r.id?`<i class="fa-solid fa-check" style="color:var(--indigo)"></i>`:''}
    </div>`).join('') +
    (curRouteId?`<div class="list-item" onclick="clearCal('${ds}')" style="color:var(--red)">
      <div class="list-item-icon" style="background:var(--red-bg);color:var(--red)"><i class="fa-solid fa-xmark"></i></div>
      <div class="list-item-info"><div class="list-item-name" style="color:var(--red)">Quitar asignación</div></div>
    </div>`:'') +
    jornadaBtn;
}
function assignCal(ds,rId){
  const repSel   = document.getElementById('cal-rep-select');
  const assignTo = repSel ? repSel.value : State.prefs._userId;
  const role     = State.prefs._role || 'rep';

  /* Si se asigna al propio usuario (rep asignándose a sí mismo, o supervisor sin equipo)
     → update optimista local. Si se asigna a otro (rep del equipo) → solo API */
  const isSelf = assignTo === State.prefs._userId;
  if(isSelf){
    State.schedule[ds] = rId;
    State.persist();
  }

  closeModal('modal-cal-assign');

  if(typeof Tokens!=='undefined' && Tokens.isLoggedIn()){
    API.post('/schedule',{date:ds,routeId:rId,userId:assignTo})
      .then(()=>{
        /* Pull silencioso para actualizar scheduleAll con la nueva asignación */
        Sync.pull({ silent:true });
        toast('Ruta asignada a ' + (repSel?.options[repSel.selectedIndex]?.text || 'comercial'),'success',2500);
        _renderCal(document.getElementById('page-content'));
      })
      .catch(()=>{
        /* Rollback local si era autoasignación */
        if(isSelf){ delete State.schedule[ds]; State.persist(); }
        _renderCal(document.getElementById('page-content'));
        toast('No se pudo guardar la asignación — comprueba la conexión','error',4000);
      });
  } else {
    _renderCal(document.getElementById('page-content'));
    toast('Ruta asignada','success');
  }
}
function clearCal(ds){
  const repSel     = document.getElementById('cal-rep-select');
  const targetUser = repSel ? repSel.value : State.prefs._userId;
  const isSelf     = targetUser === State.prefs._userId;
  const prevRId    = State.schedule[ds];

  if(isSelf){ delete State.schedule[ds]; State.persist(); }
  closeModal('modal-cal-assign');

  if(typeof Tokens!=='undefined' && Tokens.isLoggedIn()){
    API.del('/schedule/' + ds + '/' + targetUser)
      .then(()=>{
        Sync.pull({ silent:true });
        _renderCal(document.getElementById('page-content'));
        toast('Asignación eliminada','info',2000);
      })
      .catch(()=>{
        if(isSelf && prevRId){ State.schedule[ds] = prevRId; State.persist(); }
        _renderCal(document.getElementById('page-content'));
        toast('No se pudo quitar la asignación — comprueba la conexión','error',4000);
      });
  } else {
    _renderCal(document.getElementById('page-content'));
  }
}

/* ═══════════════════════════════════════════════════════
   INFORMES
   ═══════════════════════════════════════════════════════ */
Router.register('reports',(el)=>{
  const role    = State.prefs._role || 'rep';
  const myId    = State.prefs._userId || null;
  const isRep   = role === 'rep';
  const roleLevel = {rep:0,supervisor:1,admin:2,owner:3}[role]??0;

  const g=State.globalStats();
  const sched=Object.entries(State.schedule).sort((a,b)=>b[0].localeCompare(a[0]));
  const byRoute={};
  sched.forEach(([,rId])=>{byRoute[rId]=(byRoute[rId]||0)+1;});

  // Filtrar visitas y jornadas por userId si es rep
  const allVisitsRaw = typeof _loadVisits==='function' ? _loadVisits() : {};
  const allVisits = isRep && myId
    ? Object.fromEntries(Object.entries(allVisitsRaw).filter(([,v])=> !v.userId || v.userId===myId))
    : allVisitsRaw;
  const totalVisits = Object.keys(allVisits).length;

  const jornadasRaw = typeof _loadJornadas==='function' ? _loadJornadas() : {};
  const jornadasAll = isRep && myId
    ? Object.fromEntries(Object.entries(jornadasRaw).filter(([,s])=> !s.userId || s.userId===myId))
    : jornadasRaw;
  const jornadasList = Object.entries(jornadasAll)
    .filter(([,s])=>s.state==='finished'||s.elapsed>0)
    .sort((a,b)=>b[0].localeCompare(a[0]))
    .slice(0,10);

  const pageTitle   = isRep ? 'Mi actividad' : 'Informes';
  const pageSub     = isRep ? 'Tus jornadas y visitas' : 'Historial de jornadas y visitas del equipo';
  /* Para supervisor+ cargar jornadas del equipo async tras render inicial */
  const needsTeamData = roleLevel >= 1 && Auth.isLoggedIn();

  el.innerHTML=`
  <div class="page-header mb-4">
    <div><h1 class="page-h1">${pageTitle}</h1><p class="page-sub">${pageSub}</p></div>
    <div style="display:flex;gap:var(--sp-2);flex-wrap:wrap">
      ${roleLevel >= 1 ? `<button class="btn btn-primary btn-sm" onclick="Router.go('stats')">
        <i class="fa-solid fa-chart-line"></i> Estadísticas
      </button>` : ''}
      <button class="btn btn-ghost btn-sm" onclick="exportData()">
        <i class="fa-solid fa-download"></i> Backup
      </button>
    </div>
  </div>

  <div class="grid-4 mb-4">
    <div class="stat-card accent-indigo"><div class="stat-card-label">Rutas activas</div><div class="stat-card-value">${g.routes}</div></div>
    <div class="stat-card accent-blue"><div class="stat-card-label">Total paradas</div><div class="stat-card-value">${g.stops}</div></div>
    <div class="stat-card accent-green"><div class="stat-card-label">Visitas registradas</div><div class="stat-card-value">${totalVisits}</div></div>
    <div class="stat-card"><div class="stat-card-label">Días planificados</div><div class="stat-card-value">${g.scheduled}</div></div>
  </div>

  <!-- Equipo: actividad del mes (solo supervisor+, cargado async) -->
  ${needsTeamData ? `<div class="card mb-4" id="team-sessions-wrap">
    <div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm);text-align:center">
      <i class="fa-solid fa-spinner fa-spin"></i> Cargando actividad del equipo…
    </div>
  </div>` : ''}

  <!-- Historial jornadas -->
  <div class="card mb-4">
    <div class="card-header">
      <div class="card-title"><i class="fa-solid fa-calendar-check"></i> ${isRep ? 'Historial de jornadas' : 'Mis jornadas'}</div>
    </div>
    ${jornadasList.length===0
      ? `<div class="card-body">${_empty('Sin jornadas','Inicia tu primera jornada del día','','')}</div>`
      : `<div>${jornadasList.map(([key,s])=>{
          /* Key format: routeId_YYYY-MM-DD
             dateStr siempre son los últimos 10 chars, routeId todo lo anterior */
          const dStr = key.slice(-10);
          const rId  = key.slice(0, -11); /* quitar el _ y los 10 chars de fecha */
          const route=State.getRoute(rId);
          if(!route) return '';
          const d=new Date(dStr+'T12:00');
          const h=Math.floor((s.elapsed||0)/3600);
          const m=Math.floor(((s.elapsed||0)%3600)/60);
          const dayPrefix=rId+'_'+dStr+'_';
          const visCount=Object.keys(allVisits).filter(k=>k.startsWith(dayPrefix)).length;
          const rStats=State.routeStats(rId);
          return '<div class="list-item" onclick="Router.go(\'jornada\',{routeId:\''+rId+'\',dateStr:\''+dStr+'\'})">'+
            '<div style="width:38px;min-width:32px;text-align:center;flex-shrink:0">'+
              '<div style="font-size:1.1rem;font-weight:800;color:var(--indigo);line-height:1">'+d.getDate()+'</div>'+
              '<div style="font-size:var(--t-xs);color:var(--tx-3);text-transform:uppercase">'+d.toLocaleDateString('es-ES',{month:'short'})+'</div>'+
            '</div>'+
            '<div class="list-item-info">'+
              '<div class="list-item-name">'+esc(route.name)+'</div>'+
              '<div class="list-item-sub">'+h+'h '+m+'m · '+(s.distance||0).toFixed(1)+' km · '+visCount+'/'+rStats.total+' paradas</div>'+
            '</div>'+
            '<span class="badge '+(s.state==='finished'?'badge-green':'badge-muted')+'">'+(s.state==='finished'?'Completa':'En curso')+'</span>'+
          '</div>';
        }).filter(Boolean).join('')}</div>`
    }
  </div>

  <div class="grid-2">
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-chart-bar"></i> Uso por ruta</div></div>
      <div class="card-body">
        ${State.routes.length===0?_empty('Sin datos','Crea rutas y planifica','',''):
          State.routes.map(r=>{
            const uses=byRoute[r.id]||0;
            const maxUses=Math.max(...Object.values(byRoute),1);
            const pct=Math.round(uses/maxUses*100);
            return `<div style="margin-bottom:var(--sp-3)">
              <div style="display:flex;justify-content:space-between;margin-bottom:4px">
                <span style="font-size:var(--t-sm);font-weight:600;color:var(--tx-1)">${esc(r.name)}</span>
                <span style="font-size:var(--t-xs);color:var(--tx-3)">${uses} días</span>
              </div>
              <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
            </div>`;}).join('')}
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-calendar-check"></i> Planificación reciente</div></div>
      ${sched.length===0?`<div class="card-body">${_empty('Sin datos','Asigna rutas al calendario','','')}</div>`:
        `<div>${sched.slice(0,8).map(([ds,rId])=>{
          const r=State.getRoute(rId); if(!r) return '';
          const d=new Date(ds+'T12:00');
          return `<div class="list-item">
            <div style="width:38px;min-width:32px;text-align:center;flex-shrink:0">
              <div style="font-size:1rem;font-weight:800;color:var(--indigo)">${d.getDate()}</div>
              <div style="font-size:var(--t-xs);color:var(--tx-3);text-transform:uppercase">${d.toLocaleDateString('es-ES',{month:'short'})}</div>
            </div>
            <div class="list-item-info">
              <div class="list-item-name">${esc(r.name)}</div>
              <div class="list-item-sub">${d.toLocaleDateString('es-ES',{weekday:'long'})}</div>
            </div>
          </div>`;}).join('')}</div>`}
    </div>
  </div>`;
});

/* ═══════════════════════════════════════════════════════
   AJUSTES
   ═══════════════════════════════════════════════════════ */
/* ═══════════════════════════════════════════════════════
   CHANGELOG
   ═══════════════════════════════════════════════════════ */
const CHANGELOG = [
  {
    version: 'v2.24.6',
    date: '2026-03-29',
    tag: 'latest',
    tagColor: 'badge-indigo',
    title: 'Fix HY093 en dashboard — _coverage_gaps rompe al hacer login',
    changes: [
      { type: 'fixed', text: 'SQLSTATE[HY093]: _coverage_gaps usaba array_diff() que preserva claves originales, causando desajuste entre placeholders ? y parámetros PDO. Todas las llamadas a _coverage_gaps envueltas en try/catch con array_values() defensivo en cada paso.' },
      { type: 'fixed', text: '_active_sessions_for: añadido array_values() en userIds para garantizar claves consecutivas antes de construir el IN(?).' },
      { type: 'fixed', text: '_coverage_gaps: también filtra archived_at IS NULL en memberships y valida que los stop IDs sean strings no vacíos antes de construir la query.' },
    ]
  },
  {
    version: 'v2.24.5',
    date: '2026-03-29',
    tag: '',
    tagColor: 'badge-gray',
    title: 'Fix crítico SW + paused_s + versiones sincronizadas',
    changes: [
      { type: 'fixed', text: 'Service Worker: el filtro de API usaba startsWith("/api/") que nunca coincidía con el path real /gestor-rutas-web/api/ — todas las respuestas GET del API se cacheaban como assets estáticos, rompiendo el login en cada bump de versión.' },
      { type: 'fixed', text: 'sync.php: paused_s nunca se guardaba en BD ni se devolvía en sync/pull. Ahora INSERT y _map_session incluyen pausedS correctamente.' },
      { type: 'fixed', text: 'api-test.html y manifest.json: versión actualizada a v2.24.5 (estaban en v2.22.2 y v2.24.2 respectivamente).' },
    ]
  },
  {
    version: 'v2.24.4',
    date: '2026-03-29',
    tag: '',
    tagColor: 'badge-gray',
    title: 'Fix Dashboard, Estadísticas, Calendario y lista Equipo',
    changes: [
      { type: 'fixed', text: 'Dashboard/Estadísticas: owner usaba CTE recursiva que fallaba en MariaDB compartido. Ahora usa COUNT(*) directo sobre la org; admin/supervisor con try/catch y fallback.' },
      { type: 'fixed', text: 'Dashboard/Estadísticas: _stats_owner filtra archived_at IS NULL además de active=1, evitando que miembros con datos inconsistentes rompan el endpoint.' },
      { type: 'fixed', text: 'Calendario en blanco: get_visible_user_ids y get_visible_members añaden filtro archived_at IS NULL — sync/pull ya no incluye miembros archivados.' },
      { type: 'fixed', text: 'Lista Equipo (Ajustes): se pintaba "false" entre cada fila de supervisor/admin/owner. Causa: && en template literal emitía booleano. Fix: ternario ? ... : "".' },
      { type: 'fixed', text: 'BD: supervisor con active=1 + archived_at inconsistente corregido. Visitas sync_test, paradas y rutas de test eliminadas de producción.' },
    ]
  },
  {
    version: 'v2.24.3',
    date: '2026-03-29',
    tag: '',
    tagColor: 'badge-gray',
    title: 'Fix error 500 en login — columnas BD faltantes',
    changes: [
      { type: 'fixed', text: 'Error 500 al hacer login cuando las columnas settings (users), manager_id o targets (memberships) no existían en BD. Todos los accesos a estas columnas son ahora defensivos con try/catch y fallback.' },
      { type: 'fixed', text: 'auth_me, auth_settings, _build_session, auth_refresh: protegidos contra tabla platform_roles o columna settings ausente.' },
      { type: 'fixed', text: 'get_visible_members, get_visible_user_ids: protegidos contra columnas manager_id y targets ausentes.' },
      { type: 'fixed', text: 'stats.php y routes.php: consultas con targets envueltas en try/catch con fallback sin esa columna.' },
      { type: 'new',   text: 'migrate_v2.21_fix_columnas.sql: migración idempotente que añade todas las columnas faltantes de una sola vez.' },
    ]
  },
  {
    version: 'v2.24.2',
    date: '2026-03-28',
    tag: '',
    tagColor: 'badge-gray',
    title: 'Fix login roto tras abrir "¿Olvidaste tu contraseña?"',
    changes: [
      { type: 'fixed', text: '_showForgotPwd reemplazaba el DOM del modal de login; al volver llamaba _authTab que buscaba elementos ya eliminados — TypeError silencioso que dejaba el modal sin botones funcionales. Ahora "Volver" cierra y reabre el modal limpio.' },
    ]
  },
  {
    version: 'v2.24.2',
    date: '2026-03-21',
    tag: '',
    tagColor: 'badge-gray',
    title: 'Objetivos por comercial',
    changes: [
      { type: 'new', text: 'Supervisor/admin/owner: botón de diana en cada fila de comercial para definir visitas/semana y jornadas/semana esperadas — modal simple, guarda en memberships.targets' },
      { type: 'new', text: 'Dashboard supervisor: barra de progreso contra objetivo debajo de cada comercial — verde ≥100%, índigo ≥60%, ámbar ≥30%, rojo <30%' },
      { type: 'new', text: 'Dashboard rep: si el supervisor le ha asignado un objetivo de visitas semanales, aparece barra de progreso propia al seleccionar el periodo Semana' },
    ]
  },
  {
    version: 'v2.24.2',
    date: '2026-03-21',
    tag: '',
    tagColor: 'badge-gray',
    title: 'P4 — Objetivos por comercial: targets completos',
    changes: [
      { type: 'new',      text: 'Objetivos por comercial: supervisor puede fijar visitas/semana y jornadas/semana para cada rep desde el árbol del equipo (icono diana) o desde la ficha del comercial en el dashboard' },
      { type: 'new',      text: 'Dashboard rep: barra de progreso semanal contra el objetivo configurado — verde al 100%, ámbar al 30–60%, rojo por debajo' },
      { type: 'new',      text: 'Dashboard supervisor: cada fila del equipo muestra barra de progreso y badge visual del cumplimiento del objetivo semanal del comercial' },
      { type: 'improved', text: 'BD: migrate actualizado con ALTER TABLE memberships ADD COLUMN targets (JSON) para almacenar los objetivos' },
    ]
  },
  {
    version: 'v2.24.1',
    date: '2026-03-28',
    tag: 'v2.24',
    tagColor: 'badge-muted',
    title: 'Recuperación de contraseña · CSP headers',
    changes: [
      { type: 'new',      text: 'Recuperación de contraseña olvidada: flujo completo en dos pasos — formulario en el modal de login, email con enlace seguro (token 1h, timing-safe), modal de nueva contraseña al abrir el enlace' },
      { type: 'new',      text: 'Backend: POST /auth/forgot y POST /auth/reset con rate limiting (5 intentos/15min), sin revelar si el email existe, revocar todos los refresh tokens al resetear' },
      { type: 'new',      text: 'Seguridad: Content-Security-Policy en .htaccess — script-src, style-src, img-src (tiles OSM/CARTO/ArcGIS), connect-src (API + Nominatim), font-src (cdnjs)' },
      { type: 'new',      text: 'Seguridad: X-Content-Type-Options, X-Frame-Options DENY, Referrer-Policy, Permissions-Policy (geolocation/camera self)' },
    ]
  },
  {
    version: 'v2.24.1',
    date: '2026-03-21',
    tag: 'v2.24',
    tagColor: 'badge-muted',
    title: 'exportCSV incluye campos de formulario',
    changes: [
      { type: 'fixed', text: 'exportCSV: las columnas de formulario personalizado (todos los campos dinámicos definidos por el admin) ahora aparecen en el CSV entre los KPIs y las Notas — los checkboxes se exportan como Sí/No' },
    ]
  },
  {
    version: 'v2.24.1',
    date: '2026-03-21',
    tag: 'v2.24',
    tagColor: 'badge-muted',
    title: 'Export CSV visitas equipo con form_data · Seguridad visits',
    changes: [
      { type: 'new',      text: 'Export CSV del equipo: ahora exporta visitas individuales del mes con nombre del comercial, parada, estado, KPIs y todos los campos del formulario personalizado (form_data)' },
      { type: 'fixed',    text: 'Backend: GET /visits sin filtro devolvía todas las visitas de la org a cualquier rol — ahora rep solo ve las suyas, supervisor+ ve su árbol jerárquico' },
      { type: 'improved', text: 'Backend: GET /visits acepta ?team=1, ?userId=X, ?from=, ?to= para filtrar visitas del equipo por periodo' },
      { type: 'improved', text: 'Backend: _visit_out incluye userId y checkOutAt — necesarios para el CSV y para calcular duración de visita en el servidor' },
    ]
  },
  {
    version: 'v2.24.1',
    date: '2026-03-28',
    tag: 'latest',
    tagColor: 'badge-indigo',
    title: 'P4 — Objetivos por comercial operativos',
    changes: [
      { type: 'fixed',    text: 'Backend: _rep_summary usaba $targets sin haberla definido — la query de $info solo leía name/email, causando PHP Notice y targets=null en el dashboard del supervisor' },
      { type: 'fixed',    text: 'Backend: modo ?lite=1 leía targets de BD pero no los incluía en el array del equipo — el botón de editar objetivo aparecía pero mostraba valores vacíos' },
      { type: 'improved', text: 'BD: migrate_v2.23.sql añade ALTER TABLE memberships ADD COLUMN targets JSON — la columna que ya leía y escribía el backend pero no existía en la BD' },
    ]
  },
  {
    version: 'v2.24.0',
    date: '2026-03-21',
    tag: 'v2.24',
    tagColor: 'badge-muted',
    title: 'Stats y KPIs por rol · Cobertura · Ranking equipo · Drill-down owner',
    changes: [
      { type: 'fixed',    text: 'Stats: cobertura media del equipo ya aparece en el dashboard del supervisor — el campo coverage_pct ahora se calcula y promedia correctamente en el agregado' },
      { type: 'fixed',    text: 'Stats: PDVs sin visitar ahora incluye stops de rutas asignadas además de zone_ids — antes un rep que ejecutaba rutas fuera de su zona no contabilizaba esas paradas' },
      { type: 'fixed',    text: 'Stats admin: si el admin no tiene supervisores con manager_id configurado, usa el árbol visible completo como fallback — el dashboard ya no sale vacío' },
      { type: 'new',      text: 'Dashboard supervisor: ranking del equipo ordenado por activos primero y visitas desc — con barra de cobertura individual en color verde/ámbar/rojo según rendimiento' },
      { type: 'new',      text: 'Dashboard supervisor: alerta de "Sin check-ins" en reps con jornada activa pero cero visitas registradas' },
      { type: 'new',      text: 'Dashboard owner: clic en cualquier director abre panel con sus supervisores y comerciales con stats completos — drill-down real sobre el árbol org' },
      { type: 'improved', text: 'Dashboard owner: barra de progreso por director con color según porcentaje relativo al máximo del equipo' },
    ]
  },
  {
    version: 'v2.24.0',
    date: '2026-03-21',
    tag: 'v2.24',
    tagColor: 'badge-muted',
    title: 'P4 — daily_stats: dashboards instantáneos con volumen de datos',
    changes: [
      { type: 'new',      text: 'Backend: daily_stats se puebla automáticamente al finalizar cada jornada (sessions_upsert y sync/push) — una fila por rep/día con visitas, km, tiempo y cobertura' },
      { type: 'improved', text: 'Backend: _rep_summary lee primero de daily_stats (1 query GROUP BY) y solo cae a las tablas fuente si no hay caché — de 5 queries por rep a 3 independientemente del periodo' },
      { type: 'improved', text: 'Backend: el fallback sin caché sigue funcionando para datos históricos anteriores a esta versión — sin pérdida de información' },
      { type: 'improved', text: 'BD: migrate_v2.23.sql actualizado con índices para daily_stats (UNIQUE KEY y lectura por periodo)' },
    ]
  },
  {
    version: 'v2.23.7',
    date: '2026-03-21',
    tag: 'v2.23',
    tagColor: 'badge-muted',
    title: 'Fix Ajustes en blanco · P3 · Historial equipo · Errores con contexto',
    changes: [
      { type: 'fixed',    text: 'Ajustes: tab completamente en blanco — variable needsTeamData de Informes referenciada en Settings donde no existe, causando ReferenceError silencioso' },
      { type: 'new',      text: 'Ficha de parada: supervisor/admin/owner ven el historial de visitas de su equipo (cargado de la API) además de sus propias visitas locales' },
      { type: 'new',      text: 'Informes: supervisor ve actividad del mes de cada comercial (visitas, jornadas, km); admin/owner ven quién está en jornada activa ahora mismo' },
      { type: 'fixed',    text: 'Dashboard manager: si la sesión caduca o hay error de red, muestra mensaje y botón reintentar en vez de spinner eterno' },
      { type: 'fixed',    text: 'Panel de director (owner drill-down): error de red muestra mensaje con botón reintentar en vez de texto genérico' },
      { type: 'fixed',    text: 'Rutas: el comercial (rep) ve un empty-state explicativo en vez de ser redirigido silenciosamente al dashboard' },
      { type: 'fixed',    text: 'Ficha de parada: el parser de la key de visita usaba split incorrecto — fechas y rutas podían aparecer mal' },
      { type: 'improved', text: 'BD: migrate_v2.23.sql — 5 índices nuevos (sessions ×2, visits ×2, memberships ×1) para stats por rol e historial de paradas sin full scan' },
    ]
  },
  {
    version: 'v2.23.5',
    date: '2026-03-21',
    tag: 'v2.23',
    tagColor: 'badge-muted',
    title: 'Cobertura completa de roles en Stats y Dashboard',
    changes: [
      { type: 'fixed', text: 'Backend: admin y owner ahora incluyen active_sessions[] en la respuesta — el panel Jornadas del equipo y el contador de activos funcionan correctamente para los cuatro roles' },
      { type: 'fixed', text: 'Backend: modo ?lite=1 actualiza active_now de cada rep usando las sesiones activas reales, no siempre false como antes' },
      { type: 'fixed', text: 'Dashboard: el contador de jornadas activas ahora usa active_sessions.length como fuente prioritaria para rep, supervisor, admin y owner' },
    ]
  },
  {
    version: 'v2.23.4',
    date: '2026-03-21',
    tag: 'v2.23',
    tagColor: 'badge-muted',
    title: 'Fix error 500 en Stats y Jornadas del equipo',
    changes: [
      { type: 'fixed', text: 'Backend: _stats_admin crasheaba con PHP Fatal Error al hacer spread de array vacío cuando un admin no tiene supervisores configurados — corregido con array_map guard' },
      { type: 'fixed', text: 'Backend: _rep_summary ahora tiene try/catch — si falla la query de un rep concreto devuelve fila vacía en vez de tumbar todo el endpoint con error 500' },
      { type: 'fixed', text: 'Backend: ?lite=1 en /stats/dashboard — Jornadas del equipo hoy ya no hace N+1 queries (5 queries por rep), solo carga active_sessions con una query directa' },
    ]
  },
  {
    version: 'v2.23.3',
    date: '2026-03-21',
    tag: 'v2.23',
    tagColor: 'badge-muted',
    title: 'Stats del equipo · Ranking comerciales · Ajustes con datos reales',
    changes: [
      { type: 'new',      text: 'Estadísticas supervisor/admin/owner: carga datos reales de la API — visitas, jornadas, km, PDVs sin cobertura del equipo completo, no del dispositivo local' },
      { type: 'new',      text: 'Ranking de comerciales en Estadísticas: ordenados por visitas del mes con barra de progreso visual y badge de activo en tiempo real' },
      { type: 'new',      text: 'PDVs sin cobertura en Estadísticas: lista de paradas sin visita en 30 días con nombre, ciudad y dirección' },
      { type: 'new',      text: 'Exportar CSV del equipo: genera archivo con visitas, jornadas, km y PDVs sin visitar por cada comercial' },
      { type: 'improved', text: 'Ajustes · Tu organización: muestra datos reales del servidor (visitas mes, jornadas, PDVs sin cubrir, comerciales) en vez de contadores locales del dispositivo' },
      { type: 'fixed',    text: 'Stats y exportCSV: el parser de keys de visita usaba split incorrecto que podía romper fechas y stopIds en IDs con guiones bajos' },
    ]
  },
  {
    version: 'v2.23.2',
    date: '2026-03-21',
    tag: 'v2.23',
    tagColor: 'badge-muted',
    title: 'Fix fechas NaN · Dashboard supervisor · Historial jornadas',
    changes: [
      { type: 'fixed',    text: 'Historial jornadas: fechas mostraban NaN/INVALID DATE — parser de key routeId_YYYY-MM-DD corregido' },
      { type: 'fixed',    text: 'Dashboard supervisor: muestra mensaje útil si el equipo no tiene actividad, con botón reintentar si hay error' },
      { type: 'fixed',    text: 'Dashboard supervisor: aviso si no hay comerciales invitados al árbol todavía' },
    ]
  },
  {
    version: 'v2.23.1',
    date: '2026-03-21',
    tag: 'v2.23',
    tagColor: 'badge-muted',
    title: 'Fix asignación de rutas a comerciales · XSS · Formularios · Sync',
    changes: [
      { type: 'fixed',    text: 'Calendario: supervisor ya puede asignar rutas a sus comerciales — el selector mostraba supervisores mezclados con reps y nunca enviaba la asignación al comercial correcto' },
      { type: 'fixed',    text: 'Calendario: assignCal diferencia autoasignación (update local inmediato) de asignación a rep del equipo (pull silencioso tras confirmación del servidor)' },
      { type: 'fixed',    text: 'Calendario: clearCal con la misma lógica — rollback selectivo según si la asignación era propia o de un rep' },
      { type: 'fixed',    text: 'Calendario: mensaje claro cuando el supervisor no tiene comerciales asignados a su árbol todavía' },
    ]
  },
  {
    version: 'v2.23.0',
    date: '2026-03-21',
    tag: 'v2.23',
    tagColor: 'badge-muted',
    title: 'Seguridad XSS · Rollback calendario · Formulario visita · Sync y permisos',
    changes: [
      { type: 'fixed',    text: 'XSS: todos los campos de usuario (nombres de rutas, paradas, visitas, KPIs) se escapan antes de insertar en el DOM — 39 puntos corregidos en pages.js y jornada.js' },
      { type: 'fixed',    text: 'Calendario: assignCal y clearCal ahora hacen rollback automático si la API falla — el calendario local no queda desincronizado del servidor en caso de error de red' },
      { type: 'fixed',    text: 'Formulario de visita: los campos guardados ya no aparecen vacíos al editar — se rellenan con overlay.querySelector en el mismo frame del render, no diferido' },
      { type: 'fixed',    text: 'Backend: schedule_get filtra por usuario para rep — ya no devuelve la agenda de toda la organización a cualquier comercial autenticado' },
      { type: 'fixed',    text: 'Backend: assert_can_manage_resource implementado — supervisor solo puede editar/borrar paradas y rutas que él mismo creó' },
      { type: 'fixed',    text: 'Backend: users_invite bajado a rol supervisor con restricción de rango — supervisor puede invitar reps pero no otros supervisores ni admins' },
      { type: 'fixed',    text: 'Backend: stops_create tenía require_role duplicado — eliminado' },
      { type: 'fixed',    text: 'Backend: visits_update añade guard de propiedad — rep solo puede editar sus propias visitas' },
      { type: 'improved', text: 'Sync: polling automático reducido de 30s a 3 minutos — menos re-renders involuntarios al navegar rápido' },
      { type: 'improved', text: 'Sync: visibilitychange con cooldown de 10s — evita pull en cada cambio de pestaña o desbloqueo de móvil' },
      { type: 'improved', text: 'Router: flag _navigating protege el re-render del pull mientras el usuario está cambiando de pantalla' },
    ]
  },
  {
    version: 'v2.22.2',
    date: '2026-03-21',
    tag: 'v2.22',
    tagColor: 'badge-muted',
    title: 'Guards rep · Calendario verde · Resumen jornadas · Borrar real',
    changes: [
      { type: 'fixed',    text: 'Comercial no puede crear ni editar paradas, rutas ni importar — guards en todas las funciones (frontend y backend)' },
      { type: 'fixed',    text: 'Backend: stops_create/update/delete requieren rol supervisor o superior — rep recibe 403 aunque llame directamente a la API' },
      { type: 'new',      text: 'Calendario: días con jornada completada se marcan en verde — leyenda actualizada con el nuevo estado' },
      { type: 'new',      text: 'Sección jornadas recientes debajo del calendario del comercial — lista de las últimas 5 con paradas, km y tiempo' },
      { type: 'improved', text: 'Borrar paradas, rutas y miembros muestra texto Eliminar (no Archivar) para owner/admin/supervisor' },
      { type: 'fixed',    text: '_renderRouteDetail tiene guard de rol — rep que navegue directamente es redirigido al dashboard' },
    ]
  },
  {
    version: 'v2.22.1',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fase 6+7 · Árbol equipo · Perfil miembro · Uploads mejorados',
    changes: [
      { type: 'new',      text: 'Árbol del equipo expandible con click — cada miembro abre su perfil con KPIs, PDVs y jornadas recientes' },
      { type: 'new',      text: 'Perfil de miembro: visitas semanales, jornadas completadas, km recorridos, cobertura y PDVs sin visitar' },
      { type: 'new',      text: 'Fotos de visitas: subida real al servidor con redimensionado automático a 1200px máx' },
      { type: 'new',      text: 'DELETE /uploads/photo/:filename para borrar fotos del servidor al eliminarlas de la visita' },
      { type: 'improved', text: 'require_once uploads duplicado en index.php eliminado' },
    ]
  },
  {
    version: 'v2.21.2',
    date: '2026-03-21',
    tag: 'latest',
    tagColor: 'badge-indigo',
    title: 'Fase 6+7 · Perfil miembro · Árbol clickable · Uploads fotos',
    changes: [
      { type: 'new',      text: 'Árbol de equipo: clicar el nombre abre perfil con KPIs de la semana, cobertura, PDVs asignados y acciones rápidas' },
      { type: 'new',      text: 'Perfil de miembro carga stats reales del servidor — visitas, jornadas completadas, km y tiempo' },
      { type: 'new',      text: 'Uploads de fotos reales al servidor — las fotos de visitas se guardan en /uploads/visits/ en lugar de base64 local' },
      { type: 'improved', text: 'Directorio uploads/ protegido con .htaccess — bloquea ejecución de código subido' },
      { type: 'improved', text: 'stats/dashboard acepta userId externo para ver stats de cualquier miembro del equipo' },
    ]
  },
  {
    version: 'v2.22.0',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fase 6+7 · Árbol de equipo · Uploads de fotos',
    changes: [
      { type: 'new',      text: 'Equipo en Ajustes muestra árbol jerárquico expandible — propietario > director > jefe de zona > comercial con niveles visuales' },
      { type: 'new',      text: 'Nodos con hijos muestran botón colapsar/expandir y contador de miembros' },
      { type: 'new',      text: 'Fotos de visitas se suben al servidor real (POST /uploads/photo) en lugar de guardarse en base64 en localStorage' },
      { type: 'improved', text: 'Fallback automático a base64 local si no hay conexión o la subida falla — sin pérdida de fotos' },
      { type: 'improved', text: 'Fotos en servidor se comprimen a máx 1200px y 85% calidad para ahorrar espacio' },
    ]
  },
  {
    version: 'v2.21.1',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'GPS tracking · Resumen jornadas equipo · Tramo por visita',
    changes: [
      { type: 'new',      text: 'Mapa muestra polilínea verde del recorrido GPS real de la jornada + puntos de inicio y fin' },
      { type: 'new',      text: 'Marcadores naranja en el mapa para cada parada visitada con check-in registrado' },
      { type: 'new',      text: 'Botón Jornadas hoy en dashboard de supervisor/director/propietario — muestra estado de todo el equipo' },
      { type: 'new',      text: 'Detalle de visita muestra posición GPS registrada + botón Ver tramo que abre el mapa centrado en ese PDV' },
      { type: 'new',      text: 'Mapa resalta en amarillo el tramo GPS recorrido durante el tiempo de permanencia en cada visita' },
    ]
  },
  {
    version: 'v2.21.0',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Dashboards por rol · GPS visitas · Sync completo',
    changes: [
      { type: 'new',      text: 'Dashboard comercial: KPIs reales del servidor — visitas hoy, cobertura, comparativa con periodo anterior' },
      { type: 'new',      text: 'Dashboard supervisor/director/propietario: estado del equipo en tiempo real con datos de /stats/dashboard' },
      { type: 'new',      text: 'Selector de periodo en dashboard (hoy/semana/mes) para todos los roles' },
      { type: 'new',      text: 'Propietario ve desglose por director con barra de progreso de visitas' },
      { type: 'new',      text: 'GPS en visitas: lat/lng capturado automáticamente en check-in y check-out de cada parada' },
      { type: 'improved', text: 'Sync: visits guarda check_in_at, check_out_at, lat_in/lng_in/lat_out/lng_out y session_id en BD' },
      { type: 'improved', text: 'Sync: sessions guarda started_at y finished_at en BD' },
    ]
  },
  {
    version: 'v2.20.3',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Permisos por rol · Limpieza datos demo · Fix schedules',
    changes: [
      { type: 'fixed',    text: 'Supervisor ya puede crear, editar y archivar rutas y PDVs de su org — el guard ya no requiere ser el creador original' },
      { type: 'fixed',    text: 'Comercial ya no puede crear rutas ni asignar PDVs — solo ve calendario y jornada asignada' },
      { type: 'fixed',    text: 'Schedule duplicado al asignar: añadido UNIQUE KEY (org, rep, fecha) en schedules — un rep una ruta por día' },
      { type: 'fixed',    text: 'Datos demo eliminados de BD: rutas R1/R2/R3, stops C001/C002, NORTE duplicada — ver fix_datos_demo.sql' },
      { type: 'fixed',    text: 'users_assign_stops: eliminado filtro duplicado de zone_ids del supervisor' },
      { type: 'improved', text: 'routes_delete bajado a supervisor — puede archivar rutas sin necesitar ser admin' },
    ]
  },
  {
    version: 'v2.20.3',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fix permisos rutas · Limpieza datos demo',
    changes: [
      { type: 'fixed',    text: 'Supervisor ya puede editar y gestionar todas las rutas y paradas de su org — created_by NULL no bloquea' },
      { type: 'fixed',    text: 'Asignación de rutas a comerciales corregida — UNIQUE KEY en schedules evita duplicados' },
      { type: 'fixed',    text: 'Datos demo (R1/R2/R3 y stops C001/C002) eliminados via SQL — ver fix_datos_demo_y_rutas.sql' },
      { type: 'improved', text: 'Supervisor puede archivar rutas (antes solo admin) — archivar no es borrar definitivo' },
      { type: 'improved', text: 'users_assign_stops: supervisor puede asignar cualquier PDV de la org a sus comerciales' },
    ]
  },
  {
    version: 'v2.20.2',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fix paradas jornada · Dashboards backend · GPS visitas',
    changes: [
      { type: 'fixed',    text: 'Bug crítico: paradas de rutas asignadas no llegaban al comercial si existían antes de su primer sync — corregido en sync delta' },
      { type: 'new',      text: 'Backend: endpoint /stats/dashboard con KPIs completos por rol — rep, supervisor, director y propietario' },
      { type: 'new',      text: 'GPS en visitas: campos lat_in/lng_in/lat_out/lng_out para tracking de posición en check-in y check-out' },
      { type: 'new',      text: 'daily_stats: tabla de stats precalculadas para dashboards rápidos' },
      { type: 'new',      text: 'Índices de BD en sessions, visits y schedules para queries de dashboard' },
      { type: 'improved', text: 'Timestamps check_in_at y check_out_at de visitas incluidos en el sync delta' },
    ]
  },
  {
    version: 'v2.20.1',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fase 4 · Ajustes completos por rol',
    changes: [
      { type: 'new',      text: 'Cambio de contraseña desde Ajustes → Mi cuenta — revoca sesiones en otros dispositivos al guardar' },
      { type: 'new',      text: 'Notificaciones de jornada solo visibles para comercial — no tiene sentido para roles que no hacen jornada' },
      { type: 'improved', text: 'Subtítulo de Ajustes contextual por rol — propietario ve Organización, comercial ve Tu cuenta y preferencias' },
      { type: 'improved', text: 'Resumen muestra Tu organización para supervisor y superior en lugar de Estado actual' },
    ]
  },
  {
    version: 'v2.20.0',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fase 3 · Nav y ajustes por rol',
    changes: [
      { type: 'new',      text: 'Jornada desaparece del nav inferior para supervisor, director y propietario — solo la ven los comerciales' },
      { type: 'new',      text: 'Calendario muestra "Equipo" en el nav inferior para supervisor+ en lugar de "Cal."' },
      { type: 'new',      text: 'Ajustes: Exportar e Importar backup solo visibles para jefe de zona y superior' },
      { type: 'new',      text: 'Ajustes: Borrar todos los datos solo visible para propietario' },
    ]
  },
  {
    version: 'v2.19.7',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Hotfix · Error 500 en login',
    changes: [
      { type: 'fixed', text: 'ORDER BY FIELD con comillas simples dentro de string PHP rompía el login — eliminado en auth_login y auth_refresh' },
    ]
  },
  {
    version: 'v2.19.6',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fix selector manager · Preselección correcta por rango',
    changes: [
      { type: 'fixed', text: 'El selector Reporta a ya no muestra Propietario por defecto — selecciona el rango inmediatamente superior al rol asignado' },
      { type: 'fixed', text: 'La lista de managers se ordena de menor a mayor rango — Director aparece antes que Propietario' },
      { type: 'fixed', text: 'Fix m.id en respuesta de API — el frontend puede acceder correctamente al ID del miembro' },
      { type: 'fixed', text: 'Si el manager actual sigue siendo válido se mantiene preseleccionado al editar' },
    ]
  },
  {
    version: 'v2.19.5',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fix login multi-org · Propietario gestiona su equipo',
    changes: [
      { type: 'fixed', text: 'Login con usuario de varias orgs ahora entra en la org donde es propietario, no en la primera aleatoria' },
      { type: 'fixed', text: 'Propietario ya puede cambiar el manager de supervisores y comerciales sin error de permisos' },
    ]
  },
  {
    version: 'v2.19.5',
    date: '2026-03-21',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fix permisos propietario · Bypass de árbol',
    changes: [
      { type: 'fixed', text: 'Propietario puede gestionar cualquier miembro de su org sin depender del árbol de manager_id' },
      { type: 'fixed', text: 'Propietario no puede gestionar a otro propietario — única restricción que se mantiene' },
    ]
  },
  {
    version: 'v2.19.4',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Asignación de manager · Jerarquía configurable',
    changes: [
      { type: 'fixed',    text: 'Al invitar un miembro aparece selector de manager — ya no se asigna siempre al que invita' },
      { type: 'fixed',    text: 'Modal editar miembro muestra el manager actual preseleccionado y permite cambiarlo sin tocar el rol' },
      { type: 'fixed',    text: 'Propietario puede reasignar a quién reporta cada supervisor y comercial desde Ajustes → Equipo' },
      { type: 'improved', text: 'El selector de manager se actualiza automáticamente al cambiar el rol — solo muestra rangos superiores válidos' },
    ]
  },
  {
    version: 'v2.19.3',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fix permisos · Fallback jerarquía vacía',
    changes: [
      { type: 'fixed',    text: 'Admin ya puede gestionar supervisores y reps aunque no tenga el árbol de manager_id configurado' },
      { type: 'fixed',    text: 'Jerarquía de managers corregida via SQL — ver fix_jerarquia_managers.sql' },
    ]
  },
  {
    version: 'v2.19.2',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'God mode · Mover usuarios entre orgs · Bypass de permisos',
    changes: [
      { type: 'fixed',    text: 'God ya puede gestionar usuarios sin recibir error de permisos — bypass en todos los guards jerárquicos' },
      { type: 'new',      text: 'God puede mover cualquier usuario a otra organización con el rol que elija' },
      { type: 'new',      text: 'Panel God: botón mover (⇄) en cada fila de usuario abre modal con selector de org y rol destino' },
      { type: 'improved', text: 'users_list acepta parámetro orgId para que God pueda consultar usuarios de cualquier org' },
    ]
  },
  {
    version: 'v2.19.1',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fase 2 · Archivar vs eliminar · Badges de equipo',
    changes: [
      { type: 'new',      text: 'Archivar en lugar de eliminar — rutas, paradas y miembros se archivan con archived_at y archived_by en BD' },
      { type: 'new',      text: 'Solo God puede hacer DELETE real — el resto siempre archiva para mantener trazabilidad' },
      { type: 'fixed',    text: 'Badge de Comercial ahora aparece con color verde como los demás roles' },
      { type: 'fixed',    text: 'Modal de invitar mostraba Admin/Supervisor en lugar de Director/Jefe de zona' },
      { type: 'improved', text: 'Confirmaciones de borrado cambiadas a Archivar con texto explicativo' },
    ]
  },
  {
    version: 'v2.19.0',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fase 1 · Permisos jerárquicos en backend',
    changes: [
      { type: 'new',      text: 'assert_can_manage_user() — supervisor/admin solo puede modificar usuarios de su árbol descendiente' },
      { type: 'new',      text: 'assert_can_manage_resource() — supervisor solo puede editar/borrar rutas y PDVs que él creó' },
      { type: 'new',      text: 'assert_can_schedule_for() — solo puede planificar para reps de su árbol' },
      { type: 'improved', text: 'routes_update, routes_delete, stops_update, stops_delete verifican ownership antes de actuar' },
      { type: 'improved', text: 'schedule_set verifica que el rep asignado pertenece al árbol del supervisor' },
      { type: 'improved', text: 'users_update_role y users_remove verifican jerarquía — no puedes gestionar usuarios de igual o mayor rango' },
      { type: 'fixed',    text: 'Eliminada constante _ROLE_LEVELS duplicada en frontend — toda la app usa _ROLE_ORDER como fuente única' },
    ]
  },
  {
    version: 'v2.18.4',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Dashboard manager · Forzar sync · Precargar equipo',
    changes: [
      { type: 'fixed',    text: 'Dashboard de propietario/supervisor ya no aparece en blanco — muestra skeleton mientras carga el equipo' },
      { type: 'new',      text: 'Botón "Forzar sincronización" en Ajustes — descarga todos los datos del servidor y limpia datos locales obsoletos' },
      { type: 'improved', text: 'Datos del equipo se precargan al restaurar sesión para que el dashboard esté listo al entrar' },
    ]
  },
  {
    version: 'v2.18.4',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Jerarquía de equipo · Dashboard por rol',
    changes: [
      { type: 'new',      text: 'Jerarquía manager_id en BD — cada miembro tiene un responsable directo explícito, escalable a N niveles' },
      { type: 'new',      text: 'Dashboard diferenciado: comercial ve su jornada de hoy, supervisor/director/propietario ven el resumen de su equipo' },
      { type: 'new',      text: 'Visibilidad jerárquica: propietario ve toda la org, director ve su árbol sin otros directores, supervisor solo sus comerciales' },
      { type: 'new',      text: 'Al invitar un miembro, el que invita queda automáticamente como su manager directo' },
      { type: 'new',      text: 'Al cambiar rol, selector de manager para asignarlo al responsable correcto' },
      { type: 'improved', text: 'Sessions y visitas del sync filtradas por jerarquía — cada rol ve solo la actividad de su árbol' },
      { type: 'improved', text: 'get_visible_user_ids con CTE recursiva — eficiente para cualquier profundidad de árbol' },
    ]
  },
  {
    version: 'v2.17.6',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fixes: sync badge · restricción PDVs · chips calendario',
    changes: [
      { type: 'fixed',    text: 'Badge "Sin sync" ya no aparece al arrancar antes de que el token esté listo — solo sale cuando hay cambios reales pendientes' },
      { type: 'fixed',    text: 'Jefe de zona ya no puede asignar a un comercial PDVs que él mismo no tiene en su zona' },
      { type: 'improved', text: 'Chips del calendario muestran tooltip con las rutas asignadas al pasar el dedo por el día' },
      { type: 'fixed',    text: 'Versiones del historial de cambios corregidas — cada entrega tiene su número correcto' },
    ]
  },
  {
    version: 'v2.17.6',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Fixes pendientes del QA · Seguridad de asignaciones',
    changes: [
      { type: 'fixed',    text: 'Badge "Sin sync" ya no aparece al cargar — la cola pendiente se envía automáticamente al restaurar sesión' },
      { type: 'fixed',    text: 'Jefe de zona solo puede asignar a sus comerciales PDVs que él mismo tiene asignados en su zona' },
      { type: 'fixed',    text: 'Changelog corregido — versiones 2.17.1 a 2.17.4 ya aparecen con sus números correctos' },
    ]
  },
  {
    version: 'v2.17.5',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Calendario multi-rep · UI al recargar · Schedules correctos',
    changes: [
      { type: 'fixed',    text: 'Al recargar la página la UI ya se muestra correctamente como logueado sin esperar al refresh del token' },
      { type: 'fixed',    text: 'Quitar asignación de un día ya no borra los schedules de otros reps ese mismo día' },
      { type: 'improved', text: 'Calendario del jefe de zona muestra chips con el número de reps asignados ese día, no solo su propia asignación' },
      { type: 'improved', text: 'El sync devuelve los schedules de todo el equipo al jefe de zona para la vista de calendario' },
    ]
  },
  {
    version: 'v2.17.4',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Sesión persistente · Preferencias en servidor',
    changes: [
      { type: 'fixed',    text: 'Al recargar la página ya no se cierra la sesión — reintento automático antes de logout' },
      { type: 'fixed',    text: 'Timeout de renovación de sesión ampliado de 8s a 15s para conexiones lentas' },
      { type: 'new',      text: 'Tema claro/oscuro, notificaciones y hora de recordatorio se guardan en el servidor — persisten en cualquier dispositivo' },
      { type: 'improved', text: 'Al hacer login o volver a la app, las preferencias del servidor se aplican automáticamente' },
    ]
  },
  {
    version: 'v2.17.3',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Limpieza de datos demo · Prefs solo locales',
    changes: [
      { type: 'fixed',    text: 'Los datos demo (C001-C009, R1-R3) ya no se suben nunca al servidor — filtro reforzado en SyncQueue y en initialSync' },
      { type: 'fixed',    text: 'Al hacer login se limpian automáticamente los datos demo del localStorage antes de sincronizar' },
      { type: 'fixed',    text: 'En cada pull se eliminan demos residuales que pudieran haber quedado de sesiones anteriores' },
      { type: 'improved', text: 'Nombre y email del usuario ahora se guardan en prefs para usarlos en el selector del calendario' },
    ]
  },
  {
    version: 'v2.17.2',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Sync instantáneo en todas las acciones',
    changes: [
      { type: 'improved', text: 'Debounce de persist reducido de 2s a 300ms — cambios locales llegan al servidor casi instantáneamente' },
      { type: 'improved', text: 'Polling de actualización reducido de 5 minutos a 30 segundos' },
      { type: 'improved', text: 'Reintentos de sync mucho más rápidos: 0.5s→1s→2s→5s→15s (antes 2s→4s→8s→30s→5min)' },
      { type: 'improved', text: 'Push inmediato al iniciar, pausar y finalizar jornada' },
      { type: 'improved', text: 'Push inmediato al guardar visita, eliminar visita, añadir foto y resetear jornada' },
      { type: 'improved', text: 'Push inmediato al crear, editar y eliminar rutas y PDVs' },
      { type: 'improved', text: 'Push inmediato al importar CSV/XLSX y al restaurar backup' },
      { type: 'improved', text: 'Pull automático al volver a abrir la app — datos siempre frescos' },
      { type: 'new',      text: 'syncNow() disponible globalmente para forzar push inmediato desde cualquier acción' },
    ]
  },
  {
    version: 'v2.17.1',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Selector de rep en calendario · Schedules aislados por rol',
    changes: [
      { type: 'new',      text: 'Calendario: al asignar una ruta a un día aparece selector de rep — la ruta se asigna al comercial elegido, no al usuario actual' },
      { type: 'fixed',    text: 'Sync: el comercial solo recibe los schedules que le están asignados a él — no ve las planificaciones de otros reps' },
      { type: 'improved', text: 'Dashboard: el comercial ve "Sin rutas asignadas" en lugar de "Sin planificación" y al tocar una entrada va directo a la jornada' },
      { type: 'improved', text: 'Dashboard: el botón "Planificar" solo aparece para jefe de zona y superior — el rep no puede planificar' },
    ]
  },
  {
    version: 'v2.16.4',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Aislamiento de datos por rol — QA completo',
    changes: [
      { type: 'fixed', text: 'Backend: comercial solo recibe rutas asignadas en su calendario — no todas las de la org' },
      { type: 'fixed', text: 'Sync: delta de rutas filtrado para comercial igual que en routes_list' },
      { type: 'fixed', text: 'Informes: comercial ve solo sus jornadas y visitas propias — filtrado por userId en localStorage' },
      { type: 'fixed', text: 'Informes: botón Estadísticas oculto para comercial — solo ve su historial' },
      { type: 'improved', text: 'Títulos contextuales: "Mi actividad" para comercial, "Estadísticas de mi zona" para jefe de zona' },
      { type: 'improved', text: 'Todos los warnings del informe QA v2.14 cerrados — aislamiento de datos completo por rol' },
    ]
  },
  {
    version: 'v2.15.0',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'QA fixes · botones por rol',
    changes: [
      { type: 'fixed', text: 'Calendario: comercial toca un día y va directo a la jornada — ya no ve el picker de rutas' },
      { type: 'fixed', text: 'PDV detalle: botón Editar solo visible para jefe de zona y superior' },
      { type: 'fixed', text: 'Dashboard: botones "Ver todas" y "Nueva ruta" ocultos para comercial' },
      { type: 'fixed', text: 'Lista de PDVs: comercial solo ve el botón de ficha — sin editar, asignar ni eliminar' },
      { type: 'fixed', text: 'Header: botones Nueva Ruta y Nueva Parada ocultos para comercial' },
      { type: 'fixed', text: 'Página de PDVs muestra "Mis PDVs" al comercial e "Información PDVs" al resto' },
      { type: 'fixed', text: 'Supervisor sin zona asignada ve todos los PDVs — comportamiento esperado en migración gradual' },
    ]
  },
  {
    version: 'v2.14.0',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Asignación de PDVs por jerarquía',
    changes: [
      { type: 'new',      text: 'Comercial solo ve sus PDVs asignados — si no tiene ninguno asignado ve lista vacía' },
      { type: 'new',      text: 'Jefe de zona ve solo sus PDVs asignados — si no tiene asignados ve todos (transitorio)' },
      { type: 'new',      text: 'Director y Propietario ven todos los PDVs de la org siempre' },
      { type: 'new',      text: 'Botón asignar PDVs en la lista de equipo — abre selector con búsqueda y checkboxes' },
      { type: 'new',      text: 'Jerarquía de asignación: director asigna a jefe de zona, jefe de zona asigna a sus comerciales' },
      { type: 'new',      text: 'Jefe de zona no puede asignar PDVs que no tiene en su propia zona' },
      { type: 'improved', text: 'Sync pull también filtra PDVs por zone_ids — el comercial solo descarga los suyos' },
    ]
  },
  {
    version: 'v2.14.0-a',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Asignación de PDVs por jerarquía (migración)',
    changes: [
      { type: 'new',      text: 'Sistema de asignación de PDVs — propietario/director asigna a jefe de zona, jefe de zona asigna a comercial' },
      { type: 'new',      text: 'Botón de mapa-pin en cada miembro del equipo para abrir el modal de asignación' },
      { type: 'new',      text: 'Modal de asignación: lista completa de PDVs con checkbox, buscador y contador en tiempo real' },
      { type: 'new',      text: 'Backend: stops_list y sync filtran PDVs por zone_ids cuando el rol es comercial o jefe de zona con asignación' },
      { type: 'new',      text: 'Jefes de zona ahora ven la sección Equipo en Ajustes para gestionar sus comerciales' },
      { type: 'improved', text: 'Nombres de roles: Comercial, Jefe de zona, Director, Propietario — más intuitivos' },
      { type: 'improved', text: 'Lista de equipo ordenada por importancia de rol (propietario primero, comercial último)' },
    ]
  },
  {
    version: 'v2.13.0',
    date: '2026-03-20',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Nav adaptativo por rol',
    changes: [
      { type: 'new',      text: 'Menú lateral adaptativo — cada rol ve solo las páginas que le corresponden' },
      { type: 'new',      text: 'Comercial: ve Inicio, Mapa, Calendario, Mis PDVs, Mi actividad y Ajustes' },
      { type: 'new',      text: 'Jefe de zona: añade Rutas, Estadísticas y Formularios sobre el comercial' },
      { type: 'new',      text: 'Labels duales: comercial ve "Mis PDVs" y "Mi actividad", supervisor ve "PDVs" e "Informes"' },
      { type: 'new',      text: 'Botón Nueva Ruta solo visible para supervisor, director y propietario' },
      { type: 'fixed',    text: 'Calendario: solo supervisor+ puede asignar rutas — rep tiene vista solo lectura' },
      { type: 'fixed',    text: 'Rutas, Estadísticas y Formularios redirigen a Inicio si el rol es comercial' },
    ]
  },
  {
    version: 'v2.12.0',
    date: '2026-03-19',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Sistema de aprobación de registros',
    changes: [
      { type: 'new',   text: 'Registro ahora crea una solicitud pendiente — god debe aprobarla antes de que el usuario pueda entrar' },
      { type: 'new',   text: 'Pantalla de solicitud pendiente con polling automático cada 30s — avisa cuando se aprueba' },
      { type: 'new',   text: 'Panel God: pestaña Solicitudes con badge de contador y botones Aprobar/Rechazar' },
      { type: 'new',   text: 'Si una solicitud fue rechazada, el usuario puede volver a solicitarlo con nuevos datos' },
      { type: 'improved', text: 'Botón de registro renombrado a Solicitar acceso para reflejar el nuevo flujo' },
    ]
  },
  {
    version: 'v2.11.0',
    date: '2026-03-19',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Panel God — vistas nativas, tests ocultos',
    changes: [
      { type: 'improved', text: 'Panel God: edición de org como vista completa en lugar de modal — funciona bien en móvil' },
      { type: 'improved', text: 'Orgs y usuarios de test agrupados y colapsados — solo se muestran orgs/usuarios reales por defecto' },
      { type: 'new',      text: 'Vista de edición de org con selector de plan por botones, stepper de seats y toggle activa/inactiva' },
      { type: 'new',      text: 'Caché local de orgs y usuarios en el panel — no recarga en cada cambio de tab' },
    ]
  },
  {
    version: 'v2.10.0',
    date: '2026-03-19',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Panel God · Versión dinámica',
    changes: [
      { type: 'new',   text: 'Panel God accesible solo para rol god — lista de todas las orgs y usuarios de la plataforma' },
      { type: 'new',   text: 'Endpoints /platform/orgs y /platform/users protegidos con verificación en tiempo real contra BD' },
      { type: 'new',   text: 'Gestión de orgs: cambiar plan, seat_limit y estado activo sin entrar a phpMyAdmin' },
      { type: 'fixed', text: 'Versión en ajustes ahora es dinámica — se lee de CHANGELOG[0].version sin hardcodear' },
    ]
  },
  {
    version: 'v2.9.0',
    date: '2026-03-19',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'God mode · Roles de plataforma',
    changes: [
      { type: 'new',   text: 'Sistema de roles de plataforma — god y platform_admin, independientes de las orgs de clientes' },
      { type: 'new',   text: 'El creador de la app (god) tiene visibilidad y control sobre todas las organizaciones' },
      { type: 'new',   text: 'Badge de plataforma visible en el perfil — identifica al usuario god/platform_admin' },
      { type: 'new',   text: 'JWT extendido con claim pRole — incluido solo si el usuario tiene rol de plataforma' },
      { type: 'new',   text: 'require_platform_role() y verify_god_realtime() — middleware listo para el panel god' },
      { type: 'fixed', text: 'host=127.0.0.1 en config.php — elimina errores de socket MySQL en hosting compartido' },
    ]
  },
  {
    version: 'v2.8.1',
    date: '2026-03-19',
    tag: 'badge-gray',
    tagColor: 'badge-gray',
    title: 'Invitaciones con contraseña temporal',
    changes: [
      { type: 'improved', text: 'Invitar miembro muestra contraseña temporal legible (xxxx-xxxx-xxxx) en un modal' },
      { type: 'new',      text: 'Botón para copiar la contraseña al portapapeles' },
      { type: 'new',      text: 'Botón para copiar el texto completo de invitación: URL + email + contraseña' },
      { type: 'fixed',    text: 'Si el email ya tiene cuenta existente, se añade al equipo sin mostrar contraseña' },
    ]
  },
  {
    version: 'v2.8',
    date: '2026-03-19',
    tag: 'anterior',
    tagColor: 'badge-gray',
    title: 'Fase 4 · Gestión de equipo',
    changes: [
      { type: 'new', text: 'Sección Equipo en Ajustes — visible para admin y owner' },
      { type: 'new', text: 'Invitar miembro por email con selección de rol (Comercial, Supervisor, Admin)' },
      { type: 'new', text: 'Cambiar rol de cualquier miembro del equipo' },
      { type: 'new', text: 'Desactivar miembro con confirmación — no borra datos históricos' },
      { type: 'new', text: 'Lista de miembros con nombre, email, rol y estado activo/inactivo' },
      { type: 'improved', text: 'Invitación muestra contraseña temporal y botones para copiar — no requiere email del servidor' },
    ]
  },
  {
    version: 'v2.7.2',
    date: '2026-03-19',
    tag: 'anterior',
    tagColor: 'badge-gray',
    title: 'Fix login automático al arrancar sin sesión',
    changes: [
      { type: 'fixed', text: 'Al arrancar sin sesión → modal de login se abre automáticamente en lugar de mostrar pantalla vacía' },
      { type: 'fixed', text: 'Al expirar sesión en cualquier momento → modal de login se abre solo, sin tener que pulsar Cuenta' },
    ]
  },
  {
    version: 'v2.7.1',
    date: '2026-03-18',
    tag: 'anterior',
    tagColor: 'badge-gray',
    title: 'Test suite completo · Script de limpieza',
    changes: [
      { type: 'new',   text: 'Test suite reescrito: 60 tests cubriendo todas las tablas — stops, routes, schedules, sessions, visits, forms, kpis, sync, seguridad' },
      { type: 'new',   text: 'Test de idempotencia del sync push — verifica que el mismo requestId no se procesa dos veces' },
      { type: 'new',   text: 'Tests de seguridad — 5 endpoints verificados como protegidos sin token' },
      { type: 'new',   text: 'cleanup_v15.php — script para eliminar carpeta antigua del servidor con autoeliminación' },
      { type: 'fixed', text: 'Al arrancar sin sesión → modal de login se abre automáticamente en lugar de mostrar pantalla vacía' },
      { type: 'fixed', text: 'Al expirar sesión en cualquier momento → modal de login se abre solo, sin tener que pulsar Cuenta' },
    ]
  },
  {
    version: 'v2.7',
    date: '2026-03-18',
    tag: 'anterior',
    tagColor: 'badge-gray',
    title: 'Fase 3 · Sync robusto y retry exponencial',
    changes: [
      { type: 'fixed', text: 'S-02 · Idempotency keys en push — reenvíos de cola ya no crean registros duplicados en el servidor' },
      { type: 'fixed', text: 'S-05 · Tabla schedules con updated_at — pull de calendario vuelve a ser incremental, no carga todo cada vez' },
      { type: 'new',   text: 'Retry exponencial en sync push — reintenta automáticamente: 2s→4s→8s→30s→5min si no hay red' },
      { type: 'new',   text: 'Indicador de sync muestra tiempo de próximo reintento al pasar el ratón' },
      { type: 'fixed', text: 'Sesión: refresh token movido a localStorage — ya no se pierde al cerrar la PWA instalada en Android' },
      { type: 'fixed', text: 'Sesión: _doRefresh con timeout propio de 8s — ya no hace logout por servidor lento' },
      { type: 'fixed', text: 'Sesión: sin red → mantiene sesión con datos locales y reintenta al volver online' },
      { type: 'fixed', text: 'Sesión: Tokens.clear() ya no borra _lastSyncTs — el pull sigue siendo incremental al re-login' },
      { type: 'fixed', text: 'Schedule: path /api/schedule duplicado corregido a /schedule — las asignaciones de calendario ya llegan al servidor' },
      { type: 'fixed', text: 'Visitas: DB.setVisits ahora encola en SyncQueue — las visitas ya se sincronizan con el servidor' },
      { type: 'fixed', text: 'Visitas: saveVisit genera un id UUID por visita — el backend puede hacer upsert por PK sin duplicados' },
      { type: 'fixed', text: 'Jornadas: setJornadas encolaba con collection jornadas (ignorada) — corregido a sessions con routeId y dateStr separados' },
    ]
  },
  {
    version: 'v2.6',
    date: '2026-03-18',
    tag: 'anterior',
    tagColor: 'badge-gray',
    title: 'Fase 2 · Seguridad y aislamiento de datos',
    changes: [
      { type: 'fixed', text: 'L-01 · Sesiones y visitas aisladas por rol — rep solo ve sus propios datos; supervisor/admin/owner ven toda la org' },
      { type: 'fixed', text: 'A-02 · Access token en memoria JS (no localStorage) — refresh token en sessionStorage; superficie XSS reducida' },
      { type: 'fixed', text: 'A-02 · Migración automática del AT/RT del formato antiguo (localStorage) al nuevo al arrancar la app' },
      { type: 'fixed', text: 'A-03 · Purga automática de refresh tokens expirados y revocados en cada login/refresh — tabla nunca crece indefinidamente' },
      { type: 'fixed', text: 'L-02 · seat_limit aplicado antes de crear membership — plan free no puede superar el límite de usuarios' },
    ]
  },
  {
    version: 'v2.6',
    date: '2026-03-18',
    tag: 'anterior',
    tagColor: 'badge-indigo',
    title: 'Fase 1 — Fixes críticos de seguridad y datos',
    changes: [
      { type: 'fixed', text: 'S-04 · Path /api/sync/pull duplicado corregido — el pull incremental nunca llegaba al servidor correctamente' },
      { type: 'fixed', text: 'S-01 · Visitas indexadas por id único — doble visita al mismo cliente ya no sobreescribe la primera silenciosamente' },
      { type: 'fixed', text: 'S-01 · _map_visit() incluye id, stopId y sessionId — el cliente reconstruye la clave local correctamente tras sync' },
      { type: 'fixed', text: 'A-01 · Refresh token lookup O(n) eliminado — selector hash permite buscar en O(1) con índice UNIQUE en BD' },
      { type: 'fixed', text: 'S-03 · Datos de seedDemo filtrados por _isDemo:true — nunca se sincronizan al servidor al hacer login' },
    ]
  },
  {
    version: 'v2.4',
    date: '2026-03-18',
    tag: 'anterior',
    tagColor: 'badge-gray',
    title: 'Fix planificación · Fix SW versión · Mejoras test suite',
    changes: [
      { type: 'fixed', text: 'Planificación de rutas no persistía al refrescar — assignCal y clearCal sincronizan con /api/schedule en servidor' },
      { type: 'fixed', text: 'sync/pull devolvía schedule vacío si los registros eran anteriores al último sync — ahora se devuelve completo siempre' },
      { type: 'fixed', text: 'SW: handler GET_VERSION respondía por e.source en lugar de e.ports[0] — corrige Timeout en test de versión SW' },
      { type: 'fixed', text: 'Rate limit /auth/register subido de 10 a 20 por hora — el test suite fallaba tras varios runs seguidos' },
      { type: 'fixed', text: 'Test suite: delay 400ms tras llamadas de auth para no saturar el rate limiter' },
    ]
  },
  {
    version: 'v2.3',
    date: '2026-03-18',
    tag: 'anterior',
    tagColor: 'badge-gray',
    title: 'Mapas multicapa · Backend PHP',
    changes: [
      { type: 'new',      text: '24 estilos de mapa organizados en 6 proveedores: OpenStreetMap, Carto, Esri, Stadia, Jawg, Thunderforest' },
      { type: 'new',      text: 'Backend PHP completo para hosting compartido — sin Node ni Railway' },
      { type: 'new',      text: 'JWT HS256 puro en PHP sin dependencias externas' },
      { type: 'fixed',    text: 'Service Worker reescrito limpio — eliminado código duplicado que impedía detectar actualizaciones' },
      { type: 'fixed',    text: 'API routes.php: startedAt y finishedAt protegidos con !empty() — elimina PHP 8 Undefined array key warning' },
    ]
  },
  {
    version: 'v1.7.10',
    date: '2025-09-20',
    tag: 'anterior',
    tagColor: 'badge-gray',
    title: 'Estadísticas, CSV y modo offline',
    changes: [
      { type: 'new', text: 'Página de Estadísticas con gráficas de barras de visitas por semana (últimas 8)' },
      { type: 'new', text: 'KPIs por semana: una gráfica independiente por cada KPI configurado' },
      { type: 'new', text: 'Top 5 paradas más visitadas con barra de progreso relativa' },
      { type: 'new', text: 'Resumen global: visitas totales, km recorridos, horas en ruta y media de visitas por jornada' },
      { type: 'new', text: 'Exportación CSV de todas las visitas con columnas dinámicas por KPI — compatible con Excel' },
      { type: 'new', text: 'BOM UTF-8 en el CSV para correcta visualización de tildes en Excel' },
      { type: 'new', text: 'Service Worker: la app funciona offline tras primera carga (cache-first para assets, CDN cacheado)' },
      { type: 'new', text: 'Estadísticas accesibles desde menú lateral' },
      { type: 'fixed', text: 'Jornada: barra de timer movida fuera del page-body al main-content — elimina definitivamente el desbordamiento horizontal' },
      { type: 'fixed', text: 'Jornada: barra de timer se oculta al navegar a otras vistas (calendario, inicio, etc.)' },
      { type: 'fixed', text: 'Jornada: header sin overflow:hidden — botón mapa siempre visible, no se corta por la derecha' },
      { type: 'fixed', text: 'Layout: #page-content con overflow-x:hidden — los flex-children respetan el ancho disponible' },
      { type: 'fixed', text: 'Layout: app-shell con width:100% explícito — el flex container tiene ancho definido, no expandible' },
      { type: 'fixed', text: 'Layout: main-content con overflow-x:hidden y min-width:0 — el contenido principal nunca puede expandir el viewport' },
      { type: 'fixed', text: 'Topbar: max-width:100% para que no supere el ancho del contenedor padre' },
      { type: 'fixed', text: 'Changelog: versiones v1.3.1 a v1.3.9 faltantes añadidas, tags de versiones antiguas corregidos' },
      { type: 'fixed', text: 'Changelog: añadidas versiones v1.3.1–v1.3.9 que faltaban; corregidos tags de versiones anteriores' },
      { type: 'fixed', text: 'Auditoría HTML completa: 12 fixes en jornada, formularios, KPIs, mapa y listas de fechas' },
      { type: 'fixed', text: 'Overlays: todos los botones cerrar/cancelar usan Overlay.pop() — body overflow nunca queda bloqueado' },
      { type: 'fixed', text: 'Mapa popup: colores hardcodeados reemplazados por valores accesibles' },
      { type: 'fixed', text: 'Listas de fechas: width fijo reemplazado por min-width para adaptarse a pantallas pequeñas' },
      { type: 'improved', text: 'Informes: botón CSV directo en la cabecera' },
    ]
  },
  {
    version: 'v1.3.10',
    date: '2025-07-26',
    tag: 'estable',
    tagColor: 'badge-indigo',
    title: 'Mapa interactivo, ficha de parada y fixes móvil',
    changes: [
      { type: 'new',      text: 'Vista de Mapa con Leaflet/OpenStreetMap — pins coloreados por estado (visitada/pendiente)' },
      { type: 'new',      text: 'Mapa accesible desde bottom nav, menú lateral, jornada y ficha de parada' },
      { type: 'new',      text: 'Popup en cada pin con nombre, dirección, estado de visita y botones Ir/Ver jornada' },
      { type: 'new',      text: 'Filtro de ruta en el mapa: ver todas las paradas o solo las de una ruta' },
      { type: 'new',      text: 'Ficha detalle de parada/cliente con historial completo de visitas' },
      { type: 'new',      text: 'Ficha muestra KPIs acumulados de todas las visitas, rutas asignadas y notas permanentes' },
      { type: 'new',      text: 'Botón "Ver ficha" en lista de paradas, detalle de ruta y jornada' },
      { type: 'improved', text: 'Bottom nav: "Mapa" reemplaza "Rutas" para acceso directo más útil en campo' },
      { type: 'improved', text: 'Jornada: botón de mapa en cabecera para ver el recorrido del día' },
      { type: 'fixed',    text: 'Móvil: stat-cards siempre en 2×2, nunca colapsan a 1 columna' },
      { type: 'fixed',    text: 'Móvil: stop-cards de jornada ya no desbordan horizontalmente' },
      { type: 'fixed',    text: 'Móvil: toolbar del mapa compacta con título truncado' },
      { type: 'fixed',    text: 'Móvil: campos Lat/Lng se apilan correctamente en pantallas pequeñas' },
      { type: 'fixed',    text: 'Novedades: texto de items ya no se corta por la derecha' },
      { type: 'fixed',    text: 'Ajustes: estado actual en 2×2 en móvil' },
      { type: 'fixed',    text: 'Topbar: título "map" → "Mapa" con mayúscula correcta' },
      { type: 'fixed',    text: 'Bottom nav: icono de Jornada ya se activa correctamente al estar en esa pantalla' },
      { type: 'fixed',    text: 'Novedades: etiqueta de tipo (Nuevo/Fix/Mejora) oculta en móvil para evitar texto cortado' },
      { type: 'fixed',    text: 'App: zoom con dedos desactivado en toda la app excepto en el mapa' },
      { type: 'fixed',    text: 'Novedades: texto ya no desborda horizontalmente — overflow-x contenido en todos los niveles' },
      { type: 'fixed',    text: 'Jornada: cabecera rehecha con flex correcto — nombre ruta, fecha, badge Hoy y botón mapa siempre visibles y sin cortes' },
      { type: 'fixed',    text: 'Jornada: stop-cards con box-sizing correcto, nunca salen del ancho de pantalla' },
      { type: 'fixed',    text: 'Jornada: barra de timer sin wrap, todos los elementos en una línea' },
      { type: 'fixed',    text: 'CSS: limpieza completa de reglas duplicadas y contradictorias acumuladas en versiones anteriores' },
      { type: 'fixed',    text: 'Layout: page-content con width y box-sizing correctos — nada puede desbordarlo' },
      { type: 'fixed',    text: 'Jornada: barra sticky con margen negativo para ir de borde a borde correctamente' },
      { type: 'fixed',    text: 'Auditoría completa: 22 fixes en list-items, modales, sheets, cards, formularios, mapa y settings' },
      { type: 'fixed',    text: 'Todos los textos largos truncan con ellipsis; todos los flex-containers tienen min-width:0' },
      { type: 'fixed',    text: 'Modal parada: campos ID, CP y GPS con flex correcto, se adaptan en pantallas pequeñas' },
      { type: 'fixed',    text: 'Form-editor: select y labels no desbordan en móvil' },
      { type: 'fixed',    text: 'Visit-sheet: nombre y dirección de parada truncan si son muy largos' },
      { type: 'fixed',    text: 'Navegación: al abrir cualquier vista nueva el scroll vuelve al inicio automáticamente' },
      { type: 'fixed',    text: 'Modales y sheets: scroll reseteado al abrirse en modal-body, visit-body, listas de rutas y calendario' },
      { type: 'fixed',    text: 'Overlay.push: cualquier sheet dinámico también resetea scroll interno al abrirse' },
      { type: 'fixed',    text: 'Form-editor y KPI: unificados con Overlay.push (consistente con el resto de sheets)' },
      { type: 'fixed',    text: 'Jornada: eliminado width:calc(100%+32px) en .jornada-page que causaba desbordamiento horizontal persistente' },
      { type: 'fixed',    text: 'Jornada: vista completa con margen negativo — ocupa el 100% real de pantalla sin recortes' },
      { type: 'fixed',    text: 'Jornada: barra de timer va de borde a borde; header con icono mapa siempre visible' },
      { type: 'fixed',    text: 'Jornada: stats se comprimen si no hay espacio, botones de acción nunca se cortan' },
      { type: 'fixed',    text: 'Layout: html+body con max-width:100vw y overflow-x:hidden — imposible que nada desborde' },
      { type: 'fixed',    text: 'Topbar y bottom-nav: safe-area-inset para dispositivos con puntos de cámara (S24 Ultra, iPhone)' },
      { type: 'fixed',    text: 'Jornada: barra timer sin margin negativo — ya no expande el layout' },
      { type: 'fixed',    text: 'Global: box-sizing:border-box en todos los elementos sin excepción' },
    ]
  },
  {
    version: 'v1.3.1',
    date: '2025-07-17',
    tag: 'v1.3',
    tagColor: 'badge-muted',
    title: 'Fixes móvil — primera ronda',
    changes: [
      { type: 'fixed', text: 'Stat-cards siempre en 2×2, nunca colapsan a 1 columna en móvil' },
      { type: 'fixed', text: 'Stop-cards de jornada ya no desbordan horizontalmente' },
      { type: 'fixed', text: 'Toolbar del mapa compacta con título truncado' },
      { type: 'fixed', text: 'Campos Lat/Lng se apilan correctamente en pantallas pequeñas' },
      { type: 'fixed', text: 'Texto de novedades ya no se corta por la derecha' },
      { type: 'fixed', text: 'Ajustes: estado actual en 2×2 en móvil' },
    ]
  },
  {
    version: 'v1.3.2',
    date: '2025-07-18',
    tag: 'v1.3',
    tagColor: 'badge-muted',
    title: 'Fixes nav y overflow',
    changes: [
      { type: 'fixed', text: 'Topbar: título "map" → "Mapa" con mayúscula correcta' },
      { type: 'fixed', text: 'Bottom nav: icono de Jornada ya se activa correctamente al estar en esa pantalla' },
      { type: 'fixed', text: 'Novedades: etiqueta de tipo oculta en móvil para evitar texto cortado' },
    ]
  },
  {
    version: 'v1.3.3',
    date: '2025-07-19',
    tag: 'v1.3',
    tagColor: 'badge-muted',
    title: 'Zoom y overflow global',
    changes: [
      { type: 'fixed', text: 'Zoom con dedos desactivado en toda la app excepto en el mapa' },
      { type: 'fixed', text: 'Novedades: overflow-x contenido en todos los niveles' },
    ]
  },
  {
    version: 'v1.3.4',
    date: '2025-07-20',
    tag: 'v1.3',
    tagColor: 'badge-muted',
    title: 'Overflow definitivo — primera capa',
    changes: [
      { type: 'fixed', text: 'page-body y #page-content con overflow-x:hidden y box-sizing correctos' },
      { type: 'fixed', text: 'Jornada: botón mapa en cabecera ya no queda cortado' },
    ]
  },
  {
    version: 'v1.3.5',
    date: '2025-07-21',
    tag: 'v1.3',
    tagColor: 'badge-muted',
    title: 'Jornada: cabecera rehecha',
    changes: [
      { type: 'fixed', text: 'Jornada: cabecera con flex correcto — nombre ruta, fecha, badge Hoy y botón mapa siempre visibles' },
      { type: 'fixed', text: 'Jornada: barra de timer sin wrap, todos los elementos en una línea' },
    ]
  },
  {
    version: 'v1.3.6',
    date: '2025-07-22',
    tag: 'v1.3',
    tagColor: 'badge-muted',
    title: 'Limpieza CSS y layout base',
    changes: [
      { type: 'fixed', text: 'CSS: limpieza completa de reglas duplicadas y contradictorias acumuladas' },
      { type: 'fixed', text: 'Layout: page-content con width y box-sizing correctos' },
      { type: 'fixed', text: 'Jornada: barra sticky con margen negativo para ir de borde a borde' },
    ]
  },
  {
    version: 'v1.3.7',
    date: '2025-07-23',
    tag: 'v1.3',
    tagColor: 'badge-muted',
    title: 'Auditoría completa de elementos',
    changes: [
      { type: 'fixed', text: 'Auditoría completa: 22 fixes en list-items, modales, sheets, cards, formularios, mapa y settings' },
      { type: 'fixed', text: 'Todos los textos largos truncan con ellipsis; todos los flex-containers con min-width:0' },
      { type: 'fixed', text: 'Modal parada: campos ID, CP y GPS con flex correcto' },
      { type: 'fixed', text: 'Form-editor: select y labels no desbordan en móvil' },
    ]
  },
  {
    version: 'v1.3.8',
    date: '2025-07-24',
    tag: 'v1.3',
    tagColor: 'badge-muted',
    title: 'Scroll to top en navegación',
    changes: [
      { type: 'fixed', text: 'Al abrir cualquier vista nueva el scroll vuelve al inicio automáticamente' },
    ]
  },
  {
    version: 'v1.3.9',
    date: '2025-07-25',
    tag: 'v1.3',
    tagColor: 'badge-muted',
    title: 'Scroll en modales y sheets',
    changes: [
      { type: 'fixed', text: 'Modales y sheets: scroll reseteado al abrirse en modal-body, visit-body y listas' },
      { type: 'fixed', text: 'Overlay.push: cualquier sheet dinámico resetea scroll interno al abrirse' },
      { type: 'fixed', text: 'Form-editor y KPI: unificados con Overlay.push' },
    ]
  },
    {
    version: 'v1.2.0',
    date: '2025-07-15',
    tag: 'v1.2',
    tagColor: 'badge-indigo',
    title: 'Arquitectura refactorizada',
    changes: [
      { type: 'improved', text: 'DB layer unificado: todos los módulos acceden a localStorage a través de DB.get/set/del' },
      { type: 'improved', text: 'Hash routing: la URL se actualiza con cada navegación (#dashboard, #jornada/R1/2025-07-15...)' },
      { type: 'improved', text: 'El botón Atrás del navegador funciona correctamente en toda la app' },
      { type: 'improved', text: 'Overlay Manager centralizado: ESC cierra cualquier sheet, stack de overlays controlado' },
      { type: 'improved', text: 'Exportación de backup ahora incluye visitas, formularios y KPIs además de rutas' },
      { type: 'improved', text: 'Importación compatible con backups v1.1 (legacy) y el nuevo formato v1.2' },
      { type: 'improved', text: 'Demo data genérica sin referencias sectoriales específicas' },
      { type: 'fixed',    text: 'openTodayJornada desde bottom nav redirige al calendario si no hay ruta asignada hoy' },
    ]
  },
  
  {
    version: 'v1.1.0',
    date: '2025-07-15',
    tag: 'v1.1',
    tagColor: 'badge-muted',
    title: 'Jornada, Visitas & Formularios personalizables',
    changes: [
      { type: 'new',  text: 'Pantalla de Jornada con timer en vivo, km GPS y ratio de paradas visitadas' },
      { type: 'new',  text: 'Barra sticky de jornada: Iniciar · Pausar · Reanudar · Finalizar' },
      { type: 'new',  text: 'Reinicio de jornada con 3 opciones: contadores, visitas del día o todo' },
      { type: 'new',  text: 'Check-in de parada: sheet con datos de contacto, localización y botón navegar' },
      { type: 'new',  text: 'Formularios de visita completamente personalizables (text, select, número, checkbox…)' },
      { type: 'new',  text: 'KPIs personalizados con nombre, unidad y rango — válido para cualquier sector' },
      { type: 'new',  text: 'Captura de fotos por visita con preview y eliminación individual' },
      { type: 'new',  text: 'Editor de Formularios & KPIs en menú lateral' },
      { type: 'new',  text: 'Historial de jornadas en página de Informes' },
      { type: 'new',  text: 'Tracking GPS de km con Haversine + corrección de saltos al volver de segundo plano' },
      { type: 'improved', text: 'Dashboard: botón "Iniciar jornada" directo con estado en vivo (en curso / completada)' },
      { type: 'improved', text: 'Calendario: botón "Ir a jornada del día" al asignar ruta' },
      { type: 'improved', text: 'Bottom nav: acceso directo a Jornada de hoy desde cualquier pantalla' },
      { type: 'improved', text: 'Informes: contador de visitas totales registradas' },
    ]
  },
  {
    version: 'v1.0.0',
    date: '2025-07-01',
    tag: 'v1.0',
    tagColor: 'badge-muted',
    title: 'Versión inicial',
    changes: [
      { type: 'new', text: 'Gestor de rutas comerciales con paradas geolocalizadas' },
      { type: 'new', text: 'Calendario de planificación con asignación de rutas por día' },
      { type: 'new', text: 'Geocodificación automática de direcciones (Nominatim)' },
      { type: 'new', text: 'Exportación / importación de backup JSON' },
      { type: 'new', text: 'PWA instalable, datos locales, sin cuenta necesaria' },
    ]
  },
];

Router.register('changelog',(el)=>{
  const TYPE_META = {
    new:      { icon:'fa-plus-circle',      color:'var(--green)',  label:'Nuevo' },
    improved: { icon:'fa-arrow-up-right-dots', color:'var(--indigo)', label:'Mejora' },
    fixed:    { icon:'fa-wrench',            color:'var(--amber)',  label:'Fix' },
    removed:  { icon:'fa-minus-circle',      color:'var(--red)',    label:'Eliminado' },
  };

  el.innerHTML = `
  <div class="page-header mb-4">
    <div>
      <h1 class="page-h1">Novedades</h1>
      <p class="page-sub">Historial de versiones y cambios</p>
    </div>
  </div>

  <div style="max-width:640px;width:100%;display:flex;flex-direction:column;gap:var(--sp-5);box-sizing:border-box">
    ${CHANGELOG.map((release, ri) => `
    <div class="changelog-release ${ri===0?'changelog-latest':''}">
      <div class="changelog-release-header">
        <div class="changelog-version-badge">${release.version}</div>
        <div class="changelog-release-info">
          <div class="changelog-release-title">${release.title}</div>
          <div class="changelog-release-date">${_fmtChangelogDate(release.date)}</div>
        </div>
        <span class="badge ${release.tagColor}">${release.tag}</span>
      </div>
      <div class="changelog-items">
        ${release.changes.map(c => {
          const m = TYPE_META[c.type] || TYPE_META.new;
          return `<div class="changelog-item">
            <span class="changelog-item-dot" style="color:${m.color}">
              <i class="fa-solid ${m.icon}"></i>
            </span>
            <span class="changelog-item-text">${c.text}</span>
            <span class="changelog-item-type" style="color:${m.color}">${m.label}</span>
          </div>`;
        }).join('')}
      </div>
    </div>`).join('')}
  </div>`;
});

function _fmtChangelogDate(s){
  return new Date(s+'T12:00').toLocaleDateString('es-ES',{day:'numeric',month:'long',year:'numeric'});
}

Router.register('settings',(el)=>{
  const g=State.globalStats();
  const _role = State.prefs._role || 'rep';
  const _settingsTitle = {rep:'Ajustes', supervisor:'Ajustes', admin:'Ajustes', owner:'Ajustes'}[_role] || 'Ajustes';
  const _settingsSub   = {
    rep:        'Tu cuenta y preferencias',
    supervisor: 'Tu cuenta, equipo y configuración',
    admin:      'Tu cuenta, equipo y configuración',
    owner:      'Cuenta, organización y configuración',
  }[_role] || 'Datos y configuración';

  el.innerHTML=`
  <div class="page-header mb-4">
    <div><h1 class="page-h1">${_settingsTitle}</h1><p class="page-sub">${_settingsSub}</p></div>
  </div>

  <div style="max-width:560px;width:100%;display:flex;flex-direction:column;gap:var(--sp-4);box-sizing:border-box">
    <!-- Cuenta (inyectada por auth-ui.js si está disponible) -->
    ${typeof renderAccountSection === 'function' ? renderAccountSection() : ''}

    <!-- Apariencia -->
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-palette"></i> Apariencia</div></div>
      <div>
        <div class="settings-row" style="border-bottom:none">
          <div class="settings-row-info">
            <div class="settings-row-title">Tema</div>
            <div class="settings-row-sub">Claro, oscuro o según el sistema</div>
          </div>
          <div style="display:flex;gap:6px">
            ${['auto','light','dark'].map(m => {
              const active = (State.prefs.theme||'auto') === m;
              const label = {auto:'Auto',light:'Claro',dark:'Oscuro'}[m];
              return `<button class="btn btn-sm ${active?'btn-primary':'btn-ghost'}"
                onclick="setTheme('${m}')" id="theme-btn-${m}">${label}</button>`;
            }).join('')}
          </div>
        </div>
      </div>
    </div>

    <!-- Notificaciones: solo comercial tiene jornada propia -->
    <div class="card settings-rep-only">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-bell"></i> Notificaciones</div></div>
      <div>
        <div class="settings-row" style="border-bottom:none">
          <div class="settings-row-info">
            <div class="settings-row-title">Recordatorio de jornada</div>
            <div class="settings-row-sub" id="notif-sub">Aviso diario a la hora configurada si hay ruta asignada</div>
          </div>
          <div style="display:flex;align-items:center;gap:10px">
            <input type="time" id="notif-time" class="form-input"
              style="width:90px;font-size:var(--t-sm)"
              value="${State.prefs.notifTime||'08:00'}"
              onchange="saveNotifTime(this.value)">
            <button class="btn btn-sm ${State.prefs.notifEnabled?'btn-primary':'btn-ghost'}"
              id="notif-toggle-btn"
              onclick="toggleNotifications()">
              ${State.prefs.notifEnabled?'Activado':'Activar'}
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Datos -->
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-database"></i> Base de datos</div></div>
      <div>
        <div class="settings-row settings-supervisor-only">
          <div class="settings-row-info">
            <div class="settings-row-title">Exportar backup JSON</div>
            <div class="settings-row-sub">Descarga rutas, paradas y planificación</div>
          </div>
          <button class="btn btn-ghost btn-sm" onclick="exportData()"><i class="fa-solid fa-download"></i> Exportar</button>
        </div>
        <div class="settings-row settings-supervisor-only">
          <div class="settings-row-info">
            <div class="settings-row-title">Restaurar backup</div>
            <div class="settings-row-sub">Importa un archivo JSON exportado</div>
          </div>
          <button class="btn btn-ghost btn-sm" onclick="document.getElementById('restore-input').click()">
            <i class="fa-solid fa-upload"></i> Importar
          </button>
          <input type="file" id="restore-input" accept=".json" style="display:none" onchange="restoreBackup(event)">
        </div>
        <div class="settings-row">
          <div class="settings-row-info">
            <div class="settings-row-title">Forzar sincronización</div>
            <div class="settings-row-sub">Descarga todos los datos del servidor</div>
          </div>
          <button class="btn btn-ghost btn-sm" onclick="forcePullSync()">
            <i class="fa-solid fa-rotate"></i> Sync
          </button>
        </div>
        <div class="settings-row settings-owner-only" style="border-bottom:none">
          <div class="settings-row-info">
            <div class="settings-row-title" style="color:var(--red)">Borrar todos los datos</div>
            <div class="settings-row-sub">${g.routes} rutas · ${g.stops} paradas</div>
          </div>
          <button class="btn btn-danger btn-sm" onclick="confirmClearAll()">
            <i class="fa-solid fa-trash"></i> Borrar
          </button>
        </div>
      </div>
    </div>

    <!-- Equipo (solo visible para admin/owner con sesión) -->
    ${(['supervisor','admin','owner'].includes(State.prefs._role)) && typeof Tokens !== 'undefined' && Tokens.isLoggedIn() ? `
    <div class="card" id="team-card">
      <div class="card-header">
        <div class="card-title"><i class="fa-solid fa-users"></i> Equipo</div>
        <button class="btn btn-primary btn-sm" onclick="showInviteModal()">
          <i class="fa-solid fa-user-plus"></i> Invitar
        </button>
      </div>
      <div id="team-list-wrap">
        <div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">
          <i class="fa-solid fa-spinner fa-spin"></i> Cargando equipo…
        </div>
      </div>
    </div>` : ''}

    <!-- Stats resumen — contextual por rol -->
    <div class="card" id="org-stats-card">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-circle-info"></i> ${(_ROLE_ORDER[_role]??0) >= 1 ? 'Tu organización' : 'Estado actual'}</div></div>
      <div class="card-body" id="org-stats-body">
        <div class="grid-4" style="gap:var(--sp-2)">
          ${[['Rutas',g.routes,'indigo'],['Paradas',g.stops,'blue'],
             ['Con GPS',g.withGeo,'green'],['Sin GPS',g.noGeo,'red']].map(([l,v,c])=>
            `<div style="background:var(--bg-surface);border:1px solid var(--bd-0);border-radius:var(--r-sm);padding:var(--sp-3);text-align:center">
              <div style="font-size:1.4rem;font-weight:800;color:var(--${c})">${v}</div>
              <div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:2px">${l}</div>
            </div>`).join('')}
        </div>
      </div>
    </div>

    <!-- Acerca de -->
    <div class="card">
      <div class="card-body" style="display:flex;align-items:center;gap:var(--sp-4)">
        <div style="width:52px;height:52px;background:var(--indigo);border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fa-solid fa-route" style="color:#fff;font-size:1.3rem"></i>
        </div>
        <div>
          <div style="font-size:var(--t-lg);font-weight:800;color:var(--tx-1)">Gestor de Rutas Pro</div>
          <div style="font-size:var(--t-sm);color:var(--tx-3)">${CHANGELOG[0].version} · ${CHANGELOG[0].title}</div>
          <div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:4px">
            Datos guardados localmente en este dispositivo
          </div>
          <button class="btn btn-ghost btn-sm" style="margin-top:8px;padding:4px 10px" onclick="Router.go('changelog')">
            <i class="fa-solid fa-scroll"></i> Ver novedades
          </button>
        </div>
      </div>
    </div>
  </div>`;

  /* Cargar equipo si el usuario es supervisor/admin/owner */
  const _teamRoles = ['supervisor','admin','owner'];
  if (_teamRoles.includes(State.prefs._role) &&
       typeof Tokens !== 'undefined' && Tokens.isLoggedIn()) {
    _loadTeam();
    _loadOrgStats();
  }
});

/* ── Stats de organización desde servidor (supervisor+) ────── */
async function _loadOrgStats() {
  const body = document.getElementById('org-stats-body');
  if (!body) return;
  const role = State.prefs._role || 'rep';
  if (({rep:0,supervisor:1,admin:2,owner:3}[role]??0) < 1) return;

  try {
    const data = await API.get('/stats/dashboard?period=month');
    if (!data) return;

    const agg  = data.aggregated || data.kpis || {};
    const gaps = (data.coverage_gaps || []).length;
    const active = data.active_sessions?.length ?? agg.active_count ?? data.kpis?.active_now ?? 0;
    const visits = agg.total_visits ?? data.kpis?.total_visits ?? 0;
    const sessions = agg.total_sessions ?? data.kpis?.total_sessions ?? 0;
    const done = agg.sessions_done ?? data.kpis?.finished_sessions ?? 0;
    const km = agg.distance_km ?? data.kpis?.avg_distance_km ?? 0;

    /* Para supervisor: team count, para admin: supervisores, para owner: miembros */
    const teamCount = role === 'supervisor'
      ? (data.team || []).length
      : role === 'admin'
        ? (data.supervisors || []).reduce((a,s) => a + (s.team||[]).length, 0)
        : data.kpis?.total_members ?? 0;

    body.innerHTML = `
    <div class="grid-4" style="gap:var(--sp-2);margin-bottom:var(--sp-3)">
      <div style="background:var(--bg-surface);border:1px solid var(--bd-0);border-radius:var(--r-sm);padding:var(--sp-3);text-align:center">
        <div style="font-size:1.4rem;font-weight:800;color:var(--indigo)">${visits}</div>
        <div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:2px">Visitas (mes)</div>
      </div>
      <div style="background:var(--bg-surface);border:1px solid var(--bd-0);border-radius:var(--r-sm);padding:var(--sp-3);text-align:center">
        <div style="font-size:1.4rem;font-weight:800;color:var(--green)">${done}/${sessions}</div>
        <div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:2px">Jornadas</div>
      </div>
      <div style="background:var(--bg-surface);border:1px solid var(--bd-0);border-radius:var(--r-sm);padding:var(--sp-3);text-align:center">
        <div style="font-size:1.4rem;font-weight:800;color:var(--amber)">${gaps}</div>
        <div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:2px">PDVs sin cubrir</div>
      </div>
      <div style="background:var(--bg-surface);border:1px solid var(--bd-0);border-radius:var(--r-sm);padding:var(--sp-3);text-align:center">
        <div style="font-size:1.4rem;font-weight:800;color:var(--blue)">${teamCount}</div>
        <div style="font-size:var(--t-xs);color:var(--tx-3);margin-top:2px">Comerciales</div>
      </div>
    </div>
    ${active > 0 ? `<div style="font-size:var(--t-xs);color:var(--green);font-weight:500">
      <i class="fa-solid fa-circle" style="font-size:8px"></i> ${active} en jornada ahora mismo
    </div>` : ''}`;
  } catch(e) {
    /* silencioso — mantiene datos locales */
  }
}

/* ── Gestión de equipo ─────────────────────────────────── */
async function _loadTeam() {
  const wrap = document.getElementById('team-list-wrap');
  if (!wrap) return;
  try {
    const members = await API.get('/users');
    if (!members?.length) {
      wrap.innerHTML = `<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">Solo tú en el equipo.</div>`;
      return;
    }
    wrap.innerHTML = _renderTeamTree(members);
  } catch {
    wrap.innerHTML = `<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">Error al cargar el equipo.</div>`;
  }
}

function _renderTeamTree(members) {
  const ROLES       = { rep:'Comercial', supervisor:'Jefe de zona', admin:'Director', owner:'Propietario' };
  const ROLE_COLORS = { rep:'badge-green', supervisor:'badge-blue', admin:'badge-indigo', owner:'badge-purple' };
  const ROLE_ORDER  = { rep:0, supervisor:1, admin:2, owner:3 };
  const myId    = State.prefs._userId;
  const myLevel = ROLE_ORDER[State.prefs._role] ?? 0;

  /* Construir índice id→miembro */
  const byId = {};
  members.forEach(m => byId[m.id] = m);

  /* Construir árbol: children[managerId] = [miembros que reportan a él] */
  const children = {};
  const roots = [];
  members.forEach(m => {
    const mgr = m.manager_id;
    if (!mgr || !byId[mgr]) {
      roots.push(m); /* sin manager visible → raíz */
    } else {
      if (!children[mgr]) children[mgr] = [];
      children[mgr].push(m);
    }
  });
  /* Ordenar cada nivel por rol desc, luego nombre */
  const sortFn = (a,b) => (ROLE_ORDER[b.role]??0)-(ROLE_ORDER[a.role]??0) || (a.name||a.email).localeCompare(b.name||b.email);
  roots.sort(sortFn);
  Object.values(children).forEach(arr => arr.sort(sortFn));

  /* Renderizar nodo recursivamente */
  function renderNode(m, depth) {
    const indent     = depth * 20;
    const targetLevel = ROLE_ORDER[m.role] ?? 0;
    const isMe       = m.id === myId;
    const canManage  = !isMe && m.active != 0 && myLevel > targetLevel;
    const canAssign  = canManage;
    const kids       = children[m.id] || [];
    const hasKids    = kids.length > 0;

    const nameEsc  = (m.name||m.email).replace(/'/g,"\'");
    const emailEsc = m.email.replace(/'/g,"\'");

    const connectorLine = depth > 0
      ? `<div style="position:absolute;left:${indent-12}px;top:0;bottom:50%;width:1px;background:var(--color-border-tertiary)"></div>
         <div style="position:absolute;left:${indent-12}px;top:50%;width:12px;height:1px;background:var(--color-border-tertiary)"></div>`
      : '';

    const row = `
    <div style="position:relative;padding-left:${indent + (depth>0?4:0)}px;${m.active==0?'opacity:.45':''}">
      ${connectorLine}
      <div class="settings-row" style="padding-left:0;gap:var(--sp-2)">
        <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;color:var(--tx-3)">
          ${hasKids
            ? `<button class="btn btn-ghost btn-sm" style="padding:2px 4px;font-size:11px"
                 onclick="this.closest('[data-tree-node]').classList.toggle('collapsed');
                          this.innerHTML=this.closest('[data-tree-node]').classList.contains('collapsed')
                            ?'<i class=\"fa-solid fa-chevron-right\" style=\"font-size:9px\"></i>'
                            :'<i class=\"fa-solid fa-chevron-down\" style=\"font-size:9px\"></i>'">
                 <i class="fa-solid fa-chevron-down" style="font-size:9px"></i>
               </button>`
            : `<span style="width:20px;display:inline-block"></span>`}
        </div>
        <div class="settings-row-info">
          <div class="settings-row-title" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            <button class="btn btn-ghost btn-sm" style="padding:0;font-weight:500;color:var(--color-text-primary);font-size:inherit"
              onclick="showMemberProfile('${m.id}','${nameEsc}','${m.role}','${emailEsc}')">
              ${m.name || m.email.split('@')[0]}
            </button>
            <span class="badge ${ROLE_COLORS[m.role]||'badge-gray'}" style="font-size:10px">${ROLES[m.role]||m.role}</span>
            ${m.active==0 ? '<span class="badge badge-gray" style="font-size:10px">Inactivo</span>' : ''}
            ${isMe ? '<span style="font-size:11px;color:var(--tx-3)">(tú)</span>' : ''}
          </div>
          <div class="settings-row-sub">${m.email}${hasKids ? ` · ${kids.length} ${kids.length===1?'miembro':'miembros'}` : ''}</div>
        </div>
        ${!isMe ? `
        <div style="display:flex;gap:4px;flex-shrink:0">
          ${canAssign ? `<button class="btn btn-ghost btn-sm" title="Asignar PDVs"
              onclick="showAssignStopsModal('${m.id}','${nameEsc}')">
              <i class="fa-solid fa-map-pin"></i>
            </button>` : ''}
          ${canManage && m.role === 'rep' ? `
            <button class="btn btn-ghost btn-sm" title="Objetivos"
              onclick="showTargetsModal('${m.id}','${nameEsc}',${JSON.stringify(
                typeof m.targets === 'string' ? JSON.parse(m.targets||'{}') : (m.targets||{})
              )})">
              <i class="fa-solid fa-bullseye"></i>
            </button>` : ''}
          ${canManage && myLevel >= 2 ? `
            <button class="btn btn-ghost btn-sm" title="Editar"
              onclick="showChangeRoleModal('${m.id}','${m.role}','${nameEsc}','${m.manager_id||''}')">
              <i class="fa-solid fa-pen"></i>
            </button>
            <button class="btn btn-ghost btn-sm" style="color:var(--red)" title="Archivar"
              onclick="confirmRemoveMember('${m.id}','${nameEsc}')">
              <i class="fa-solid fa-user-minus"></i>
            </button>` : ''}
        </div>` : ''}
      </div>
      ${m.role === 'rep' ? (() => {
        const tgt = typeof m.targets === 'string' ? JSON.parse(m.targets||'{}') : (m.targets||{});
        const tw = tgt.visits_week ?? 0;
        if (!tw) return '';
        return `<div style="padding:0 0 6px ${indent + (depth>0?4:0) + 4}px;margin-top:-2px">
          <div style="font-size:10px;color:var(--tx-3)">
            <i class="fa-solid fa-bullseye" style="font-size:9px"></i>
            Objetivo: ${tw} visitas/semana
          </div>
        </div>`;
      })() : ''}
    </div>`;

    const childrenHtml = hasKids
      ? `<div class="team-children">${kids.map(k => renderNode(k, depth+1)).join('')}</div>`
      : '';

    return `<div data-tree-node data-id="${m.id}">${row}${childrenHtml}</div>`;
  }

  return `<style>
    [data-tree-node].collapsed > .team-children { display:none }
  </style>` + roots.map(r => renderNode(r, 0)).join('');
}

function showInviteModal() {
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.id = 'modal-invite';
  ov.innerHTML = `
  <div class="modal" style="max-width:400px" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title"><i class="fa-solid fa-user-plus"></i> Invitar al equipo</div>
      <button class="modal-close" onclick="closeModal('modal-invite')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="email" id="invite-email" class="form-input" placeholder="email@empresa.com" autocomplete="off">
      </div>
      <div class="form-group">
        <label class="form-label">Rol</label>
        <select id="invite-role" class="form-input" onchange="_updateInviteManagerSelector()">
          <option value="rep">Comercial</option>
          <option value="supervisor">Jefe de zona</option>
          <option value="admin">Director</option>
        </select>
      </div>
      <div id="invite-manager-wrap">
        ${_buildInviteManagerSelector('rep')}
      </div>
      <div id="invite-error" style="color:var(--red);font-size:var(--t-sm);display:none;margin-top:8px"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="closeModal('modal-invite')">Cancelar</button>
      <button class="btn btn-primary" style="flex:2" onclick="_doInvite()">
        <i class="fa-solid fa-paper-plane"></i> Enviar invitación
      </button>
    </div>
  </div>`;
  Overlay.push(ov);
  setTimeout(() => document.getElementById('invite-email')?.focus(), 100);
}

async function _doInvite() {
  const email     = document.getElementById('invite-email')?.value.trim();
  const role      = document.getElementById('invite-role')?.value;
  const mgrSel    = document.getElementById('invite-manager-select');
  const managerId = mgrSel?.value || undefined;
  const errEl     = document.getElementById('invite-error');
  if (!email) { errEl.textContent='Email requerido'; errEl.style.display='block'; return; }
  try {
    const res = await API.post('/users/invite', { email, role, ...(managerId && { managerId }) });
    closeModal('modal-invite');
    if (res.isNew && res.tempPwd) {
      /* Mostrar contraseña temporal para compartir */
      _showTempPwdModal(res.email, res.tempPwd);
    } else {
      toast(`${email} añadido al equipo`, 'success', 3000);
    }
    _loadTeam();
  } catch(e) {
    errEl.textContent = e.message || 'Error al invitar';
    errEl.style.display = 'block';
  }
}

function _showTempPwdModal(email, pwd) {
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.id = 'modal-temppwd';
  ov.innerHTML = `
  <div class="modal" style="max-width:420px" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title"><i class="fa-solid fa-key"></i> Cuenta creada</div>
      <button class="modal-close" onclick="closeModal('modal-temppwd')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="display:flex;flex-direction:column;gap:var(--sp-3)">
      <p style="font-size:var(--t-sm);color:var(--tx-2);line-height:1.6">
        Se ha creado una cuenta para <strong>${email}</strong>.<br>
        Comparte estas credenciales con el nuevo miembro:
      </p>
      <div style="background:var(--bg-surface);border:1px solid var(--bd-0);border-radius:var(--r-md);padding:var(--sp-4)">
        <div style="font-size:var(--t-xs);color:var(--tx-3);margin-bottom:4px">URL de acceso</div>
        <div style="font-size:var(--t-sm);color:var(--tx-1);word-break:break-all;margin-bottom:12px">${location.origin}/gestor-rutas-web/</div>
        <div style="font-size:var(--t-xs);color:var(--tx-3);margin-bottom:4px">Email</div>
        <div style="font-size:var(--t-sm);color:var(--tx-1);margin-bottom:12px">${email}</div>
        <div style="font-size:var(--t-xs);color:var(--tx-3);margin-bottom:4px">Contraseña temporal</div>
        <div style="display:flex;align-items:center;gap:10px">
          <code style="font-size:1.2rem;font-weight:700;letter-spacing:.1em;color:var(--indigo);background:var(--bg-2);padding:6px 14px;border-radius:var(--r-sm);flex:1;text-align:center" id="tmp-pwd-val">${pwd}</code>
          <button class="btn btn-ghost btn-sm" onclick="_copyTempPwd('${pwd}')" title="Copiar">
            <i class="fa-solid fa-copy"></i>
          </button>
        </div>
      </div>
      <p style="font-size:var(--t-xs);color:var(--tx-3)">
        <i class="fa-solid fa-circle-info"></i> El miembro podrá cambiar su contraseña desde Ajustes una vez acceda.
      </p>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="_copyInviteText('${email}','${pwd}')">
        <i class="fa-solid fa-share"></i> Copiar todo
      </button>
      <button class="btn btn-primary" style="flex:2" onclick="closeModal('modal-temppwd')">
        <i class="fa-solid fa-check"></i> Entendido
      </button>
    </div>
  </div>`;
  Overlay.push(ov);
}

function _copyTempPwd(pwd) {
  navigator.clipboard?.writeText(pwd).then(() => toast('Contraseña copiada', 'success', 1500));
}

function _copyInviteText(email, pwd) {
  const url = `${location.origin}/gestor-rutas-web/`;
  const text = `Accede a Gestor de Rutas:\nURL: ${url}\nEmail: ${email}\nContraseña: ${pwd}`;
  navigator.clipboard?.writeText(text).then(() => toast('Texto copiado', 'success', 1500));
}

/* Niveles de rol — cuanto más alto el número, más autoridad */
const _ROLE_NAMES  = {rep:'Comercial', supervisor:'Jefe de zona', admin:'Director', owner:'Propietario'};

function showChangeRoleModal(userId, currentRole, name, currentManagerId) {
  const allMembers = (_calAssignReps || []);

  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.id = 'modal-changerole';
  ov.innerHTML = `
  <div class="modal" style="max-width:360px" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title">Editar miembro — ${name}</div>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="display:flex;flex-direction:column;gap:var(--sp-3)">
      <div>
        <label style="font-size:var(--t-xs);color:var(--tx-3);font-weight:500">Rol</label>
        <select id="new-role-select" class="form-input" style="margin-top:4px"
          onchange="_updateManagerSelector('${userId}','${currentManagerId||''}')">
          ${['rep','supervisor','admin'].map(r =>
            `<option value="${r}" ${r===currentRole?'selected':''}>${_ROLE_NAMES[r]||r}</option>`
          ).join('')}
        </select>
      </div>
      <div id="manager-selector-wrap">
        ${_buildManagerOptions(currentRole, userId, allMembers, currentManagerId)}
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cancelar</button>
      <button class="btn btn-primary" style="flex:2" onclick="_doChangeRole('${userId}')">Guardar</button>
    </div>
  </div>`;
  Overlay.push(ov);
}

function _buildManagerOptions(targetRole, targetUserId, allMembers, currentManagerId) {
  /* El manager debe tener rango SUPERIOR al rol destino */
  const targetLevel = _ROLE_ORDER[targetRole] ?? 0;
  const managers = allMembers.filter(m =>
    m.id !== targetUserId &&
    (_ROLE_ORDER[m.role] ?? 0) > targetLevel
  );
  if (!managers.length) return '';

  /* Ordenar de menor a mayor rango — el director aparece antes que el propietario */
  managers.sort((a, b) => (_ROLE_ORDER[a.role]??0) - (_ROLE_ORDER[b.role]??0));

  /* Determinar preselección: manager actual si es válido,
     si no el de rango inmediatamente superior al rol destino */
  const currentIsValid = managers.some(m => m.id === currentManagerId);
  const defaultManager = currentIsValid
    ? currentManagerId
    : (managers.find(m => (_ROLE_ORDER[m.role]??0) === targetLevel + 1) || managers[0])?.id;

  return `
    <div>
      <label style="font-size:var(--t-xs);color:var(--tx-3);font-weight:500">Reporta a</label>
      <select id="new-manager-select" class="form-input" style="margin-top:4px">
        ${managers.map(m =>
          `<option value="${m.id}" ${m.id === defaultManager ? 'selected' : ''}>${m.name||m.email.split('@')[0]} · ${_ROLE_NAMES[m.role]||m.role}</option>`
        ).join('')}
      </select>
    </div>`;
}

function _updateManagerSelector(targetUserId, currentManagerId) {
  const roleSelect = document.getElementById('new-role-select');
  const wrap       = document.getElementById('manager-selector-wrap');
  if (!roleSelect || !wrap) return;
  wrap.innerHTML = _buildManagerOptions(roleSelect.value, targetUserId, _calAssignReps||[], currentManagerId);
}

async function _doChangeRole(userId) {
  const role = document.getElementById('new-role-select')?.value;
  try {
    const managerSel = document.getElementById('new-manager-select');
    const managerId  = managerSel ? managerSel.value : undefined;
    await API.patch(`/users/${userId}/role`, { role, ...(managerId && { managerId }) });
    closeModal('modal-changerole');
    toast('Rol actualizado', 'success', 2000);
    _loadTeam();
  } catch(e) { toast(e.message || 'Error', 'error'); }
}

function confirmRemoveMember(userId, name) {
  if (!confirm(`¿Eliminar acceso a ${name}?\nPerderá el acceso a la aplicación. Sus datos y visitas se conservan.`)) return;
  API.del(`/users/${userId}`)
    .then(() => { toast(`${name} eliminado del equipo`, 'info', 2500); _loadTeam(); syncNow(); })
    .catch(e => toast(e.message || 'Error', 'error'));
}

/* ═══════════════════════════════════════════════════════
   ACCIONES — Nueva Ruta
   ═══════════════════════════════════════════════════════ */
function showModalNewRoute(){
  if((_ROLE_ORDER[State.prefs._role]??0) < 1){ toast('Sin permisos para crear rutas','error'); return; }
  document.getElementById('new-route-name').value='';
  document.querySelector('#modal-new-route .modal-body')?.scrollTo(0,0);
  openModal('modal-new-route');
  setTimeout(()=>document.getElementById('new-route-name').focus(),220);
}
function confirmNewRoute(){
  const n=document.getElementById('new-route-name').value.trim();
  if(!n){toast('Escribe un nombre para la ruta','error');return;}
  const id=State.addRoute(n);
  syncNow();
  closeModal('modal-new-route');
  toast(`Ruta "${n.toUpperCase()}" creada`,'success');
  Router.go('routes',{routeId:id});
}

function showRenameRoute(id){
  const r=State.getRoute(id); if(!r) return;
  document.getElementById('rename-route-id').value=id;
  document.getElementById('rename-route-name').value=r.name;
  openModal('modal-rename-route');
  setTimeout(()=>document.getElementById('rename-route-name').focus(),220);
}
function confirmRenameRoute(){
  const id=document.getElementById('rename-route-id').value;
  const n=document.getElementById('rename-route-name').value.trim();
  if(!n){toast('Escribe un nombre','error');return;}
  State.updateRoute(id,{name:n.toUpperCase()});
  syncNow();
  closeModal('modal-rename-route');
  toast('Ruta renombrada','success');
  Router.go('routes');
}

function confirmDeleteRoute(id){
  const r=State.getRoute(id); if(!r) return;
  confirm_(`¿Eliminar "${esc(r.name)}"?\nSe eliminará del calendario. Las visitas históricas se conservan.`,()=>{
    State.deleteRoute(id);
    syncNow();
    toast('Ruta eliminada','info');
    Router.go('routes');
  },'Eliminar ruta','danger');
}

/* ═══════════════════════════════════════════════════════
   ACCIONES — Nueva / Editar Parada
   ═══════════════════════════════════════════════════════ */
const _debouncedGeo=debounce(async(q)=>{
  const box=document.getElementById('addr-suggestions');
  if(!box||q.length<4){if(box)box.style.display='none';return;}
  const res=await geocodeAddr(q);
  if(!res.length){box.style.display='none';return;}
  box.innerHTML=res.map(r=>`<div class="suggestion-item" onclick="pickSuggestion(${r.lat},${r.lon},'${r.display_name.replace(/'/g,'`')}')">
    <i class="fa-solid fa-location-dot"></i>
    <span style="line-height:1.4">${r.display_name}</span>
  </div>`).join('');
  box.style.display='block';
},400);

function pickSuggestion(lat,lon,display){
  document.getElementById('stop-lat').value=parseFloat(lat).toFixed(6);
  document.getElementById('stop-lng').value=parseFloat(lon).toFixed(6);
  const parts=display.split(',');
  if(!document.getElementById('stop-addr').value.trim())
    document.getElementById('stop-addr').value=parts[0]?.trim()||'';
  document.getElementById('addr-suggestions').style.display='none';
  document.getElementById('coords-status').innerHTML=
    `<span style="color:var(--green)"><i class="fa-solid fa-circle-check"></i> ${parseFloat(lat).toFixed(5)}, ${parseFloat(lon).toFixed(5)}</span>`;
}

function showModalNewStop(prefill={}){
  if((_ROLE_ORDER[State.prefs._role]??0) < 1){ toast('Sin permisos para crear paradas','error'); return; }
  ['edit-id','ref','name','addr','town','zip','lat','lng',
   'horario','notes','contact','phone','mobile','email','tags'].forEach(f=>{
    const el=document.getElementById(`stop-${f}`); if(el) el.value=prefill[f]||'';
  });
  document.getElementById('stop-edit-id').value=prefill._editId||'';
  document.getElementById('modal-stop-h3').textContent=prefill._editId?'Editar Parada':'Nueva Parada';
  document.getElementById('addr-suggestions').style.display='none';
  document.getElementById('stop-gmaps-url').value='';
  document.getElementById('gmaps-status').textContent='';
  document.getElementById('coords-status').textContent=
    (prefill.lat&&prefill.lng)?`${prefill.lat}, ${prefill.lng}`:'';
  document.querySelector('#modal-stop .modal-body')?.scrollTo(0,0);
  openModal('modal-stop');
  setTimeout(()=>document.getElementById('stop-name').focus(),220);
}
function editStop(id){
  if((_ROLE_ORDER[State.prefs._role]??0) < 1){ toast('Sin permisos para editar paradas','error'); return; }
  const s=State.getStop(id); if(!s) return;
  showModalNewStop({...s,ref:s.id,_editId:id});
}
function confirmStop(){
  const id=document.getElementById('stop-ref').value.trim()||`S${uid()}`;
  const name=document.getElementById('stop-name').value.trim();
  if(!name){toast('El nombre es obligatorio','error');return;}
  const rawTags = document.getElementById('stop-tags').value.trim();
  const data={
    id, name,
    addr:    document.getElementById('stop-addr').value.trim(),
    town:    document.getElementById('stop-town').value.trim(),
    zip:     document.getElementById('stop-zip').value.trim(),
    lat:     parseFloat(document.getElementById('stop-lat').value)||null,
    lng:     parseFloat(document.getElementById('stop-lng').value)||null,
    horario: document.getElementById('stop-horario').value.trim(),
    notes:   document.getElementById('stop-notes').value.trim(),
    contact: document.getElementById('stop-contact').value.trim(),
    phone:   document.getElementById('stop-phone').value.trim(),
    mobile:  document.getElementById('stop-mobile').value.trim(),
    email:   document.getElementById('stop-email').value.trim(),
    tags:    rawTags ? rawTags.split(',').map(t=>t.trim().toLowerCase()).filter(Boolean) : [],
    _oldId:  document.getElementById('stop-edit-id').value||id,
  };
  State.upsertStop(data);
  syncNow();
  closeModal('modal-stop');
  toast(data._oldId===id?'Parada guardada':'Parada actualizada','success');
  Router.go(Router._current||'stops', Router._params||{});
}

function confirmDeleteStop(id){
  const s=State.getStop(id); if(!s) return;
  confirm_(`¿Eliminar "${s.name}"?\nSe eliminará de las rutas. Sus visitas históricas se conservan.`,()=>{
    State.deleteStop(id);
    syncNow();
    toast('Parada eliminada','info');
    Router.go('stops');
  },'Eliminar parada','danger');
}

/* ═══════════════════════════════════════════════════════
   ACCIONES — Asignar parada a ruta
   ═══════════════════════════════════════════════════════ */
function assignStopToRoute(stopId){
  if(!State.routes.length){toast('Crea una ruta primero','error');return;}
  document.getElementById('assign-modal-title').textContent='Asignar a Ruta';
  const _arl=document.getElementById('assign-route-list');
  if(_arl) _arl.scrollTop=0;
  _arl.innerHTML=
    State.routes.map(r=>{
      const ok=r.stops.includes(stopId);
      return `<div class="list-item ${ok?'active':''}" onclick="doAssignStopToRoute('${stopId}','${r.id}')">
        <div class="list-item-icon"><i class="fa-solid fa-route"></i></div>
        <div class="list-item-info">
          <div class="list-item-name">${esc(r.name)}</div>
          <div class="list-item-sub">${State.routeStats(r.id).total} paradas</div>
        </div>
        ${ok?`<i class="fa-solid fa-check" style="color:var(--indigo);flex-shrink:0"></i>`:''}
      </div>`;}).join('');
  openModal('modal-assign-route');
}
function doAssignStopToRoute(stopId,routeId){
  State.addStopToRoute(routeId,stopId);
  closeModal('modal-assign-route');
  toast('Parada añadida a la ruta','success');
}

function showAddStopToRoute(routeId){
  if((_ROLE_ORDER[State.prefs._role]??0) < 1){ toast('Sin permisos para asignar paradas','error'); return; }
  const route = State.getRoute(routeId);
  const unassigned=State.allStops().filter(s=>!route?.stops.includes(s.id));
  if(!unassigned.length){toast('Todas las paradas ya están en esta ruta','info');return;}
  const routeName = route?.name || 'esta ruta';
  document.getElementById('assign-modal-title').textContent=`Añadir Parada a ${routeName}`;
  const _arl2=document.getElementById('assign-route-list');
  if(_arl2) _arl2.scrollTop=0;
  _arl2.innerHTML=
    (unassigned.length < State.allStops().length
      ? `<div style="padding:var(--sp-2) var(--sp-4);font-size:var(--t-xs);color:var(--tx-3)">
           <i class="fa-solid fa-circle-info" style="margin-right:4px"></i>
           Las paradas ya en esta ruta no aparecen
         </div>` : '') +
    unassigned.map(s=>`<div class="list-item" onclick="doAddStopToRoute('${routeId}','${s.id}')">
      <div class="list-item-icon"><i class="fa-solid fa-map-pin"></i></div>
      <div class="list-item-info">
        <div class="list-item-name">${s.name}</div>
        <div class="list-item-sub">${[s.zip,s.town].filter(Boolean).join(' · ')||'—'}</div>
      </div>
      ${!s.lat?`<span class="badge badge-muted" style="font-size:10px">sin GPS</span>`:''}
    </div>`).join('');
  openModal('modal-assign-route');
}
function doAddStopToRoute(routeId,stopId){
  State.addStopToRoute(routeId,stopId);
  syncNow();
  closeModal('modal-assign-route');
  toast('Parada añadida','success');
  Router.go('routes',{routeId});
}

function confirmRemoveFromRoute(routeId,stopId){
  const s=State.getStop(stopId);
  confirm_(`¿Quitar "${s?.name}" de esta ruta?`,()=>{
    State.removeStopFromRoute(routeId,stopId);
    syncNow();
    toast('Parada quitada','info');
    Router.go('routes',{routeId});
  });
}

/* ═══════════════════════════════════════════════════════
   DATOS — Export / Import
   ═══════════════════════════════════════════════════════ */
function exportData(){
  const d=DB.exportAll();
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([JSON.stringify(d,null,2)],{type:'application/json'}));
  a.download=`gestor-rutas-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  toast('Backup completo descargado','success');
}
function restoreBackup(e){
  const f=e.target.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=ev=>{
    try{
      const d=JSON.parse(ev.target.result);
      // Nuevo formato (v1.2): usa DB.importAll
      if(d.version&&d.routes){
        const n=DB.importAll(d);
        // Recargar State desde DB
        State.routes=DB.get(DB.KEYS.routes,[]);
        State.stops=DB.get(DB.KEYS.stops,{});
        State.schedule=DB.get(DB.KEYS.schedule,{});
        State.prefs=DB.get(DB.KEYS.prefs,{});
        /* Aplicar tema restaurado sin recargar */
        if(typeof _applyTheme==='function') _applyTheme(State.prefs.theme||'auto');
        syncNow();
        toast('Backup restaurado ('+n+' colecciones)','success');
      } else {
        // Formato legacy
        if(d.routes)   State.routes=d.routes;
        if(d.stops)    State.stops=d.stops;
        if(d.schedule) State.schedule=d.schedule;
        State.persist();
        syncNow();
        if(typeof _applyTheme==='function') _applyTheme(State.prefs.theme||'auto');
        toast('Backup legacy restaurado','success');
      }
      Router.go('dashboard');
    }catch{toast('Archivo inválido','error');}
  };
  r.readAsText(f);
}
/* handleImportXLS → ver sección IMPORTACIÓN CSV/EXCEL */

/* ── Parsear URL de Google Maps → coords + geocodificación inversa ── */
async function parseGmapsUrl() {
  const url = document.getElementById('stop-gmaps-url').value.trim();
  const status = document.getElementById('gmaps-status');
  if (!url) { status.textContent = 'Pega una URL de Google Maps primero'; return; }

  status.textContent = 'Analizando URL...';

  /* Patrones de coords en URLs de Google Maps:
     @LAT,LNG,  ?q=LAT,LNG  /place/.../LAT,LNG  maps?ll=LAT,LNG */
  const patterns = [
    /@(-?\d+\.?\d*),(-?\d+\.?\d*)/,
    /[?&]q=(-?\d+\.?\d*),(-?\d+\.?\d*)/,
    /ll=(-?\d+\.?\d*),(-?\d+\.?\d*)/,
    /\/(-?\d{1,3}\.\d+),(-?\d{1,3}\.\d+)/,
  ];

  let lat = null, lng = null;
  for (const p of patterns) {
    const m = url.match(p);
    if (m) { lat = parseFloat(m[1]); lng = parseFloat(m[2]); break; }
  }

  /* Intentar también con URL acortada — extraer coordenadas del destino */
  if (!lat && url.includes('goo.gl')) {
    status.textContent = 'URLs acortadas no soportadas — usa la URL completa';
    return;
  }

  if (!lat || isNaN(lat) || !lng || isNaN(lng)) {
    status.textContent = 'No se encontraron coordenadas en la URL';
    return;
  }

  /* Validar rango */
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
    status.textContent = 'Coordenadas fuera de rango';
    return;
  }

  /* Rellenar lat/lng inmediatamente */
  document.getElementById('stop-lat').value = lat.toFixed(6);
  document.getElementById('stop-lng').value = lng.toFixed(6);
  document.getElementById('coords-status').textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  status.textContent = `Coords: ${lat.toFixed(5)}, ${lng.toFixed(5)} — buscando dirección...`;

  /* Geocodificación inversa con Nominatim */
  try {
    const r = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&accept-language=es`
    );
    const d = await r.json();
    if (d && d.address) {
      const a = d.address;
      const road    = [a.road, a.house_number].filter(Boolean).join(', ');
      const town    = a.city || a.town || a.village || a.municipality || '';
      const zip     = a.postcode || '';
      if (road && !document.getElementById('stop-addr').value)
        document.getElementById('stop-addr').value = road;
      if (town && !document.getElementById('stop-town').value)
        document.getElementById('stop-town').value = town;
      if (zip && !document.getElementById('stop-zip').value)
        document.getElementById('stop-zip').value = zip;
      status.textContent = `✓ Dirección rellenada desde las coordenadas`;
    } else {
      status.textContent = `✓ Coordenadas aplicadas`;
    }
  } catch {
    status.textContent = `✓ Coordenadas aplicadas (sin dirección — sin conexión)`;
  }
}

function confirmClearAll(){
  confirm_('¿Borrar TODOS los datos? Esta acción es irreversible.',()=>{
    /* Limpiar datos maestros en State */
    State.routes=[];State.stops={};State.schedule={};
    State.prefs={};
    State.persist();
    /* Limpiar colecciones operacionales */
    DB.setJornadas({});
    DB.setVisits({});
    DB.setForms([]);
    DB.setKpis([]);
    /* Limpiar SyncQueue */
    SyncQueue.clear();
    toast('Todos los datos borrados','info');
    Router.go('dashboard');
  },'⚠️ Borrar todos los datos');
}

/* _localDate defined in core.js */

/* ═══════════════════════════════════════════════════════
   MAPA DE PARADAS — v1.3
   Usa Leaflet + OpenStreetMap, sin API key
   ═══════════════════════════════════════════════════════ */
/* Vista de mapa — ver js/map.js */

/* ═══════════════════════════════════════════════════════
   FICHA DETALLE DE PARADA/CLIENTE — v1.3
   ═══════════════════════════════════════════════════════ */
Router.register('stop-detail', (el, params = {}) => {
  const { stopId } = params;
  const stop = State.getStop(stopId);
  if (!stop) { el.innerHTML = `<div class="empty-state"><div class="empty-title">Parada no encontrada</div></div>`; return; }

  /* Historial local (siempre disponible, incluye datos offline) */
  const allVisits = DB.getVisits();
  const localVisits = Object.entries(allVisits)
    .filter(([k]) => k.endsWith('_' + stopId))
    .map(([k, v]) => {
      const dStr    = k.slice(-10 - 1 - stopId.length, -1 - stopId.length);
      const routeId = k.slice(0, k.length - 1 - stopId.length - 1 - 10 - 1);
      return { routeId, dateStr: dStr, _source: 'local', ...v };
    });

  /* Para supervisor+: complementar con visitas del equipo de la API */
  const roleLevel = ({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0);
  const stopVisits = localVisits
    .sort((a, b) => (b.dateStr || '').localeCompare(a.dateStr || ''))
    .slice(0, 20);

  // KPI acumulados
  const kpiDefs = DB.getKpis();
  const kpiTotals = {};
  kpiDefs.forEach(k => { kpiTotals[k.id] = 0; });
  stopVisits.forEach(v => {
    kpiDefs.forEach(k => {
      const val = v['kpi_' + k.id];
      if (val !== null && val !== undefined) kpiTotals[k.id] += Number(val) || 0;
    });
  });

  // Rutas que contienen esta parada
  const inRoutes = State.routes.filter(r => r.stops.includes(stopId));

  el.innerHTML = `
  <!-- Hero -->
  <div class="stop-detail-hero">
    <div class="stop-detail-id">${stop.id}</div>
    <div class="stop-detail-name">${esc(stop.name)}</div>
    <div class="stop-detail-addr">${[stop.addr, stop.zip, stop.town].filter(Boolean).join(' · ')}</div>
    <div class="stop-detail-chips">
      ${stop.horario ? `<span class="stop-detail-chip"><i class="fa-regular fa-clock"></i>${esc(stop.horario)}</span>` : ''}
      ${stop.lat ? `<span class="stop-detail-chip"><i class="fa-solid fa-location-dot"></i>GPS ✓</span>`
                 : `<span class="stop-detail-chip" style="background:rgba(255,80,80,.25)"><i class="fa-solid fa-location-dot"></i>Sin GPS</span>`}
      <span class="stop-detail-chip"><i class="fa-solid fa-calendar-check"></i>${stopVisits.length} visitas</span>
      ${(stop.tags||[]).map(t=>`<span class="stop-tag">${t}</span>`).join('')}
    </div>
  </div>

  <!-- Acciones rápidas -->
  <div style="display:flex;gap:var(--sp-2);margin-bottom:var(--sp-4);flex-wrap:wrap">
    ${(({rep:0,supervisor:1,admin:2,owner:3}[State.prefs._role]??0) >= 1) ? `
    <button class="btn btn-primary" onclick="editStop('${stopId}')">
      <i class="fa-solid fa-pen"></i> Editar
    </button>` : ''}
    ${stop.lat ? `<button class="btn btn-outline" onclick="openNav(${stop.lat},${stop.lng})">
      <i class="fa-solid fa-diamond-turn-right"></i> Navegar
    </button>` : ''}
    ${stop.phone ? `<a class="btn btn-outline" href="tel:${stop.phone}">
      <i class="fa-solid fa-phone"></i> ${stop.phone}
    </a>` : ''}
    ${stop.mobile ? `<a class="btn btn-outline" href="tel:${stop.mobile}">
      <i class="fa-solid fa-mobile-screen"></i> ${stop.mobile}
    </a>` : ''}
    ${stop.email ? `<a class="btn btn-ghost" href="mailto:${stop.email}">
      <i class="fa-solid fa-envelope"></i> Email
    </a>` : ''}
    ${stop.lat ? `<button class="btn btn-ghost" onclick="Router.go('map',{routeId:undefined});setTimeout(()=>_mapFocusStop&&_mapFocusStop('${stopId}'),400)">
      <i class="fa-solid fa-map"></i> Ver en mapa
    </button>` : ''}
  </div>

  <div style="display:flex;flex-direction:column;gap:var(--sp-4)">

    <!-- Contacto -->
    ${(stop.contact||stop.phone||stop.mobile||stop.email) ? `
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-address-card"></i> Contacto</div></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:8px">
        ${stop.contact ? `<div style="display:flex;align-items:center;gap:8px;font-size:var(--t-sm)">
          <i class="fa-solid fa-user" style="color:var(--tx-3);width:16px;text-align:center"></i>
          <span>${esc(stop.contact)}</span>
        </div>` : ''}
        ${stop.phone ? `<a href="tel:${stop.phone}" style="display:flex;align-items:center;gap:8px;font-size:var(--t-sm);color:var(--tx-1);text-decoration:none">
          <i class="fa-solid fa-phone" style="color:var(--green);width:16px;text-align:center"></i>
          <span>${stop.phone}</span>
        </a>` : ''}
        ${stop.mobile ? `<a href="tel:${stop.mobile}" style="display:flex;align-items:center;gap:8px;font-size:var(--t-sm);color:var(--tx-1);text-decoration:none">
          <i class="fa-solid fa-mobile-screen" style="color:var(--blue);width:16px;text-align:center"></i>
          <span>${stop.mobile}</span>
        </a>` : ''}
        ${stop.email ? `<a href="mailto:${stop.email}" style="display:flex;align-items:center;gap:8px;font-size:var(--t-sm);color:var(--tx-1);text-decoration:none">
          <i class="fa-solid fa-envelope" style="color:var(--tx-3);width:16px;text-align:center"></i>
          <span>${stop.email}</span>
        </a>` : ''}
      </div>
    </div>` : ''}

    <!-- Notas permanentes -->
    ${stop.notes ? `
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-note-sticky"></i> Notas</div></div>
      <div class="card-body" style="font-size:var(--t-sm);color:var(--tx-2);line-height:1.6">${esc(stop.notes)}</div>
    </div>` : ''}

    <!-- Rutas asignadas -->
    <div class="card">
      <div class="card-header">
        <div class="card-title"><i class="fa-solid fa-route"></i> Rutas asignadas</div>
        <button class="btn btn-ghost btn-sm" onclick="assignStopToRoute('${stopId}')">
          <i class="fa-solid fa-plus"></i> Asignar
        </button>
      </div>
      ${inRoutes.length === 0
        ? `<div class="card-body"><span style="font-size:var(--t-sm);color:var(--tx-3)">No está en ninguna ruta</span></div>`
        : `<div>${inRoutes.map(r => `
            <div class="list-item" onclick="Router.go('routes',{routeId:'${r.id}'})">
              <div class="list-item-icon"><i class="fa-solid fa-route"></i></div>
              <div class="list-item-info">
                <div class="list-item-name">${esc(r.name)}</div>
                <div class="list-item-sub">${State.routeStats(r.id).total} paradas</div>
              </div>
              <i class="fa-solid fa-chevron-right" style="color:var(--tx-3);font-size:var(--t-xs)"></i>
            </div>`).join('')}</div>`}
    </div>

    <!-- KPIs acumulados -->
    ${kpiDefs.length > 0 ? `
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fa-solid fa-chart-bar"></i> KPIs acumulados</div></div>
      <div class="card-body">
        <div class="kpi-summary-grid">
          ${kpiDefs.map(k => `
            <div class="kpi-summary-cell">
              <div class="kpi-summary-val">${kpiTotals[k.id] || 0}${k.unit ? `<span style="font-size:.75em;font-weight:400"> ${k.unit}</span>` : ''}</div>
              <div class="kpi-summary-label">${esc(k.label)}</div>
            </div>`).join('')}
        </div>
      </div>
    </div>` : ''}

    <!-- Historial de visitas del equipo (cargado async para supervisor+) -->
    ${roleLevel >= 1 ? `<div class="card" id="stop-history-api">
      <div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm);text-align:center">
        <i class="fa-solid fa-spinner fa-spin"></i> Cargando historial del equipo…
      </div>
    </div>` : ''}

    <!-- Historial de visitas propias -->
    <div class="card">
      <div class="card-header">
        <div class="card-title"><i class="fa-solid fa-clock-rotate-left"></i> ${roleLevel >= 1 ? 'Mis visitas' : 'Historial de visitas'}</div>
        <span class="badge badge-muted">${stopVisits.length}</span>
      </div>
      ${stopVisits.length === 0
        ? `<div class="card-body">${_empty('Sin visitas registradas','Haz check-in desde la pantalla de Jornada','','')}</div>`
        : `<div style="padding:0 var(--sp-4)">
            ${stopVisits.map(v => {
              const d = new Date((v.dateStr || '') + 'T12:00');
              const dur = (v.checkInTs && v.checkOutTs)
                ? Math.round((v.checkOutTs - v.checkInTs) / 60000) + ' min' : '';
              const kpiLine = kpiDefs.length
                ? kpiDefs.map(k => v['kpi_'+k.id] != null ? `${esc(k.label)}: ${v['kpi_'+k.id]}${k.unit?' '+k.unit:''}` : null).filter(Boolean).join(' · ')
                : '';
              return `<div class="visit-history-item">
                <div class="visit-history-date">
                  <div class="visit-history-day">${d.getDate()}</div>
                  <div class="visit-history-month">${d.toLocaleDateString('es-ES',{month:'short'})}</div>
                </div>
                <div class="visit-history-body">
                  <div class="visit-history-status">${v.estado || 'Visitada'}</div>
                  <div class="visit-history-meta">
                    ${v.routeId ? (State.getRoute(v.routeId)?.name || v.routeId) : ''}
                    ${dur ? ' · ' + dur : ''}
                  </div>
                  ${kpiLine ? `<div class="visit-history-meta" style="color:var(--indigo)">${kpiLine}</div>` : ''}
                  ${v.notas ? `<div class="visit-history-notes">${v.notas}</div>` : ''}
                  ${(v.photos||[]).length ? `<div class="visit-history-meta" style="margin-top:4px">
                    <i class="fa-solid fa-camera"></i> ${v.photos.length} foto${v.photos.length>1?'s':''}</div>` : ''}
                </div>
                <div style="display:flex;flex-direction:column;gap:4px">
                  <button class="btn btn-ghost btn-icon sm"
                      onclick="openVisitDetail('${v.routeId}','${v.dateStr}','${v.stopId||stopId}')"
                      title="Ver detalle visita">
                    <i class="fa-solid fa-eye"></i>
                  </button>
                  <button class="btn btn-ghost btn-icon sm"
                      onclick="Router.go('jornada',{routeId:'${v.routeId}',dateStr:'${v.dateStr}'})"
                      title="Ir a esa jornada">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                  </button>
                </div>
              </div>`;
            }).join('')}
          </div>`}
    </div>

  </div>`;

  /* Para supervisor+: cargar historial de la parada del equipo desde la API */
  if (roleLevel >= 1 && Auth.isLoggedIn()) {
    _loadStopHistory(stopId);
  }
});


/* ── Modal de objetivos por comercial ─────────────────── */
function showTargetsModal(userId, userName, currentTargets) {
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.id = 'modal-targets';
  const visWeek  = currentTargets?.visits_week   ?? '';
  const sessWeek = currentTargets?.sessions_week ?? '';
  ov.innerHTML = `
  <div class="modal" style="max-width:360px" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title"><i class="fa-solid fa-bullseye"></i> Objetivos</div>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="display:flex;flex-direction:column;gap:var(--sp-3)">
      <div style="font-size:var(--t-sm);color:var(--tx-2);font-weight:500">${esc(userName)}</div>
      <div class="form-group">
        <label class="form-label">Visitas por semana</label>
        <input id="tgt-visits-week" type="number" min="0" max="999" class="form-input"
          placeholder="Sin objetivo" value="${visWeek}">
      </div>
      <div class="form-group">
        <label class="form-label">Jornadas por semana</label>
        <input id="tgt-sessions-week" type="number" min="0" max="7" class="form-input"
          placeholder="Sin objetivo" value="${sessWeek}">
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cancelar</button>
      <button class="btn btn-primary" style="flex:2" onclick="_saveTargets('${userId}')">
        <i class="fa-solid fa-check"></i> Guardar
      </button>
    </div>
  </div>`;
  Overlay.push(ov);
}

async function _saveTargets(userId) {
  const vw = parseInt(document.getElementById('tgt-visits-week')?.value) || 0;
  const sw = parseInt(document.getElementById('tgt-sessions-week')?.value) || 0;
  const btn = document.querySelector('#modal-targets .btn-primary');
  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>'; }
  try {
    await API.patch(`/users/${userId}/targets`, {
      visits_week:   vw || null,
      sessions_week: sw || null,
    });
    Overlay.pop();
    toast('Objetivos guardados ✓', 'success', 2500);
    /* Recargar dashboard para reflejar cambios */
    if (typeof _loadMgrDashboard === 'function') _loadMgrDashboard('week');
  } catch(e) {
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-check"></i> Guardar'; }
    toast(e.message || 'Error al guardar objetivos', 'error');
  }
}

/* ── Jornadas del equipo para Informes (supervisor+) ─── */
async function _loadTeamSessions() {
  const wrap = document.getElementById('team-sessions-wrap');
  if (!wrap) return;
  try {
    const data = await API.get('/stats/dashboard?period=month');
    const role = State.prefs._role;
    let sessions = [];
    if (role === 'supervisor') {
      sessions = (data?.active_sessions || []);
      /* Para historial: pedir period=month y extraer sesiones de team */
      const team = data?.team || [];
      /* Mostrar resumen por rep del mes */
      if (!team.length) {
        wrap.innerHTML = '<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">Sin actividad del equipo este mes</div>';
        return;
      }
      wrap.innerHTML = '<div class="card-header"><div class="card-title"><i class="fa-solid fa-users"></i> Actividad del equipo (mes)</div></div>' +
        '<div>' + team.sort((a,b) => b.visits - a.visits).map(rep => {
          const h = Math.floor((rep.elapsed_s||0)/3600);
          const isActive = rep.active_now;
          return `<div class="list-item">
            <div class="list-item-icon" style="background:${isActive?'var(--green-bg)':'var(--bg-surface)'}">
              <i class="fa-solid fa-user" style="color:${isActive?'var(--green)':'var(--tx-3)'}"></i>
            </div>
            <div class="list-item-info">
              <div class="list-item-name">${esc(rep.name||rep.email)} ${isActive?'<span class="badge badge-green" style="font-size:10px">Activo</span>':''}</div>
              <div class="list-item-sub">${rep.visits} visitas · ${rep.sessions_done}/${rep.sessions} jornadas · ${h}h · ${rep.distance_km}km</div>
            </div>
          </div>`;
        }).join('') + '</div>';
    } else {
      /* admin/owner: mostrar activos ahora */
      const active = data?.active_sessions || [];
      if (!active.length) {
        wrap.innerHTML = '<div class="card-body" style="color:var(--tx-3);font-size:var(--t-sm)">Sin jornadas activas ahora mismo</div>';
        return;
      }
      wrap.innerHTML = '<div class="card-header"><div class="card-title"><i class="fa-solid fa-circle" style="color:var(--green);font-size:10px"></i> En jornada ahora</div></div>' +
        '<div>' + active.map(s => `<div class="list-item">
          <div class="list-item-info">
            <div class="list-item-name">${esc(s.user_name||s.user_id)}</div>
            <div class="list-item-sub">${esc(s.route_name||'—')} · ${s.visits_today||0} visitas hoy</div>
          </div>
        </div>`).join('') + '</div>';
    }
  } catch {
    const wrap = document.getElementById('team-sessions-wrap');
    if (wrap) wrap.innerHTML = '';
  }
}

/* ── Historial de parada desde API (supervisor+) ──────── */
async function _loadStopHistory(stopId) {
  try {
    const visits = await API.get('/visits?stopId=' + stopId);
    if (!visits?.length) return;
    const histEl = document.getElementById('stop-history-api');
    if (!histEl) return;
    const kpiDefs = DB.getKpis();
    const rows = visits.slice(0, 30).map(v => {
      const d   = new Date((v.checkInAt || v.createdAt || 0));
      const dur = (v.checkInAt && v.checkOutAt)
        ? Math.round((v.checkOutAt - v.checkInAt) / 60000) + ' min' : '';
      const route = State.getRoute(v.routeId || '');
      return `<div class="visit-history-item">
        <div class="visit-history-date">
          <div class="visit-history-day">${d.getDate() || '—'}</div>
          <div class="visit-history-month">${d.toLocaleDateString('es-ES',{month:'short'})}</div>
        </div>
        <div class="visit-history-body">
          <div class="visit-history-status">${esc(v.estado || 'Visitada')}</div>
          <div class="visit-history-meta">${route ? esc(route.name) : ''} ${dur ? '· ' + dur : ''}</div>
          ${v.notas ? `<div class="visit-history-notes">${esc(v.notas)}</div>` : ''}
        </div>
      </div>`;
    }).join('');
    histEl.innerHTML = `
      <div class="card-header" style="padding-top:var(--sp-3)">
        <div class="card-title" style="font-size:var(--t-sm)">
          <i class="fa-solid fa-users" style="color:var(--indigo)"></i>
          Visitas del equipo (${visits.length})
        </div>
      </div>
      <div style="padding:0 var(--sp-4)">${rows}</div>`;
  } catch { /* silencioso — historial local ya está visible */ }
}

/* ═══════════════════════════════════════════════════════
   ESTADÍSTICAS v1.4
   KPIs por periodo · Visitas por semana · Exportación CSV
   ═══════════════════════════════════════════════════════ */
/* Estadísticas y exportación CSV — ver js/stats.js */

/* ═══════════════════════════════════════════════════════
   IMPORTACIÓN CSV / EXCEL — v1.5.4
   Lee CSV o XLSX · previsualiza · mapea columnas · upsertStop
   ═══════════════════════════════════════════════════════ */

/* Campos destino de una parada */
const _IMPORT_FIELDS = [
  { key:'id',      label:'ID / Ref',         required:false },
  { key:'name',    label:'Nombre',            required:true  },
  { key:'addr',    label:'Dirección',         required:false },
  { key:'town',    label:'Población',         required:false },
  { key:'zip',     label:'CP',               required:false },
  { key:'lat',     label:'Latitud',           required:false },
  { key:'lng',     label:'Longitud',          required:false },
  { key:'contact', label:'Persona contacto',  required:false },
  { key:'phone',   label:'Teléfono',          required:false },
  { key:'mobile',  label:'Móvil',             required:false },
  { key:'email',   label:'Email',             required:false },
  { key:'tags',    label:'Etiquetas',         required:false },
  { key:'horario', label:'Horario',           required:false },
  { key:'notes',   label:'Notas',             required:false },
];

/* Heurística de autodetección de columna → campo */
const _IMPORT_HINTS = {
  id:      ['id','ref','codigo','code','cod','cliente','cód'],
  name:    ['nombre','name','cliente','razon','razón','empresa','company','denominacion','denominación'],
  addr:    ['direccion','dirección','address','calle','domicilio','dir'],
  town:    ['poblacion','población','ciudad','localidad','municipio','town','city'],
  zip:     ['cp','zip','postal','codigo postal','cód. postal'],
  lat:     ['lat','latitud','latitude'],
  lng:     ['lng','lon','long','longitud','longitude'],
  contact: ['contacto','contact','responsable','persona','interlocutor'],
  phone:   ['telefono','teléfono','tel','phone','fijo'],
  mobile:  ['movil','móvil','celular','mobile','cel'],
  email:   ['email','correo','mail','e-mail'],
  tags:    ['tags','etiquetas','categorias','categorías','tipo','canal'],
  horario: ['horario','horarios','schedule','atencion','atención'],
  notes:   ['notas','notes','observaciones','obs','comentarios'],
};

let _importRows = [];
let _importHeaders = [];

function handleImportXLS(e) {
  if((_ROLE_ORDER[State.prefs._role]??0) < 1){ toast('Sin permisos para importar','error'); return; }
  const file = e.target.files[0];
  e.target.value = ''; /* reset para permitir reimportar mismo archivo */
  if (!file) return;

  const ext = file.name.split('.').pop().toLowerCase();

  if (ext === 'csv') {
    const reader = new FileReader();
    reader.onload = ev => _importParsed(_parseCSV(ev.target.result));
    reader.readAsText(file, 'UTF-8');
  } else if (ext === 'xlsx' || ext === 'xls') {
    /* XLSX via SheetJS — cargado dinámicamente si no está disponible */
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        if (typeof XLSX === 'undefined') {
          toast('Para importar Excel instala la app desde el navegador o usa formato CSV', 'error', 5000);
          return;
        }
        const wb = XLSX.read(ev.target.result, { type:'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const data = XLSX.utils.sheet_to_json(ws, { header:1, defval:'' });
        _importParsed(data);
      } catch {
        toast('No se pudo leer el archivo Excel. Prueba exportándolo como CSV.', 'error', 4000);
      }
    };
    reader.readAsArrayBuffer(file);
  } else {
    toast('Formato no soportado. Usa .csv, .xlsx o .xls', 'error');
  }
}

function _parseCSV(text) {
  /* Soporta ; y , como separador, con y sin comillas */
  const lines = text.replace(/\r\n/g,'\n').replace(/\r/g,'\n').trim().split('\n');
  if (!lines.length) return [];
  /* Detectar separador */
  const sep = (lines[0].split(';').length >= lines[0].split(',').length) ? ';' : ',';
  return lines.map(line => {
    const result = [];
    let cur = '', inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') { inQ = !inQ; continue; }
      if (ch === sep && !inQ) { result.push(cur.trim()); cur = ''; continue; }
      cur += ch;
    }
    result.push(cur.trim());
    return result;
  });
}

function _autoMap(headers) {
  const map = {};
  headers.forEach((h, i) => {
    const norm = h.toLowerCase().trim();
    for (const [field, hints] of Object.entries(_IMPORT_HINTS)) {
      if (!map[field] && hints.some(hint => norm.includes(hint))) {
        map[field] = i;
      }
    }
  });
  return map;
}

function _importParsed(rows) {
  if (!rows || rows.length < 2) {
    toast('El archivo no tiene datos suficientes', 'error'); return;
  }
  _importHeaders = rows[0].map(String);
  _importRows = rows.slice(1).filter(r => r.some(c => String(c).trim()));

  if (!_importRows.length) {
    toast('No se encontraron filas con datos', 'error'); return;
  }

  _openImportOverlay(_autoMap(_importHeaders));
}

function _openImportOverlay(autoMap) {
  const headerOpts = _importHeaders.map((h,i) =>
    `<option value="${i}" ${autoMap ? '' : ''}>${h}</option>`
  ).join('');
  const noneOpt = `<option value="">— ignorar —</option>`;

  const selects = _IMPORT_FIELDS.map(f => {
    const mapped = autoMap[f.key] !== undefined ? autoMap[f.key] : '';
    return `
    <div class="import-field-row">
      <label class="import-field-label">${f.label}${f.required ? ' <span style="color:var(--red)">*</span>':''}</label>
      <select class="import-select form-control" data-field="${f.key}">
        ${noneOpt}
        ${_importHeaders.map((h,i) =>
          `<option value="${i}" ${String(mapped)===String(i)?'selected':''}>${h}</option>`
        ).join('')}
      </select>
    </div>`;
  }).join('');

  /* Previsualización — primeras 3 filas */
  const previewRows = _importRows.slice(0,3).map(r =>
    `<tr>${_importHeaders.map((_,i) => `<td>${r[i]||''}</td>`).join('')}</tr>`
  ).join('');

  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.innerHTML = `
  <div class="modal" style="max-width:560px;max-height:92vh;overflow-y:auto" onclick="event.stopPropagation()">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-file-import"></i> Importar paradas</h3>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">

      <div class="import-info">
        <i class="fa-solid fa-circle-info"></i>
        <span>${_importRows.length} filas detectadas · ${_importHeaders.length} columnas</span>
      </div>

      <div style="margin:12px 0 4px;font-size:var(--t-sm);font-weight:600;color:var(--tx-2)">
        Previsualización (primeras 3 filas)
      </div>
      <div style="overflow-x:auto;margin-bottom:16px">
        <table class="import-preview-table">
          <thead><tr>${_importHeaders.map(h=>`<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${previewRows}</tbody>
        </table>
      </div>

      <div style="margin-bottom:8px;font-size:var(--t-sm);font-weight:600;color:var(--tx-2)">
        Asignar columnas
      </div>
      <div class="import-fields">${selects}</div>

      <div id="import-result" style="margin-top:12px"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="Overlay.pop()">Cancelar</button>
      <button class="btn btn-primary" onclick="_doImport()">
        <i class="fa-solid fa-file-import"></i> Importar ${_importRows.length} paradas
      </button>
    </div>
  </div>`;

  Overlay.push(ov);
}

function _doImport() {
  /* Leer mapeo actual de selects */
  const map = {};
  document.querySelectorAll('.import-select').forEach(sel => {
    if (sel.value !== '') map[sel.dataset.field] = parseInt(sel.value);
  });

  if (map.name === undefined) {
    toast('Debes asignar al menos la columna Nombre', 'error'); return;
  }

  let ok = 0, skipped = 0;
  _importRows.forEach((row, ri) => {
    const name = String(row[map.name] || '').trim();
    if (!name) { skipped++; return; }

    const stop = {};
    _IMPORT_FIELDS.forEach(f => {
      if (map[f.key] !== undefined) {
        let val = String(row[map[f.key]] || '').trim();
        if (f.key === 'lat' || f.key === 'lng') {
          val = parseFloat(val.replace(',', '.')) || null;
        }
        stop[f.key] = val || null;
      }
    });

    stop.name = name;
    if (!stop.id) stop.id = `IMP${String(Date.now()).slice(-6)}${ri}`;
    /* Tags: convertir string CSV a array */
    if (typeof stop.tags === 'string' && stop.tags) {
      stop.tags = stop.tags.split(/[,;]/).map(t=>t.trim().toLowerCase()).filter(Boolean);
    } else if (!stop.tags) {
      stop.tags = [];
    }

    State.upsertStop(stop);
    ok++;
  });

  syncNow(); /* push inmediato tras importar */
  Overlay.pop();

  const msg = skipped
    ? `${ok} paradas importadas · ${skipped} filas sin nombre ignoradas`
    : `${ok} paradas importadas correctamente`;
  toast(msg, 'success', 4000);

  Router.go('stops');
}

/* ═══════════════════════════════════════════════════════
   NOTIFICACIONES PUSH — recordatorio de jornada
   ═══════════════════════════════════════════════════════ */

async function toggleNotifications() {
  if (!('Notification' in window)) {
    toast('Tu navegador no soporta notificaciones', 'error'); return;
  }

  if (State.prefs.notifEnabled) {
    /* Desactivar */
    State.prefs.notifEnabled = false;
    State.persist();
    if (Auth.isLoggedIn()) API.patch('/auth/settings', { notifEnabled: false }).catch(() => {});
    _updateNotifUI();
    toast('Recordatorio desactivado', 'info');
    return;
  }

  /* Pedir permiso */
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') {
    document.getElementById('notif-sub').textContent =
      'Permiso denegado — actívalo en los ajustes del navegador';
    toast('Permiso de notificaciones denegado', 'error', 4000);
    return;
  }

  State.prefs.notifEnabled = true;
  if (!State.prefs.notifTime) State.prefs.notifTime = '08:00';
  State.persist();
  if (Auth.isLoggedIn()) API.patch('/auth/settings', { notifEnabled: true, notifTime: State.prefs.notifTime }).catch(() => {});
  _updateNotifUI();
  _scheduleJornadaNotif();
  toast('Recordatorio activado', 'success');
}

function saveNotifTime(val) {
  State.prefs.notifTime = val;
  State.persist();
  if (Auth.isLoggedIn()) API.patch('/auth/settings', { notifTime: val }).catch(() => {});
  if (State.prefs.notifEnabled) _scheduleJornadaNotif();
}

function _updateNotifUI() {
  const btn = document.getElementById('notif-toggle-btn');
  if (!btn) return;
  btn.textContent = State.prefs.notifEnabled ? 'Activado' : 'Activar';
  btn.className = `btn btn-sm ${State.prefs.notifEnabled ? 'btn-primary' : 'btn-ghost'}`;
}

function _scheduleJornadaNotif() {
  if (!State.prefs.notifEnabled || Notification.permission !== 'granted') return;

  const [h, m] = (State.prefs.notifTime || '08:00').split(':').map(Number);
  const now = new Date();
  const target = new Date();
  target.setHours(h, m, 0, 0);
  if (target <= now) target.setDate(target.getDate() + 1);

  const ms = target - now;

  /* Limpiar timer anterior */
  if (window._notifTimer) clearTimeout(window._notifTimer);

  window._notifTimer = setTimeout(() => {
    const today = _localDate(new Date());
    const routeId = State.schedule[today];
    const route = routeId ? State.getRoute(routeId) : null;

    if (route) {
      new Notification('Gestor de Rutas Pro', {
        body: `Hoy tienes la ruta "${esc(route.name)}" — ${route.stops.length} paradas`,
        icon: '/gestor-rutas/manifest.json',
        tag: 'jornada-reminder',
      });
      Events.emit('notification:sent', { type: 'jornada', routeId, today });
    }
    /* Re-programar para mañana */
    _scheduleJornadaNotif();
  }, ms);
}

/* Arrancar al cargar si estaba activado */
document.addEventListener('DOMContentLoaded', () => {
  if (State.prefs.notifEnabled && Notification.permission === 'granted') {
    _scheduleJornadaNotif();
  }
});

/* Reaccionar a cambio de tema para actualizar botones en ajustes */
Events.on('theme:changed', () => {
  /* Si la página de ajustes está activa, refrescar los botones */
  if (Router._current === 'settings') {
    ['auto','light','dark'].forEach(m => {
      const btn = document.getElementById(`theme-btn-${m}`);
      if (btn) {
        const active = (State.prefs.theme||'auto') === m;
        btn.className = `btn btn-sm ${active?'btn-primary':'btn-ghost'}`;
      }
    });
  }
});

/* ══════════════════════════════════════════════════════════
   PANEL GOD — solo visible si State.prefs._pRole === 'god'
   ══════════════════════════════════════════════════════════ */
/* ── Estado del panel god (persiste entre tabs sin recargar) ── */
const _GodState = { orgs: null, users: null, editingOrgId: null };
const _GOD_ROLES = { rep:'Comercial', supervisor:'Supervisor', admin:'Admin', owner:'Propietario' };
const _GOD_PLANS = { free:'Free', pro:'Pro', enterprise:'Enterprise' };

Router.register('god', async (el) => {
  if (State.prefs._pRole !== 'god' && State.prefs._pRole !== 'platform_admin') {
    el.innerHTML = `<div class="page-header"><h1 class="page-title">Acceso denegado</h1></div>`;
    return;
  }
  _GodState.orgs = null; _GodState.users = null; _GodState.editingOrgId = null;
  el.innerHTML = `
    <div class="page-header" style="margin-bottom:0">
      <h1 class="page-title" style="display:flex;align-items:center;gap:8px">
        <span class="badge badge-purple" style="font-size:11px">⚡ God</span>
        Plataforma
      </h1>
    </div>
    <div id="god-stats" class="stats-grid" style="margin:12px 0 16px"></div>
    <div style="display:flex;gap:6px;margin-bottom:12px">
      <button class="btn btn-sm god-tab-btn active" data-tab="orgs" onclick="_godShowTab('orgs',this)">
        <i class="fa-solid fa-building"></i> Orgs
      </button>
      <button class="btn btn-ghost btn-sm god-tab-btn" data-tab="users" onclick="_godShowTab('users',this)">
        <i class="fa-solid fa-users"></i> Usuarios
      </button>
      <button class="btn btn-ghost btn-sm god-tab-btn" data-tab="requests" onclick="_godShowTab('requests',this)">
        <i class="fa-solid fa-user-clock"></i> Solicitudes
        <span id="god-req-badge" style="display:none;background:var(--danger);color:#fff;border-radius:999px;font-size:10px;padding:1px 6px;margin-left:4px">0</span>
      </button>
    </div>
    <div id="god-content"></div>
  `;
  _godLoadStats();
  _godLoadReqBadge();
  _godShowTab('orgs', el.querySelector('[data-tab="orgs"]'));
});

async function _godLoadStats() {
  try {
    const r = await API.get('/platform/stats');
    const s = document.getElementById('god-stats');
    if (!s) return;
    s.innerHTML = `
      <div class="stat-card"><div class="stat-value">${r.totalOrgs}</div><div class="stat-label">Orgs</div></div>
      <div class="stat-card"><div class="stat-value">${r.totalUsers}</div><div class="stat-label">Usuarios</div></div>
      <div class="stat-card"><div class="stat-value">${r.loginsToday}</div><div class="stat-label">Logins hoy</div></div>
      <div class="stat-card"><div class="stat-value">${r.newThisWeek}</div><div class="stat-label">Nuevos 7d</div></div>
    `;
  } catch(e) {}
}

async function _godShowTab(tab, btn) {
  document.querySelectorAll('.god-tab-btn').forEach(b => {
    b.className = b.dataset.tab === tab ? 'btn btn-sm god-tab-btn active' : 'btn btn-ghost btn-sm god-tab-btn';
  });
  const el = document.getElementById('god-content');
  if (!el) return;

  if (tab === 'orgs') {
    /* Si hay una org en edición, mostrar la vista de edición */
    if (_GodState.editingOrgId) { _godRenderOrgEdit(el); return; }
    if (!_GodState.orgs) {
      el.innerHTML = `<div class="empty-state"><i class="fa-solid fa-spinner fa-spin"></i></div>`;
      try { _GodState.orgs = await API.get('/platform/orgs'); } catch(e) {
        el.innerHTML = `<div class="empty-state" style="color:var(--danger)">Error cargando orgs</div>`; return;
      }
    }
    _godRenderOrgList(el);
  } else if (tab === 'requests') {
    _GodState.reqs = null;
    el.innerHTML = `<div class="empty-state"><i class="fa-solid fa-spinner fa-spin"></i></div>`;
    try {
      _GodState.reqs = await API.get('/platform/registrations?status=pending');
      _godRenderRequests(el);
    } catch(e) {
      el.innerHTML = `<div class="empty-state" style="color:var(--danger)">Error cargando solicitudes</div>`;
    }
    return;
  } else {
    if (!_GodState.users) {
      el.innerHTML = `<div class="empty-state"><i class="fa-solid fa-spinner fa-spin"></i></div>`;
      try { _GodState.users = await API.get('/platform/users'); } catch(e) {
        el.innerHTML = `<div class="empty-state" style="color:var(--danger)">Error cargando usuarios</div>`; return;
      }
    }
    _godRenderUserList(el);
  }
}

function _godRenderOrgList(el) {
  const orgs = _GodState.orgs || [];
  /* Separar orgs reales de orgs de test */
  const real = orgs.filter(o => !o.slug.startsWith('org-test-'));
  const test = orgs.filter(o => o.slug.startsWith('org-test-'));
  const _orgRow = (o) => `
    <div class="list-item" onclick="_godOpenOrgEdit('${o.id}')" style="cursor:pointer">
      <div style="flex:1;min-width:0">
        <div style="font-weight:500;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${o.name}</div>
        <div style="font-size:12px;color:var(--tx-3)">${o.memberCount} miembro${o.memberCount!==1?'s':''} · ${new Date(o.createdAt).toLocaleDateString('es-ES')}</div>
      </div>
      <div style="display:flex;gap:5px;align-items:center;flex-shrink:0">
        <span class="badge ${o.active?'badge-green':'badge-gray'}" style="font-size:10px">${o.active?'Activa':'Inactiva'}</span>
        <span class="badge badge-indigo" style="font-size:10px">${_GOD_PLANS[o.plan]||o.plan}</span>
        <i class="fa-solid fa-chevron-right" style="font-size:11px;color:var(--tx-3)"></i>
      </div>
    </div>`;
  el.innerHTML = `
    <div class="list-items">
      ${real.length ? real.map(_orgRow).join('') : '<div class="empty-state" style="padding:12px">Sin orgs reales aún</div>'}
    </div>
    ${test.length ? `
    <details style="margin-top:12px">
      <summary style="font-size:12px;color:var(--tx-3);cursor:pointer;padding:6px 0">
        <i class="fa-solid fa-flask"></i> ${test.length} org${test.length!==1?'s':''} de test (ocultas)
      </summary>
      <div class="list-items" style="margin-top:6px;opacity:.6">${test.map(_orgRow).join('')}</div>
    </details>` : ''}
  `;
}

function _godOpenOrgEdit(id) {
  _GodState.editingOrgId = id;
  const el = document.getElementById('god-content');
  if (el) _godRenderOrgEdit(el);
}

function _godRenderOrgEdit(el) {
  const o = (_GodState.orgs || []).find(x => x.id === _GodState.editingOrgId);
  if (!o) return;
  el.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
      <button class="btn btn-ghost btn-icon" onclick="_godCloseOrgEdit()">
        <i class="fa-solid fa-arrow-left"></i>
      </button>
      <div>
        <div style="font-weight:500;font-size:15px">${o.name}</div>
        <div style="font-size:12px;color:var(--tx-3)">${o.slug}</div>
      </div>
    </div>

    <div style="display:flex;flex-direction:column;gap:16px">
      <div>
        <div style="font-size:12px;font-weight:500;color:var(--tx-2);margin-bottom:6px">Plan</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          ${['free','pro','enterprise'].map(p=>`
            <button class="btn btn-sm ${o.plan===p?'btn-primary':'btn-ghost'}" id="god-plan-${p}"
              onclick="_godSelectPlan('${p}')">
              ${_GOD_PLANS[p]}
            </button>`).join('')}
        </div>
      </div>

      <div>
        <div style="font-size:12px;font-weight:500;color:var(--tx-2);margin-bottom:6px">Límite de usuarios</div>
        <div style="display:flex;align-items:center;gap:12px">
          <button class="btn btn-ghost btn-icon" onclick="_godAdjSeats(-1)">
            <i class="fa-solid fa-minus"></i>
          </button>
          <span id="god-seats-val" style="font-size:20px;font-weight:600;min-width:32px;text-align:center">${o.seatLimit}</span>
          <button class="btn btn-ghost btn-icon" onclick="_godAdjSeats(1)">
            <i class="fa-solid fa-plus"></i>
          </button>
        </div>
      </div>

      <div>
        <div style="font-size:12px;font-weight:500;color:var(--tx-2);margin-bottom:6px">Estado</div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-sm ${o.active?'btn-primary':'btn-ghost'}" id="god-state-active"
            onclick="_godSetActive(true)">Activa</button>
          <button class="btn btn-sm ${!o.active?'btn-danger':'btn-ghost'}" id="god-state-inactive"
            onclick="_godSetActive(false)">Inactiva</button>
        </div>
      </div>

      <div style="background:var(--bg-2);border-radius:var(--r-md);padding:12px;font-size:12px;color:var(--tx-3)">
        ${o.memberCount} miembro${o.memberCount!==1?'s':', solo owner'} ·
        Creada ${new Date(o.createdAt).toLocaleDateString('es-ES')}
        ${o.lastActivity ? '· Último acceso ' + new Date(o.lastActivity).toLocaleDateString('es-ES') : ''}
      </div>

      <button class="btn btn-primary w-full" id="god-save-btn" onclick="_godSaveOrg()">
        <i class="fa-solid fa-floppy-disk"></i> Guardar cambios
      </button>
    </div>
  `;
  /* Guardar valores editados en memoria temporal */
  el._editPlan   = o.plan;
  el._editSeats  = o.seatLimit;
  el._editActive = o.active;
}

function _godSelectPlan(plan) {
  const el = document.getElementById('god-content');
  el._editPlan = plan;
  ['free','pro','enterprise'].forEach(p => {
    const btn = document.getElementById(`god-plan-${p}`);
    if (btn) btn.className = `btn btn-sm ${p===plan?'btn-primary':'btn-ghost'}`;
  });
}

function _godAdjSeats(delta) {
  const el = document.getElementById('god-content');
  el._editSeats = Math.max(1, (el._editSeats||1) + delta);
  const v = document.getElementById('god-seats-val');
  if (v) v.textContent = el._editSeats;
}

function _godSetActive(val) {
  const el = document.getElementById('god-content');
  el._editActive = val;
  const a = document.getElementById('god-state-active');
  const i = document.getElementById('god-state-inactive');
  if (a) a.className = `btn btn-sm ${val?'btn-primary':'btn-ghost'}`;
  if (i) i.className = `btn btn-sm ${!val?'btn-danger':'btn-ghost'}`;
}

function _godCloseOrgEdit() {
  _GodState.editingOrgId = null;
  const el = document.getElementById('god-content');
  if (el) _godRenderOrgList(el);
}

async function _godSaveOrg() {
  const el    = document.getElementById('god-content');
  const id    = _GodState.editingOrgId;
  const btn   = document.getElementById('god-save-btn');
  if (!id || !el) return;
  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Guardando...'; }
  try {
    await API.patch(`/platform/orgs/${id}`, {
      plan:      el._editPlan,
      seatLimit: el._editSeats,
      active:    el._editActive,
    });
    /* Actualizar caché local */
    const idx = (_GodState.orgs||[]).findIndex(o => o.id === id);
    if (idx !== -1) {
      _GodState.orgs[idx].plan      = el._editPlan;
      _GodState.orgs[idx].seatLimit = el._editSeats;
      _GodState.orgs[idx].active    = el._editActive;
    }
    _GodState.editingOrgId = null;
    _godRenderOrgList(el);
  } catch(e) {
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Guardar cambios'; }
    alert('Error: ' + e.message);
  }
}

function _godRenderUserList(el) {
  const users = _GodState.users || [];
  /* Separar usuarios reales de test */
  const real = users.filter(u => !u.email.includes('@gestor.test'));
  const test = users.filter(u => u.email.includes('@gestor.test'));
  const _userRow = (u) => `
    <div class="list-item god-user-row" data-search="${(u.name+' '+u.email+' '+(u.orgName||'')).toLowerCase()}" style="cursor:default">
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${u.email}</div>
        <div style="font-size:11px;color:var(--tx-3)">${u.name||'—'} · ${u.orgName||'Sin org'}</div>
      </div>
      <div style="display:flex;gap:4px;align-items:center;flex-shrink:0">
        ${u.pRole ? `<span class="badge badge-purple" style="font-size:10px">⚡</span>` : ''}
        ${u.role ? `<span class="badge badge-indigo" style="font-size:10px">${_GOD_ROLES[u.role]||u.role}</span>` : ''}
        <button class="btn btn-ghost btn-sm" style="padding:2px 6px;font-size:10px"
          onclick="godMoveUserOrg('${u.id}','${u.email}','${u.orgId||''}')">
          <i class="fa-solid fa-right-left"></i>
        </button>
        <span style="font-size:10px;color:var(--tx-3)">${u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleDateString('es-ES') : '—'}</span>
      </div>
    </div>`;
  el.innerHTML = `
    <input type="search" placeholder="Buscar..." style="width:100%;margin-bottom:8px"
      oninput="_godFilterUsers(this.value)">
    <div id="god-users-list" class="list-items">
      ${real.length ? real.map(_userRow).join('') : '<div class="empty-state" style="padding:12px">Sin usuarios reales</div>'}
    </div>
    ${test.length ? `
    <details style="margin-top:12px">
      <summary style="font-size:12px;color:var(--tx-3);cursor:pointer;padding:6px 0">
        <i class="fa-solid fa-flask"></i> ${test.length} usuario${test.length!==1?'s':''} de test (ocultos)
      </summary>
      <div id="god-users-test" class="list-items" style="margin-top:6px;opacity:.6">${test.map(_userRow).join('')}</div>
    </details>` : ''}
  `;
}

function _godFilterUsers(q) {
  const term = q.toLowerCase();
  document.querySelectorAll('.god-user-row').forEach(row => {
    row.style.display = row.dataset.search.includes(term) ? '' : 'none';
  });
}

/* ── Panel God: lista de solicitudes de registro ── */
function _godRenderRequests(el) {
  const reqs = _GodState.reqs || [];

  /* Actualizar badge de cuenta */
  const badge = document.getElementById('god-req-badge');
  if (badge) {
    badge.style.display = reqs.length ? 'inline' : 'none';
    badge.textContent   = reqs.length;
  }

  if (!reqs.length) {
    el.innerHTML = `
      <div class="empty-state" style="padding:2rem 0">
        <i class="fa-solid fa-check-circle" style="font-size:2rem;color:var(--success);margin-bottom:0.75rem;display:block"></i>
        Sin solicitudes pendientes
      </div>`;
    return;
  }

  el.innerHTML = `
    <div class="list-items">
      ${reqs.map(r => `
        <div class="list-item" style="flex-direction:column;align-items:stretch;gap:10px;cursor:default">
          <div style="display:flex;align-items:flex-start;gap:10px">
            <div style="width:40px;height:40px;border-radius:50%;background:var(--indigo-dim);display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fa-solid fa-user" style="color:var(--indigo);font-size:16px"></i>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-weight:500;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${r.email}</div>
              <div style="font-size:12px;color:var(--tx-3)">${r.name || '—'} · Org: ${r.orgName}</div>
              <div style="font-size:11px;color:var(--tx-3);margin-top:2px">${new Date(r.createdAt).toLocaleString('es-ES')}</div>
            </div>
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-primary btn-sm" style="flex:1" onclick="_godApproveReq('${r.id}','${r.email.replace(/'/g,"\\'")}')">
              <i class="fa-solid fa-check"></i> Aprobar
            </button>
            <button class="btn btn-ghost btn-sm" style="flex:1;border-color:var(--danger-border);color:var(--danger)"
              onclick="_godRejectReq('${r.id}','${r.email.replace(/'/g,"\\'")}')">
              <i class="fa-solid fa-xmark"></i> Rechazar
            </button>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

async function _godApproveReq(id, email) {
  try {
    await API.post(`/platform/registrations/${id}/approve`, {});
    toast(`✓ ${email} aprobado`, 'success', 3000);
    /* Quitar de la lista local */
    _GodState.reqs = (_GodState.reqs || []).filter(r => r.id !== id);
    /* Invalidar caché de usuarios para que recargue */
    _GodState.users = null;
    _GodState.orgs  = null;
    const el = document.getElementById('god-content');
    if (el) _godRenderRequests(el);
  } catch(e) {
    toast('Error: ' + e.message, 'error', 4000);
  }
}

async function _godRejectReq(id, email) {
  /* Input de motivo inline en un confirm */
  confirm_(
    `Rechazar solicitud de ${email}.\nPuedes añadir un motivo (opcional):`,
    async (reason) => {
      try {
        await API.post(`/platform/registrations/${id}/reject`, { reason: reason || '' });
        toast(`Solicitud de ${email} rechazada`, 'info', 3000);
        _GodState.reqs = (_GodState.reqs || []).filter(r => r.id !== id);
        const el = document.getElementById('god-content');
        if (el) _godRenderRequests(el);
      } catch(e) {
        toast('Error: ' + e.message, 'error', 4000);
      }
    }
  );
}

/* Cargar badge de solicitudes al entrar al panel god */
async function _godLoadReqBadge() {
  try {
    const reqs = await API.get('/platform/registrations?status=pending');
    const badge = document.getElementById('god-req-badge');
    if (badge && reqs.length) {
      badge.style.display = 'inline';
      badge.textContent   = reqs.length;
    }
  } catch(e) {}
}

/* ══════════════════════════════════════════════════════════
   ASIGNACIÓN DE PDVs A MIEMBROS DEL EQUIPO
   ══════════════════════════════════════════════════════════ */
async function showAssignStopsModal(userId, userName) {
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.id = 'modal-assign-stops';
  ov.innerHTML = `
  <div class="modal" style="max-width:480px;max-height:90vh;display:flex;flex-direction:column" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header" style="flex-shrink:0">
      <div class="modal-title">
        <i class="fa-solid fa-map-pin"></i> PDVs de ${userName}
      </div>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div style="padding:0 var(--sp-4) 8px;flex-shrink:0">
      <input type="search" id="assign-stops-search" placeholder="Buscar PDV..."
        style="width:100%" oninput="_filterAssignStops(this.value)">
    </div>
    <div class="modal-body" style="overflow-y:auto;flex:1;padding-top:0" id="assign-stops-list">
      <div class="empty-state"><i class="fa-solid fa-spinner fa-spin"></i> Cargando…</div>
    </div>
    <div class="modal-footer" style="flex-shrink:0">
      <button class="btn btn-ghost" onclick="Overlay.pop()">Cancelar</button>
      <button class="btn btn-primary" onclick="_saveAssignStops('${userId}')">
        <i class="fa-solid fa-floppy-disk"></i> Guardar asignación
      </button>
    </div>
  </div>`;
  Overlay.push(ov);

  /* Cargar PDVs de la org y asignación actual del usuario */
  try {
    const [allStops, current] = await Promise.all([
      API.get('/stops'),
      API.get(`/users/${userId}/stops`),
    ]);
    const assigned = new Set(current.stopIds || []);
    window._assignStopsAll      = allStops;
    window._assignStopsAssigned = assigned;
    window._assignStopsUserId   = userId;
    _renderAssignStops(allStops, assigned);
  } catch(e) {
    document.getElementById('assign-stops-list').innerHTML =
      `<div class="empty-state" style="color:var(--danger)">Error: ${e.message}</div>`;
  }
}

function _renderAssignStops(stops, assigned) {
  const list = document.getElementById('assign-stops-list');
  if (!list) return;
  if (!stops.length) {
    list.innerHTML = `<div class="empty-state">Sin PDVs en la org</div>`;
    return;
  }
  /* Ordenar: asignados primero, luego alfabético */
  const sorted = [...stops].sort((a,b) => {
    const aA = assigned.has(a.id), bA = assigned.has(b.id);
    if (aA !== bA) return aA ? -1 : 1;
    return (a.name||'').localeCompare(b.name||'');
  });
  list.innerHTML = sorted.map(s => `
    <label class="settings-row assign-stop-row" data-search="${(s.name+' '+(s.town||'')+' '+(s.addr||'')).toLowerCase()}"
      style="cursor:pointer;user-select:none">
      <div class="settings-row-info">
        <div class="settings-row-title" style="font-size:13px">${s.name}</div>
        ${s.town ? `<div class="settings-row-sub">${s.town}${s.addr?` · ${s.addr}`:''}</div>` : ''}
      </div>
      <input type="checkbox" ${assigned.has(s.id)?'checked':''} value="${s.id}"
        onchange="_toggleAssignStop('${s.id}',this.checked)"
        style="width:18px;height:18px;accent-color:var(--indigo);flex-shrink:0">
    </label>`).join('');

  /* Contador */
  _updateAssignCount();
}

function _toggleAssignStop(stopId, checked) {
  if (!window._assignStopsAssigned) return;
  if (checked) window._assignStopsAssigned.add(stopId);
  else         window._assignStopsAssigned.delete(stopId);
  _updateAssignCount();
}

function _updateAssignCount() {
  const count = window._assignStopsAssigned?.size ?? 0;
  const btn   = document.querySelector('#modal-assign-stops .btn-primary');
  if (btn) btn.innerHTML = `<i class="fa-solid fa-floppy-disk"></i> Guardar (${count} PDVs)`;
}

function _filterAssignStops(q) {
  const term = q.toLowerCase();
  document.querySelectorAll('.assign-stop-row').forEach(row => {
    row.style.display = row.dataset.search.includes(term) ? '' : 'none';
  });
}

async function _saveAssignStops(userId) {
  const stopIds = [...(window._assignStopsAssigned || [])];
  try {
    const r = await API.patch(`/users/${userId}/stops`, { stopIds });
    Overlay.pop();
    toast(`${r.count} PDV${r.count!==1?'s':''} asignado${r.count!==1?'s':''} correctamente`, 'success', 3000);
    _loadTeam(); /* refrescar lista */
  } catch(e) {
    toast('Error al guardar: ' + e.message, 'error', 4000);
  }
}

/* ── Forzar sincronización completa desde el servidor ── */
async function forcePullSync() {
  if (!Auth.isLoggedIn()) { toast('Inicia sesión primero', 'error'); return; }
  toast('Sincronizando con el servidor…', 'info', 2000);
  try {
    /* Reset timestamp para forzar pull completo */
    State.prefs._lastSyncTs = 0;
    DB.set(DB.KEYS.prefs, State.prefs);
    /* Usar Sync.pull que ya tiene toda la lógica de merge */
    await Sync.pull({ silent: true });
    toast('Sincronización completada ✓', 'success', 3000);
    Router.go(Router._current || 'dashboard');
  } catch(e) {
    toast('Error: ' + e.message, 'error', 4000);
  }
}

/* ── God: mover usuario a otra organización ── */
async function godMoveUserOrg(userId, email, currentOrgId) {
  const orgs = _GodState.orgs || [];
  if (!orgs.length) { toast('Carga el panel God primero', 'error'); return; }

  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.id = 'modal-god-move';
  ov.innerHTML = `
  <div class="modal" style="max-width:360px" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title"><i class="fa-solid fa-right-left"></i> Mover usuario</div>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" style="display:flex;flex-direction:column;gap:var(--sp-3)">
      <div style="font-size:var(--t-sm);color:var(--tx-2)">${email}</div>
      <div>
        <label style="font-size:var(--t-xs);color:var(--tx-3);font-weight:500">Mover a organización</label>
        <select id="god-move-org" class="form-input" style="margin-top:4px">
          ${orgs.filter(o => o.id !== currentOrgId).map(o =>
            `<option value="${o.id}">${o.name}</option>`
          ).join('')}
        </select>
      </div>
      <div>
        <label style="font-size:var(--t-xs);color:var(--tx-3);font-weight:500">Rol en la nueva org</label>
        <select id="god-move-role" class="form-input" style="margin-top:4px">
          <option value="rep">Comercial</option>
          <option value="supervisor">Jefe de zona</option>
          <option value="admin">Director</option>
          <option value="owner">Propietario</option>
        </select>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost flex-1" onclick="Overlay.pop()">Cancelar</button>
      <button class="btn btn-primary" style="flex:2" onclick="_doGodMoveUser('${userId}')">Mover</button>
    </div>
  </div>`;
  Overlay.push(ov);
}

async function _doGodMoveUser(userId) {
  const orgId = document.getElementById('god-move-org')?.value;
  const role  = document.getElementById('god-move-role')?.value;
  if (!orgId || !role) return;
  try {
    await API.patch(`/users/${userId}/org`, { orgId, role });
    Overlay.pop();
    toast('Usuario movido correctamente', 'success');
    /* Recargar lista de usuarios del panel God */
    _GodState.users = null;
    Router.go('god');
  } catch(e) {
    toast(e.message || 'Error al mover usuario', 'error');
  }
}

/* ── Helpers selector de manager al invitar ── */
function _buildInviteManagerSelector(role) {
  const allMembers = _calAssignReps || [];
  const targetLevel = _ROLE_ORDER[role] ?? 0;
  const managers = allMembers.filter(m => (_ROLE_ORDER[m.role] ?? 0) > targetLevel);
  if (!managers.length) return '';
  /* Ordenar de menor a mayor rango — director antes que propietario */
  managers.sort((a, b) => (_ROLE_ORDER[a.role]??0) - (_ROLE_ORDER[b.role]??0));
  /* Preseleccionar el de rango inmediatamente superior */
  const defaultId = (managers.find(m => (_ROLE_ORDER[m.role]??0) === targetLevel + 1) || managers[0])?.id;
  return `<div class="form-group">
    <label class="form-label">Reporta a</label>
    <select id="invite-manager-select" class="form-input">
      ${managers.map(m =>
        `<option value="${m.id}" ${m.id === defaultId ? 'selected' : ''}>${m.name||m.email.split('@')[0]} · ${_ROLE_NAMES[m.role]||m.role}</option>`
      ).join('')}
    </select>
  </div>`;
}

function _updateInviteManagerSelector() {
  const role = document.getElementById('invite-role')?.value;
  const wrap = document.getElementById('invite-manager-wrap');
  if (!wrap) return;
  wrap.innerHTML = _buildInviteManagerSelector(role);
}

/* ══════════════════════════════════════════════════════════
   RESUMEN DE JORNADAS DEL EQUIPO — para supervisor / admin / owner
   ══════════════════════════════════════════════════════════ */

async function showTeamJornadas() {
  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.id = 'modal-team-jornadas';
  ov.innerHTML = `
  <div class="modal" style="max-width:520px;max-height:85vh;overflow-y:auto" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div class="modal-title"><i class="fa-solid fa-users"></i> Jornadas del equipo hoy</div>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div id="team-jornadas-body" class="modal-body" style="padding:0">
      <div style="text-align:center;padding:var(--sp-6);color:var(--tx-3)">
        <i class="fa-solid fa-spinner fa-spin" style="font-size:1.5rem"></i>
      </div>
    </div>
  </div>`;
  Overlay.push(ov);

  try {
    /* ?lite=1 evita N+1 queries por rep — solo necesitamos active_sessions */
    const data = await API.get('/stats/dashboard?period=today&lite=1');
    const body = document.getElementById('team-jornadas-body');
    if (!body) return;

    /* Unir active_sessions con team stats */
    const active = data.active_sessions || [];
    const team   = data.team || (data.supervisors || []).flatMap(s => s.team || []);
    const today  = _localDate(new Date());

    /* Si no hay datos directos de team, usar active_sessions */
    const rows = team.length
      ? team.map(rep => {
          const act = active.find(a => a.user_id === rep.id);
          return _teamJornadaRow(rep, act, today);
        })
      : active.map(a => {
          const rep = { id: a.user_id, name: a.user_name, email: a.user_id,
                        visits: a.visits_today || 0, sessions: 1, sessions_done: 0,
                        distance_km: parseFloat(a.distance_km || 0), elapsed_s: 0,
                        active_now: true, last_activity: null, unvisited: 0 };
          return _teamJornadaRow(rep, a, today);
        });

    if (!rows.length) {
      body.innerHTML = `<div style="text-align:center;padding:var(--sp-6);color:var(--tx-3)">Sin jornadas activas hoy</div>`;
      return;
    }

    body.innerHTML = rows.join('');
  } catch(e) {
    const body = document.getElementById('team-jornadas-body');
    if (body) body.innerHTML = `<div style="padding:var(--sp-4);color:var(--red)">Error cargando datos</div>`;
  }
}

function _teamJornadaRow(rep, activeSess, today) {
  const isActive  = rep.active_now || !!activeSess;
  const routeId   = activeSess?.route_id || null;
  const routeName = activeSess?.route_name || '—';
  const visits    = rep.visits || 0;

  /* Calcular paradas totales de la ruta */
  const route     = routeId ? State.getRoute(routeId) : null;
  const stopsTotal = route ? State.routeStats(route.id).total : '?';

  const h = Math.floor((rep.elapsed_s || 0) / 3600);
  const m = Math.floor(((rep.elapsed_s || 0) % 3600) / 60);
  const timeStr = rep.elapsed_s ? `${h}h ${m}m` : '—';

  const statusBadge = isActive
    ? '<span class="badge badge-green" style="font-size:10px">En jornada</span>'
    : rep.sessions_done
      ? '<span class="badge badge-muted" style="font-size:10px">Completada</span>'
      : '<span class="badge" style="font-size:10px;color:var(--tx-3)">Sin iniciar</span>';

  const mapBtn = routeId && activeSess
    ? `<button class="btn btn-ghost btn-sm" title="Ver en mapa"
        onclick="Overlay.pop();Router.go('map',{routeId:'${routeId}',dateStr:'${today}'})">
        <i class="fa-solid fa-map-location-dot"></i>
      </button>`
    : '';

  return `
  <div class="settings-row" style="align-items:flex-start;gap:var(--sp-3)">
    <div class="settings-row-info" style="flex:1">
      <div class="settings-row-title" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
        ${esc(rep.name || rep.email)}
        ${statusBadge}
      </div>
      <div class="settings-row-sub" style="margin-top:2px">
        ${routeName !== '—' ? `<span>${routeName}</span> · ` : ''}
        <span>${visits}/${stopsTotal} paradas</span> ·
        <span>${(rep.distance_km||0).toFixed(1)} km</span> ·
        <span>${timeStr}</span>
      </div>
      ${rep.unvisited ? `<div style="font-size:11px;color:var(--amber);margin-top:2px">
        <i class="fa-solid fa-triangle-exclamation"></i> ${rep.unvisited} PDVs sin visitar (30d)
      </div>` : ''}
    </div>
    <div style="display:flex;gap:4px;flex-shrink:0;align-items:center">
      ${mapBtn}
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════════════════
   PERFIL DE MIEMBRO — stats reales + PDVs + rutas
   ══════════════════════════════════════════════════════════ */

async function showMemberProfile(userId, name, role, email) {
  const ROLES = { rep:'Comercial', supervisor:'Jefe de zona', admin:'Director', owner:'Propietario' };
  const COLORS = { rep:'badge-green', supervisor:'badge-blue', admin:'badge-indigo', owner:'badge-purple' };

  const ov = document.createElement('div');
  ov.className = 'modal-backdrop open';
  ov.id = 'modal-member-profile';
  ov.innerHTML = `
  <div class="modal" style="max-width:480px;max-height:88vh;overflow-y:auto" onclick="event.stopPropagation()">
    <div class="modal-handle"></div>
    <div class="modal-header">
      <div>
        <div class="modal-title">${name}</div>
        <div style="display:flex;gap:6px;margin-top:4px">
          <span class="badge ${COLORS[role]||'badge-gray'}" style="font-size:10px">${ROLES[role]||role}</span>
          <span style="font-size:11px;color:var(--color-text-tertiary)">${email}</span>
        </div>
      </div>
      <button class="modal-close" onclick="Overlay.pop()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div id="member-profile-body" class="modal-body" style="display:flex;flex-direction:column;gap:var(--sp-4)">
      <div style="text-align:center;padding:var(--sp-4);color:var(--color-text-tertiary)">
        <i class="fa-solid fa-spinner fa-spin" style="font-size:1.5rem"></i>
      </div>
    </div>
  </div>`;
  Overlay.push(ov);

  try {
    /* Cargar stats en paralelo: semana y PDVs */
    const [weekData, stopsData] = await Promise.all([
      API.get(`/stats/dashboard?period=week&userId=${userId}`),
      API.get(`/users/${userId}/stops`).catch(() => ({ stopIds: [] })),
    ]);

    const body = document.getElementById('member-profile-body');
    if (!body) return;

    const kpis    = weekData?.kpis || {};
    const sessions = weekData?.sessions || [];
    const stopIds = stopsData?.stopIds || [];
    const stops   = stopIds.map(id => State.getStop(id)).filter(Boolean);

    /* KPIs semana */
    const finishedSess = sessions.filter(s => s.state === 'finished').length;
    const totalDist    = sessions.reduce((a,s) => a + parseFloat(s.distance_km||0), 0).toFixed(1);
    const totalH       = Math.floor(sessions.reduce((a,s) => a + parseInt(s.elapsed_s||0), 0) / 3600);

    /* Rutas asignadas a este rep */
    const repRoutes = State.routes.filter(r =>
      Object.values(State.scheduleAll || {}).some(dayReps =>
        dayReps.some && dayReps.some(x => x.assignedTo === userId && x.routeId === r.id)
      )
    );

    body.innerHTML = `
    <!-- KPIs esta semana -->
    <div>
      <div style="font-size:var(--t-xs);font-weight:500;color:var(--color-text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">Esta semana</div>
      <div class="grid-4" style="gap:6px">
        <div class="stat-card accent-blue" style="padding:10px">
          <div class="stat-card-value" style="font-size:1.4rem">${kpis.total_visits ?? '—'}</div>
          <div class="stat-card-label">Visitas</div>
        </div>
        <div class="stat-card accent-green" style="padding:10px">
          <div class="stat-card-value" style="font-size:1.4rem">${finishedSess}/${sessions.length}</div>
          <div class="stat-card-label">Jornadas</div>
        </div>
        <div class="stat-card" style="padding:10px">
          <div class="stat-card-value" style="font-size:1.4rem">${totalDist}</div>
          <div class="stat-card-label">km</div>
        </div>
        <div class="stat-card" style="padding:10px">
          <div class="stat-card-value" style="font-size:1.4rem">${totalH}h</div>
          <div class="stat-card-label">Tiempo</div>
        </div>
      </div>
      ${kpis.coverage_pct != null ? `
      <div style="margin-top:8px;display:flex;align-items:center;gap:8px">
        <div style="flex:1;height:6px;background:var(--color-background-secondary);border-radius:3px;overflow:hidden">
          <div style="width:${Math.min(100,kpis.coverage_pct)}%;height:100%;background:var(--indigo);border-radius:3px"></div>
        </div>
        <span style="font-size:11px;color:var(--color-text-secondary);white-space:nowrap">${kpis.coverage_pct}% cobertura</span>
      </div>` : ''}
      ${kpis.unvisited_stops > 0 ? `
      <div style="margin-top:6px;font-size:11px;color:var(--amber)">
        <i class="fa-solid fa-triangle-exclamation"></i> ${kpis.unvisited_stops} PDVs sin visitar en 30 días
      </div>` : ''}
    </div>

    <!-- PDVs asignados -->
    <div>
      <div style="font-size:var(--t-xs);font-weight:500;color:var(--color-text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">
        PDVs asignados (${stops.length})
        ${State.prefs._role !== 'rep' ? `<button class="btn btn-ghost btn-sm" style="padding:1px 6px;font-size:10px;margin-left:6px"
          onclick="showAssignStopsModal('${userId}','${name.replace(/'/g,"\\'")}')">
          <i class="fa-solid fa-pen"></i> Editar
        </button>` : ''}
      </div>
      ${stops.length === 0
        ? `<div style="color:var(--color-text-tertiary);font-size:var(--t-sm)">Sin PDVs asignados</div>`
        : `<div style="display:flex;flex-direction:column;gap:4px;max-height:140px;overflow-y:auto">
            ${stops.slice(0,20).map(s => `
              <div style="display:flex;align-items:center;gap:6px;font-size:var(--t-sm)">
                <i class="fa-solid fa-map-pin" style="font-size:10px;color:var(--indigo)"></i>
                <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${s.name}</span>
                ${s.town ? `<span style="font-size:10px;color:var(--color-text-tertiary)">${s.town}</span>` : ''}
              </div>`).join('')}
            ${stops.length > 20 ? `<div style="font-size:10px;color:var(--color-text-tertiary)">+${stops.length-20} más</div>` : ''}
          </div>`}
    </div>

    <!-- Acciones -->
    <div style="display:flex;gap:var(--sp-2);flex-wrap:wrap;border-top:1px solid var(--color-border-tertiary);padding-top:var(--sp-3)">
      <button class="btn btn-ghost btn-sm" onclick="Overlay.pop();showTeamJornadas()">
        <i class="fa-solid fa-calendar-check"></i> Ver jornadas
      </button>
      ${State.prefs._role !== 'rep' ? `
      <button class="btn btn-ghost btn-sm"
        onclick="showChangeRoleModal('${userId}','${role}','${name.replace(/'/g,"\\'")}','')">
        <i class="fa-solid fa-pen"></i> Cambiar rol
      </button>` : ''}
    </div>`;

  } catch(e) {
    const body = document.getElementById('member-profile-body');
    if (body) body.innerHTML = `<div style="color:var(--color-text-tertiary);padding:var(--sp-4)">Error cargando perfil</div>`;
  }
}

/* ── Resumen de jornadas recientes para rep (debajo del calendario) ── */
function _renderCalJornadaSummary() {
  const jornadas = typeof _loadJornadas === 'function' ? _loadJornadas() : {};
  const entries = Object.entries(jornadas)
    .filter(([,s]) => s.state === 'finished' || s.elapsed > 0)
    .sort((a,b) => b[0].localeCompare(a[0]))
    .slice(0, 5);

  if (!entries.length) return '';

  const rows = entries.map(([key, s]) => {
    const parts = key.split('_');
    const rId   = parts[0];
    const dStr  = parts[parts.length - 1];
    const route = State.getRoute(rId);
    if (!route) return '';

    const d    = new Date(dStr + 'T12:00');
    const day  = d.getDate();
    const mon  = d.toLocaleDateString('es-ES', { month: 'short' });
    const h    = Math.floor((s.elapsed||0) / 3600);
    const m    = Math.floor(((s.elapsed||0) % 3600) / 60);
    const km   = (s.distance||0).toFixed(1);
    const done = s.state === 'finished';

    const visits = typeof _loadVisits === 'function'
      ? Object.keys(_loadVisits()).filter(k => k.startsWith(rId + '_' + dStr + '_')).length
      : 0;
    const total = State.routeStats(rId).total || 0;

    return `
    <div class="list-item" onclick="Router.go('jornada',{routeId:'${rId}',dateStr:'${dStr}'})">
      <div style="width:36px;text-align:center;flex-shrink:0">
        <div style="font-size:1rem;font-weight:700;color:var(--indigo);line-height:1">${day}</div>
        <div style="font-size:10px;color:var(--tx-3);text-transform:uppercase">${mon}</div>
      </div>
      <div class="list-item-info">
        <div class="list-item-name">${esc(route.name)}</div>
        <div class="list-item-sub">${visits}/${total} paradas · ${h}h ${m}m · ${km} km</div>
      </div>
      <span class="badge ${done ? 'badge-green' : 'badge-muted'}">${done ? 'Completa' : 'En curso'}</span>
    </div>`;
  }).filter(Boolean);

  if (!rows.length) return '';

  return `
  <div class="card" style="margin-top:var(--sp-4)">
    <div class="card-header">
      <div class="card-title"><i class="fa-solid fa-calendar-check"></i> Mis jornadas recientes</div>
      <button class="btn btn-ghost btn-sm" onclick="Router.go('reports')">
        Ver todas
      </button>
    </div>
    <div>${rows.join('')}</div>
  </div>`;
}
