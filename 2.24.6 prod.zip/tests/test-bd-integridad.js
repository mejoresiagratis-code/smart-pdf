/**
 * TEST 3 — INTEGRIDAD DE BASE DE DATOS
 * ======================================
 * Queries de verificación directa sobre MariaDB:
 *   A. schedules sin duplicados (misma org+route+user+date)
 *   B. rutas sin created_by null (activas y no archivadas)
 *   C. memberships con jerarquía coherente (manager existe y es de nivel superior)
 *   D. schedules con assigned_to que no pertenece a la org
 *   E. routes con stop_ids que referencian stops inexistentes o de otra org
 *   F. memberships huérfanos (user_id o org_id inexistentes)
 *
 * Ejecución:
 *   node test-bd-integridad.js
 *
 * Requiere variables de entorno:
 *   DB_HOST, DB_PORT, DB_USER, DB_PASS, DB_NAME
 * o un fichero .env con esas claves.
 *
 * Alternativa: copiar las queries al phpMyAdmin y ejecutarlas manualmente.
 * Un resultado vacío (0 filas) = ✅ sin problemas.
 */

/* ── Config ── */
require('dotenv').config();   // opcional — si usas dotenv

const DB_CONFIG = {
  host:     process.env.DB_HOST || 'localhost',
  port:     parseInt(process.env.DB_PORT || '3306'),
  user:     process.env.DB_USER || 'cqvkelal_gestorrutas',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'cqvkelal_gestorrutas',
};

/* ══════════════════════════════════════════════════════════
   QUERIES DE INTEGRIDAD
   Cada entrada: { id, title, description, sql, expectEmpty }
   expectEmpty=true → 0 filas es "todo OK"
   ══════════════════════════════════════════════════════════ */
const CHECKS = [

  /* ─────────────────────────────────────────────────────────
     A. Schedules duplicados
     (mismo org + route + assigned_to + date → solo debe existir 1)
     ───────────────────────────────────────────────────────── */
  {
    id:          'A',
    title:       'Schedules duplicados (org+route+user+date)',
    description: 'Un rep no puede tener dos asignaciones a la misma ruta el mismo día',
    expectEmpty: true,
    sql: `
      SELECT
        org_id,
        route_id,
        assigned_to,
        date,
        COUNT(*) AS cnt,
        GROUP_CONCAT(id ORDER BY created_at SEPARATOR ', ') AS ids
      FROM schedules
      GROUP BY org_id, route_id, assigned_to, date
      HAVING cnt > 1
      ORDER BY cnt DESC;
    `,
  },

  /* ─────────────────────────────────────────────────────────
     A2. Un rep con dos rutas diferentes el mismo día
     (negocialmente puede ser válido, pero avisa)
     ───────────────────────────────────────────────────────── */
  {
    id:          'A2',
    title:       'Reps con más de una ruta asignada el mismo día',
    description: 'Posible conflicto de agenda — revisar si es intencionado',
    expectEmpty: false,   // solo informativo
    sql: `
      SELECT
        s.org_id,
        s.assigned_to,
        u.email,
        s.date,
        COUNT(DISTINCT s.route_id) AS rutas_ese_dia,
        GROUP_CONCAT(s.route_id SEPARATOR ', ') AS route_ids
      FROM schedules s
      LEFT JOIN users u ON u.id = s.assigned_to
      GROUP BY s.org_id, s.assigned_to, s.date
      HAVING rutas_ese_dia > 1
      ORDER BY s.date;
    `,
  },

  /* ─────────────────────────────────────────────────────────
     B. Rutas activas sin created_by
     ───────────────────────────────────────────────────────── */
  {
    id:          'B',
    title:       'Rutas activas con created_by NULL',
    description: 'Toda ruta activa debería tener trazabilidad de quién la creó',
    expectEmpty: true,
    sql: `
      SELECT id, org_id, name, created_at, updated_at
      FROM routes
      WHERE deleted = 0
        AND archived_at IS NULL
        AND created_by IS NULL
      ORDER BY created_at DESC;
    `,
  },

  /* ─────────────────────────────────────────────────────────
     B2. Rutas con stop_ids vacío que están activas en schedules
     ───────────────────────────────────────────────────────── */
  {
    id:          'B2',
    title:       'Rutas activas en schedules futuros pero con stop_ids vacío',
    description: 'Un rep tendría una jornada sin paradas que visitar',
    expectEmpty: true,
    sql: `
      SELECT
        r.id   AS route_id,
        r.name AS route_name,
        r.stop_ids,
        s.date,
        s.assigned_to,
        u.email
      FROM routes r
      INNER JOIN schedules s ON s.route_id = r.id
      LEFT JOIN  users u     ON u.id = s.assigned_to
      WHERE r.deleted = 0
        AND s.date >= CURDATE()
        AND (r.stop_ids IS NULL OR r.stop_ids = '[]' OR r.stop_ids = '')
      ORDER BY s.date;
    `,
  },

  /* ─────────────────────────────────────────────────────────
     C. Memberships con jerarquía incoherente
     (manager_id debe existir en memberships con un rol superior)
     ───────────────────────────────────────────────────────── */
  {
    id:          'C',
    title:       'Memberships con manager inexistente en la misma org',
    description: 'El manager_id debe apuntar a un membership activo de la misma org',
    expectEmpty: true,
    sql: `
      SELECT
        m.id,
        m.org_id,
        m.user_id,
        u.email AS user_email,
        m.role,
        m.manager_id
      FROM memberships m
      LEFT JOIN users u ON u.id = m.user_id
      WHERE m.manager_id IS NOT NULL
        AND m.active = 1
        AND NOT EXISTS (
          SELECT 1 FROM memberships mgr
          WHERE mgr.user_id = m.manager_id
            AND mgr.org_id  = m.org_id
            AND mgr.active  = 1
        )
      ORDER BY m.org_id;
    `,
  },

  /* ─────────────────────────────────────────────────────────
     C2. Memberships con manager de nivel igual o inferior
     Orden jerárquico: rep=0, supervisor=1, admin=2, owner=3
     ───────────────────────────────────────────────────────── */
  {
    id:          'C2',
    title:       'Memberships con manager de rol no superior',
    description: 'Un rep no puede tener como manager a otro rep',
    expectEmpty: true,
    sql: `
      SELECT
        m.id,
        m.org_id,
        m.user_id,
        ue.email  AS employee_email,
        m.role    AS employee_role,
        m.manager_id,
        um.email  AS manager_email,
        mgr.role  AS manager_role
      FROM memberships m
      JOIN memberships mgr ON mgr.user_id = m.manager_id AND mgr.org_id = m.org_id AND mgr.active = 1
      JOIN users ue  ON ue.id = m.user_id
      JOIN users um  ON um.id = m.manager_id
      WHERE m.active = 1
        AND m.manager_id IS NOT NULL
        AND FIELD(mgr.role, 'rep', 'supervisor', 'admin', 'owner')
            <= FIELD(m.role,  'rep', 'supervisor', 'admin', 'owner')
      ORDER BY m.org_id;
    `,
  },

  /* ─────────────────────────────────────────────────────────
     D. Schedules con assigned_to que no es miembro activo de la org
     ───────────────────────────────────────────────────────── */
  {
    id:          'D',
    title:       'Schedules asignados a usuarios sin membership activo',
    description: 'No puede haber agenda para alguien que ya no pertenece a la org',
    expectEmpty: true,
    sql: `
      SELECT
        s.id       AS schedule_id,
        s.org_id,
        s.route_id,
        s.assigned_to,
        u.email    AS user_email,
        s.date
      FROM schedules s
      LEFT JOIN users u ON u.id = s.assigned_to
      WHERE s.assigned_to IS NOT NULL
        AND NOT EXISTS (
          SELECT 1 FROM memberships m
          WHERE m.user_id = s.assigned_to
            AND m.org_id  = s.org_id
            AND m.active  = 1
        )
      ORDER BY s.date;
    `,
  },

  /* ─────────────────────────────────────────────────────────
     E. Memberships huérfanos (user o org inexistentes)
     ───────────────────────────────────────────────────────── */
  {
    id:          'E',
    title:       'Memberships con user_id o org_id inexistente',
    description: 'FKs lógicas — MariaDB no tiene FK por diseño en hosting compartido',
    expectEmpty: true,
    sql: `
      SELECT
        m.id,
        m.org_id,
        m.user_id,
        m.role,
        CASE WHEN u.id IS NULL  THEN 'USER_NOT_FOUND'  ELSE 'ok' END AS user_status,
        CASE WHEN o.id IS NULL  THEN 'ORG_NOT_FOUND'   ELSE 'ok' END AS org_status
      FROM memberships m
      LEFT JOIN users         u ON u.id = m.user_id
      LEFT JOIN organizations o ON o.id = m.org_id
      WHERE u.id IS NULL OR o.id IS NULL;
    `,
  },

  /* ─────────────────────────────────────────────────────────
     F. Schedules con route_id inexistente
     ───────────────────────────────────────────────────────── */
  {
    id:          'F',
    title:       'Schedules con route_id inexistente',
    description: 'La ruta asignada debe existir en la tabla routes',
    expectEmpty: true,
    sql: `
      SELECT
        s.id       AS schedule_id,
        s.org_id,
        s.route_id,
        s.assigned_to,
        s.date
      FROM schedules s
      LEFT JOIN routes r ON r.id = s.route_id AND r.org_id = s.org_id
      WHERE r.id IS NULL
      ORDER BY s.date;
    `,
  },

  /* ─────────────────────────────────────────────────────────
     G. Orgs sin owner activo
     ───────────────────────────────────────────────────────── */
  {
    id:          'G',
    title:       'Organizaciones sin owner activo',
    description: 'Toda org debe tener al menos un owner',
    expectEmpty: true,
    sql: `
      SELECT
        o.id   AS org_id,
        o.name AS org_name
      FROM organizations o
      WHERE NOT EXISTS (
        SELECT 1 FROM memberships m
        WHERE m.org_id = o.id
          AND m.role   = 'owner'
          AND m.active = 1
      )
      ORDER BY o.name;
    `,
  },
];

/* ══════════════════════════════════════════════════════════
   RUNNER
   ══════════════════════════════════════════════════════════ */
async function runIntegrityChecks() {
  let mysql2;
  try {
    mysql2 = require('mysql2/promise');
  } catch {
    console.error('mysql2 no instalado. Ejecuta: npm install mysql2');
    console.log('\n──────────────────────────────────────────');
    console.log('ALTERNATIVA: copia y pega estas queries en phpMyAdmin');
    console.log('Un resultado vacío (0 filas) = ✅ sin problemas\n');
    CHECKS.forEach(c => {
      console.log(`\n/* CHECK ${c.id} — ${c.title} */`);
      console.log(`/* ${c.description} */`);
      console.log(c.sql.trim());
    });
    return;
  }

  let conn;
  try {
    conn = await mysql2.createConnection(DB_CONFIG);
    console.log(`\nConectado a ${DB_CONFIG.host}:${DB_CONFIG.port}/${DB_CONFIG.database}\n`);
  } catch (e) {
    console.error('No se pudo conectar a la BD:', e.message);
    console.log('\nSi no hay acceso directo, usa las queries SQL en phpMyAdmin:');
    CHECKS.forEach(c => {
      console.log(`\n/* CHECK ${c.id} — ${c.title} */`);
      console.log(c.sql.trim());
    });
    process.exit(1);
  }

  console.log('═══════════════════════════════════════════');
  console.log('TEST 3 — INTEGRIDAD DE BASE DE DATOS');
  console.log('═══════════════════════════════════════════\n');

  let passed = 0;
  let warnings = 0;
  let failed = 0;

  for (const check of CHECKS) {
    try {
      const [rows] = await conn.query(check.sql);
      const count  = rows.length;

      if (check.expectEmpty) {
        if (count === 0) {
          console.log(`  ✅ [${check.id}] ${check.title} — 0 problemas`);
          passed++;
        } else {
          console.error(`  ❌ [${check.id}] ${check.title} — ${count} filas problemáticas`);
          console.table(rows.slice(0, 10));
          if (count > 10) console.log(`  ... (${count - 10} más)`);
          failed++;
        }
      } else {
        // Solo informativo
        if (count === 0) {
          console.log(`  ℹ️  [${check.id}] ${check.title} — 0 casos`);
        } else {
          console.warn(`  ⚠️  [${check.id}] ${check.title} — ${count} casos (revisar)`);
          console.table(rows.slice(0, 5));
          warnings++;
        }
      }
    } catch (e) {
      console.error(`  💥 [${check.id}] ${check.title} — ERROR SQL: ${e.message}`);
      failed++;
    }
  }

  await conn.end();

  console.log('\n═══════════════════════════════════════════');
  console.log(`RESULTADO: ${passed} OK, ${warnings} advertencias, ${failed} fallos`);
  console.log('═══════════════════════════════════════════\n');

  process.exit(failed > 0 ? 1 : 0);
}

/* ── Si se llama directamente, también imprime las queries como referencia ── */
if (require.main === module) {
  console.log('\n── Queries SQL de referencia (para phpMyAdmin) ──\n');
  CHECKS.forEach(c => {
    console.log(`-- CHECK ${c.id}: ${c.title}`);
    console.log(`-- ${c.description}`);
    console.log(c.sql.trim());
    console.log('');
  });
  console.log('─────────────────────────────────────────────\n');

  runIntegrityChecks();
}

module.exports = { CHECKS, runIntegrityChecks };
