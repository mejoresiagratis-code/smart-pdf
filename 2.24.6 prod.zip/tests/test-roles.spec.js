/**
 * TEST 1 — ROLES CON PLAYWRIGHT
 * ==============================
 * Verifica que cada rol (rep, supervisor, admin, owner) ve los botones correctos
 * y que las llamadas a la API devuelven 200 o 403 según corresponda.
 *
 * Usuarios reales de la BD (org: eec84ae0-4b54-454f-8ccd-e3fb6a4d10ab):
 *   rep        → comercial.test@gestor.dev
 *   supervisor → supervisor.test@gestor.dev
 *   admin      → pabl3st@gmail.com
 *   owner      → caudete2003@gmail.com
 *
 * Ajusta BASE_URL y las contraseñas antes de ejecutar.
 * Ejecución: npx playwright test test-roles.spec.js
 */

const { test, expect } = require('@playwright/test');

const BASE_URL = process.env.BASE_URL || 'https://cqvkelal.cloud.cuentica.com/gestor-rutas-web';
const API_URL  = `${BASE_URL}/api`;

/* ── Credenciales de test ── */
const USERS = {
  rep: {
    email:    'comercial.test@gestor.dev',
    password: process.env.PASS_REP || 'Test1234!',
    id:       '6a0f7929-e055-44d2-a21d-c409e5a1f6c1',
  },
  supervisor: {
    email:    'supervisor.test@gestor.dev',
    password: process.env.PASS_SUPERVISOR || 'Test1234!',
    id:       '3da4c598-3f49-47c3-91de-6bb7900ccb65',
  },
  admin: {
    email:    'pabl3st@gmail.com',
    password: process.env.PASS_ADMIN || 'Test1234!',
    id:       'ee4150c1-da6d-423e-a69e-fcd7135d5fe0',
  },
  owner: {
    email:    'caudete2003@gmail.com',
    password: process.env.PASS_OWNER || 'Test1234!',
    id:       'e17bcf40-facb-4be7-a9e2-d88b05245052',
  },
};

/* ── Helper: login y obtener access_token vía API ── */
async function apiLogin(email, password) {
  const resp = await fetch(`${API_URL}/auth/login`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ email, password }),
  });
  if (!resp.ok) throw new Error(`Login fallido para ${email}: ${resp.status}`);
  const data = await resp.json();
  return data.access_token;
}

/* ── Helper: llamada autenticada a la API ── */
async function apiCall(token, method, path, body = null) {
  const opts = {
    method,
    headers: {
      'Content-Type':  'application/json',
      'Authorization': `Bearer ${token}`,
    },
  };
  if (body) opts.body = JSON.stringify(body);
  return fetch(`${API_URL}${path}`, opts);
}

/* ── Helper: login en la UI con Playwright ── */
async function uiLogin(page, email, password) {
  await page.goto(`${BASE_URL}/`);
  await page.waitForLoadState('networkidle');

  // El app es una SPA — busca el formulario de login
  await page.fill('input[type="email"], input[name="email"]', email);
  await page.fill('input[type="password"], input[name="password"]', password);
  await page.click('button[type="submit"], .btn-login, button:has-text("Entrar")');
  await page.waitForLoadState('networkidle');
  await page.waitForTimeout(1500); // esperar animaciones SPA
}

/* ══════════════════════════════════════════════════════════
   BLOQUE A — Controles de UI según rol
   ══════════════════════════════════════════════════════════ */

test.describe('UI — visibilidad de controles por rol', () => {

  test('rep: NO ve botones de gestión (crear ruta, invitar, agenda global)', async ({ page }) => {
    await uiLogin(page, USERS.rep.email, USERS.rep.password);

    // El rep NO debe ver el botón de crear ruta
    await expect(page.locator('[data-action="create-route"], .btn-create-route, button:has-text("Nueva ruta")')).toHaveCount(0);

    // El rep NO debe ver "Invitar usuario"
    await expect(page.locator('[data-action="invite-user"], button:has-text("Invitar")')).toHaveCount(0);

    // El rep SÍ debe ver su agenda / jornada
    await expect(page.locator('.agenda, .jornada, [data-view="schedule"], nav a:has-text("Jornada")')).toBeVisible();
  });

  test('supervisor: ve agenda de equipo pero NO puede crear rutas', async ({ page }) => {
    await uiLogin(page, USERS.supervisor.email, USERS.supervisor.password);

    // Ve la sección de rutas (lectura)
    await expect(page.locator('nav a:has-text("Rutas"), .nav-routes')).toBeVisible();

    // No puede crear rutas (solo admin/owner)
    await expect(page.locator('[data-action="create-route"], button:has-text("Nueva ruta")')).toHaveCount(0);
  });

  test('admin: ve gestión de rutas y usuarios, pero NO panel de platform', async ({ page }) => {
    await uiLogin(page, USERS.admin.email, USERS.admin.password);

    // Ve la sección de gestión
    await expect(page.locator('nav a:has-text("Gestión"), nav a:has-text("Rutas"), .nav-admin')).toBeVisible();

    // NO ve el panel de plataforma (solo god/platform_admin)
    await expect(page.locator('nav a:has-text("Platform"), [data-view="platform"]')).toHaveCount(0);
  });

  test('owner: ve todo incluyendo configuración de organización', async ({ page }) => {
    await uiLogin(page, USERS.owner.email, USERS.owner.password);

    // Owner ve ajustes de organización
    await expect(page.locator('nav a:has-text("Config"), nav a:has-text("Ajustes"), [data-view="settings"]')).toBeVisible();
  });
});

/* ══════════════════════════════════════════════════════════
   BLOQUE B — Permisos de API según rol
   ══════════════════════════════════════════════════════════ */

test.describe('API — códigos HTTP según rol', () => {

  /* ── rep ── */
  test.describe('rol rep', () => {
    let token;
    test.beforeAll(async () => {
      token = await apiLogin(USERS.rep.email, USERS.rep.password);
    });

    test('GET /sync/pull → 200', async () => {
      const r = await apiCall(token, 'GET', '/sync/pull?since=0');
      expect(r.status).toBe(200);
    });

    test('POST /routes → 403', async () => {
      const r = await apiCall(token, 'POST', '/routes', { name: 'Test' });
      expect(r.status).toBe(403);
    });

    test('POST /users/invite → 403', async () => {
      const r = await apiCall(token, 'POST', '/users/invite', { email: 'x@y.com', role: 'rep' });
      expect(r.status).toBe(403);
    });

    test('POST /schedule → 403', async () => {
      const r = await apiCall(token, 'POST', '/schedule', { routeId: 'R1', userId: USERS.rep.id, date: '2026-03-25' });
      expect(r.status).toBe(403);
    });

    test('GET /platform/stats → 403', async () => {
      const r = await apiCall(token, 'GET', '/platform/stats');
      expect(r.status).toBe(403);
    });
  });

  /* ── supervisor ── */
  test.describe('rol supervisor', () => {
    let token;
    test.beforeAll(async () => {
      token = await apiLogin(USERS.supervisor.email, USERS.supervisor.password);
    });

    test('GET /sync/pull → 200', async () => {
      const r = await apiCall(token, 'GET', '/sync/pull?since=0');
      expect(r.status).toBe(200);
    });

    test('GET /schedule → 200 (ve agenda de equipo)', async () => {
      const r = await apiCall(token, 'GET', '/schedule');
      expect(r.status).toBe(200);
    });

    test('POST /routes → 403 (no puede crear rutas)', async () => {
      const r = await apiCall(token, 'POST', '/routes', { name: 'Test' });
      expect(r.status).toBe(403);
    });

    test('POST /users/invite → 403', async () => {
      const r = await apiCall(token, 'POST', '/users/invite', { email: 'x@y.com', role: 'rep' });
      expect(r.status).toBe(403);
    });

    test('GET /platform/stats → 403', async () => {
      const r = await apiCall(token, 'GET', '/platform/stats');
      expect(r.status).toBe(403);
    });
  });

  /* ── admin ── */
  test.describe('rol admin', () => {
    let token;
    test.beforeAll(async () => {
      token = await apiLogin(USERS.admin.email, USERS.admin.password);
    });

    test('GET /sync/pull → 200', async () => {
      const r = await apiCall(token, 'GET', '/sync/pull?since=0');
      expect(r.status).toBe(200);
    });

    test('GET /routes → 200', async () => {
      const r = await apiCall(token, 'GET', '/routes');
      expect(r.status).toBe(200);
    });

    test('POST /schedule → 200 (puede asignar agenda)', async () => {
      // Usa una fecha futura para no pisar datos reales
      const r = await apiCall(token, 'POST', '/schedule', {
        routeId:    'R1774056182732',
        userId:     USERS.rep.id,
        date:       '2099-12-01',
      });
      // 200 o 201 es OK; 400 por conflicto también indica que llegó al controlador
      expect([200, 201, 400]).toContain(r.status);
    });

    test('GET /platform/stats → 403 (solo god/platform_admin)', async () => {
      const r = await apiCall(token, 'GET', '/platform/stats');
      expect(r.status).toBe(403);
    });
  });

  /* ── owner ── */
  test.describe('rol owner', () => {
    let token;
    test.beforeAll(async () => {
      token = await apiLogin(USERS.owner.email, USERS.owner.password);
    });

    test('GET /sync/pull → 200', async () => {
      const r = await apiCall(token, 'GET', '/sync/pull?since=0');
      expect(r.status).toBe(200);
    });

    test('POST /routes → 201 o 200 (owner puede crear rutas)', async () => {
      const r = await apiCall(token, 'POST', '/routes', { name: `__test_${Date.now()}` });
      expect([200, 201]).toContain(r.status);
      // Cleanup: borrar la ruta creada
      if (r.ok) {
        const body = await r.json();
        const routeId = body.id || body.route?.id;
        if (routeId) await apiCall(token, 'DELETE', `/routes/${routeId}`);
      }
    });

    test('GET /platform/stats → 403 (platform solo para god)', async () => {
      const r = await apiCall(token, 'GET', '/platform/stats');
      expect(r.status).toBe(403);
    });
  });

  /* ── Sin token ── */
  test.describe('sin autenticación', () => {
    test('GET /sync/pull sin token → 401', async () => {
      const r = await fetch(`${API_URL}/sync/pull?since=0`);
      expect(r.status).toBe(401);
    });

    test('GET /routes sin token → 401', async () => {
      const r = await fetch(`${API_URL}/routes`);
      expect(r.status).toBe(401);
    });
  });
});
