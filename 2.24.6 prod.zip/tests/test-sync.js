/**
 * TEST 2 — SYNC: ruta asignada → paradas en el pull del rep
 * ===========================================================
 * Escenario que reproduce el bug principal de la sesión anterior:
 *   1. Admin asigna la ruta R1774056182732 (stop: IMP0337930) al rep para mañana
 *   2. Rep hace GET /sync/pull?since=0
 *   3. El delta DEBE incluir esa ruta y ese stop
 *
 * Es un test de integración puro (Node.js + fetch), sin navegador.
 * Ejecución: node test-sync.js
 *            — o —
 *            npx jest test-sync.js   (si usas Jest)
 */

const BASE_URL = process.env.BASE_URL || 'https://cqvkelal.cloud.cuentica.com/gestor-rutas-web';
const API_URL  = `${BASE_URL}/api`;

/* Datos reales de la BD */
const CREDS = {
  admin: { email: 'pabl3st@gmail.com',            password: process.env.PASS_ADMIN      || 'Test1234!' },
  rep:   { email: 'comercial.test@gestor.dev',     password: process.env.PASS_REP        || 'Test1234!' },
};

const ROUTE_CENTRO = 'R1774056182732';   // ruta "1" con stop IMP0337930
const STOP_EXPECTED = 'IMP0337930';
const REP_ID = '6a0f7929-e055-44d2-a21d-c409e5a1f6c1';

/* ── helpers ── */
async function login(email, password) {
  const r = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  if (!r.ok) {
    const txt = await r.text();
    throw new Error(`Login fallido (${r.status}): ${txt}`);
  }
  return (await r.json()).access_token;
}

async function api(token, method, path, body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
  };
  if (body) opts.body = JSON.stringify(body);
  const r = await fetch(`${API_URL}${path}`, opts);
  return r;
}

function tomorrow() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

/* ── test runner minimalista ── */
let passed = 0;
let failed = 0;
const errors = [];

function assert(condition, msg) {
  if (condition) {
    console.log(`  ✅ ${msg}`);
    passed++;
  } else {
    console.error(`  ❌ FAIL: ${msg}`);
    failed++;
    errors.push(msg);
  }
}

/* ══════════════════════════════════════════════════════════
   SUITE PRINCIPAL
   ══════════════════════════════════════════════════════════ */
async function runSyncTests() {
  console.log('\n═══════════════════════════════════════════');
  console.log('TEST 2 — SYNC: ruta asignada → paradas en pull');
  console.log('═══════════════════════════════════════════\n');

  /* ── Paso 0: login ── */
  console.log('[ Paso 0 ] Login admin y rep...');
  let adminToken, repToken;
  try {
    adminToken = await login(CREDS.admin.email, CREDS.admin.password);
    repToken   = await login(CREDS.rep.email,   CREDS.rep.password);
    assert(!!adminToken, 'Admin obtiene access_token');
    assert(!!repToken,   'Rep obtiene access_token');
  } catch (e) {
    console.error('Login fallido — abortando:', e.message);
    process.exit(1);
  }

  /* ── Paso 1: pull ANTES de asignar (baseline) ── */
  console.log('\n[ Paso 1 ] Pull baseline del rep (since=0)...');
  const pullBefore = await api(repToken, 'GET', '/sync/pull?since=0');
  assert(pullBefore.status === 200, 'GET /sync/pull → 200');
  const deltaBefore = await pullBefore.json();

  const routesBefore = Object.keys(deltaBefore.routes ?? {});
  const stopsBefore  = Object.keys(deltaBefore.stops  ?? {});
  console.log(`  → rutas antes: ${routesBefore.length}, stops antes: ${stopsBefore.length}`);

  /* ── Paso 2: admin asigna la ruta al rep para mañana ── */
  const testDate = tomorrow();
  console.log(`\n[ Paso 2 ] Admin asigna ${ROUTE_CENTRO} al rep para ${testDate}...`);

  const assignResp = await api(adminToken, 'POST', '/schedule', {
    routeId: ROUTE_CENTRO,
    userId:  REP_ID,
    date:    testDate,
  });

  const assignStatus = assignResp.status;
  const assignBody   = await assignResp.json().catch(() => ({}));
  console.log(`  → Respuesta asignación: ${assignStatus}`, JSON.stringify(assignBody).slice(0, 120));

  // 200/201 OK; 400 puede indicar que ya existe esa asignación ese día (idempotente)
  assert(
    [200, 201, 400].includes(assignStatus),
    `POST /schedule responde ${assignStatus} (200/201 creado, 400 ya existía)`
  );

  /* ── Paso 3: pull DESPUÉS de asignar ── */
  console.log('\n[ Paso 3 ] Pull del rep tras la asignación (since=0)...');
  const pullAfter = await api(repToken, 'GET', '/sync/pull?since=0');
  assert(pullAfter.status === 200, 'GET /sync/pull → 200 tras asignación');
  const deltaAfter = await pullAfter.json();

  /* ── Verificación de rutas ── */
  console.log('\n[ Check A ] La ruta asignada aparece en el delta del rep');
  const routesAfter = deltaAfter.routes ?? {};
  assert(
    Object.prototype.hasOwnProperty.call(routesAfter, ROUTE_CENTRO),
    `La ruta ${ROUTE_CENTRO} está en delta.routes del rep`
  );

  /* ── Verificación de paradas ── */
  console.log('\n[ Check B ] Las paradas de esa ruta aparecen en el delta');
  const stopsAfter = deltaAfter.stops ?? {};
  assert(
    Object.prototype.hasOwnProperty.call(stopsAfter, STOP_EXPECTED),
    `Stop ${STOP_EXPECTED} está en delta.stops del rep`
  );

  /* ── Verificación de schedule ── */
  console.log('\n[ Check C ] El schedule del rep incluye la fecha asignada');
  const scheduleAfter = deltaAfter.schedule ?? {};
  // El schedule puede venir como { "YYYY-MM-DD": routeId } o anidado
  const hasDate = scheduleAfter[testDate] === ROUTE_CENTRO ||
                  scheduleAfter[testDate]?.routeId === ROUTE_CENTRO;
  assert(hasDate, `schedule["${testDate}"] apunta a ${ROUTE_CENTRO}`);

  /* ── Verificación: el stop pertenece a la ruta ── */
  console.log('\n[ Check D ] stop_ids de la ruta incluye el stop esperado');
  const routeData = routesAfter[ROUTE_CENTRO];
  if (routeData) {
    const stopIds = routeData.stops ?? routeData.stop_ids ?? [];
    assert(
      stopIds.includes(STOP_EXPECTED),
      `La ruta ${ROUTE_CENTRO} tiene ${STOP_EXPECTED} en su lista de stops`
    );
  } else {
    assert(false, `No hay datos de la ruta ${ROUTE_CENTRO} en el delta`);
  }

  /* ── Paso 4 (cleanup): borrar la asignación de test ── */
  console.log(`\n[ Cleanup ] Borrando schedule de test (${testDate})...`);
  const scheduleId = assignBody.id ?? assignBody.schedule?.id;
  if (scheduleId) {
    const delResp = await api(adminToken, 'DELETE', `/schedule/${scheduleId}`);
    console.log(`  → DELETE /schedule/${scheduleId}: ${delResp.status}`);
  } else {
    // Intentar borrar por ruta+fecha
    const delResp = await api(adminToken, 'DELETE', `/schedule/${ROUTE_CENTRO}/${testDate}`);
    console.log(`  → DELETE /schedule/${ROUTE_CENTRO}/${testDate}: ${delResp.status}`);
  }

  /* ── Paso 5: pull tras cleanup — la ruta ya no debe aparecer si no hay más schedules futuros ── */
  // (opcional — solo si el rep no tenía otras asignaciones a esa ruta)
  console.log('\n[ Paso 5 ] Pull del rep tras cleanup (verificación inversa)...');
  const pullClean = await api(repToken, 'GET', '/sync/pull?since=0');
  if (pullClean.status === 200) {
    const deltaClean = await pullClean.json();
    const routesClean = deltaClean.routes ?? {};
    const stillHasRoute = Object.prototype.hasOwnProperty.call(routesClean, ROUTE_CENTRO);

    if (!routesBefore.includes(ROUTE_CENTRO)) {
      // Si antes no la tenía, ahora tampoco debería
      assert(!stillHasRoute, `Tras cleanup, la ruta ${ROUTE_CENTRO} ya no aparece en el delta`);
    } else {
      console.log('  → (rep ya tenía esta ruta antes del test — verificación inversa omitida)');
    }
  }

  /* ── Resumen ── */
  console.log('\n═══════════════════════════════════════════');
  console.log(`RESULTADO: ${passed} passed, ${failed} failed`);
  if (errors.length) {
    console.error('Fallos:');
    errors.forEach(e => console.error(`  • ${e}`));
  }
  console.log('═══════════════════════════════════════════\n');

  process.exit(failed > 0 ? 1 : 0);
}

runSyncTests().catch(err => {
  console.error('Error inesperado:', err);
  process.exit(1);
});
