// playwright.config.js
const { defineConfig } = require('@playwright/test');

module.exports = defineConfig({
  testDir:   '.',
  timeout:   30_000,
  retries:   1,
  reporter:  'list',
  use: {
    baseURL:     process.env.BASE_URL || 'https://cqvkelal.cloud.cuentica.com/gestor-rutas-web',
    headless:    true,
    screenshot:  'only-on-failure',
    video:       'retain-on-failure',
  },
  // Los tests de roles son los únicos que necesitan navegador
  projects: [
    {
      name:    'chromium',
      use:     { browserName: 'chromium' },
      testMatch: 'test-roles.spec.js',
    },
  ],
});
