-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración v2.18.0
-- Jerarquía de equipo: manager_id en memberships
-- Permite escalar a N niveles sin cambio de esquema futuro
-- Ejecutar en phpMyAdmin → cqvkelal_gestorrutas
-- ═══════════════════════════════════════════════════════════

-- 1. Añadir manager_id en memberships
ALTER TABLE memberships
  ADD COLUMN IF NOT EXISTS `manager_id` VARCHAR(36) DEFAULT NULL
  AFTER `role`,
  ADD KEY IF NOT EXISTS `idx_mem_manager` (`manager_id`),
  ADD CONSTRAINT IF NOT EXISTS `fk_mem_manager`
    FOREIGN KEY (`manager_id`) REFERENCES `users`(`id`) ON DELETE SET NULL;

-- 2. Inferir jerarquía inicial desde roles existentes
--    Regla: admin/supervisor/rep sin manager_id → asignar al owner de la org
UPDATE memberships m
JOIN (
  SELECT org_id, user_id AS owner_id
  FROM memberships
  WHERE role = 'owner' AND active = 1
) owners ON owners.org_id = m.org_id
SET m.manager_id = owners.owner_id
WHERE m.manager_id IS NULL
  AND m.role != 'owner'
  AND m.active = 1;

-- 3. Verificación
SELECT
  u.email,
  m.role,
  mgr.email AS manager_email,
  m.manager_id IS NOT NULL AS has_manager
FROM memberships m
JOIN users u ON u.id = m.user_id
LEFT JOIN users mgr ON mgr.id = m.manager_id
WHERE m.org_id = 'eec84ae0-4b54-454f-8ccd-e3fb6a4d10ab'
ORDER BY FIELD(m.role, 'owner','admin','supervisor','rep');

SELECT 'Migración v2.18.0 completada — jerarquía manager_id' AS resultado;
