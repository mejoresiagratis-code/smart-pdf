-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración v2.14.0
-- Asignación de PDVs por jerarquía de rol
-- La columna zone_ids ya existe en memberships — sin ALTER TABLE.
-- Este script solo verifica y añade el índice si falta.
-- ═══════════════════════════════════════════════════════════

-- Asegurar que zone_ids acepta JSON válido (MariaDB ya lo tiene con CHECK)
-- Sin cambios de estructura — el campo ya existe.

-- Verificación
SELECT
  u.email,
  u.name,
  m.role,
  m.zone_ids,
  o.name AS org_name
FROM memberships m
JOIN users u ON u.id = m.user_id
JOIN organizations o ON o.id = m.org_id
WHERE o.active = 1
ORDER BY o.name, FIELD(m.role,'owner','admin','supervisor','rep');

SELECT 'Migración v2.14.0 — sin cambios de estructura (zone_ids ya existe)' AS resultado;
