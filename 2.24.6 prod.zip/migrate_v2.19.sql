-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración v2.19.0
-- Fase 2: archivar vs eliminar
-- Añade archived_at + archived_by en stops, routes, memberships
-- Solo God puede hacer DELETE real. El resto archiva (soft hide).
-- Ejecutar en phpMyAdmin → cqvkelal_gestorrutas
-- ═══════════════════════════════════════════════════════════

-- stops
ALTER TABLE stops
  ADD COLUMN IF NOT EXISTS `archived_at` DATETIME DEFAULT NULL AFTER `deleted`,
  ADD COLUMN IF NOT EXISTS `archived_by` VARCHAR(36) DEFAULT NULL AFTER `archived_at`;

-- routes
ALTER TABLE routes
  ADD COLUMN IF NOT EXISTS `archived_at` DATETIME DEFAULT NULL AFTER `deleted`,
  ADD COLUMN IF NOT EXISTS `archived_by` VARCHAR(36) DEFAULT NULL AFTER `archived_at`;

-- memberships
ALTER TABLE memberships
  ADD COLUMN IF NOT EXISTS `archived_at` DATETIME DEFAULT NULL AFTER `active`,
  ADD COLUMN IF NOT EXISTS `archived_by` VARCHAR(36) DEFAULT NULL AFTER `archived_at`;

-- Verificación
SELECT 'archived_at en stops'       AS col, COUNT(*) AS total FROM stops;
SELECT 'archived_at en routes'      AS col, COUNT(*) AS total FROM routes;
SELECT 'archived_at en memberships' AS col, COUNT(*) AS total FROM memberships;
SELECT 'Migración v2.19.0 completada' AS resultado;
