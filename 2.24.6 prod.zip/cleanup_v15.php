<?php
/**
 * GESTOR DE RUTAS — Limpieza carpeta antigua v1.5
 * Ejecutar UNA SOLA VEZ desde cPanel File Manager o SSH:
 *   php cleanup_v15.php
 * 
 * O acceder via URL (borrar el archivo después):
 *   https://mejoresiagratis.com/gestor-rutas-web/cleanup_v15.php?confirm=SI_BORRAR
 */

$confirm = $_GET['confirm'] ?? $_SERVER['argv'][1] ?? '';
if ($confirm !== 'SI_BORRAR') {
    echo json_encode([
        'status' => 'pendiente',
        'msg'    => 'Pasa ?confirm=SI_BORRAR para ejecutar el borrado',
        'target' => 'Carpeta: /gestor-rutas-web/v1.5/ (si existe)',
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

$base   = dirname(__FILE__);
$target = $base . '/v1.5';
$log    = [];

if (!is_dir($target)) {
    echo json_encode([
        'status' => 'ok',
        'msg'    => 'La carpeta v1.5 no existe — nada que borrar',
        'path'   => $target,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

function rrmdir(string $dir, array &$log): void {
    $items = array_diff(scandir($dir), ['.','..']);
    foreach ($items as $item) {
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) rrmdir($path, $log);
        else { unlink($path); $log[] = "DEL $path"; }
    }
    rmdir($dir);
    $log[] = "RMD $dir";
}

try {
    rrmdir($target, $log);
    echo json_encode([
        'status'  => 'ok',
        'msg'     => 'Carpeta v1.5 eliminada correctamente',
        'deleted' => count($log) . ' archivos/carpetas',
        'log'     => $log,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    echo json_encode([
        'status' => 'error',
        'msg'    => $e->getMessage(),
        'log'    => $log,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

// Autoborrarse tras ejecutar
@unlink(__FILE__);
