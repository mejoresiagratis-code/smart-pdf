-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración v2.17
-- Añade columna settings JSON en users para persistir
-- preferencias de dispositivo (tema, notificaciones) por usuario
-- Ejecutar en phpMyAdmin → cqvkelal_gestorrutas
-- ═══════════════════════════════════════════════════════════

-- Añadir columna settings en users
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS `settings` JSON DEFAULT NULL
  AFTER `avatar_url`;

-- Inicializar con objeto vacío en usuarios existentes
UPDATE users SET settings = '{}' WHERE settings IS NULL;

-- Verificación
SELECT id, email, settings FROM users;
SELECT 'Migración v2.17 completada' AS resultado;
