-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración MySQL v1.0
-- Ejecutar en cPanel → phpMyAdmin → tu base de datos
-- ═══════════════════════════════════════════════════════════

SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- ── organizations ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS organizations (
  id          VARCHAR(36)  NOT NULL PRIMARY KEY,
  name        VARCHAR(200) NOT NULL,
  slug        VARCHAR(60)  NOT NULL UNIQUE,
  plan        VARCHAR(20)  NOT NULL DEFAULT 'free',
  seat_limit  INT          NOT NULL DEFAULT 3,
  trial_ends_at DATETIME   DEFAULT NULL,
  stripe_customer_id VARCHAR(100) DEFAULT NULL,
  active      TINYINT(1)   NOT NULL DEFAULT 1,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── users ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            VARCHAR(36)  NOT NULL PRIMARY KEY,
  email         VARCHAR(254) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  name          VARCHAR(100) NOT NULL DEFAULT '',
  avatar_url    VARCHAR(500) DEFAULT NULL,
  email_verified TINYINT(1)  NOT NULL DEFAULT 0,
  last_login_at DATETIME     DEFAULT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── memberships ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS memberships (
  id          VARCHAR(36) NOT NULL PRIMARY KEY,
  org_id      VARCHAR(36) NOT NULL,
  user_id     VARCHAR(36) NOT NULL,
  role        VARCHAR(20) NOT NULL DEFAULT 'rep',
  zone_ids    JSON        DEFAULT NULL,
  active      TINYINT(1)  NOT NULL DEFAULT 1,
  invited_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  joined_at   DATETIME    DEFAULT NULL,
  UNIQUE KEY uq_membership (org_id, user_id),
  KEY idx_user (user_id),
  CONSTRAINT fk_mem_org  FOREIGN KEY (org_id)  REFERENCES organizations(id) ON DELETE CASCADE,
  CONSTRAINT fk_mem_user FOREIGN KEY (user_id) REFERENCES users(id)         ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── refresh_tokens ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id          VARCHAR(36)  NOT NULL PRIMARY KEY,
  user_id     VARCHAR(36)  NOT NULL,
  selector    VARCHAR(32)  NOT NULL UNIQUE,
  token_hash  VARCHAR(64)  NOT NULL,
  expires_at  DATETIME     NOT NULL,
  device_hint VARCHAR(100) DEFAULT NULL,
  revoked     TINYINT(1)   NOT NULL DEFAULT 0,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_rt_user (user_id),
  KEY idx_rt_expires (expires_at),
  CONSTRAINT fk_rt_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── stops (PDVs) ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stops (
  id          VARCHAR(36)  NOT NULL PRIMARY KEY,
  org_id      VARCHAR(36)  NOT NULL,
  ref         VARCHAR(50)  DEFAULT NULL,
  name        VARCHAR(200) NOT NULL,
  addr        VARCHAR(300) DEFAULT NULL,
  town        VARCHAR(100) DEFAULT NULL,
  zip         VARCHAR(10)  DEFAULT NULL,
  lat         DECIMAL(10,7) DEFAULT NULL,
  lng         DECIMAL(10,7) DEFAULT NULL,
  tags        JSON         DEFAULT NULL,
  contact     VARCHAR(100) DEFAULT NULL,
  phone       VARCHAR(30)  DEFAULT NULL,
  mobile      VARCHAR(30)  DEFAULT NULL,
  email       VARCHAR(254) DEFAULT NULL,
  horario     VARCHAR(200) DEFAULT NULL,
  notes       TEXT         DEFAULT NULL,
  deleted     TINYINT(1)   NOT NULL DEFAULT 0,
  created_by  VARCHAR(36)  DEFAULT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_stops_org (org_id),
  KEY idx_stops_updated (org_id, updated_at),
  CONSTRAINT fk_stops_org FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── routes ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS routes (
  id          VARCHAR(36)  NOT NULL PRIMARY KEY,
  org_id      VARCHAR(36)  NOT NULL,
  name        VARCHAR(200) NOT NULL,
  stop_ids    JSON         DEFAULT NULL,
  deleted     TINYINT(1)   NOT NULL DEFAULT 0,
  created_by  VARCHAR(36)  DEFAULT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_routes_org (org_id),
  CONSTRAINT fk_routes_org FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── schedules ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS schedules (
  id           VARCHAR(36) NOT NULL PRIMARY KEY,
  org_id       VARCHAR(36) NOT NULL,
  route_id     VARCHAR(36) NOT NULL,
  assigned_to  VARCHAR(36) DEFAULT NULL,
  date         DATE        NOT NULL,
  created_at   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_schedule_day (org_id, assigned_to, date),
  KEY idx_sch_org (org_id, date),
  CONSTRAINT fk_sch_org   FOREIGN KEY (org_id)   REFERENCES organizations(id) ON DELETE CASCADE,
  CONSTRAINT fk_sch_route FOREIGN KEY (route_id) REFERENCES routes(id)        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── sessions (jornadas) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
  id           VARCHAR(36)  NOT NULL PRIMARY KEY,
  org_id       VARCHAR(36)  NOT NULL,
  user_id      VARCHAR(36)  NOT NULL,
  route_id     VARCHAR(36)  DEFAULT NULL,
  date         DATE         NOT NULL,
  state        VARCHAR(20)  NOT NULL DEFAULT 'idle',
  elapsed_s    INT          NOT NULL DEFAULT 0,
  distance_km  DECIMAL(8,3) NOT NULL DEFAULT 0,
  gps_path     JSON         DEFAULT NULL,
  started_at   DATETIME     DEFAULT NULL,
  finished_at  DATETIME     DEFAULT NULL,
  created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_sess_user_date (user_id, date),
  KEY idx_sess_org (org_id, updated_at),
  CONSTRAINT fk_sess_org  FOREIGN KEY (org_id)  REFERENCES organizations(id) ON DELETE CASCADE,
  CONSTRAINT fk_sess_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── visits ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS visits (
  id           VARCHAR(36) NOT NULL PRIMARY KEY,
  org_id       VARCHAR(36) NOT NULL,
  session_id   VARCHAR(36) DEFAULT NULL,
  stop_id      VARCHAR(36) NOT NULL,
  user_id      VARCHAR(36) NOT NULL,
  estado       VARCHAR(100) DEFAULT NULL,
  form_data    JSON         DEFAULT NULL,
  kpi_data     JSON         DEFAULT NULL,
  photo_urls   JSON         DEFAULT NULL,
  notas        TEXT         DEFAULT NULL,
  check_in_at  DATETIME     DEFAULT NULL,
  check_out_at DATETIME     DEFAULT NULL,
  created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_visits_stop (stop_id, updated_at),
  KEY idx_visits_org  (org_id,  updated_at),
  CONSTRAINT fk_vis_org  FOREIGN KEY (org_id)  REFERENCES organizations(id) ON DELETE CASCADE,
  CONSTRAINT fk_vis_stop FOREIGN KEY (stop_id) REFERENCES stops(id),
  CONSTRAINT fk_vis_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── forms ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS forms (
  id         VARCHAR(36)  NOT NULL PRIMARY KEY,
  org_id     VARCHAR(36)  NOT NULL,
  name       VARCHAR(200) NOT NULL,
  icon       VARCHAR(100) DEFAULT 'fa-clipboard-check',
  fields     JSON         DEFAULT NULL,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_forms_org FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── kpi_defs ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS kpi_defs (
  id         VARCHAR(36)  NOT NULL PRIMARY KEY,
  org_id     VARCHAR(36)  NOT NULL,
  label      VARCHAR(100) NOT NULL,
  unit       VARCHAR(30)  DEFAULT NULL,
  min_val    DECIMAL(10,3) DEFAULT NULL,
  max_val    DECIMAL(10,3) DEFAULT NULL,
  sort_order INT          NOT NULL DEFAULT 0,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_kpi_org FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET foreign_key_checks = 1;

-- ── Verificar ────────────────────────────────────────────
SELECT 'Tablas creadas correctamente' AS resultado;
SHOW TABLES;

-- ── Migración v2.5: selector en refresh_tokens (A-01) ────
-- Ejecutar solo si ya tenías la tabla sin columna selector:
ALTER TABLE refresh_tokens
  ADD COLUMN IF NOT EXISTS selector   VARCHAR(32) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS token_hash_new VARCHAR(64) DEFAULT NULL;
-- Después de correr este ALTER, los tokens viejos (sin selector)
-- serán inválidos y los usuarios harán login de nuevo — comportamiento correcto.
-- Eliminar tokens sin selector:
DELETE FROM refresh_tokens WHERE selector IS NULL;
-- Hacer selector NOT NULL y UNIQUE:
ALTER TABLE refresh_tokens MODIFY COLUMN selector VARCHAR(32) NOT NULL;
ALTER TABLE refresh_tokens ADD UNIQUE INDEX IF NOT EXISTS uq_rt_selector (selector);

-- ── Migración v2.7: idempotency_keys (S-02) ──────────────
CREATE TABLE IF NOT EXISTS idempotency_keys (
  id         VARCHAR(36)  NOT NULL PRIMARY KEY,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ik_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Limpiar keys antiguas automáticamente (>24h)
-- (se purgan en cada push, ver sync.php)

-- ── Migración v2.7: updated_at en schedules (S-05) ───────
ALTER TABLE schedules
  ADD COLUMN IF NOT EXISTS updated_at DATETIME NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP;

SELECT 'Migración v2.7 completada' AS resultado;
