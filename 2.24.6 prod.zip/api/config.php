<?php
/* ═══════════════════════════════════════════════════════════
   GESTOR DE RUTAS — config.php
   ▶ EDITA SOLO ESTE ARCHIVO antes de subir al servidor
   ═══════════════════════════════════════════════════════════ */

/* ── Base de datos MySQL (cPanel → MySQL Databases) ── */
define('DB_HOST',     '127.0.0.1');  // fix: TCP en vez de socket Unix
define('DB_NAME',     'cqvkelal_gestorrutas');   // ← cambiar
define('DB_USER',     'cqvkelal_gestoruser');          // ← cambiar
define('DB_PASS',     'Shimba2021,,');         // ← cambiar
define('DB_CHARSET',  'utf8mb4');

/* ── JWT ── */
// Genera una clave con: openssl rand -hex 48
define('JWT_SECRET',      '654a598b6b768d3a55b6203255026baa1c375ba0f6e3342d5a3cc442c1851eec');
define('JWT_EXPIRES',     900);          // segundos (15 min)
define('RT_EXPIRES_DAYS', 30);

/* ── CORS ── */
// Tu dominio donde está el frontend (sin barra final)
define('ALLOWED_ORIGINS', 'https://mejoresiagratis.com,https://www.mejoresiagratis.com');

/* ── Rate limiting (simple, basado en archivos) ── */
define('RATE_LIMIT_DIR', sys_get_temp_dir() . '/gestor_rl');
define('RATE_ENABLED',   true);

/* ── Email — recuperación de contraseña ── */
define('MAIL_FROM',    'noreply@mejoresiagratis.com');
define('MAIL_FROM_NAME', 'Gestor de Rutas Pro');
define('APP_URL',      'https://mejoresiagratis.com/gestor-rutas-web');
