<?php
/* ═══════════════════════════════════════════════════
   DIAGNÓSTICO TEMPORAL — borrar después de usarlo
   Subir a: /gestor-rutas-web/api/debug.php
   Abrir:   https://mejoresiagratis.com/gestor-rutas-web/api/debug.php
   ═══════════════════════════════════════════════════ */

error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json; charset=utf-8');

$result = [];

/* 1. PHP version */
$result['php_version'] = PHP_VERSION;
$result['php_ok']      = version_compare(PHP_VERSION, '7.4', '>=');

/* 2. Extensiones requeridas */
$exts = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'openssl'];
foreach ($exts as $ext) {
    $result['ext'][$ext] = extension_loaded($ext);
}

/* 3. Config.php cargable */
try {
    require_once __DIR__ . '/config.php';
    $result['config_loaded'] = true;
    $result['db_host'] = DB_HOST;
    $result['db_name'] = DB_NAME;
    $result['db_user'] = DB_USER;
    $result['jwt_secret_len'] = strlen(JWT_SECRET);
    $result['jwt_secret_ok']  = strlen(JWT_SECRET) >= 32;
} catch (Throwable $e) {
    $result['config_loaded'] = false;
    $result['config_error']  = $e->getMessage();
}

/* 4. Conexión MySQL */
if ($result['config_loaded'] ?? false) {
    try {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $result['db_connected'] = true;

        /* Tablas existentes */
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        $result['db_tables'] = $tables;

        $expected = ['users','organizations','memberships','refresh_tokens','stops','routes','schedules','sessions','visits','forms','kpi_defs'];
        $missing  = array_diff($expected, $tables);
        $result['db_tables_missing'] = array_values($missing);
        $result['db_migrate_ok']     = count($missing) === 0;

    } catch (Throwable $e) {
        $result['db_connected'] = false;
        $result['db_error']     = $e->getMessage();
    }
}

/* 5. Permisos de escritura (rate limiting) */
$tmpDir = sys_get_temp_dir();
$result['tmp_dir']       = $tmpDir;
$result['tmp_writable']  = is_writable($tmpDir);

/* 6. mod_rewrite activo */
$result['mod_rewrite'] = in_array('mod_rewrite', apache_get_modules() ?? []);

/* 7. Resumen */
$ok = ($result['php_ok'] ?? false)
   && ($result['ext']['pdo'] ?? false)
   && ($result['ext']['pdo_mysql'] ?? false)
   && ($result['config_loaded'] ?? false)
   && ($result['db_connected'] ?? false)
   && ($result['db_migrate_ok'] ?? false);

$result['ALL_OK'] = $ok;

echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
