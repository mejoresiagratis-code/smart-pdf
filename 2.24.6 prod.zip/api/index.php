<?php
/* ═══════════════════════════════════════════════════════════
   GESTOR DE RUTAS — Backend PHP v1.0
   Hosting compartido · MySQL/MariaDB · JWT manual
   Estructura: /api/index.php — router central
   ═══════════════════════════════════════════════════════════ */

define('ROOT', __DIR__);
require_once ROOT . '/config.php';
require_once ROOT . '/lib/db.php';
require_once ROOT . '/lib/jwt.php';
require_once ROOT . '/lib/helpers.php';

/* ── CORS ── */
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = explode(',', ALLOWED_ORIGINS);
if (in_array($origin, $allowed) || in_array('*', $allowed)) {
    header("Access-Control-Allow-Origin: $origin");
} else {
    header('Access-Control-Allow-Origin: ' . $allowed[0]);
}
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Expose-Headers: X-RateLimit-Remaining');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

/* ── Router ── */
$method = $_SERVER['REQUEST_METHOD'];
$uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

/* Quitar prefijo /gestor-rutas-web/api de la URI */
$uri = preg_replace('#^.*?/gestor-rutas-web/api#', '', $uri);
$uri = '/' . trim($uri, '/');

/* Health check */
if ($uri === '/health' || $uri === '') {
    json_out(['ok' => true, 'ts' => time() * 1000]);
}

/* Cargar controladores */
require_once ROOT . '/controllers/auth.php';
require_once ROOT . '/controllers/registration.php';
require_once ROOT . '/controllers/sync.php';
require_once ROOT . '/controllers/stops.php';
require_once ROOT . '/controllers/routes.php';
require_once ROOT . '/controllers/sessions.php';
require_once ROOT . '/controllers/visits.php';
require_once ROOT . '/controllers/forms.php';
require_once ROOT . '/controllers/users.php';
require_once ROOT . '/controllers/schedule.php';
require_once ROOT . '/controllers/platform.php';
require_once ROOT . '/controllers/stats.php';
require_once ROOT . '/controllers/uploads.php';

/* Tabla de rutas: [método, patrón regex, función, requiere_auth] */
$routes = [
    /* Auth (público) */
    ['POST',   '#^/auth/register$#',           'auth_register',         false],
    ['GET',    '#^/auth/register/status$#',    'auth_register_status',  false],
    ['POST',   '#^/auth/forgot$#',             'auth_forgot',           false],
    ['POST',   '#^/auth/reset$#',              'auth_reset',            false],
    ['POST',   '#^/auth/login$#',              'auth_login',         false],
    ['POST',   '#^/auth/refresh$#',            'auth_refresh',       false],
    ['POST',   '#^/auth/logout$#',             'auth_logout',        false],
    ['GET',    '#^/auth/me$#',                 'auth_me',            true],
    ['PATCH',  '#^/auth/settings$#',           'auth_settings',      true],
    ['PATCH',  '#^/auth/password$#',           'auth_change_password',true],

    /* Sync */
    ['POST',   '#^/sync/push$#',               'sync_push',          true],
    ['GET',    '#^/sync/pull$#',               'sync_pull',          true],
    ['POST',   '#^/sync/import$#',             'sync_import',        true],

    /* Stops */
    ['GET',    '#^/stops$#',                   'stops_list',         true],
    ['POST',   '#^/stops$#',                   'stops_create',       true],
    ['GET',    '#^/stops/([^/]+)$#',           'stops_get',          true],
    ['PATCH',  '#^/stops/([^/]+)$#',           'stops_update',       true],
    ['DELETE', '#^/stops/([^/]+)$#',           'stops_delete',       true],
    ['GET',    '#^/stops/([^/]+)/history$#',   'stops_history',      true],

    /* Routes */
    ['GET',    '#^/routes$#',                  'routes_list',        true],
    ['POST',   '#^/routes$#',                  'routes_create',      true],
    ['GET',    '#^/routes/([^/]+)$#',          'routes_get',         true],
    ['PATCH',  '#^/routes/([^/]+)$#',          'routes_update',      true],
    ['DELETE', '#^/routes/([^/]+)$#',          'routes_delete',      true],
    ['POST',   '#^/routes/([^/]+)/stops/([^/]+)$#', 'routes_add_stop',    true],
    ['DELETE', '#^/routes/([^/]+)/stops/([^/]+)$#', 'routes_remove_stop', true],

    /* Sessions */
    ['GET',    '#^/sessions$#',                'sessions_list',      true],
    ['GET',    '#^/sessions/([^/]+)/([^/]+)$#','sessions_get',       true],
    ['PUT',    '#^/sessions/([^/]+)/([^/]+)$#','sessions_upsert',    true],

    /* Visits */
    ['GET',    '#^/visits$#',                  'visits_list',        true],
    ['POST',   '#^/visits$#',                  'visits_create',      true],
    ['PATCH',  '#^/visits/([^/]+)$#',          'visits_update',      true],
    ['DELETE', '#^/visits/([^/]+)$#',          'visits_delete',      true],

    /* Forms & KPIs */
    ['GET',    '#^/forms$#',                   'forms_list',         true],
    ['POST',   '#^/forms$#',                   'forms_create',       true],
    ['PATCH',  '#^/forms/([^/]+)$#',           'forms_update',       true],
    ['DELETE', '#^/forms/([^/]+)$#',           'forms_delete',       true],
    ['GET',    '#^/kpis$#',                    'kpis_list',          true],
    ['POST',   '#^/kpis$#',                    'kpis_create',        true],
    ['DELETE', '#^/kpis/([^/]+)$#',            'kpis_delete',        true],

    /* Users */
    ['GET',    '#^/users$#',                   'users_list',         true],
    ['POST',   '#^/users/invite$#',            'users_invite',       true],
    ['PATCH',  '#^/users/([^/]+)/role$#',      'users_update_role',  true],
    ['PATCH',  '#^/users/([^/]+)/targets$#',   'users_set_targets',  true],
    ['PATCH',  '#^/users/([^/]+)/org$#',       'users_move_org',     true],
    ['DELETE', '#^/users/([^/]+)$#',           'users_remove',       true],
    ['GET',    '#^/users/([^/]+)/stops$#',      'users_get_stops',    true],
    ['PATCH',  '#^/users/([^/]+)/stops$#',      'users_assign_stops', true],

    /* Schedule */
    ['GET',    '#^/schedule$#',                'schedule_get',       true],
    ['POST',   '#^/schedule$#',                'schedule_set',       true],
    ['DELETE', '#^/schedule/([^/]+)(?:/([^/]+))?$#', 'schedule_delete', true],

    /* Platform (solo god / platform_admin) */
    ['GET',    '#^/platform/stats$#',                             'platform_stats',                  true],
    ['GET',   '#^/stats/dashboard$#',           'stats_dashboard',    true],
    ['POST',  '#^/uploads/photo$#',             'uploads_photo',      true],
    ['DELETE','#^/uploads/photo/([^/]+)$#',      'uploads_delete',     true],
    ['POST',  '#^/uploads/photo$#',             'uploads_photo',      true],
    ['DELETE','#^/uploads/photo/([^/]+)$#',      'uploads_delete',     true],
    ['GET',    '#^/platform/orgs$#',                              'platform_orgs_list',               true],
    ['GET',    '#^/platform/orgs/([^/]+)$#',                      'platform_orgs_get',                true],
    ['PATCH',  '#^/platform/orgs/([^/]+)$#',                      'platform_orgs_update',             true],
    ['GET',    '#^/platform/users$#',                             'platform_users_list',              true],
    ['GET',    '#^/platform/registrations$#',                     'platform_registrations_list',      true],
    ['POST',   '#^/platform/registrations/([^/]+)/approve$#',     'platform_registrations_approve',   true],
    ['POST',   '#^/platform/registrations/([^/]+)/reject$#',      'platform_registrations_reject',    true],
];

$matched = false;
foreach ($routes as [$rMethod, $pattern, $fn, $requiresAuth]) {
    if ($method !== $rMethod) continue;
    if (!preg_match($pattern, $uri, $matches)) continue;

    $matched = true;
    $params  = array_slice($matches, 1);

    /* Auth middleware */
    $ctx = null;
    if ($requiresAuth) {
        $ctx = require_auth();
        if (!$ctx) {
            json_error('No autorizado', 401);
        }
    }

    call_user_func($fn, $params, $ctx);
    exit;
}

if (!$matched) {
    json_error('Ruta no encontrada', 404);
}
