<?php
/* ══════════════════════════════════════════════════════════
   STOPS — con filtrado por zone_ids según rol
   rep       → solo sus zone_ids
   supervisor → sus zone_ids (o todos si no tiene asignados aún)
   admin/owner → todos los de la org
   ══════════════════════════════════════════════════════════ */

function stops_list(array $p, array $ctx): never {
    $q     = $_GET['q']     ?? null;
    $tag   = $_GET['tag']   ?? null;
    $noGeo = ($_GET['noGeo'] ?? '') === '1';
    $role  = $ctx['role'];

    /* Obtener todos los stops de la org primero */
    $rows = db_all(
        'SELECT * FROM stops WHERE org_id=? AND deleted=0 ORDER BY name LIMIT 2000',
        [$ctx['orgId']]
    );

    /* Filtrar por zone_ids para rep y supervisor.
       Rep: ve sus zone_ids + stops de sus rutas asignadas (para la jornada). */
    if ($role === 'rep' || $role === 'supervisor') {
        $mem = db_one(
            'SELECT zone_ids FROM memberships WHERE org_id=? AND user_id=? AND active=1',
            [$ctx['orgId'], $ctx['userId']]
        );
        $assigned = $mem ? (json_decode($mem['zone_ids'] ?? 'null', true) ?? []) : [];

        if ($role === 'rep') {
            /* Añadir stops de rutas asignadas */
            $assignedRoutes = db_all(
                'SELECT DISTINCT r.stop_ids FROM routes r
                 INNER JOIN schedules s ON s.route_id = r.id
                 WHERE r.org_id=? AND r.deleted=0
                   AND s.assigned_to=? AND s.date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)',
                [$ctx['orgId'], $ctx['userId']]
            );
            $routeStopIds = [];
            foreach ($assignedRoutes as $ar) {
                $ids = json_decode($ar['stop_ids'] ?? '[]', true) ?? [];
                $routeStopIds = array_merge($routeStopIds, $ids);
            }
            $allVisible = array_unique(array_merge($assigned, $routeStopIds));
            $rows = array_filter($rows, fn($s) => in_array($s['id'], $allVisible));
        } elseif ($role === 'supervisor' && !empty($assigned)) {
            $rows = array_filter($rows, fn($s) => in_array($s['id'], $assigned));
        }
        /* supervisor sin asignados: ve todos (transitorio) */
    }

    if ($q) {
        $ql = strtolower($q);
        $rows = array_filter($rows, fn($s) =>
            str_contains(strtolower($s['name'] ?? ''), $ql) ||
            str_contains(strtolower($s['addr'] ?? ''), $ql) ||
            str_contains(strtolower($s['town'] ?? ''), $ql)
        );
    }
    if ($tag) {
        $rows = array_filter($rows, fn($s) => in_array($tag, json_col($s['tags']) ?? []));
    }
    if ($noGeo) {
        $rows = array_filter($rows, fn($s) => !$s['lat']);
    }

    json_out(array_values(array_map('_stop_out', $rows)));
}

function stops_get(array $p, array $ctx): never {
    $s = _find_stop($ctx['orgId'], $p[0]);
    if (!$s) json_error('Parada no encontrada', 404);
    json_out(_stop_out($s));
}

function stops_create(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    $b = body();
    $id = uuid4(); $now = now_sql();
    db_run('INSERT INTO stops
            (id,org_id,name,ref,addr,town,zip,lat,lng,tags,contact,phone,mobile,email,horario,notes,created_by,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [$id, $ctx['orgId'], $b['name'] ?? '—', $b['ref'] ?? null,
         $b['addr'] ?? null, $b['town'] ?? null, $b['zip'] ?? null,
         $b['lat'] ?? null, $b['lng'] ?? null,
         to_json($b['tags'] ?? []),
         $b['contact'] ?? null, $b['phone'] ?? null, $b['mobile'] ?? null,
         $b['email'] ?? null, $b['horario'] ?? null, $b['notes'] ?? null,
         $ctx['userId'], $now, $now]);
    json_out(_stop_out(db_one('SELECT * FROM stops WHERE id=?', [$id])), 201);
}

function stops_update(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    require_role($ctx, 'supervisor');
    $s = _find_stop($ctx['orgId'], $p[0]);
    if (!$s) json_error('Parada no encontrada', 404);
    assert_can_manage_resource($ctx, $s['created_by']);
    $b = body();
    $fields = ['name','ref','addr','town','zip','lat','lng','contact','phone','mobile','email','horario','notes'];
    $sets = []; $vals = [];
    foreach ($fields as $f) {
        if (array_key_exists($f, $b)) { $sets[] = "$f=?"; $vals[] = $b[$f]; }
    }
    if (isset($b['tags'])) { $sets[] = 'tags=?'; $vals[] = to_json($b['tags']); }
    if (!$sets) json_out(_stop_out($s));
    $sets[] = 'updated_at=?'; $vals[] = now_sql();
    $vals[] = $p[0];
    db_run('UPDATE stops SET ' . implode(',', $sets) . ' WHERE id=?', $vals);
    json_out(_stop_out(db_one('SELECT * FROM stops WHERE id=?', [$p[0]])));
}

function stops_delete(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    require_role($ctx, 'supervisor');
    $s = _find_stop($ctx['orgId'], $p[0]);
    if (!$s) json_error('Parada no encontrada', 404);
    assert_can_manage_resource($ctx, $s['created_by']);
    /* Archivar — solo God puede DELETE real */
    $now = now_sql();
    db_run('UPDATE stops SET deleted=1, archived_at=?, archived_by=?, updated_at=?
            WHERE org_id=? AND id=?',
        [$now, $ctx['userId'], $now, $ctx['orgId'], $p[0]]);
    http_response_code(204); exit;
}

function stops_history(array $p, array $ctx): never {
    $s = _find_stop($ctx['orgId'], $p[0]);
    if (!$s) json_error('Parada no encontrada', 404);
    $rows = db_all('SELECT v.*, u.name as user_name FROM visits v
                    LEFT JOIN users u ON u.id=v.user_id
                    WHERE v.org_id=? AND v.stop_id=? ORDER BY v.check_in_at DESC LIMIT 50',
        [$ctx['orgId'], $p[0]]);
    json_out($rows);
}


function _find_stop(string $orgId, string $id): ?array {
    return db_one('SELECT * FROM stops WHERE org_id=? AND id=? AND deleted=0', [$orgId, $id]);
}

function _stop_out(array $s): array {
    return ['id' => $s['id'], 'ref' => $s['ref'], 'name' => $s['name'],
            'addr' => $s['addr'], 'town' => $s['town'], 'zip' => $s['zip'],
            'lat' => $s['lat'] ? (float)$s['lat'] : null,
            'lng' => $s['lng'] ? (float)$s['lng'] : null,
            'tags' => json_col($s['tags']) ?? [],
            'contact' => $s['contact'], 'phone' => $s['phone'],
            'mobile' => $s['mobile'], 'email' => $s['email'],
            'horario' => $s['horario'], 'notes' => $s['notes'],
            'deleted' => (bool)$s['deleted'],
            'updatedAt' => to_ts($s['updated_at'])];
}
