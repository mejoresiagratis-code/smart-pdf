<?php
/* ══════════════════════════════════════════════════════════
   ROUTES
   ══════════════════════════════════════════════════════════ */
function routes_list(array $p, array $ctx): never {
    /* Rep: solo ve rutas que tiene asignadas en su schedule (presente y futuro) */
    if ($ctx['role'] === 'rep') {
        $rows = db_all(
            'SELECT DISTINCT r.* FROM routes r
             INNER JOIN schedules s ON s.route_id = r.id
             WHERE r.org_id=? AND r.deleted=0
               AND s.assigned_to=? AND s.date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
             ORDER BY r.name',
            [$ctx['orgId'], $ctx['userId']]
        );
    } else {
        $rows = db_all('SELECT * FROM routes WHERE org_id=? AND deleted=0 ORDER BY name', [$ctx['orgId']]);
    }
    json_out(array_map('_route_out', $rows));
}
function routes_get(array $p, array $ctx): never {
    $r = db_one('SELECT * FROM routes WHERE org_id=? AND id=? AND deleted=0', [$ctx['orgId'], $p[0]]);
    if (!$r) json_error('Ruta no encontrada', 404);
    json_out(_route_out($r));
}
function routes_create(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    $b = body(); $id = uuid4(); $now = now_sql();
    db_run('INSERT INTO routes (id,org_id,name,stop_ids,created_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?)',
        [$id, $ctx['orgId'], $b['name'] ?? 'Nueva ruta', to_json($b['stopIds'] ?? []), $ctx['userId'], $now, $now]);
    json_out(_route_out(db_one('SELECT * FROM routes WHERE id=?', [$id])), 201);
}
function routes_update(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    $r = db_one('SELECT created_by FROM routes WHERE org_id=? AND id=? AND deleted=0',
        [$ctx['orgId'], $p[0]]);
    if (!$r) json_error('Ruta no encontrada', 404);
    assert_can_manage_resource($ctx, $r['created_by']);
    $b = body(); $sets = []; $vals = [];
    if (isset($b['name']))    { $sets[] = 'name=?';     $vals[] = $b['name']; }
    if (isset($b['stopIds'])) { $sets[] = 'stop_ids=?'; $vals[] = to_json($b['stopIds']); }
    if (!$sets) { $r = db_one('SELECT * FROM routes WHERE id=?', [$p[0]]); json_out(_route_out($r)); }
    $sets[] = 'updated_at=?'; $vals[] = now_sql(); $vals[] = $p[0];
    db_run('UPDATE routes SET ' . implode(',', $sets) . ' WHERE id=?', $vals);
    json_out(_route_out(db_one('SELECT * FROM routes WHERE id=?', [$p[0]])));
}
function routes_delete(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    $r = db_one('SELECT created_by FROM routes WHERE org_id=? AND id=? AND deleted=0',
        [$ctx['orgId'], $p[0]]);
    if (!$r) json_error('Ruta no encontrada', 404);
    assert_can_manage_resource($ctx, $r['created_by']);
    /* Archivar — solo God puede DELETE real */
    $now = now_sql();
    db_run('UPDATE routes SET deleted=1, archived_at=?, archived_by=?, updated_at=?
            WHERE org_id=? AND id=?',
        [$now, $ctx['userId'], $now, $ctx['orgId'], $p[0]]);
    http_response_code(204); exit;
}
function routes_add_stop(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    $r = db_one('SELECT * FROM routes WHERE org_id=? AND id=?', [$ctx['orgId'], $p[0]]);
    if (!$r) json_error('Ruta no encontrada', 404);
    $ids = json_col($r['stop_ids']) ?? [];
    if (!in_array($p[1], $ids)) $ids[] = $p[1];
    db_run('UPDATE routes SET stop_ids=?,updated_at=? WHERE id=?', [to_json($ids), now_sql(), $p[0]]);
    json_out(_route_out(db_one('SELECT * FROM routes WHERE id=?', [$p[0]])));
}
function routes_remove_stop(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    $r = db_one('SELECT * FROM routes WHERE org_id=? AND id=?', [$ctx['orgId'], $p[0]]);
    if (!$r) json_error('Ruta no encontrada', 404);
    $ids = array_values(array_filter(json_col($r['stop_ids']) ?? [], fn($id) => $id !== $p[1]));
    db_run('UPDATE routes SET stop_ids=?,updated_at=? WHERE id=?', [to_json($ids), now_sql(), $p[0]]);
    http_response_code(204); exit;
}
function _route_out(array $r): array {
    return ['id' => $r['id'], 'name' => $r['name'],
            'stops' => json_col($r['stop_ids']) ?? [],
            'deleted' => (bool)$r['deleted'], 'updatedAt' => to_ts($r['updated_at'])];
}

/* ══════════════════════════════════════════════════════════
   SESSIONS (jornadas)
   ══════════════════════════════════════════════════════════ */
function sessions_list(array $p, array $ctx): never {
    $userId = ($ctx['role'] === 'rep' || !isset($_GET['userId'])) ? $ctx['userId'] : $_GET['userId'];
    $date   = $_GET['date'] ?? null;
    $sql    = 'SELECT * FROM sessions WHERE org_id=? AND user_id=?';
    $vals   = [$ctx['orgId'], $userId];
    if ($date) { $sql .= ' AND date=?'; $vals[] = $date; }
    $sql .= ' ORDER BY date DESC LIMIT 60';
    json_out(array_map('_session_out', db_all($sql, $vals)));
}
function sessions_get(array $p, array $ctx): never {
    $s = db_one('SELECT * FROM sessions WHERE org_id=? AND user_id=? AND route_id=? AND date=?',
        [$ctx['orgId'], $ctx['userId'], $p[0], $p[1]]);
    json_out($s ? _session_out($s) : ['state'=>'idle','elapsed'=>0,'distance'=>0,'gpsPath'=>[]]);
}
function sessions_upsert(array $p, array $ctx): never {
    $b = body();
    $existing = db_one('SELECT * FROM sessions WHERE org_id=? AND user_id=? AND route_id=? AND date=?',
        [$ctx['orgId'], $ctx['userId'], $p[0], $p[1]]);
    /* finished no retrocede */
    if ($existing && $existing['state'] === 'finished' && isset($b['state']) && $b['state'] !== 'finished') {
        json_out(_session_out($existing));
    }
    $now = now_sql();
    $state   = $b['state']      ?? $existing['state']      ?? 'idle';
    $elapsed = $b['elapsedS']   ?? $existing['elapsed_s']  ?? 0;
    $dist    = $b['distanceKm'] ?? $existing['distance_km'] ?? 0;
    $gps     = to_json($b['gpsPath'] ?? json_col($existing['gps_path'] ?? null) ?? []);
    $startedAt  = !empty($b['startedAt'])  ? date('Y-m-d H:i:s', strtotime($b['startedAt']))  : ($existing['started_at']  ?? null);
    $finishedAt = !empty($b['finishedAt']) ? date('Y-m-d H:i:s', strtotime($b['finishedAt'])) : ($existing['finished_at'] ?? null);

    $wasFinishing = ($state === 'finished' && ($existing['state'] ?? '') !== 'finished');

    if ($existing) {
        db_run('UPDATE sessions SET state=?,elapsed_s=?,distance_km=?,gps_path=?,started_at=?,finished_at=?,updated_at=? WHERE id=?',
            [$state, $elapsed, $dist, $gps, $startedAt, $finishedAt, $now, $existing['id']]);
        /* Al finalizar: poblar daily_stats */
        if ($wasFinishing) {
            _upsert_daily_stats($ctx['orgId'], $ctx['userId'], $p[1]);
        }
        json_out(_session_out(db_one('SELECT * FROM sessions WHERE id=?', [$existing['id']])));
    }
    $id = uuid4();
    db_run('INSERT INTO sessions (id,org_id,user_id,route_id,date,state,elapsed_s,distance_km,gps_path,started_at,finished_at,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [$id, $ctx['orgId'], $ctx['userId'], $p[0], $p[1], $state, $elapsed, $dist, $gps, $startedAt, $finishedAt, $now, $now]);
    /* Sesión nueva ya finalizada */
    if ($wasFinishing) {
        _upsert_daily_stats($ctx['orgId'], $ctx['userId'], $p[1]);
    }
    json_out(_session_out(db_one('SELECT * FROM sessions WHERE id=?', [$id])), 201);
}
function _session_out(array $s): array {
    return ['id' => $s['id'], 'routeId' => $s['route_id'], 'date' => $s['date'],
            'state' => $s['state'], 'elapsed' => (int)$s['elapsed_s'],
            'distance' => (float)$s['distance_km'],
            'gpsPath' => json_col($s['gps_path']) ?? [],
            'startedAt' => $s['started_at'], 'finishedAt' => $s['finished_at'],
            'updatedAt' => to_ts($s['updated_at'])];
}

/* ══════════════════════════════════════════════════════════
   VISITS
   ══════════════════════════════════════════════════════════ */
function visits_list(array $p, array $ctx): never {
    $stopId = $_GET['stopId'] ?? null;
    $date   = $_GET['date']   ?? null;
    $userId = $_GET['userId'] ?? null;
    $team   = isset($_GET['team']);   /* ?team=1 → todas las visitas del árbol del usuario */
    $from   = $_GET['from']   ?? null;
    $to     = $_GET['to']     ?? null;

    $sql = 'SELECT * FROM visits WHERE org_id=?';
    $vals = [$ctx['orgId']];

    if ($ctx['role'] === 'rep') {
        /* Rep solo ve sus propias visitas */
        $sql .= ' AND user_id=?'; $vals[] = $ctx['userId'];
    } elseif ($team) {
        /* Supervisor+: todas las visitas de su árbol */
        $visibleIds = get_visible_user_ids($ctx['orgId'], $ctx['userId'], $ctx['role']);
        if (!empty($visibleIds)) {
            $ph = implode(',', array_fill(0, count($visibleIds), '?'));
            $sql .= " AND user_id IN ($ph)"; $vals = array_merge($vals, $visibleIds);
        }
    } elseif ($userId) {
        /* Supervisor+ pidiendo visitas de un rep concreto */
        assert_can_manage_user($ctx, $userId);
        $sql .= ' AND user_id=?'; $vals[] = $userId;
    }

    if ($stopId) { $sql .= ' AND stop_id=?';  $vals[] = $stopId; }
    if ($date)   { $sql .= ' AND DATE(check_in_at)=?'; $vals[] = $date; }
    if ($from)   { $sql .= ' AND DATE(check_in_at)>=?'; $vals[] = $from; }
    if ($to)     { $sql .= ' AND DATE(check_in_at)<=?'; $vals[] = $to; }
    $sql .= ' ORDER BY check_in_at DESC LIMIT 500';
    json_out(array_map('_visit_out', db_all($sql, $vals)));
}
function visits_create(array $p, array $ctx): never {
    $b = body(); $id = uuid4(); $now = now_sql();
    db_run('INSERT INTO visits (id,org_id,user_id,session_id,stop_id,estado,form_data,kpi_data,photo_urls,notas,check_in_at,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [$id, $ctx['orgId'], $ctx['userId'],
         $b['sessionId'] ?? null, $b['stopId'] ?? null,
         $b['estado'] ?? null, to_json($b['formData'] ?? []),
         to_json($b['kpiData'] ?? []), to_json($b['photoUrls'] ?? []),
         $b['notas'] ?? null, $now, $now, $now]);
    json_out(_visit_out(db_one('SELECT * FROM visits WHERE id=?', [$id])), 201);
}
function visits_update(array $p, array $ctx): never {
    /* Solo el creador de la visita o supervisor+ puede editarla */
    $visit = db_one('SELECT user_id FROM visits WHERE org_id=? AND id=?', [$ctx['orgId'], $p[0]]);
    if (!$visit) json_error('Visita no encontrada', 404);
    $roleOrder = ['rep'=>0,'supervisor'=>1,'admin'=>2,'owner'=>3];
    $myLevel   = $roleOrder[$ctx['role']] ?? 0;
    if ($myLevel < 1 && $visit['user_id'] !== $ctx['userId']) {
        json_error('No puedes editar visitas de otros usuarios', 403);
    }
    $b = body(); $sets = []; $vals = [];
    foreach (['estado','notas'] as $f) {
        if (array_key_exists($f, $b)) { $sets[] = "$f=?"; $vals[] = $b[$f]; }
    }
    if (isset($b['formData']))  { $sets[] = 'form_data=?';  $vals[] = to_json($b['formData']); }
    if (isset($b['kpiData']))   { $sets[] = 'kpi_data=?';   $vals[] = to_json($b['kpiData']); }
    if (isset($b['photoUrls'])) { $sets[] = 'photo_urls=?'; $vals[] = to_json($b['photoUrls']); }
    if ($sets) { $sets[] = 'updated_at=?'; $vals[] = now_sql(); $vals[] = $p[0];
        db_run('UPDATE visits SET ' . implode(',', $sets) . ' WHERE id=?', $vals); }
    json_out(_visit_out(db_one('SELECT * FROM visits WHERE id=?', [$p[0]])));
}
function visits_delete(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    db_run('DELETE FROM visits WHERE org_id=? AND id=?', [$ctx['orgId'], $p[0]]);
    http_response_code(204); exit;
}
function _visit_out(array $v): array {
    $fd = json_col($v['form_data']) ?? [];
    $kd = json_col($v['kpi_data'])  ?? [];
    /* Retrocompatibilidad: si kpi_data está vacío (visitas anteriores al fix),
       extraer los campos kpi_* que están dentro de form_data */
    if (empty($kd) && !empty($fd)) {
        $kd = array_filter(
            $fd,
            fn($val, $key) => str_starts_with((string)$key, 'kpi_'),
            ARRAY_FILTER_USE_BOTH
        );
    }
    return ['id' => $v['id'], 'userId' => $v['user_id'],
            'stopId' => $v['stop_id'], 'sessionId' => $v['session_id'],
            'estado' => $v['estado'], 'notas' => $v['notas'],
            'formData' => $fd,
            'kpiData' => $kd,
            'photoUrls' => json_col($v['photo_urls']) ?? [],
            'checkInAt' => $v['check_in_at'],
            'checkOutAt' => $v['check_out_at'] ?? null,
            'updatedAt' => to_ts($v['updated_at'])];
}

/* ══════════════════════════════════════════════════════════
   FORMS & KPIS
   ══════════════════════════════════════════════════════════ */
function forms_list(array $p, array $ctx): never {
    json_out(array_map(fn($f) => array_merge($f, ['fields' => json_col($f['fields']) ?? []]),
        db_all('SELECT * FROM forms WHERE org_id=? ORDER BY name', [$ctx['orgId']])));
}
function forms_create(array $p, array $ctx): never {
    require_role($ctx, 'admin');
    $b = body(); $id = uuid4(); $now = now_sql();
    db_run('INSERT INTO forms (id,org_id,name,icon,fields,created_at,updated_at) VALUES (?,?,?,?,?,?,?)',
        [$id, $ctx['orgId'], $b['name'] ?? 'Formulario', $b['icon'] ?? 'fa-clipboard-check', to_json($b['fields'] ?? []), $now, $now]);
    json_out(db_one('SELECT * FROM forms WHERE id=?', [$id]), 201);
}
function forms_update(array $p, array $ctx): never {
    require_role($ctx, 'admin');
    $b = body(); $sets = []; $vals = [];
    if (isset($b['name']))   { $sets[] = 'name=?';   $vals[] = $b['name']; }
    if (isset($b['icon']))   { $sets[] = 'icon=?';   $vals[] = $b['icon']; }
    if (isset($b['fields'])) { $sets[] = 'fields=?'; $vals[] = to_json($b['fields']); }
    if ($sets) { $sets[] = 'updated_at=?'; $vals[] = now_sql(); $vals[] = $p[0];
        db_run('UPDATE forms SET ' . implode(',', $sets) . ' WHERE id=?', $vals); }
    json_out(db_one('SELECT * FROM forms WHERE id=?', [$p[0]]));
}
function forms_delete(array $p, array $ctx): never {
    require_role($ctx, 'admin');
    db_run('DELETE FROM forms WHERE org_id=? AND id=?', [$ctx['orgId'], $p[0]]);
    http_response_code(204); exit;
}
function kpis_list(array $p, array $ctx): never {
    json_out(db_all('SELECT * FROM kpi_defs WHERE org_id=? ORDER BY sort_order', [$ctx['orgId']]));
}
function kpis_create(array $p, array $ctx): never {
    require_role($ctx, 'admin');
    $b = body(); $id = uuid4(); $now = now_sql();
    db_run('INSERT INTO kpi_defs (id,org_id,label,unit,min_val,max_val,sort_order,created_at) VALUES (?,?,?,?,?,?,?,?)',
        [$id, $ctx['orgId'], $b['label'] ?? 'KPI', $b['unit'] ?? null,
         $b['minVal'] ?? null, $b['maxVal'] ?? null, $b['sortOrder'] ?? 0, $now]);
    json_out(db_one('SELECT * FROM kpi_defs WHERE id=?', [$id]), 201);
}
function kpis_delete(array $p, array $ctx): never {
    require_role($ctx, 'admin');
    db_run('DELETE FROM kpi_defs WHERE org_id=? AND id=?', [$ctx['orgId'], $p[0]]);
    http_response_code(204); exit;
}

/* ══════════════════════════════════════════════════════════
   USERS
   ══════════════════════════════════════════════════════════ */
function users_list(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    /* God puede ver usuarios de cualquier org — útil para mover usuarios */
    $targetOrg = $_GET['orgId'] ?? $ctx['orgId'];
    if ($targetOrg !== $ctx['orgId'] && ($ctx['pRole'] ?? null) !== 'god') {
        json_error('Solo god puede consultar otras organizaciones', 403);
    }
    $ctxForQuery = $ctx;
    if (($ctx['pRole'] ?? null) === 'god') {
        $ctxForQuery['orgId'] = $targetOrg;
        $ctxForQuery['role']  = 'owner'; /* God ve todo */
    }
    $members = get_visible_members($ctxForQuery['orgId'], $ctxForQuery['userId'], $ctxForQuery['role']);
    json_out($members);
}
function users_invite(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    $b = body();
    $email = strtolower(trim($b['email'] ?? ''));
    $role  = $b['role'] ?? 'rep';
    if (!valid_email($email)) json_error('Email inválido', 422);

    /* FIX: supervisor solo puede invitar reps — no supervisores ni admins */
    $roleOrder = ['rep'=>0,'supervisor'=>1,'admin'=>2,'owner'=>3];
    $myLevel    = $roleOrder[$ctx['role']] ?? 0;
    $targetLevel= $roleOrder[$role]        ?? 0;
    if ($targetLevel >= $myLevel) {
        json_error('No puedes invitar usuarios de igual o mayor rango que el tuyo', 403);
    }

    $tempPwd  = null;
    $isNew    = false;

    /* Si el usuario ya existe, añadir membresía */
    $user = db_one('SELECT id FROM users WHERE email=?', [$email]);
    if (!$user) {
        /* Usuario nuevo — generar contraseña temporal legible */
        $tempPwd = _gen_temp_password();
        $userId  = uuid4(); $now = now_sql();
        db_run('INSERT INTO users (id,email,password_hash,name,created_at,updated_at) VALUES (?,?,?,?,?,?)',
            [$userId, $email, password_hash($tempPwd, PASSWORD_BCRYPT, ['cost'=>12]), '', $now, $now]);
        $user  = ['id' => $userId];
        $isNew = true;
    }

    /* manager_id: usar el especificado, si no quien invita */
    $managerId = $b['managerId'] ?? $ctx['userId'];
    /* Validar que el manager pertenece a la org y tiene rango superior */
    if ($managerId !== $ctx['userId']) {
        $roleOrder = ['rep'=>0,'supervisor'=>1,'admin'=>2,'owner'=>3];
        $mgr = db_one('SELECT role FROM memberships WHERE org_id=? AND user_id=? AND active=1',
            [$ctx['orgId'], $managerId]);
        if (!$mgr || ($roleOrder[$mgr['role']]??0) <= ($roleOrder[$role]??0)) {
            $managerId = $ctx['userId']; /* fallback al invitador */
        }
    }

    $existing = db_one('SELECT id FROM memberships WHERE org_id=? AND user_id=?',
        [$ctx['orgId'], $user['id']]);
    if ($existing) {
        db_run('UPDATE memberships SET role=?,manager_id=?,active=1 WHERE id=?',
            [$role, $managerId, $existing['id']]);
    } else {
        db_run('INSERT INTO memberships (id,org_id,user_id,role,manager_id,invited_at) VALUES (?,?,?,?,?,?)',
            [uuid4(), $ctx['orgId'], $user['id'], $role, $managerId, now_sql()]);
    }

    json_out([
        'ok'       => true,
        'userId'   => $user['id'],
        'isNew'    => $isNew,
        'tempPwd'  => $tempPwd,
        'email'    => $email,
    ]);
}

/* Genera contraseña temporal legible: 3 grupos de 4 chars */
function _gen_temp_password(): string {
    $chars = 'abcdefghjkmnpqrstuvwxyz23456789'; /* sin 0,o,1,l,i para evitar confusiones */
    $pwd = '';
    for ($i = 0; $i < 12; $i++) {
        if ($i > 0 && $i % 4 === 0) $pwd .= '-';
        $pwd .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $pwd; /* formato: xxxx-xxxx-xxxx */
}
function users_update_role(array $p, array $ctx): never {
    require_role($ctx, 'admin');
    $b         = body();
    $role      = $b['role']      ?? null;
    $managerId = $b['managerId'] ?? null; /* opcional — cambiar manager */
    /* role es opcional — puede enviarse solo managerId para reasignar sin cambiar rol */
    if ($role && !in_array($role, ['rep','supervisor','admin'])) json_error('Rol inválido', 422);
    if (!$role && !$managerId) json_error('Se requiere role o managerId', 422);
    assert_can_manage_user($ctx, $p[0]);
    /* Si no se envía role, usar el actual */
    if (!$role) {
        $cur = db_one('SELECT role FROM memberships WHERE org_id=? AND user_id=?',
            [$ctx['orgId'], $p[0]]);
        $role = $cur['role'] ?? 'rep';
    }

    /* Validar que el nuevo manager pertenece a la org y tiene rango superior */
    if ($managerId) {
        $roleOrder = ['rep'=>0,'supervisor'=>1,'admin'=>2,'owner'=>3];
        $targetLevel = $roleOrder[$role] ?? 0;
        $mgr = db_one(
            'SELECT m.user_id, m.role FROM memberships m WHERE m.org_id=? AND m.user_id=? AND m.active=1',
            [$ctx['orgId'], $managerId]
        );
        if (!$mgr) json_error('Manager no encontrado en la org', 404);
        $mgrLevel = $roleOrder[$mgr['role']] ?? 0;
        if ($mgrLevel <= $targetLevel) {
            json_error('El manager debe tener un rango superior al rol asignado', 422);
        }
    }

    $sets = ['role=?'];
    $vals = [$role];
    if ($managerId) { $sets[] = 'manager_id=?'; $vals[] = $managerId; }
    $vals[] = $ctx['orgId'];
    $vals[] = $p[0];

    db_run('UPDATE memberships SET ' . implode(',', $sets) . ' WHERE org_id=? AND user_id=?', $vals);
    json_out(['ok' => true]);
}
function users_remove(array $p, array $ctx): never {
    require_role($ctx, 'admin');
    if ($p[0] === $ctx['userId']) json_error('No puedes eliminarte a ti mismo', 400);
    assert_can_manage_user($ctx, $p[0]);
    /* Archivar — solo God puede DELETE real */
    $now = now_sql();
    db_run('UPDATE memberships SET active=0, archived_at=?, archived_by=?
            WHERE org_id=? AND user_id=?',
        [$now, $ctx['userId'], $ctx['orgId'], $p[0]]);
    http_response_code(204); exit;
}

/* ── PATCH /users/:id/stops — asignar PDVs a un miembro ── */
/* ── PATCH /users/:id/org — mover usuario a otra org (solo God) ── */
function users_move_org(array $p, array $ctx): never {
    require_platform_role($ctx, 'god');
    $b = body();
    $newOrgId = $b['orgId'] ?? null;
    $newRole  = $b['role']  ?? 'rep';
    if (!$newOrgId) json_error('orgId requerido', 422);
    if (!in_array($newRole, ['rep','supervisor','admin','owner'])) json_error('Rol inválido', 422);

    /* Verificar que la org destino existe */
    $org = db_one('SELECT id FROM organizations WHERE id=?', [$newOrgId]);
    if (!$org) json_error('Organización no encontrada', 404);

    /* Desactivar membership actual en todas las orgs */
    db_run('UPDATE memberships SET active=0 WHERE user_id=?', [$p[0]]);

    /* Crear o reactivar membership en la nueva org */
    $existing = db_one('SELECT id FROM memberships WHERE org_id=? AND user_id=?',
        [$newOrgId, $p[0]]);
    $now = now_sql();
    if ($existing) {
        db_run('UPDATE memberships SET role=?, active=1, manager_id=NULL WHERE id=?',
            [$newRole, $existing['id']]);
    } else {
        db_run('INSERT INTO memberships (id,org_id,user_id,role,invited_at,joined_at) VALUES (?,?,?,?,?,?)',
            [uuid4(), $newOrgId, $p[0], $newRole, $now, $now]);
    }
    json_out(['ok' => true]);
}



function users_set_targets(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    $userId = $p[0];
    /* Solo puede editar objetivos de usuarios en su árbol */
    $roleLevel = ['rep' => 0, 'supervisor' => 1, 'admin' => 2, 'owner' => 3][$ctx['role']] ?? 0;
    $allowed = false;
    if ($roleLevel >= 2) {
        $subtree = _get_subtree_ids($ctx['orgId'], $ctx['userId']);
        $allowed = in_array($userId, $subtree);
    } else {
        $repIds  = _get_direct_report_ids($ctx['orgId'], $ctx['userId']);
        $allowed = in_array($userId, $repIds);
    }
    if (!$allowed) json_error('No puedes editar objetivos de este usuario', 403);

    $b = body();
    $targets = array_filter([
        'visits_week'   => isset($b['visits_week'])   ? max(0,(int)$b['visits_week'])   : null,
        'sessions_week' => isset($b['sessions_week'])  ? max(0,(int)$b['sessions_week']) : null,
    ], fn($v) => $v !== null);

    try {
        db_run(
            'UPDATE memberships SET targets=? WHERE org_id=? AND user_id=?',
            [empty($targets) ? null : json_encode($targets), $ctx['orgId'], $userId]
        );
    } catch (\Throwable $e) {
        /* columna targets no existe aún — devolver ok silencioso */
        json_out(['ok' => true, 'targets' => $targets, '_warn' => 'targets column not yet migrated']);
    }
    json_out(['ok' => true, 'targets' => $targets]);
}

function users_assign_stops(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');

    $targetUserId = $p[0];

    /* Verificar que el target pertenece a la misma org */
    $target = db_one(
        'SELECT m.role, m.zone_ids FROM memberships m
         WHERE m.org_id=? AND m.user_id=? AND m.active=1',
        [$ctx['orgId'], $targetUserId]
    );
    if (!$target) json_error('Usuario no encontrado en la org', 404);

    /* Supervisor solo puede asignar a reps — no a otros supervisores ni admins */
    $roleOrder = ['rep' => 0, 'supervisor' => 1, 'admin' => 2, 'owner' => 3];
    $myLevel     = $roleOrder[$ctx['role']] ?? 0;
    $targetLevel = $roleOrder[$target['role']] ?? 0;
    if ($myLevel <= $targetLevel && $ctx['role'] !== 'owner') {
        json_error('Solo puedes asignar PDVs a usuarios de menor rango', 403);
    }

    $stopIds = body()['stopIds'] ?? [];
    if (!is_array($stopIds)) json_error('stopIds debe ser un array', 422);

    /* Verificar que todos los stop_ids pertenecen a la org */
    if (!empty($stopIds)) {
        $ph = implode(',', array_fill(0, count($stopIds), '?'));
        $found = db_all(
            "SELECT id FROM stops WHERE org_id=? AND deleted=0 AND id IN ($ph)",
            array_merge([$ctx['orgId']], $stopIds)
        );
        $foundIds = array_column($found, 'id');
        $stopIds  = array_values(array_intersect($stopIds, $foundIds));
    }
    /* Cualquier rol >= supervisor puede asignar PDVs de la org a sus reps */

    db_run(
        'UPDATE memberships SET zone_ids=? WHERE org_id=? AND user_id=?',
        [json_encode($stopIds), $ctx['orgId'], $targetUserId]
    );

    json_out([
        'ok'      => true,
        'userId'  => $targetUserId,
        'stopIds' => $stopIds,
        'count'   => count($stopIds),
    ]);
}

/* ── GET /users/:id/stops — ver PDVs asignados a un miembro ── */
function users_get_stops(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');

    $targetUserId = $p[0];
    $membership = db_one(
        'SELECT m.role, m.zone_ids FROM memberships m
         WHERE m.org_id=? AND m.user_id=? AND m.active=1',
        [$ctx['orgId'], $targetUserId]
    );
    if (!$membership) json_error('Usuario no encontrado', 404);

    $stopIds = json_decode($membership['zone_ids'] ?? '[]', true) ?? [];
    json_out(['userId' => $targetUserId, 'stopIds' => $stopIds, 'count' => count($stopIds)]);
}

/* ══════════════════════════════════════════════════════════
   SCHEDULE
   ══════════════════════════════════════════════════════════ */
function schedule_get(array $p, array $ctx): never {
    $from = $_GET['from'] ?? date('Y-m-01');
    $to   = $_GET['to']   ?? date('Y-m-t');

    /* FIX: rep solo ve su propia agenda — nunca la de otros usuarios */
    if ($ctx['role'] === 'rep') {
        $rows = db_all(
            'SELECT * FROM schedules WHERE org_id=? AND assigned_to=? AND date BETWEEN ? AND ?',
            [$ctx['orgId'], $ctx['userId'], $from, $to]
        );
    } else {
        $rows = db_all(
            'SELECT * FROM schedules WHERE org_id=? AND date BETWEEN ? AND ?',
            [$ctx['orgId'], $from, $to]
        );
    }

    $map = [];
    foreach ($rows as $r) $map[$r['date']] = $r['route_id'];
    json_out($map);
}
function schedule_set(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    $b = body();
    $date    = $b['date']    ?? null;
    $routeId = $b['routeId'] ?? null;
    $userId  = $b['userId']  ?? $ctx['userId'];
    if (!$date || !$routeId) json_error('date y routeId requeridos', 422);
    /* Solo puede planificar para usuarios de su árbol */
    assert_can_schedule_for($ctx, $userId);
    $now = now_sql();
    db_run('INSERT INTO schedules (id,org_id,route_id,assigned_to,date,created_at)
            VALUES (?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE route_id=VALUES(route_id)',
        [uuid4(), $ctx['orgId'], $routeId, $userId, $date, $now]);
    json_out(['ok' => true]);
}
function schedule_delete(array $p, array $ctx): never {
    require_role($ctx, 'supervisor');
    /* p[0] = date, p[1] = userId (opcional) — si no se especifica, borra el del propio usuario */
    $targetUser = $p[1] ?? $ctx['userId'];
    db_run('DELETE FROM schedules WHERE org_id=? AND date=? AND assigned_to=?',
        [$ctx['orgId'], $p[0], $targetUser]);
    http_response_code(204); exit;
}
