<?php
/* ══════════════════════════════════════════════════════════
   SYNC — push · pull · import
   Replica exacta de sync.service.ts
   ══════════════════════════════════════════════════════════ */

function sync_push(array $params, array $ctx): never {
    rate_limit('sync_push_' . $ctx['orgId'], 120, 60);

    $b       = body();
    $changes = $b['changes'] ?? [];
    if (!is_array($changes)) json_error('changes debe ser array', 422);
    if (count($changes) > 500) json_error('Máximo 500 cambios por batch', 422);

    /* S-02: Idempotency key — evitar duplicados en reenvíos de cola */
    $requestId = $b['requestId'] ?? null;
    if ($requestId) {
        $existing = db_one('SELECT id FROM idempotency_keys WHERE id = ?', [$requestId]);
        if ($existing) {
            json_out(['applied' => 0, 'conflicts' => [], 'idempotent' => true]);
        }
        db_run('INSERT IGNORE INTO idempotency_keys (id, created_at) VALUES (?,?)',
            [$requestId, now_sql()]);
        /* Purgar keys >24h — piggyback */
        db_run('DELETE FROM idempotency_keys WHERE created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)', []);
    }

    $applied   = 0;
    $conflicts = [];

    foreach ($changes as $entry) {
        try {
            $result = _process_entry($ctx['orgId'], $ctx['userId'], $entry);
            if (isset($result['conflict'])) {
                $conflicts[] = $result['conflict'];
            } else {
                $applied++;
            }
        } catch (Throwable $e) {
            error_log("Sync error [{$entry['collection']}/{$entry['key']}]: " . $e->getMessage());
        }
    }

    json_out(['applied' => $applied, 'conflicts' => $conflicts]);
}

function sync_pull(array $params, array $ctx): never {
    $since = (int) ($_GET['since'] ?? 0);
    json_out(_get_delta($ctx['orgId'], $ctx['userId'], $ctx['role'], $since));
}

function sync_import(array $params, array $ctx): never {
    rate_limit('sync_import_' . $ctx['orgId'], 5, 3600);
    $dump   = body();
    $result = _import_dump($ctx['orgId'], $dump);
    json_out($result, 201);
}

/* ── Procesar entrada individual ── */
function _process_entry(string $orgId, string $userId, array $entry): array {
    $op         = $entry['op']         ?? '';
    $collection = $entry['collection'] ?? '';
    $key        = $entry['key']        ?? '';
    $data       = $entry['data']       ?? null;
    $ts         = (int) ($entry['ts']  ?? 0);

    if ($op === 'delete') {
        _soft_delete($orgId, $collection, $key);
        return [];
    }

    if (!$data) return [];

    /* Buscar existente para comparar timestamps */
    $existing = _find_existing($orgId, $collection, $key);

    /* Regla: gana el updatedAt más reciente */
    if ($existing) {
        $existingTs = strtotime($existing['updated_at'] ?? '') * 1000;
        if ($existingTs > $ts) {
            return ['conflict' => ['collection' => $collection, 'key' => $key, 'serverWins' => $existing]];
        }
    }

    /* Excepción: estado finished no retrocede */
    if ($collection === 'sessions' && ($existing['state'] ?? '') === 'finished' && ($data['state'] ?? '') !== 'finished') {
        return ['conflict' => ['collection' => $collection, 'key' => $key, 'serverWins' => $existing]];
    }

    /* Excepción: fotos se fusionan */
    if ($collection === 'visits' && $existing && !empty($existing['photo_urls'])) {
        $serverPhotos = json_col($existing['photo_urls']) ?? [];
        $clientPhotos = $data['photo_urls'] ?? $data['photoUrls'] ?? [];
        $data['photo_urls'] = array_values(array_unique(array_merge($serverPhotos, $clientPhotos)));
    }

    _upsert($orgId, $userId, $collection, $key, $data, $ts);
    return [];
}

/* ── Pull delta ── */
function _get_delta(string $orgId, string $userId, string $role, int $since): array {
    $sinceDate = date('Y-m-d H:i:s', intdiv($since, 1000));

    /* Rep: recibe SIEMPRE las rutas de su schedule (sin filtro de updated_at)
       para garantizar que llegan aunque ya existieran antes del alta del rep */
    if ($role === 'rep') {
        $routeRows = db_all(
            'SELECT DISTINCT r.* FROM routes r
             INNER JOIN schedules s ON s.route_id = r.id
             WHERE r.org_id=? AND r.deleted=0
               AND s.assigned_to=? AND s.date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)',
            [$orgId, $userId]
        );
    } else {
        $routeRows = db_all('SELECT * FROM routes WHERE org_id=? AND updated_at>?', [$orgId, $sinceDate]);
    }

    /* Filtrar stops por zone_ids para rep/supervisor con asignación.
       IMPORTANTE: el rep siempre recibe los stops de sus rutas asignadas
       aunque no estén en zone_ids — necesarios para ejecutar la jornada. */
    $membership = db_one(
        'SELECT zone_ids FROM memberships WHERE org_id=? AND user_id=? AND active=1',
        [$orgId, $userId]
    );
    $zoneIds   = json_decode($membership['zone_ids'] ?? '[]', true) ?? [];
    $roleOrder = ['rep' => 0, 'supervisor' => 1, 'admin' => 2, 'owner' => 3];
    $roleLevel = $roleOrder[$role] ?? 0;

    if ($roleLevel <= 1) {
        /* Obtener stop_ids de todas las rutas asignadas al rep en los próximos 30 días */
        $assignedRoutes = db_all(
            'SELECT DISTINCT r.stop_ids FROM routes r
             INNER JOIN schedules s ON s.route_id = r.id
             WHERE r.org_id=? AND r.deleted=0
               AND s.assigned_to=? AND s.date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)',
            [$orgId, $userId]
        );
        $routeStopIds = [];
        foreach ($assignedRoutes as $ar) {
            $ids = json_decode($ar['stop_ids'] ?? '[]', true) ?? [];
            $routeStopIds = array_merge($routeStopIds, $ids);
        }
        $routeStopIds = array_unique($routeStopIds);

        /* Stops de rutas asignadas: SIEMPRE sin filtro updated_at
           (pueden existir en BD desde antes del primer sync del rep)
           Stops de zone_ids: delta incremental con updated_at */
        $routeStopIds = array_unique($routeStopIds);
        $zoneOnlyIds  = array_diff(array_unique($zoneIds), $routeStopIds);

        $stopRows = [];
        /* 1. Stops de rutas asignadas — siempre completos */
        if (!empty($routeStopIds)) {
            $ph = implode(',', array_fill(0, count($routeStopIds), '?'));
            $stopRows = db_all(
                "SELECT * FROM stops WHERE org_id=? AND deleted=0 AND id IN ($ph)",
                array_merge([$orgId], $routeStopIds)
            );
        }
        /* 2. Stops de zone_ids adicionales — delta incremental */
        if (!empty($zoneOnlyIds)) {
            $ph = implode(',', array_fill(0, count($zoneOnlyIds), '?'));
            $zoneStops = db_all(
                "SELECT * FROM stops WHERE org_id=? AND updated_at>? AND id IN ($ph)",
                array_merge([$orgId, $sinceDate], $zoneOnlyIds)
            );
            $stopRows = array_merge($stopRows, $zoneStops);
        }
    } else {
        $stopRows = db_all('SELECT * FROM stops WHERE org_id=? AND updated_at>?', [$orgId, $sinceDate]);
    }
    /* schedule: filtro incremental + aislamiento por rol.
       Rep: solo sus propios schedules (assigned_to=userId).
       Supervisor+: todos los schedules de la org. */
    $today = date('Y-m-d');
    if ($role === 'rep') {
        $scheduleRows = db_all(
            'SELECT * FROM schedules WHERE org_id=? AND assigned_to=? AND (updated_at>? OR date>=?)',
            [$orgId, $userId, $sinceDate, $today]
        );
    } else {
        $scheduleRows = db_all(
            'SELECT * FROM schedules WHERE org_id=? AND (updated_at>? OR date>=?)',
            [$orgId, $sinceDate, $today]
        );
    }
    /* Filtrar sessions/visits por jerarquía — cada rol ve solo su árbol */
    $visibleIds = get_visible_user_ids($orgId, $userId, $role);
    if (count($visibleIds) === 1 && $visibleIds[0] === $userId) {
        /* Rep: solo el suyo */
        $sessionRows = db_all('SELECT * FROM sessions WHERE org_id=? AND user_id=? AND updated_at>?', [$orgId, $userId, $sinceDate]);
        $visitRows   = db_all('SELECT * FROM visits   WHERE org_id=? AND user_id=? AND updated_at>?', [$orgId, $userId, $sinceDate]);
    } else {
        $ph = implode(',', array_fill(0, count($visibleIds), '?'));
        $sessionRows = db_all(
            "SELECT * FROM sessions WHERE org_id=? AND user_id IN ($ph) AND updated_at>?",
            array_merge([$orgId], $visibleIds, [$sinceDate])
        );
        $visitRows = db_all(
            "SELECT * FROM visits WHERE org_id=? AND user_id IN ($ph) AND updated_at>?",
            array_merge([$orgId], $visibleIds, [$sinceDate])
        );
    }
    $formRows     = db_all('SELECT * FROM forms     WHERE org_id=? AND updated_at>?', [$orgId, $sinceDate]);
    $kpiRows      = db_all('SELECT * FROM kpi_defs  WHERE org_id=? AND created_at>?', [$orgId, $sinceDate]);

    /* schedule: para rep → {date: routeId} con sus asignaciones
       para supervisor+ → {date: routeId} con todos los schedules de la org
       El campo assigned_to se incluye para que el frontend pueda diferenciar */
    $scheduleMap = [];
    foreach ($scheduleRows as $s) {
        if ($role === 'rep') {
            /* Rep: solo su propio schedule */
            $scheduleMap[$s['date']] = $s['route_id'];
        } else {
            /* Supervisor+: schedule propio en la clave simple, todos en _all */
            if ($s['assigned_to'] === $userId) {
                $scheduleMap[$s['date']] = $s['route_id'];
            }
            /* Guardar todos para la vista de equipo */
            $scheduleMap['_all'][$s['date']][] = [
                'routeId'    => $s['route_id'],
                'assignedTo' => $s['assigned_to'],
            ];
        }
    }

    /* stops: { id: stop } */
    $stopsMap = [];
    foreach ($stopRows as $s) $stopsMap[$s['id']] = _map_stop($s);

    /* sessions: { routeId_date: session } */
    $sessionsMap = [];
    foreach ($sessionRows as $s) $sessionsMap["{$s['route_id']}_{$s['date']}"] = _map_session($s);

    /* visits */
    $visitsMap = [];
    foreach ($visitRows as $v) $visitsMap[$v['id']] = _map_visit($v);

    $hasChanges = count($routeRows) + count($stopRows) + count($sessionRows) + count($visitRows) > 0;

    return [
        'routes'     => array_map('_map_route', $routeRows),
        'stops'      => $stopsMap,
        'schedule'   => $scheduleMap,
        'sessions'   => $sessionsMap,
        'visits'     => $visitsMap,
        'forms'      => $formRows,
        'kpi_defs'   => $kpiRows,
        'serverTs'   => round(microtime(true) * 1000),
        'hasChanges' => $hasChanges,
    ];
}

/* ── Import dump desde localStorage ── */
function _import_dump(string $orgId, array $dump): array {
    $imported = 0;
    $now = now_sql();

    foreach ($dump['routes'] ?? [] as $r) {
        $id = $r['id'] ?? uuid4();
        $stopIds = to_json($r['stops'] ?? []);
        db_run('INSERT IGNORE INTO routes (id,org_id,name,stop_ids,created_at,updated_at)
                VALUES (?,?,?,?,?,?)',
            [$id, $orgId, $r['name'] ?? 'Sin nombre', $stopIds, $now, $now]);
        $imported++;
    }

    foreach ($dump['stops'] ?? [] as $s) {
        if (is_array($dump['stops']) && isset($dump['stops'][0])) {
            /* Array */
        } else {
            $s = $s; /* Object map — iterar valores */
        }
        $id = $s['id'] ?? uuid4();
        db_run('INSERT IGNORE INTO stops
                (id,org_id,name,addr,town,zip,lat,lng,tags,contact,phone,mobile,email,horario,notes,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [$id, $orgId, $s['name'] ?? '—',
             $s['addr'] ?? null, $s['town'] ?? null, $s['zip'] ?? null,
             $s['lat'] ?? null, $s['lng'] ?? null,
             to_json($s['tags'] ?? []),
             $s['contact'] ?? null, $s['phone'] ?? null,
             $s['mobile'] ?? null, $s['email'] ?? null,
             $s['horario'] ?? null, $s['notes'] ?? null,
             $now, $now]);
        $imported++;
    }

    return ['imported' => $imported];
}

/* ── Helpers internos ── */
function _find_existing(string $orgId, string $collection, string $key): ?array {
    $table = match($collection) {
        'routes'   => 'routes',
        'stops'    => 'stops',
        'sessions' => 'sessions',
        'visits'   => 'visits',
        default    => null,
    };
    if (!$table) return null;
    return db_one("SELECT * FROM $table WHERE org_id=? AND id=?", [$orgId, $key]);
}

function _upsert(string $orgId, string $userId, string $collection, string $key, array $data, int $ts): void {
    $now = date('Y-m-d H:i:s', intdiv($ts, 1000));

    switch ($collection) {
        case 'routes':
            $stopIds = to_json($data['stops'] ?? []);
            db_run('INSERT INTO routes (id,org_id,name,stop_ids,created_at,updated_at)
                    VALUES (?,?,?,?,?,?)
                    ON DUPLICATE KEY UPDATE name=VALUES(name), stop_ids=VALUES(stop_ids), updated_at=VALUES(updated_at)',
                [$key, $orgId, $data['name'] ?? '', $stopIds, $now, $now]);
            break;

        case 'stops':
            db_run('INSERT INTO stops (id,org_id,name,addr,town,zip,lat,lng,tags,contact,phone,mobile,email,horario,notes,created_at,updated_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON DUPLICATE KEY UPDATE name=VALUES(name),addr=VALUES(addr),town=VALUES(town),
                    zip=VALUES(zip),lat=VALUES(lat),lng=VALUES(lng),tags=VALUES(tags),updated_at=VALUES(updated_at)',
                [$key, $orgId, $data['name'] ?? '—',
                 $data['addr'] ?? null, $data['town'] ?? null, $data['zip'] ?? null,
                 $data['lat'] ?? null, $data['lng'] ?? null,
                 to_json($data['tags'] ?? []),
                 $data['contact'] ?? null, $data['phone'] ?? null,
                 $data['mobile'] ?? null, $data['email'] ?? null,
                 $data['horario'] ?? null, $data['notes'] ?? null,
                 $now, $now]);
            break;

        case 'sessions':
            $startedAt  = isset($data['startTs'])    ? date('Y-m-d H:i:s', intdiv((int)$data['startTs'],    1000)) : null;
            $finishedAt = isset($data['finishedTs'])  ? date('Y-m-d H:i:s', intdiv((int)$data['finishedTs'], 1000)) : null;
            $syncWasFinishing = (($data['state'] ?? '') === 'finished' &&
                                 ($existing['state'] ?? '') !== 'finished');
            db_run('INSERT INTO sessions
                    (id,org_id,user_id,route_id,date,state,elapsed_s,paused_s,distance_km,gps_path,started_at,finished_at,created_at,updated_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON DUPLICATE KEY UPDATE
                    state=VALUES(state),elapsed_s=VALUES(elapsed_s),
                    paused_s=VALUES(paused_s),
                    distance_km=VALUES(distance_km),gps_path=VALUES(gps_path),
                    started_at=COALESCE(started_at,VALUES(started_at)),
                    finished_at=VALUES(finished_at),
                    updated_at=VALUES(updated_at)',
                [$key, $orgId, $userId,
                 $data['routeId'] ?? null,
                 $data['dateStr'] ?? $data['date'] ?? null,
                 $data['state'] ?? 'idle',
                 (int)($data['elapsed'] ?? 0),
                 (int)($data['pausedS'] ?? $data['paused_s'] ?? 0),
                 (float)($data['distance'] ?? 0),
                 to_json($data['gpsPath'] ?? []),
                 $startedAt, $finishedAt,
                 $now, $now]);
            /* Poblar daily_stats si la sesión se acaba de finalizar */
            if ($syncWasFinishing ?? false) {
                $dateStr = $data['dateStr'] ?? $data['date'] ?? null;
                if ($dateStr) _upsert_daily_stats($orgId, $userId, $dateStr);
            }
            break;

        case 'visits':
            /* check_in_at / check_out_at: convertir ms a datetime */
            $checkInAt  = isset($data['checkInTs'])  ? date('Y-m-d H:i:s', intdiv((int)$data['checkInTs'],  1000)) : null;
            $checkOutAt = isset($data['checkOutTs']) ? date('Y-m-d H:i:s', intdiv((int)$data['checkOutTs'], 1000)) : null;
            /* Extraer campos kpi_* del objeto completo para kpi_data separado */
            $kpiData = array_filter(
                $data,
                fn($v, $k) => str_starts_with((string)$k, 'kpi_'),
                ARRAY_FILTER_USE_BOTH
            );
            db_run('INSERT INTO visits
                    (id,org_id,user_id,session_id,stop_id,estado,form_data,kpi_data,photo_urls,notas,
                     check_in_at,check_out_at,lat_in,lng_in,lat_out,lng_out,created_at,updated_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON DUPLICATE KEY UPDATE
                    estado=VALUES(estado),form_data=VALUES(form_data),
                    kpi_data=VALUES(kpi_data),
                    photo_urls=VALUES(photo_urls),notas=VALUES(notas),
                    check_in_at=COALESCE(check_in_at,VALUES(check_in_at)),
                    check_out_at=VALUES(check_out_at),
                    lat_in=COALESCE(lat_in,VALUES(lat_in)),
                    lng_in=COALESCE(lng_in,VALUES(lng_in)),
                    lat_out=VALUES(lat_out),lng_out=VALUES(lng_out),
                    updated_at=VALUES(updated_at)',
                [$key, $orgId, $userId,
                 $data['sessionId'] ?? null,
                 $data['stopId']    ?? null,
                 $data['estado']    ?? null,
                 to_json($data),
                 to_json($kpiData),
                 to_json($data['photo_urls'] ?? $data['photos'] ?? []),
                 $data['notas']     ?? null,
                 $checkInAt, $checkOutAt,
                 isset($data['latIn'])  ? (float)$data['latIn']  : null,
                 isset($data['lngIn'])  ? (float)$data['lngIn']  : null,
                 isset($data['latOut']) ? (float)$data['latOut'] : null,
                 isset($data['lngOut']) ? (float)$data['lngOut'] : null,
                 $now, $now]);
            break;
    }
}

function _soft_delete(string $orgId, string $collection, string $key): void {
    if ($collection === 'routes') {
        db_run('UPDATE routes SET deleted=1, updated_at=? WHERE org_id=? AND id=?',
            [now_sql(), $orgId, $key]);
    } elseif ($collection === 'stops') {
        db_run('UPDATE stops SET deleted=1, updated_at=? WHERE org_id=? AND id=?',
            [now_sql(), $orgId, $key]);
    }
}

/* Mappers → formato PWA */
function _map_route(array $r): array {
    return ['id' => $r['id'], 'name' => $r['name'],
            'stops' => json_col($r['stop_ids']) ?? [],
            'deleted' => (bool)$r['deleted'],
            'updatedAt' => to_ts($r['updated_at'])];
}
function _map_stop(array $s): array {
    return ['id' => $s['id'], 'name' => $s['name'],
            'addr' => $s['addr'], 'town' => $s['town'], 'zip' => $s['zip'],
            'lat' => $s['lat'] ? (float)$s['lat'] : null,
            'lng' => $s['lng'] ? (float)$s['lng'] : null,
            'tags' => json_col($s['tags']) ?? [],
            'contact' => $s['contact'], 'phone' => $s['phone'],
            'mobile' => $s['mobile'], 'email' => $s['email'],
            'horario' => $s['horario'], 'notes' => $s['notes'],
            'deleted' => (bool)$s['deleted'],
            'updatedAt' => to_ts($s['updated_at'])];
}
function _map_session(array $s): array {
    return ['state' => $s['state'], 'elapsed' => (int)$s['elapsed_s'],
            'pausedS' => (int)($s['paused_s'] ?? 0),
            'distance' => (float)$s['distance_km'],
            'gpsPath' => json_col($s['gps_path']) ?? [],
            'updatedAt' => to_ts($s['updated_at'])];
}
function _map_visit(array $v): array {
    $fd = json_col($v['form_data']) ?? [];
    return array_merge($fd, [
        'id'          => $v['id'],
        'stopId'      => $v['stop_id'],
        'sessionId'   => $v['session_id'],
        'estado'      => $v['estado'],
        'notas'       => $v['notas'],
        'photos'      => json_col($v['photo_urls']) ?? [],
        'checkInAt'   => to_ts($v['check_in_at']  ?? null),
        'checkOutAt'  => to_ts($v['check_out_at'] ?? null),
        'latIn'       => $v['lat_in']   ? (float)$v['lat_in']  : null,
        'lngIn'       => $v['lng_in']   ? (float)$v['lng_in']  : null,
        'latOut'      => $v['lat_out']  ? (float)$v['lat_out'] : null,
        'lngOut'      => $v['lng_out']  ? (float)$v['lng_out'] : null,
        'updatedAt'   => to_ts($v['updated_at']),
    ]);
}
