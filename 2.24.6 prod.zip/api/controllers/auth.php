<?php
/* ══════════════════════════════════════════════════════════
   AUTH — register · login · refresh · logout · me
   ══════════════════════════════════════════════════════════ */

/* auth_register movido a controllers/registration.php — v2.12 */
function auth_login(array $params, ?array $ctx): never {
    rate_limit('login', 20, 900);

    $email    = strtolower(trim(body()['email']    ?? ''));
    $password = body()['password'] ?? '';

    $user = db_one('SELECT * FROM users WHERE email = ?', [$email]);
    if (!$user || !password_verify($password, $user['password_hash'])) {
        json_error('Credenciales incorrectas', 401);
    }

    $membership = db_one(
        'SELECT m.*, o.id as org_id, o.name as org_name, o.plan
         FROM memberships m
         JOIN organizations o ON o.id = m.org_id
         WHERE m.user_id = ? AND m.active = 1
         LIMIT 1',
        [$user['id']]
    );
    if (!$membership) json_error('Sin organización activa', 403);

    db_run('UPDATE users SET last_login_at = ? WHERE id = ?', [now_sql(), $user['id']]);

    $u = ['id' => $user['id'], 'name' => $user['name'], 'email' => $user['email']];
    $o = ['id' => $membership['org_id'], 'name' => $membership['org_name'], 'plan' => $membership['plan']];
    _purge_stale_tokens();
    json_out(_build_session($u, $o, $membership['role']));
}

function auth_refresh(array $params, ?array $ctx): never {
    rate_limit('refresh', 60, 3600);

    $rawToken = body()['refresh_token'] ?? '';
    if (!$rawToken) json_error('Refresh token requerido', 422);

    $result = _rotate_refresh_token($rawToken);
    if (!$result) json_error('Refresh token inválido o expirado', 401);

    ['userId' => $userId, 'newRaw' => $newRaw] = $result;

    $membership = db_one(
        'SELECT m.role, o.id as org_id, o.name as org_name, o.plan
         FROM memberships m JOIN organizations o ON o.id = m.org_id
         WHERE m.user_id = ? AND m.active = 1
         LIMIT 1',
        [$userId]
    );
    if (!$membership) json_error('Sin organización activa', 403);

    $user = db_one('SELECT id, name, email FROM users WHERE id = ?', [$userId]);
    if (!$user) json_error('Usuario no encontrado', 404);

    $pr    = null;
    try { $pr = db_one('SELECT role FROM platform_roles WHERE user_id = ?', [$userId]); } catch (\Throwable $e) {}
    $pRole = $pr ? $pr['role'] : null;

    $accessToken = jwt_issue($userId, $membership['org_id'], $membership['role'], $membership['plan'], $pRole);
    _purge_stale_tokens();
    json_out(['access_token' => $accessToken, 'refresh_token' => $newRaw]);
}

function auth_logout(array $params, ?array $ctx): never {
    $raw = body()['refresh_token'] ?? null;
    if ($raw) _rotate_refresh_token($raw); /* Invalida el token */
    json_out(['ok' => true]);
}

function auth_me(array $params, array $ctx): never {
    $user = db_one('SELECT id, name, email FROM users WHERE id = ?', [$ctx['userId']]);
    if (!$user) json_error('No encontrado', 404);
    /* settings — defensivo si columna no existe aún (pre-v2.17) */
    $settings = (object)[];
    try {
        $s = db_one('SELECT settings FROM users WHERE id = ?', [$ctx['userId']]);
        $settings = json_decode($s['settings'] ?? '{}', true) ?: (object)[];
    } catch (\Throwable $e) {}
    json_out([
        'id'       => $user['id'],
        'name'     => $user['name'],
        'email'    => $user['email'],
        'role'     => $ctx['role'],
        'orgId'    => $ctx['orgId'],
        'plan'     => $ctx['plan'],
        'pRole'    => $ctx['pRole'],
        'settings' => $settings,
    ]);
}


/* ── PATCH /auth/settings — guardar preferencias del usuario ── */
function auth_settings(array $params, array $ctx): never {
    $b = body();
    /* Solo permitir claves de settings conocidas */
    $allowed = ['theme', 'notifEnabled', 'notifTime'];
    $settings = [];
    try {
        $current  = db_one('SELECT settings FROM users WHERE id=?', [$ctx['userId']]);
        $settings = json_decode($current['settings'] ?? '{}', true) ?: [];
    } catch (\Throwable $e) { /* columna settings aún no migrada */ }
    foreach ($allowed as $key) {
        if (array_key_exists($key, $b)) {
            $settings[$key] = $b[$key];
        }
    }
    try {
        db_run('UPDATE users SET settings=? WHERE id=?',
            [json_encode($settings), $ctx['userId']]);
    } catch (\Throwable $e) { /* columna settings aún no existe — ignorar silenciosamente */ }
    json_out(['ok' => true, 'settings' => $settings]);
}

/* ── Helpers internos ─────────────────────────────── */

function _build_session(array $user, array $org, string $role): array {
    /* Consultar rol de plataforma — null para usuarios normales */
    $pr    = null;
    try { $pr = db_one('SELECT role FROM platform_roles WHERE user_id = ?', [$user['id']]); } catch (\Throwable $e) {}
    $pRole = $pr ? $pr['role'] : null;

    /* Cargar settings del usuario — defensivo si columna no existe aún (pre-v2.17) */
    $settings = (object)[];
    try {
        $userFull = db_one('SELECT settings FROM users WHERE id=?', [$user['id']]);
        $settings = json_decode($userFull['settings'] ?? '{}', true) ?: (object)[];
    } catch (\Throwable $e) { /* columna settings aún no migrada — ignorar */ }

    $accessToken  = jwt_issue($user['id'], $org['id'], $role, $org['plan'], $pRole);
    $refreshToken = _issue_refresh_token($user['id']);
    return [
        'access_token'  => $accessToken,
        'refresh_token' => $refreshToken,
        'user' => [
            'id'       => $user['id'],
            'name'     => $user['name'],
            'email'    => $user['email'],
            'role'     => $role,
            'orgId'    => $org['id'],
            'plan'     => $org['plan'],
            'pRole'    => $pRole,
            'settings' => $settings,
        ],
        'org' => ['id' => $org['id'], 'name' => $org['name'], 'plan' => $org['plan']],
    ];
}

function _issue_refresh_token(string $userId): string {
    /* Formato: selector:validator
       selector (16 bytes hex) → clave de lookup O(1) con índice UNIQUE
       validator (32 bytes hex) → verificado con hash_equals(sha256) */
    $selector  = bin2hex(random_bytes(16));
    $validator = bin2hex(random_bytes(32));
    $hash      = hash('sha256', $validator);
    $expires   = date('Y-m-d H:i:s', strtotime('+' . RT_EXPIRES_DAYS . ' days'));
    $hint      = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 100);

    db_run('INSERT INTO refresh_tokens (id,user_id,selector,token_hash,expires_at,device_hint,created_at)
            VALUES (?,?,?,?,?,?,?)',
        [uuid4(), $userId, $selector, $hash, $expires, $hint, now_sql()]);

    return $selector . ':' . $validator;
}

function _rotate_refresh_token(string $rawToken): ?array {
    $parts = explode(':', $rawToken, 2);
    if (count($parts) !== 2) return null;
    [$selector, $validator] = $parts;

    /* O(1): buscar solo el token con ese selector */
    $rt = db_one(
        'SELECT * FROM refresh_tokens
         WHERE selector = ? AND revoked = 0 AND expires_at > NOW()',
        [$selector]
    );
    if (!$rt) return null;

    /* Verificación timing-safe contra timing attacks */
    if (!hash_equals($rt['token_hash'], hash('sha256', $validator))) return null;

    /* Revocar el viejo */
    db_run('UPDATE refresh_tokens SET revoked = 1 WHERE id = ?', [$rt['id']]);

    /* Emitir uno nuevo */
    $newSel  = bin2hex(random_bytes(16));
    $newVal  = bin2hex(random_bytes(32));
    $newHash = hash('sha256', $newVal);
    $expires = date('Y-m-d H:i:s', strtotime('+' . RT_EXPIRES_DAYS . ' days'));
    db_run('INSERT INTO refresh_tokens (id,user_id,selector,token_hash,expires_at,created_at)
            VALUES (?,?,?,?,?,?)',
        [uuid4(), $rt['user_id'], $newSel, $newHash, $expires, now_sql()]);

    return ['userId' => $rt['user_id'], 'newRaw' => $newSel . ':' . $newVal];
}


/* ── A-03: Purgar tokens expirados y revocados (piggyback) ── */
function _purge_stale_tokens(): void {
    /* Expirados: borrar inmediatamente */
    db_run('DELETE FROM refresh_tokens WHERE expires_at < NOW()', []);
    /* Revocados con más de 7 días: borrar para no acumular */
    db_run('DELETE FROM refresh_tokens WHERE revoked = 1 AND created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)', []);
}

/* ── L-02: Verificar límite de usuarios por plan ── */
function _check_seat_limit(string $orgId): void {
    $org = db_one('SELECT seat_limit FROM organizations WHERE id = ?', [$orgId]);
    if (!$org) return;
    $count = db_one('SELECT COUNT(*) AS n FROM memberships WHERE org_id = ? AND active = 1', [$orgId]);
    if ((int)($count['n'] ?? 0) >= (int)($org['seat_limit'] ?? 3)) {
        json_error('Límite de usuarios del plan alcanzado. Actualiza tu plan para añadir más miembros.', 402);
    }
}

/* ── PATCH /auth/password — cambiar contraseña propia ── */
function auth_change_password(array $params, array $ctx): never {
    $b       = body();
    $current = $b['current'] ?? '';
    $newPwd  = $b['new']     ?? '';
    if (!$current || !$newPwd) json_error('Campos requeridos', 422);
    if (strlen($newPwd) < 6)   json_error('La contraseña debe tener al menos 6 caracteres', 422);

    $user = db_one('SELECT id, password_hash FROM users WHERE id=?', [$ctx['userId']]);
    if (!$user || !password_verify($current, $user['password_hash'])) {
        json_error('Contraseña actual incorrecta', 401);
    }

    $hash = password_hash($newPwd, PASSWORD_BCRYPT, ['cost' => 12]);
    db_run('UPDATE users SET password_hash=?, updated_at=? WHERE id=?',
        [$hash, now_sql(), $ctx['userId']]);

    /* Revocar todos los refresh tokens para forzar re-login en otros dispositivos */
    db_run('UPDATE refresh_tokens SET revoked=1 WHERE user_id=?', [$ctx['userId']]);

    json_out(['ok' => true]);
}

/* ══════════════════════════════════════════════════════════
   RECUPERACIÓN DE CONTRASEÑA
   POST /auth/forgot  → genera token y envía email
   POST /auth/reset   → verifica token y cambia contraseña
   ══════════════════════════════════════════════════════════ */

function auth_forgot(array $params, ?array $ctx): never {
    rate_limit('forgot', 5, 900); /* 5 intentos / 15 min por IP */

    $email = strtolower(trim(body()['email'] ?? ''));
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_error('Email inválido', 422);
    }

    /* Respuesta siempre igual para no revelar si el email existe */
    $ok = ['ok' => true, 'message' => 'Si ese email existe, recibirás un enlace en breve.'];

    $user = db_one('SELECT id, name FROM users WHERE email = ?', [$email]);
    if (!$user) json_out($ok); /* Salida silenciosa */

    /* Reutilizar tabla refresh_tokens: selector=token de reset, tipo diferenciado
       por device_hint='pwd_reset' */
    /* Invalidar resets anteriores del mismo usuario */
    db_run("UPDATE refresh_tokens SET revoked=1
            WHERE user_id=? AND device_hint='pwd_reset' AND revoked=0",
        [$user['id']]);

    /* Generar token de reset */
    $selector  = bin2hex(random_bytes(16));
    $validator = bin2hex(random_bytes(32));
    $hash      = hash('sha256', $validator);
    $expires   = date('Y-m-d H:i:s', strtotime('+1 hour'));

    db_run("INSERT INTO refresh_tokens
                (id, user_id, selector, token_hash, expires_at, device_hint, created_at)
            VALUES (?,?,?,?,?,?,?)",
        [uuid4(), $user['id'], $selector, $hash, $expires, 'pwd_reset', now_sql()]);

    $resetLink = APP_URL . '#reset-password/' . $selector . ':' . $validator;
    $name      = $user['name'] ?: 'Usuario';

    $subject = 'Recuperar contraseña — Gestor de Rutas Pro';
    $body    = "Hola {$name},\n\n"
             . "Has solicitado recuperar tu contraseña en Gestor de Rutas Pro.\n\n"
             . "Haz clic en el siguiente enlace para crear una nueva contraseña.\n"
             . "El enlace es válido durante 1 hora:\n\n"
             . "{$resetLink}\n\n"
             . "Si no solicitaste este cambio, ignora este email.\n\n"
             . "— Gestor de Rutas Pro";

    $headers  = "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM . ">\r\n";
    $headers .= "Reply-To: " . MAIL_FROM . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $headers .= "X-Mailer: PHP/" . PHP_VERSION;

    @mail($email, $subject, $body, $headers);

    json_out($ok);
}

function auth_reset(array $params, ?array $ctx): never {
    rate_limit('reset', 10, 900);

    $b        = body();
    $rawToken = $b['token']    ?? '';
    $newPwd   = $b['password'] ?? '';

    if (!$rawToken || !$newPwd) json_error('Datos requeridos', 422);
    if (strlen($newPwd) < 6)   json_error('La contraseña debe tener al menos 6 caracteres', 422);

    $parts = explode(':', $rawToken, 2);
    if (count($parts) !== 2) json_error('Token inválido', 400);
    [$selector, $validator] = $parts;

    $rt = db_one(
        "SELECT * FROM refresh_tokens
         WHERE selector=? AND device_hint='pwd_reset' AND revoked=0 AND expires_at > NOW()",
        [$selector]
    );

    if (!$rt || !hash_equals($rt['token_hash'], hash('sha256', $validator))) {
        json_error('El enlace no es válido o ha expirado. Solicita uno nuevo.', 400);
    }

    /* Token válido — cambiar contraseña y revocar */
    $hash = password_hash($newPwd, PASSWORD_BCRYPT, ['cost' => 12]);
    db_run('UPDATE users SET password_hash=?, updated_at=? WHERE id=?',
        [$hash, now_sql(), $rt['user_id']]);

    /* Revocar el token de reset */
    db_run('UPDATE refresh_tokens SET revoked=1 WHERE id=?', [$rt['id']]);

    /* Revocar todos los refresh tokens para forzar re-login en todos los dispositivos */
    db_run("UPDATE refresh_tokens SET revoked=1
            WHERE user_id=? AND device_hint != 'pwd_reset'",
        [$rt['user_id']]);

    json_out(['ok' => true, 'message' => 'Contraseña actualizada. Ya puedes iniciar sesión.']);
}
