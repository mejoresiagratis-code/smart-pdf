<?php
/* Funciones definidas en routes.php — incluidas aquí para claridad del router */
