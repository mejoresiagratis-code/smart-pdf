<?php
/* ══════════════════════════════════════════════════════════
   PLATFORM — endpoints exclusivos para rol god/platform_admin
   Todos requieren require_platform_role() + verify_god_realtime()
   ══════════════════════════════════════════════════════════ */

/* ── GET /platform/orgs ─────────────────────────────────── */
function platform_orgs_list(array $p, array $ctx): never {
    require_platform_role($ctx, 'platform_admin');
    verify_god_realtime($ctx['userId']);

    $orgs = db_all('
        SELECT
            o.id, o.name, o.slug, o.plan, o.seat_limit,
            o.active, o.created_at,
            COUNT(m.id) AS member_count,
            MAX(u.last_login_at) AS last_activity
        FROM organizations o
        LEFT JOIN memberships m ON m.org_id = o.id AND m.active = 1
        LEFT JOIN users u ON u.id = m.user_id
        GROUP BY o.id
        ORDER BY o.created_at DESC
    ', []);

    json_out(array_map(fn($o) => [
        'id'           => $o['id'],
        'name'         => $o['name'],
        'slug'         => $o['slug'],
        'plan'         => $o['plan'],
        'seatLimit'    => (int)$o['seat_limit'],
        'active'       => (bool)$o['active'],
        'memberCount'  => (int)$o['member_count'],
        'lastActivity' => to_ts($o['last_activity']),
        'createdAt'    => to_ts($o['created_at']),
    ], $orgs));
}

/* ── GET /platform/users ────────────────────────────────── */
function platform_users_list(array $p, array $ctx): never {
    require_platform_role($ctx, 'platform_admin');
    verify_god_realtime($ctx['userId']);

    $users = db_all('
        SELECT
            u.id, u.name, u.email, u.created_at, u.last_login_at,
            m.role, m.active AS mem_active, m.joined_at,
            o.id AS org_id, o.name AS org_name, o.plan,
            pr.role AS p_role
        FROM users u
        LEFT JOIN memberships m ON m.user_id = u.id AND m.active = 1
        LEFT JOIN organizations o ON o.id = m.org_id
        LEFT JOIN platform_roles pr ON pr.user_id = u.id
        ORDER BY u.created_at DESC
    ', []);

    json_out(array_map(fn($u) => [
        'id'          => $u['id'],
        'name'        => $u['name'],
        'email'       => $u['email'],
        'role'        => $u['role'] ?? null,
        'pRole'       => $u['p_role'] ?? null,
        'orgId'       => $u['org_id'] ?? null,
        'orgName'     => $u['org_name'] ?? null,
        'plan'        => $u['plan'] ?? null,
        'joinedAt'    => to_ts($u['joined_at']),
        'lastLoginAt' => to_ts($u['last_login_at']),
        'createdAt'   => to_ts($u['created_at']),
    ], $users));
}

/* ── GET /platform/orgs/:id ────────────────────────────── */
function platform_orgs_get(array $p, array $ctx): never {
    require_platform_role($ctx, 'platform_admin');
    verify_god_realtime($ctx['userId']);

    $org = db_one('SELECT * FROM organizations WHERE id=?', [$p[0]]);
    if (!$org) json_error('Organización no encontrada', 404);

    $members = db_all('
        SELECT u.id, u.name, u.email, u.last_login_at, m.role, m.joined_at
        FROM memberships m JOIN users u ON u.id = m.user_id
        WHERE m.org_id=? AND m.active=1 ORDER BY m.role DESC, u.name
    ', [$p[0]]);

    json_out([
        'id'         => $org['id'],
        'name'       => $org['name'],
        'slug'       => $org['slug'],
        'plan'       => $org['plan'],
        'seatLimit'  => (int)$org['seat_limit'],
        'active'     => (bool)$org['active'],
        'createdAt'  => to_ts($org['created_at']),
        'members'    => array_map(fn($m) => [
            'id'          => $m['id'],
            'name'        => $m['name'],
            'email'       => $m['email'],
            'role'        => $m['role'],
            'joinedAt'    => to_ts($m['joined_at']),
            'lastLoginAt' => to_ts($m['last_login_at']),
        ], $members),
    ]);
}

/* ── PATCH /platform/orgs/:id ───────────────────────────── */
function platform_orgs_update(array $p, array $ctx): never {
    require_platform_role($ctx, 'god');
    verify_god_realtime($ctx['userId']);

    $orgId = $p[0];
    $org   = db_one('SELECT id FROM organizations WHERE id = ?', [$orgId]);
    if (!$org) json_error('Organización no encontrada', 404);

    $b    = body();
    $sets = []; $vals = [];

    if (isset($b['plan']))      { $sets[] = 'plan=?';       $vals[] = $b['plan']; }
    if (isset($b['seatLimit'])) { $sets[] = 'seat_limit=?'; $vals[] = (int)$b['seatLimit']; }
    if (isset($b['active']))    { $sets[] = 'active=?';     $vals[] = $b['active'] ? 1 : 0; }

    if (!$sets) json_error('Nada que actualizar', 422);

    $sets[] = 'updated_at=?';
    $vals[] = now_sql();
    $vals[] = $orgId;

    db_run('UPDATE organizations SET ' . implode(',', $sets) . ' WHERE id=?', $vals);

    $updated = db_one('SELECT id,name,plan,seat_limit,active FROM organizations WHERE id=?', [$orgId]);
    json_out([
        'id'        => $updated['id'],
        'name'      => $updated['name'],
        'plan'      => $updated['plan'],
        'seatLimit' => (int)$updated['seat_limit'],
        'active'    => (bool)$updated['active'],
    ]);
}

/* ── GET /platform/stats ────────────────────────────────── */
function platform_stats(array $p, array $ctx): never {
    require_platform_role($ctx, 'platform_admin');
    verify_god_realtime($ctx['userId']);

    $totalOrgs    = db_one('SELECT COUNT(*) AS n FROM organizations WHERE active=1', [])['n'];
    $totalUsers   = db_one('SELECT COUNT(*) AS n FROM users', [])['n'];
    $loginsToday  = db_one('SELECT COUNT(*) AS n FROM users WHERE DATE(last_login_at)=CURDATE()', [])['n'];
    $newThisWeek  = db_one('SELECT COUNT(*) AS n FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)', [])['n'];

    json_out([
        'totalOrgs'   => (int)$totalOrgs,
        'totalUsers'  => (int)$totalUsers,
        'loginsToday' => (int)$loginsToday,
        'newThisWeek' => (int)$newThisWeek,
    ]);
}
