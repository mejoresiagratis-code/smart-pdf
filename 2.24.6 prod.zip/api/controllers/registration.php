<?php
/* ══════════════════════════════════════════════════════════
   REGISTRATION — solicitudes de registro pendientes de aprobación
   Flujo: POST /auth/register → guarda en registration_requests
          GET  /platform/registrations → god ve pendientes
          POST /platform/registrations/:id/approve → crea user+org+membership
          POST /platform/registrations/:id/reject  → marca rejected
   ══════════════════════════════════════════════════════════ */

/* ── POST /auth/register — ahora guarda solicitud, no crea usuario ── */
if (!function_exists('auth_register')) {
function auth_register(array $params, ?array $ctx): never {
    rate_limit('register', 20, 3600);

    $b       = body();
    $email   = strtolower(trim($b['email']   ?? ''));
    $password = $b['password'] ?? '';
    $name    = trim($b['name']    ?? '');
    $orgName = trim($b['orgName'] ?? 'Mi equipo');

    if (!valid_email($email))     json_error('Email inválido', 422);
    if (strlen($password) < 8)    json_error('Mínimo 8 caracteres', 422);

    /* ¿Ya existe como usuario activo? */
    if (db_one('SELECT id FROM users WHERE email = ?', [$email])) {
        json_error('Email ya registrado', 409);
    }

    /* ¿Ya tiene solicitud pendiente o aprobada? */
    $existing = db_one(
        'SELECT id, status FROM registration_requests WHERE email = ?',
        [$email]
    );
    if ($existing) {
        if ($existing['status'] === 'pending') {
            json_out(['pending' => true,
                      'message' => 'Tu solicitud ya está en revisión. Te avisaremos pronto.'], 202);
        }
        if ($existing['status'] === 'approved') {
            json_error('Este email ya tiene una cuenta activa', 409);
        }
        /* rejected → permitir reintentar: actualizar la solicitud */
        db_run(
            'UPDATE registration_requests
             SET password_hash=?, name=?, org_name=?, status=\'pending\',
                 rejected_reason=NULL, reviewed_by=NULL, reviewed_at=NULL, updated_at=?
             WHERE id=?',
            [password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
             $name, $orgName, now_sql(), $existing['id']]
        );
        json_out(['pending' => true,
                  'message' => 'Solicitud reenviada. Revisaremos tu registro en breve.'], 202);
    }

    /* Solicitud nueva */
    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    db_run(
        'INSERT INTO registration_requests (id,email,password_hash,name,org_name,created_at,updated_at)
         VALUES (?,?,?,?,?,?,?)',
        [uuid4(), $email, $hash, $name, $orgName, now_sql(), now_sql()]
    );

    json_out(['pending' => true,
              'message' => 'Solicitud enviada. Revisaremos tu registro en breve.'], 202);

} // end auth_register
} // end function_exists auth_register

/* ── GET /platform/registrations ── */
function platform_registrations_list(array $p, array $ctx): never {
    require_platform_role($ctx, 'platform_admin');

    $status = $_GET['status'] ?? 'pending';
    $rows   = db_all(
        'SELECT * FROM registration_requests WHERE status = ? ORDER BY created_at DESC LIMIT 100',
        [$status]
    );
    json_out(array_map('_rr_out', $rows));
}

/* ── POST /platform/registrations/:id/approve ── */
function platform_registrations_approve(array $p, array $ctx): never {
    require_platform_role($ctx, 'god');
    verify_god_realtime($ctx['userId']);

    $rr = db_one('SELECT * FROM registration_requests WHERE id = ?', [$p[0]]);
    if (!$rr)                          json_error('Solicitud no encontrada', 404);
    if ($rr['status'] !== 'pending')   json_error('La solicitud no está pendiente', 409);

    /* Verificar que el email no se registró mientras tanto */
    if (db_one('SELECT id FROM users WHERE email = ?', [$rr['email']])) {
        db_run('UPDATE registration_requests SET status=\'approved\', reviewed_by=?, reviewed_at=? WHERE id=?',
               [$ctx['userId'], now_sql(), $rr['id']]);
        json_error('Este email ya tiene cuenta activa (registrado por otra vía)', 409);
    }

    $userId = uuid4();
    $orgId  = uuid4();
    $now    = now_sql();
    $slug   = _make_slug($rr['org_name']) . '-' . bin2hex(random_bytes(3));

    db()->beginTransaction();
    try {
        db_run('INSERT INTO users (id,email,password_hash,name,created_at,updated_at)
                VALUES (?,?,?,?,?,?)',
               [$userId, $rr['email'], $rr['password_hash'], $rr['name'], $now, $now]);

        db_run('INSERT INTO organizations (id,name,slug,plan,created_at,updated_at)
                VALUES (?,?,?,?,?,?)',
               [$orgId, $rr['org_name'], $slug, 'free', $now, $now]);

        db_run('INSERT INTO memberships (id,org_id,user_id,role,joined_at,invited_at)
                VALUES (?,?,?,?,?,?)',
               [uuid4(), $orgId, $userId, 'owner', $now, $now]);

        db_run('UPDATE registration_requests
                SET status=\'approved\', reviewed_by=?, reviewed_at=? WHERE id=?',
               [$ctx['userId'], $now, $rr['id']]);

        db()->commit();
    } catch (Throwable $e) {
        db()->rollBack();
        json_error('Error al crear cuenta: ' . $e->getMessage(), 500);
    }

    json_out(['ok' => true, 'userId' => $userId, 'orgId' => $orgId]);
}

/* ── POST /platform/registrations/:id/reject ── */
function platform_registrations_reject(array $p, array $ctx): never {
    require_platform_role($ctx, 'god');
    verify_god_realtime($ctx['userId']);

    $rr = db_one('SELECT * FROM registration_requests WHERE id = ?', [$p[0]]);
    if (!$rr)                        json_error('Solicitud no encontrada', 404);
    if ($rr['status'] !== 'pending') json_error('La solicitud no está pendiente', 409);

    $reason = trim(body()['reason'] ?? '');
    db_run(
        'UPDATE registration_requests
         SET status=\'rejected\', rejected_reason=?, reviewed_by=?, reviewed_at=? WHERE id=?',
        [$reason ?: null, $ctx['userId'], now_sql(), $rr['id']]
    );
    json_out(['ok' => true]);
}

/* ── GET /auth/register/status ── */
/* El frontend hace polling para saber si la solicitud fue aprobada */
function auth_register_status(array $p, ?array $ctx): never {
    rate_limit('reg_status', 30, 60);

    $email = strtolower(trim($_GET['email'] ?? ''));
    if (!valid_email($email)) json_error('Email inválido', 422);

    $rr = db_one(
        'SELECT status, rejected_reason FROM registration_requests WHERE email = ?',
        [$email]
    );

    /* Si ya existe como usuario activo (aprobado y creado) */
    $user = db_one('SELECT id FROM users WHERE email = ?', [$email]);
    if ($user) {
        json_out(['status' => 'approved']);
    }

    if (!$rr) json_out(['status' => 'not_found']);

    json_out([
        'status'  => $rr['status'],
        'reason'  => $rr['rejected_reason'],
    ]);
}

/* ── Helper output ── */
function _rr_out(array $rr): array {
    return [
        'id'       => $rr['id'],
        'email'    => $rr['email'],
        'name'     => $rr['name'],
        'orgName'  => $rr['org_name'],
        'status'   => $rr['status'],
        'reason'   => $rr['rejected_reason'],
        'createdAt'=> to_ts($rr['created_at']),
    ];
}

if (!function_exists('_make_slug')) {
function _make_slug(string $name): string {
    $slug = mb_strtolower($name);
    $slug = iconv('UTF-8', 'ASCII//TRANSLIT', $slug) ?: $slug;
    $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
    return substr(trim($slug, '-'), 0, 50);
}
}
