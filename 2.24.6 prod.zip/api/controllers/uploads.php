<?php
/* ══════════════════════════════════════════════════════════════
   UPLOADS — Subida de fotos de visitas
   POST /uploads/photo  (multipart/form-data, campo 'file')
   ══════════════════════════════════════════════════════════════ */

function uploads_photo(array $p, array $ctx): never {
    if (empty($_FILES['file'])) json_error('No se recibió ningún archivo', 422);

    $file    = $_FILES['file'];
    $tmpPath = $file['tmp_name']  ?? '';
    $origName= $file['name']      ?? 'foto.jpg';
    $size    = $file['size']      ?? 0;
    $error   = $file['error']     ?? UPLOAD_ERR_NO_FILE;

    if ($error !== UPLOAD_ERR_OK) json_error('Error en la subida del archivo', 422);
    if ($size > 5 * 1024 * 1024)  json_error('El archivo supera el límite de 5MB', 422);

    /* Validar que es imagen */
    $mime = mime_content_type($tmpPath);
    if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/gif'], true)) {
        json_error('Solo se permiten imágenes (jpg, png, webp, gif)', 422);
    }

    /* Directorio de uploads — relativo a la raíz del proyecto */
    $uploadDir = dirname(__DIR__, 1) . '/uploads/visits/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    /* Nombre único: orgId/año-mes/uuid.ext */
    $ext      = match($mime) {
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
        default      => 'jpg',
    };
    $subdir   = $uploadDir . $ctx['orgId'] . '/' . date('Y-m') . '/';
    if (!is_dir($subdir)) mkdir($subdir, 0755, true);

    $filename = uuid4() . '.' . $ext;
    $destPath = $subdir . $filename;

    if (!move_uploaded_file($tmpPath, $destPath)) {
        json_error('Error al guardar el archivo en el servidor', 500);
    }
    /* Redimensionar si es demasiado grande (máx 1200px) */
    _resize_image($destPath, $destPath, $mime, 1200, 85);

    /* URL pública relativa al dominio */
    $relPath = 'uploads/visits/' . $ctx['orgId'] . '/' . date('Y-m') . '/' . $filename;
    $baseUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];

    /* Buscar la ruta base de la aplicación */
    $scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '');
    $appBase   = rtrim($scriptDir, '/');

    json_out([
        'url'      => $baseUrl . $appBase . '/' . $relPath,
        'filename' => $filename,
        'size'     => $size,
        'mime'     => $mime,
    ]);
}

/* ── DELETE /uploads/photo/:filename — borrar foto del servidor ── */
function uploads_delete(array $p, array $ctx): never {
    $filename = $p[0] ?? '';
    if (!$filename || !preg_match('/^[a-f0-9\-]+\.(jpg|png|webp|gif)$/i', $filename)) {
        json_error('Nombre de archivo inválido', 422);
    }
    /* Buscar en la carpeta del org */
    $pattern = dirname(__DIR__, 1) . '/uploads/visits/' . $ctx['orgId'] . '/*/*/' . $filename;
    /* Simplificado: buscar recursivamente */
    $base = dirname(__DIR__, 1) . '/uploads/visits/' . $ctx['orgId'] . '/';
    $found = false;
    if (is_dir($base)) {
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base));
        foreach ($it as $f) {
            if ($f->getFilename() === $filename) {
                unlink($f->getPathname());
                $found = true;
                break;
            }
        }
    }
    json_out(['ok' => true, 'deleted' => $found]);
}

/* ── Redimensionar imagen si supera el máximo ── */
function _resize_image(string $srcPath, string $destPath, string $mime, int $maxPx = 1200, int $quality = 85): bool {
    if (!function_exists('imagecreatefromjpeg')) return false; /* GD no disponible */

    $src = match($mime) {
        'image/jpeg' => imagecreatefromjpeg($srcPath),
        'image/png'  => imagecreatefrompng($srcPath),
        'image/webp' => imagecreatefromwebp($srcPath),
        default      => false,
    };
    if (!$src) return false;

    $w = imagesx($src); $h = imagesy($src);
    if ($w <= $maxPx && $h <= $maxPx) {
        imagedestroy($src);
        return copy($srcPath, $destPath);
    }

    if ($w > $h) { $nw = $maxPx; $nh = (int)($h * $maxPx / $w); }
    else         { $nh = $maxPx; $nw = (int)($w * $maxPx / $h); }

    $dst = imagecreatetruecolor($nw, $nh);
    if ($mime === 'image/png') {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);

    $ok = match($mime) {
        'image/jpeg' => imagejpeg($dst, $destPath, $quality),
        'image/png'  => imagepng($dst, $destPath, 9),
        'image/webp' => imagewebp($dst, $destPath, $quality),
        default      => false,
    };
    imagedestroy($src); imagedestroy($dst);
    return (bool)$ok;
}
