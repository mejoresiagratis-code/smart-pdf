<?php
/* ══════════════════════════════════════════════════════════════
   STATS — Dashboards por rol
   GET /stats/dashboard?period=today|week|month&userId=X
   ══════════════════════════════════════════════════════════════ */

function stats_dashboard(array $p, array $ctx): never {
    require_role($ctx, 'rep');

    $period = $_GET['period'] ?? 'week';   /* today | week | month */
    $userId = $_GET['userId'] ?? $ctx['userId'];
    $lite   = isset($_GET['lite']);  /* ?lite=1 → solo active_sessions + team básico, sin _rep_summary */

    /* Solo puede pedir stats de usuarios que puede ver */
    if ($userId !== $ctx['userId']) {
        assert_can_manage_user($ctx, $userId);
    }

    [$dateFrom, $dateTo] = _period_range($period);

    /* Si se pide userId externo → devolver stats de rep para ese usuario */
    if ($userId !== $ctx['userId']) {
        $data = _stats_rep($ctx['orgId'], $userId, $dateFrom, $dateTo);
        $data['comparison'] = _period_comparison($ctx['orgId'], $userId, 'rep', ..._prev_period_range($period));
        $data['period']     = $period;
        $data['dateFrom']   = $dateFrom;
        $data['dateTo']     = $dateTo;
        json_out($data);
    }

    $role = $ctx['role'];

    if ($role === 'rep') {
        $data = _stats_rep($ctx['orgId'], $ctx['userId'], $dateFrom, $dateTo);
    } elseif ($role === 'supervisor') {
        $data = _stats_supervisor($ctx['orgId'], $ctx['userId'], $dateFrom, $dateTo, $lite);
    } elseif ($role === 'admin') {
        $data = _stats_admin($ctx['orgId'], $ctx['userId'], $dateFrom, $dateTo);
    } else { /* owner */
        $data = _stats_owner($ctx['orgId'], $dateFrom, $dateTo);
    }

    /* Comparativa periodo anterior */
    [$prevFrom, $prevTo] = _prev_period_range($period);
    $data['comparison'] = _period_comparison($ctx['orgId'], $ctx['userId'], $role, $prevFrom, $prevTo);
    $data['period']     = $period;
    $data['dateFrom']   = $dateFrom;
    $data['dateTo']     = $dateTo;

    json_out($data);
}

/* ── Dashboard por rol ─────────────────────────────────────── */

function _stats_rep(string $orgId, string $userId, string $from, string $to): array {
    /* KPIs personales del comercial */
    $sess = db_all(
        'SELECT date, state, elapsed_s, distance_km, route_id, started_at, finished_at
         FROM sessions WHERE org_id=? AND user_id=? AND date BETWEEN ? AND ?
         ORDER BY date DESC',
        [$orgId, $userId, $from, $to]
    );
    /* lat_in/lng_in pueden no existir si migrate_v2.20 no se ejecutó — query resiliente */
    $visits = db_all(
        'SELECT v.stop_id, v.estado, v.check_in_at, v.check_out_at, v.session_id
         FROM visits v WHERE v.org_id=? AND v.user_id=? AND DATE(v.created_at) BETWEEN ? AND ?
         ORDER BY v.check_in_at',
        [$orgId, $userId, $from, $to]
    );

    $totalSess      = count($sess);
    $finishedSess   = count(array_filter($sess, fn($s) => $s['state'] === 'finished'));
    $totalVisits    = count($visits);
    $totalDistanceKm = array_sum(array_column($sess, 'distance_km'));
    $totalElapsedS  = array_sum(array_column($sess, 'elapsed_s'));

    /* Cobertura: visitas / paradas asignadas en el periodo */
    $scheduledStops = _count_scheduled_stops($orgId, $userId, $from, $to);
    $coveragePct    = $scheduledStops > 0
        ? round($totalVisits / $scheduledStops * 100, 1)
        : null;

    /* PDVs sin visitar en los últimos 30 días */
    $unvisited = _unvisited_stops($orgId, $userId, 30);

    /* Jornada activa ahora mismo */
    $activeSession = db_one(
        "SELECT s.*, r.name AS route_name FROM sessions s
         LEFT JOIN routes r ON r.id = s.route_id
         WHERE s.org_id=? AND s.user_id=? AND s.date=CURDATE() AND s.state='running'",
        [$orgId, $userId]
    );

    /* Objetivos del rep */
    $targets = [];
    try {
        $repTargets = db_one(
            'SELECT targets FROM memberships WHERE org_id=? AND user_id=? AND active=1',
            [$orgId, $userId]
        );
        $targets = json_decode($repTargets['targets'] ?? 'null', true) ?? [];
    } catch (\Throwable $e) { /* columna targets aún no migrada */ }

    return [
        'role'           => 'rep',
        'sessions'       => $sess,
        'visits'         => $visits,
        'kpis' => [
            'total_sessions'   => $totalSess,
            'finished_sessions'=> $finishedSess,
            'total_visits'     => $totalVisits,
            'total_distance_km'=> round((float)$totalDistanceKm, 2),
            'total_elapsed_s'  => $totalElapsedS,
            'coverage_pct'     => $coveragePct,
            'unvisited_stops'  => $unvisited,
        ],
        'targets'        => $targets,
        'active_session' => $activeSession,
    ];
}

function _stats_supervisor(string $orgId, string $userId, string $from, string $to, bool $lite = false): array {
    /* Reps directos */
    $repIds = _get_direct_report_ids($orgId, $userId);

    $teamStats = [];
    if (!$lite) {
        foreach ($repIds as $repId) {
            $teamStats[] = _rep_summary($orgId, $repId, $from, $to);
        }
    } else {
        /* Modo lite: solo info básica de cada rep sin queries costosas */
        foreach ($repIds as $repId) {
            $targets = [];
            $info    = null;
            try {
                $info    = db_one(
                    'SELECT u.name, u.email, m.targets
                     FROM users u
                     JOIN memberships m ON m.user_id=u.id AND m.org_id=?
                     WHERE u.id=?',
                    [$orgId, $repId]
                );
                $targets = json_decode($info['targets'] ?? 'null', true) ?? [];
            } catch (\Throwable $e) {
                /* targets no existe aún — obtener info sin esa columna */
                try {
                    $info = db_one(
                        'SELECT u.name, u.email FROM users u WHERE u.id=?',
                        [$repId]
                    );
                } catch (\Throwable $e2) {}
            }
            $teamStats[] = [
                'id'           => $repId,
                'name'         => $info['name']  ?? '',
                'email'        => $info['email'] ?? '',
                'targets'      => $targets,
                'visits'       => 0, 'sessions' => 0, 'sessions_done' => 0,
                'distance_km'  => 0.0, 'elapsed_s' => 0, 'active_now' => false,
                'last_activity'=> null, 'unvisited' => 0, 'coverage_pct' => null,
            ];
        }
    }

    /* Jornadas activas ahora mismo — siempre, lite o no */
    $activeSessions = _active_sessions_for($orgId, $repIds);

    /* En modo lite: actualizar active_now usando active_sessions reales */
    if ($lite && !empty($activeSessions)) {
        $activeUserIds = array_column($activeSessions, 'user_id');
        foreach ($teamStats as &$ts) {
            $ts['active_now'] = in_array($ts['id'], $activeUserIds);
        }
        unset($ts);
    }

    /* Aggregado del equipo */
    $agg = _aggregate_stats($teamStats);

    /* PDVs sin cobertura en últimos 30 días */
    try { $gapStops = _coverage_gaps($orgId, array_values($repIds), 30); }
    catch (\Throwable $e) { $gapStops = []; }

    return [
        'role'           => 'supervisor',
        'team'           => $teamStats,
        'aggregated'     => $agg,
        'active_sessions'=> $activeSessions,
        'coverage_gaps'  => $gapStops,
    ];
}

function _stats_admin(string $orgId, string $userId, string $from, string $to): array {
    /* Supervisores directos — si no hay ninguno con manager_id configurado,
       usar el subtree completo filtrado por rol supervisor */
    $supIds = _get_direct_report_ids($orgId, $userId);
    if (empty($supIds)) {
        /* Fallback: todos los supervisores visibles en el árbol del admin */
        $all = get_visible_members($orgId, $userId, 'admin');
        $supIds = array_column(
            array_filter($all, fn($m) => $m['role'] === 'supervisor'),
            'id'
        );
    }

    $supStats = [];
    foreach ($supIds as $supId) {
        $repIds     = _get_direct_report_ids($orgId, $supId);
        $supInfo    = db_one('SELECT u.name, u.email, m.role FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.org_id=? AND m.user_id=?', [$orgId, $supId]);
        $teamStats  = [];
        foreach ($repIds as $rid) {
            $teamStats[] = _rep_summary($orgId, $rid, $from, $to);
        }
        $supStats[] = [
            'supervisor'  => ['id' => $supId, 'name' => $supInfo['name'] ?? '', 'email' => $supInfo['email'] ?? ''],
            'team'        => $teamStats,
            'aggregated'  => _aggregate_stats($teamStats),
            'active_now'  => count(_active_sessions_for($orgId, $repIds)),
        ];
    }

    $allRepIds = [];
    foreach ($supIds as $sid) {
        $allRepIds = array_merge($allRepIds, _get_direct_report_ids($orgId, $sid));
    }
    $allRepIds = array_unique($allRepIds);

    /* active_sessions de todos los reps del árbol del admin */
    $adminActiveSessions = _active_sessions_for($orgId, $allRepIds);

    return [
        'role'            => 'admin',
        'supervisors'     => $supStats,
        'aggregated'      => _aggregate_stats(
            !empty($supStats)
                ? array_merge(...array_map(fn($s) => $s['team'] ?? [], $supStats))
                : []
        ),
        'active_sessions' => $adminActiveSessions,
        'coverage_gaps'   => (function() use ($orgId, $allRepIds) {
            try { return _coverage_gaps($orgId, array_values($allRepIds), 30); }
            catch (\Throwable $e) { return []; }
        })(),
    ];
}

function _stats_owner(string $orgId, string $from, string $to): array {
    /* Vista completa org — todos los usuarios activos */
    $members = db_all(
        "SELECT m.user_id, m.role, m.manager_id, u.name, u.email
         FROM memberships m JOIN users u ON u.id=m.user_id
         WHERE m.org_id=? AND m.active=1 AND m.archived_at IS NULL
           AND m.role IN ('rep','supervisor','admin')
         ORDER BY FIELD(m.role,'admin','supervisor','rep'), u.name",
        [$orgId]
    );

    /* Estadísticas globales */
    $totalVisits = db_one(
        'SELECT COUNT(*) AS n FROM visits WHERE org_id=? AND DATE(created_at) BETWEEN ? AND ?',
        [$orgId, $from, $to]
    )['n'];

    $totalSessions = db_one(
        'SELECT COUNT(*) AS n FROM sessions WHERE org_id=? AND date BETWEEN ? AND ?',
        [$orgId, $from, $to]
    )['n'];

    $finishedSessions = db_one(
        "SELECT COUNT(*) AS n FROM sessions WHERE org_id=? AND date BETWEEN ? AND ? AND state='finished'",
        [$orgId, $from, $to]
    )['n'];

    $avgDistance = db_one(
        'SELECT AVG(distance_km) AS avg FROM sessions WHERE org_id=? AND date BETWEEN ? AND ? AND distance_km > 0',
        [$orgId, $from, $to]
    )['avg'];

    /* Activos hoy */
    $activeNow = db_one(
        "SELECT COUNT(*) AS n FROM sessions WHERE org_id=? AND date=CURDATE() AND state='running'",
        [$orgId]
    )['n'];

    /* Por director (admin) */
    $adminIds = array_column(
        array_filter($members, fn($m) => $m['role'] === 'admin'),
        'user_id'
    );
    $byAdmin = [];
    foreach ($adminIds as $aId) {
        $aInfo  = db_one('SELECT name, email FROM users WHERE id=?', [$aId]);
        $aReps  = _get_subtree_ids($orgId, $aId);
        $aVis   = db_one(
            'SELECT COUNT(*) AS n FROM visits WHERE org_id=? AND user_id IN (' .
            implode(',', array_fill(0, max(1, count($aReps)), '?')) . ')' .
            ' AND DATE(created_at) BETWEEN ? AND ?',
            array_merge([$orgId], $aReps ?: ['__none__'], [$from, $to])
        )['n'];
        $byAdmin[] = [
            'id'     => $aId,
            'name'   => $aInfo['name']  ?? '',
            'email'  => $aInfo['email'] ?? '',
            'visits' => (int)$aVis,
        ];
    }

    /* PDVs sin cobertura 30 días en toda la org */
    $allRepIds = array_column(
        array_filter($members, fn($m) => $m['role'] === 'rep'),
        'user_id'
    );

    /* active_sessions de todos los reps en tiempo real */
    $ownerActiveSessions = _active_sessions_for($orgId, $allRepIds);

    return [
        'role'            => 'owner',
        'active_sessions' => $ownerActiveSessions,
        'kpis' => [
            'total_visits'      => (int)$totalVisits,
            'total_sessions'    => (int)$totalSessions,
            'finished_sessions' => (int)$finishedSessions,
            'active_now'        => (int)$activeNow,
            'avg_distance_km'   => round((float)($avgDistance ?? 0), 2),
            'total_members'     => count($members),
        ],
        'by_admin'      => $byAdmin,
        'members'       => $members,
        'coverage_gaps' => (function() use ($orgId, $allRepIds) {
            try { return _coverage_gaps($orgId, array_values($allRepIds), 30); }
            catch (\Throwable $e) { return []; }
        })(),
    ];
}

/* ── Helpers ────────────────────────────────────────────────── */

function _period_range(string $period): array {
    return match($period) {
        'today' => [date('Y-m-d'), date('Y-m-d')],
        'week'  => [date('Y-m-d', strtotime('monday this week')), date('Y-m-d')],
        'month' => [date('Y-m-01'), date('Y-m-d')],
        default => [date('Y-m-d', strtotime('-6 days')), date('Y-m-d')],
    };
}

function _prev_period_range(string $period): array {
    return match($period) {
        'today' => [date('Y-m-d', strtotime('-1 day')), date('Y-m-d', strtotime('-1 day'))],
        'week'  => [date('Y-m-d', strtotime('monday last week')), date('Y-m-d', strtotime('sunday last week'))],
        'month' => [date('Y-m-01', strtotime('first day of last month')), date('Y-m-t', strtotime('last day of last month'))],
        default => [date('Y-m-d', strtotime('-13 days')), date('Y-m-d', strtotime('-7 days'))],
    };
}

function _period_comparison(string $orgId, string $userId, string $role, string $from, string $to): array {
    if ($role === 'rep') {
        $n = db_one('SELECT COUNT(*) AS n FROM visits WHERE org_id=? AND user_id=? AND DATE(created_at) BETWEEN ? AND ?',
            [$orgId, $userId, $from, $to])['n'];
    } elseif ($role === 'owner') {
        /* Owner: comparativa sobre toda la org — evita CTE que puede fallar en algunos MariaDB */
        $n = db_one('SELECT COUNT(*) AS n FROM visits WHERE org_id=? AND DATE(created_at) BETWEEN ? AND ?',
            [$orgId, $from, $to])['n'];
    } else {
        /* admin / supervisor: subtree con try/catch */
        try {
            $ids = _get_subtree_ids($orgId, $userId);
        } catch (\Throwable $e) {
            $ids = [];
        }
        if (empty($ids)) return ['visits' => 0];
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $n = db_one("SELECT COUNT(*) AS n FROM visits WHERE org_id=? AND user_id IN ($ph) AND DATE(created_at) BETWEEN ? AND ?",
            array_merge([$orgId], $ids, [$from, $to]))['n'];
    }
    return ['visits' => (int)$n];
}


/* ══════════════════════════════════════════════════════════════
   DAILY_STATS — caché de métricas por rep/día
   Se llama al finalizar sesión y como fallback en _rep_summary
   ══════════════════════════════════════════════════════════════ */

function _upsert_daily_stats(string $orgId, string $userId, string $date): void {
    /* Calcular métricas del día desde las tablas fuente */
    $sess = db_one(
        "SELECT COUNT(*) AS sessions,
                SUM(IF(state='finished',1,0)) AS sessions_done,
                SUM(distance_km) AS km,
                SUM(elapsed_s) AS secs,
                MAX(route_id) AS route_id
         FROM sessions
         WHERE org_id=? AND user_id=? AND date=?",
        [$orgId, $userId, $date]
    );

    $visits = db_one(
        "SELECT COUNT(*) AS total,
                SUM(IF(estado NOT IN ('no_encontrado','cerrado','no_interesado') OR estado IS NULL, 1, 0)) AS ok
         FROM visits
         WHERE org_id=? AND user_id=? AND DATE(created_at)=?",
        [$orgId, $userId, $date]
    );

    $routeId  = $sess['route_id'] ?? null;
    $stopsTotal = 0;
    if ($routeId) {
        $r = db_one('SELECT stop_ids FROM routes WHERE id=?', [$routeId]);
        $stopsTotal = count(json_decode($r['stop_ids'] ?? '[]', true) ?? []);
    }

    $visitsTotal = (int)($visits['total'] ?? 0);
    $coveragePct = $stopsTotal > 0
        ? round($visitsTotal / $stopsTotal * 100, 2)
        : 0.00;

    db_run(
        'INSERT INTO daily_stats
            (id, org_id, user_id, date, visits_total, visits_ok, stops_total,
             distance_km, elapsed_s, coverage_pct, route_id, calculated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())
         ON DUPLICATE KEY UPDATE
            visits_total  = VALUES(visits_total),
            visits_ok     = VALUES(visits_ok),
            stops_total   = VALUES(stops_total),
            distance_km   = VALUES(distance_km),
            elapsed_s     = VALUES(elapsed_s),
            coverage_pct  = VALUES(coverage_pct),
            route_id      = VALUES(route_id),
            calculated_at = NOW()',
        [
            uuid4(), $orgId, $userId, $date,
            $visitsTotal,
            (int)($visits['ok'] ?? 0),
            $stopsTotal,
            round((float)($sess['km'] ?? 0), 3),
            (int)($sess['secs'] ?? 0),
            $coveragePct,
            $routeId,
        ]
    );
}

/* Lee métricas de daily_stats para un periodo y grupo de reps.
   Devuelve array indexado por user_id con totales del periodo. */
function _daily_stats_for(string $orgId, array $repIds, string $from, string $to): array {
    if (empty($repIds)) return [];
    $ph = implode(',', array_fill(0, count($repIds), '?'));
    $rows = db_all(
        "SELECT user_id,
                SUM(visits_total)  AS visits,
                SUM(visits_ok)     AS visits_ok,
                COUNT(*)           AS days_with_data,
                SUM(IF(visits_total > 0, 1, 0)) AS sessions_done,
                SUM(distance_km)   AS distance_km,
                SUM(elapsed_s)     AS elapsed_s,
                AVG(NULLIF(coverage_pct, 0)) AS coverage_pct
         FROM daily_stats
         WHERE org_id=? AND user_id IN ($ph) AND date BETWEEN ? AND ?
         GROUP BY user_id",
        array_merge([$orgId], $repIds, [$from, $to])
    );
    $out = [];
    foreach ($rows as $r) {
        $out[$r['user_id']] = [
            'visits'       => (int)$r['visits'],
            'visits_ok'    => (int)$r['visits_ok'],
            'sessions_done'=> (int)$r['sessions_done'],
            'distance_km'  => round((float)$r['distance_km'], 2),
            'elapsed_s'    => (int)$r['elapsed_s'],
            'coverage_pct' => $r['coverage_pct'] !== null ? round((float)$r['coverage_pct'], 1) : null,
        ];
    }
    return $out;
}

function _rep_summary(string $orgId, string $repId, string $from, string $to): array {
    try {
    $targets = [];
    try {
        $info = db_one(
            'SELECT u.name, u.email, m.targets
             FROM users u
             JOIN memberships m ON m.user_id=u.id AND m.org_id=?
             WHERE u.id=?',
            [$orgId, $repId]
        );
        $targets = json_decode($info['targets'] ?? 'null', true) ?? [];
    } catch (\Throwable $e) {
        /* targets no migrada — obtener info sin esa columna */
        $info = db_one(
            'SELECT u.name, u.email FROM users u WHERE u.id=?',
            [$repId]
        );
    }

    /* Intentar leer desde daily_stats (caché) — mucho más rápido para periodos largos */
    $cached = _daily_stats_for($orgId, [$repId], $from, $to);
    $c = $cached[$repId] ?? null;

    if ($c) {
        /* Caché disponible: solo necesitamos 2 queries en tiempo real */
        $visits        = $c['visits'];
        $sessionsDone  = $c['sessions_done'];
        $distanceKm    = $c['distance_km'];
        $elapsedS      = $c['elapsed_s'];
        $coveragePct   = $c['coverage_pct'];
        /* sessions COUNT total: daily_stats no tiene sesiones totales separadas — contar */
        $sessTotal = db_one(
            'SELECT COUNT(*) AS n FROM sessions WHERE org_id=? AND user_id=? AND date BETWEEN ? AND ?',
            [$orgId, $repId, $from, $to]
        )['n'];
    } else {
        /* Sin caché: calcular desde tablas fuente (igual que antes) */
        $visits = db_one(
            'SELECT COUNT(*) AS n FROM visits WHERE org_id=? AND user_id=? AND DATE(created_at) BETWEEN ? AND ?',
            [$orgId, $repId, $from, $to]
        )['n'];
        $sessions = db_one(
            "SELECT COUNT(*) AS total, SUM(IF(state='finished',1,0)) AS finished,
                    SUM(distance_km) AS km, SUM(elapsed_s) AS secs
             FROM sessions WHERE org_id=? AND user_id=? AND date BETWEEN ? AND ?",
            [$orgId, $repId, $from, $to]
        );
        $sessTotal    = (int)($sessions['total'] ?? 0);
        $sessionsDone = (int)($sessions['finished'] ?? 0);
        $distanceKm   = round((float)($sessions['km'] ?? 0), 2);
        $elapsedS     = (int)($sessions['secs'] ?? 0);
        /* Calcular coverage desde fuente */
        $scheduledStops = _count_scheduled_stops($orgId, $repId, $from, $to);
        $coveragePct    = $scheduledStops > 0
            ? round((int)$visits / $scheduledStops * 100, 1)
            : null;
    }

    /* Siempre en tiempo real: activeNow y lastActivity */
    $lastActivity = db_one(
        'SELECT MAX(updated_at) AS ts FROM sessions WHERE org_id=? AND user_id=?',
        [$orgId, $repId]
    )['ts'];
    $activeNow = db_one(
        "SELECT COUNT(*) AS n FROM sessions WHERE org_id=? AND user_id=? AND date=CURDATE() AND state='running'",
        [$orgId, $repId]
    )['n'];

    return [
        'id'            => $repId,
        'name'          => $info['name']  ?? '',
        'email'         => $info['email'] ?? '',
        'targets'       => $targets,
        'visits'        => (int)$visits,
        'sessions'      => (int)$sessTotal,
        'sessions_done' => (int)$sessionsDone,
        'distance_km'   => (float)$distanceKm,
        'elapsed_s'     => (int)$elapsedS,
        'active_now'    => (int)$activeNow > 0,
        'last_activity' => $lastActivity,
        'unvisited'     => _unvisited_stops($orgId, $repId, 30),
        'coverage_pct'  => $coveragePct,
    ];
    } catch (\Throwable $e) {
        error_log("_rep_summary error for $repId: " . $e->getMessage());
        return [
            'id' => $repId, 'name' => '', 'email' => '',
            'visits' => 0, 'sessions' => 0, 'sessions_done' => 0,
            'distance_km' => 0.0, 'elapsed_s' => 0, 'active_now' => false,
            'last_activity' => null, 'unvisited' => 0, 'coverage_pct' => null,
        ];
    }
}

function _aggregate_stats(array $teamStats): array {
    /* coverage_pct: promedio de los reps que tienen zona asignada (ignora nulls) */
    $coverages = array_filter(
        array_column($teamStats, 'coverage_pct'),
        fn($v) => $v !== null
    );
    $avgCoverage = count($coverages) > 0
        ? round(array_sum($coverages) / count($coverages), 1)
        : null;

    return [
        'total_visits'  => array_sum(array_column($teamStats, 'visits')),
        'total_sessions'=> array_sum(array_column($teamStats, 'sessions')),
        'sessions_done' => array_sum(array_column($teamStats, 'sessions_done')),
        'distance_km'   => round(array_sum(array_column($teamStats, 'distance_km')), 2),
        'elapsed_s'     => array_sum(array_column($teamStats, 'elapsed_s')),
        'active_count'  => count(array_filter($teamStats, fn($r) => $r['active_now'])),
        'coverage_pct'  => $avgCoverage,
    ];
}

function _active_sessions_for(string $orgId, array $userIds): array {
    if (empty($userIds)) return [];
    $userIds = array_values($userIds); /* HY093 guard */
    $ph = implode(',', array_fill(0, count($userIds), '?'));
    $rows = db_all(
        "SELECT s.*, u.name AS user_name, r.name AS route_name
         FROM sessions s
         JOIN users u ON u.id = s.user_id
         LEFT JOIN routes r ON r.id = s.route_id
         WHERE s.org_id=? AND s.user_id IN ($ph) AND s.date=CURDATE() AND s.state='running'",
        array_merge([$orgId], $userIds)
    );
    /* Añadir progreso de visitas */
    foreach ($rows as &$row) {
        $row['visits_today'] = (int)db_one(
            'SELECT COUNT(*) AS n FROM visits WHERE org_id=? AND user_id=? AND DATE(created_at)=CURDATE()',
            [$orgId, $row['user_id']]
        )['n'];
    }
    return $rows;
}

function _unvisited_stops(string $orgId, string $userId, int $days): int {
    /* Stops que el rep debería haber visitado:
       union de zone_ids + stops de rutas asignadas en los últimos $days días */
    $mem = db_one('SELECT zone_ids FROM memberships WHERE org_id=? AND user_id=? AND active=1',
        [$orgId, $userId]);
    $zoneIds = json_decode($mem['zone_ids'] ?? '[]', true) ?? [];

    $since = date('Y-m-d', strtotime("-{$days} days"));

    /* Stops de rutas asignadas en el período */
    $assignedRoutes = db_all(
        'SELECT DISTINCT r.stop_ids FROM routes r
         INNER JOIN schedules s ON s.route_id = r.id
         WHERE r.org_id=? AND r.deleted=0
           AND s.assigned_to=? AND s.date >= ?',
        [$orgId, $userId, $since]
    );
    $routeStopIds = [];
    foreach ($assignedRoutes as $ar) {
        $ids = json_decode($ar['stop_ids'] ?? '[]', true) ?? [];
        $routeStopIds = array_merge($routeStopIds, $ids);
    }

    /* Unión de ambas fuentes */
    $allStopIds = array_unique(array_merge($zoneIds, $routeStopIds));
    if (empty($allStopIds)) return 0;

    $ph = implode(',', array_fill(0, count($allStopIds), '?'));
    $visited = db_all(
        "SELECT DISTINCT stop_id FROM visits WHERE org_id=? AND user_id=? AND DATE(created_at)>=? AND stop_id IN ($ph)",
        array_merge([$orgId, $userId, $since], $allStopIds)
    );
    $visitedIds = array_column($visited, 'stop_id');
    return count(array_diff($allStopIds, $visitedIds));
}

function _coverage_gaps(string $orgId, array $repIds, int $days): array {
    if (empty($repIds)) return [];
    try {
        $since = date('Y-m-d', strtotime("-{$days} days"));

        /* Garantizar keys numéricas consecutivas en todo momento */
        $repIds = array_values($repIds);
        $ph = implode(',', array_fill(0, count($repIds), '?'));
        $mems = db_all(
            "SELECT user_id, zone_ids FROM memberships WHERE org_id=? AND user_id IN ($ph) AND active=1 AND archived_at IS NULL",
            array_merge([$orgId], $repIds)
        );
        $allZoneStops = [];
        foreach ($mems as $m) {
            $ids = json_decode($m['zone_ids'] ?? '[]', true) ?? [];
            foreach ($ids as $sid) {
                if (is_string($sid) && $sid !== '') $allZoneStops[$sid] = true;
            }
        }
        if (empty($allZoneStops)) return [];

        /* array_values → claves 0,1,2... siempre */
        $allStopIds = array_values(array_keys($allZoneStops));
        if (empty($allStopIds)) return [];

        $sph = implode(',', array_fill(0, count($allStopIds), '?'));
        $visited = db_all(
            "SELECT DISTINCT stop_id FROM visits WHERE org_id=? AND DATE(created_at)>=? AND stop_id IN ($sph)",
            array_merge([$orgId, $since], array_values($allStopIds))
        );
        $visitedIds = array_column($visited, 'stop_id');

        /* array_values doble: array_diff preserva keys → HY093 en PDO */
        $gaps = array_values(array_diff($allStopIds, $visitedIds));
        if (empty($gaps)) return [];

        /* Solo buscar stops que existen en la tabla — los IDs externos (IMP*) no están */
        $gph = implode(',', array_fill(0, count($gaps), '?'));
        $found = db_all(
            "SELECT id, name, town, addr FROM stops WHERE id IN ($gph) AND deleted=0",
            array_values($gaps)
        );
        return $found;
    } catch (\Throwable $e) {
        error_log('_coverage_gaps error: ' . $e->getMessage());
        return [];
    }
}

function _count_scheduled_stops(string $orgId, string $userId, string $from, string $to): int {
    $routes = db_all(
        'SELECT DISTINCT r.stop_ids FROM routes r
         INNER JOIN schedules s ON s.route_id = r.id
         WHERE r.org_id=? AND r.deleted=0 AND s.assigned_to=? AND s.date BETWEEN ? AND ?',
        [$orgId, $userId, $from, $to]
    );
    $ids = [];
    foreach ($routes as $r) {
        $arr = json_decode($r['stop_ids'] ?? '[]', true) ?? [];
        $ids = array_merge($ids, $arr);
    }
    return count(array_unique($ids));
}

function _get_direct_report_ids(string $orgId, string $managerId): array {
    $rows = db_all(
        'SELECT user_id FROM memberships WHERE org_id=? AND manager_id=? AND active=1',
        [$orgId, $managerId]
    );
    return array_column($rows, 'user_id');
}

function _get_subtree_ids(string $orgId, string $rootId): array {
    /* CTE recursiva — todos los descendientes */
    try {
        $rows = db_all("
            WITH RECURSIVE tree AS (
                SELECT user_id FROM memberships WHERE org_id=? AND user_id=? AND active=1
                UNION ALL
                SELECT m.user_id FROM memberships m
                INNER JOIN tree t ON t.user_id = m.manager_id
                WHERE m.org_id=? AND m.active=1 AND m.role IN ('supervisor','rep')
            )
            SELECT DISTINCT user_id FROM tree WHERE user_id != ?
        ", [$orgId, $rootId, $orgId, $rootId]);
    } catch (\Throwable $e) {
        $rows = db_all(
            "SELECT user_id FROM memberships WHERE org_id=? AND active=1 AND role IN ('supervisor','rep')",
            [$orgId]
        );
    }
    return array_column($rows, 'user_id');
}
