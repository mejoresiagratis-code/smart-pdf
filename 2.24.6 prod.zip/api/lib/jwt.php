<?php
/* ══════════════════════════════════════════════════════════
   JWT HS256 puro — sin librerías externas
   ══════════════════════════════════════════════════════════ */

function jwt_encode(array $payload): string {
    $header  = base64url_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $payload = base64url_encode(json_encode($payload));
    $sig     = base64url_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    return "$header.$payload.$sig";
}

function jwt_decode(string $token): ?array {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;

    [$header, $payload, $sig] = $parts;
    $expected = base64url_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));

    if (!hash_equals($expected, $sig)) return null;

    $data = json_decode(base64url_decode($payload), true);
    if (!$data) return null;

    if (isset($data['exp']) && $data['exp'] < time()) return null;

    return $data;
}

function jwt_issue(string $userId, string $orgId, string $role, string $plan, ?string $pRole = null): string {
    $payload = [
        'sub'   => $userId,
        'orgId' => $orgId,
        'role'  => $role,
        'plan'  => $plan,
        'iat'   => time(),
        'exp'   => time() + JWT_EXPIRES,
    ];
    /* pRole solo se incluye si el usuario tiene rol de plataforma */
    if ($pRole !== null) {
        $payload['pRole'] = $pRole;
    }
    return jwt_encode($payload);
}

function get_bearer(): ?string {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $h, $m)) return $m[1];
    return null;
}

function require_auth(): ?array {
    $token = get_bearer();
    if (!$token) return null;
    $payload = jwt_decode($token);
    if (!$payload) return null;
    return [
        'userId' => $payload['sub'],
        'orgId'  => $payload['orgId'],
        'role'   => $payload['role'],
        'plan'   => $payload['plan'] ?? 'free',
        'pRole'  => $payload['pRole'] ?? null,
    ];
}

function base64url_encode(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
function base64url_decode(string $data): string {
    return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', (4 - strlen($data) % 4) % 4));
}
