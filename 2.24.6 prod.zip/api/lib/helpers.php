<?php
/* ── Responder JSON y salir ── */
function json_out(mixed $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function json_error(string $msg, int $status = 400): never {
    json_out(['error' => $msg], $status);
}

/* ── Leer body JSON de la request ── */
function body(): array {
    static $parsed = null;
    if ($parsed !== null) return $parsed;
    $raw    = file_get_contents('php://input');
    $parsed = json_decode($raw, true) ?? [];
    return $parsed;
}

/* ── Require campo del body ── */
function need(string ...$fields): array {
    $b   = body();
    $out = [];
    foreach ($fields as $f) {
        if (!isset($b[$f]) || $b[$f] === '') {
            json_error("Campo requerido: $f", 422);
        }
        $out[$f] = $b[$f];
    }
    return count($fields) === 1 ? $out[$fields[0]] : $out;
}

/* ── Validar email ── */
function valid_email(string $e): bool {
    return (bool) filter_var($e, FILTER_VALIDATE_EMAIL);
}

/* ── Rate limiting simple basado en archivos ── */
function rate_limit(string $key, int $max, int $window): void {
    if (!RATE_ENABLED) return;

    $dir  = RATE_LIMIT_DIR;
    if (!is_dir($dir)) @mkdir($dir, 0700, true);

    $ip   = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $file = $dir . '/' . md5($key . $ip) . '.json';
    $now  = time();

    $data = ['count' => 0, 'reset' => $now + $window];
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true) ?? $data;
        if ($data['reset'] < $now) {
            $data = ['count' => 0, 'reset' => $now + $window];
        }
    }

    $data['count']++;
    file_put_contents($file, json_encode($data), LOCK_EX);

    $remaining = max(0, $max - $data['count']);
    header("X-RateLimit-Limit: $max");
    header("X-RateLimit-Remaining: $remaining");

    if ($data['count'] > $max) {
        json_error('Demasiadas peticiones, espera un momento', 429);
    }
}

/* ── Rol mínimo requerido ── */
function require_role(array $ctx, string $minRole): void {
    $order = ['rep' => 0, 'supervisor' => 1, 'admin' => 2, 'owner' => 3];
    $mine  = $order[$ctx['role']] ?? 0;
    $need  = $order[$minRole]     ?? 99;
    if ($mine < $need) {
        json_error('Permisos insuficientes', 403);
    }
}

/* ── NOW para MySQL ── */
function now_sql(): string {
    return date('Y-m-d H:i:s');
}

/* ── Timestamps: MySQL datetime → ms epoch ── */
function to_ts(?string $dt): ?int {
    if (!$dt) return null;
    return (int) (new DateTime($dt))->format('Uv') ?: strtotime($dt) * 1000;
}

/* ── Rol mínimo de PLATAFORMA requerido (god > platform_admin) ── */
function require_platform_role(array $ctx, string $minRole): void {
    $order = ['platform_admin' => 1, 'god' => 2];
    $mine  = $order[$ctx['pRole'] ?? ''] ?? 0;
    $need  = $order[$minRole]            ?? 99;
    if ($mine < $need) {
        json_error('Acceso denegado — se requiere rol de plataforma', 403);
    }
}

/* ── Check en tiempo real contra BD — para endpoints críticos de plataforma ── */
function verify_god_realtime(string $userId): void {
    $pr = db_one('SELECT role FROM platform_roles WHERE user_id = ?', [$userId]);
    if (($pr['role'] ?? '') !== 'god') {
        json_error('Acceso denegado', 403);
    }
}

/* ══════════════════════════════════════════════════════════
   JERARQUÍA — obtener árbol de usuarios bajo un manager
   Usa CTE recursiva (MariaDB 10.6+)
   ══════════════════════════════════════════════════════════ */

/**
 * Devuelve array de user_ids de todos los miembros gestionados por $userId
 * en la org $orgId, incluyendo al propio $userId.
 * Profundidad máxima 10 para evitar ciclos.
 *
 * Visibilidad por rol:
 *   owner     → todos en la org
 *   admin     → supervisores y reps bajo él (no otros admins ni owners)
 *   supervisor → solo sus reps directos
 *   rep        → solo él mismo
 */
function get_visible_user_ids(string $orgId, string $userId, string $role): array {
    /* Owner: ve toda la org */
    if ($role === 'owner') {
        $rows = db_all(
            'SELECT user_id FROM memberships WHERE org_id=? AND active=1 AND archived_at IS NULL',
            [$orgId]
        );
        return array_column($rows, 'user_id');
    }

    /* Admin: ve supervisores y reps — con CTE recursiva si disponible, fallback simple */
    if ($role === 'admin') {
        try {
            $rows = db_all("
                WITH RECURSIVE tree AS (
                    SELECT user_id, role, manager_id, 0 AS depth
                    FROM memberships
                    WHERE org_id=? AND user_id=? AND active=1
                    UNION ALL
                    SELECT m.user_id, m.role, m.manager_id, t.depth+1
                    FROM memberships m
                    INNER JOIN tree t ON t.user_id = m.manager_id
                    WHERE m.org_id=? AND m.active=1
                      AND m.role IN ('supervisor','rep')
                      AND t.depth < 10
                )
                SELECT DISTINCT user_id FROM tree
            ", [$orgId, $userId, $orgId]);
        } catch (\Throwable $e) {
            /* Fallback: admin ve supervisores y reps sin jerarquía estricta */
            $rows = db_all(
                "SELECT user_id FROM memberships WHERE org_id=? AND active=1 AND archived_at IS NULL AND role IN ('supervisor','rep')",
                [$orgId]
            );
        }
        $ids = array_column($rows, 'user_id');
        /* Si árbol vacío (jerarquía no configurada aún), admin ve todos los inferiores */
        if (empty($ids)) {
            $rows = db_all(
                "SELECT user_id FROM memberships WHERE org_id=? AND active=1 AND role IN ('supervisor','rep')",
                [$orgId]
            );
            $ids = array_column($rows, 'user_id');
        }
        return $ids;
    }

    /* Supervisor: solo sus reps directos + él mismo */
    if ($role === 'supervisor') {
        try {
            $rows = db_all(
                "SELECT user_id FROM memberships
                 WHERE org_id=? AND (user_id=? OR manager_id=?) AND active=1
                   AND role IN ('supervisor','rep')",
                [$orgId, $userId, $userId]
            );
        } catch (\Throwable $e) {
            /* Fallback si manager_id no existe aún */
            $rows = db_all(
                "SELECT user_id FROM memberships WHERE org_id=? AND user_id=? AND active=1",
                [$orgId, $userId]
            );
        }
        return array_column($rows, 'user_id');
    }

    /* Rep: solo él mismo */
    return [$userId];
}

/**
 * Devuelve array de memberships visibles para un usuario dado su rol.
 * Incluye name, email, role, zone_ids, manager_id de cada miembro visible.
 */
function get_visible_members(string $orgId, string $userId, string $role): array {
    $visibleIds = get_visible_user_ids($orgId, $userId, $role);
    if (empty($visibleIds)) return [];

    $ph = implode(',', array_fill(0, count($visibleIds), '?'));

    /* Intentar con todas las columnas opcionales; si alguna no existe, fallback sin ellas */
    try {
        return db_all(
            "SELECT m.user_id AS id, m.role, m.zone_ids, m.manager_id, m.active,
                    m.targets,
                    u.name, u.email
             FROM memberships m
             JOIN users u ON u.id = m.user_id
             WHERE m.org_id=? AND m.user_id IN ($ph) AND m.archived_at IS NULL
             ORDER BY FIELD(m.role,'owner','admin','supervisor','rep'), u.name",
            array_merge([$orgId], $visibleIds)
        );
    } catch (\Throwable $e) {
        /* Fallback: sin columnas opcionales (targets, manager_id) — pre-migración */
        try {
            return db_all(
                "SELECT m.user_id AS id, m.role, m.zone_ids, m.active,
                        NULL AS manager_id, NULL AS targets,
                        u.name, u.email
                 FROM memberships m
                 JOIN users u ON u.id = m.user_id
                 WHERE m.org_id=? AND m.user_id IN ($ph) AND m.archived_at IS NULL
                 ORDER BY FIELD(m.role,'owner','admin','supervisor','rep'), u.name",
                array_merge([$orgId], $visibleIds)
            );
        } catch (\Throwable $e2) {
            return [];
        }
    }
}

/* ══════════════════════════════════════════════════════════
   GUARDS JERÁRQUICOS
   Verifican no solo el rol mínimo sino la relación de árbol
   ══════════════════════════════════════════════════════════ */

/**
 * ¿Puede el usuario del contexto actuar sobre $targetUserId?
 * Owner: sí sobre todos
 * Admin: sí sobre supervisores y reps de su árbol, no sobre otros admins ni owners
 * Supervisor: sí solo sobre sus reps directos
 * Rep: solo sobre sí mismo
 */
function assert_can_manage_user(array $ctx, string $targetUserId): void {
    if ($ctx['userId'] === $targetUserId) return; /* Siempre puede sobre sí mismo */
    /* God bypass — puede gestionar cualquier usuario en cualquier org */
    if (($ctx['pRole'] ?? null) === 'god') return;
    /* Owner bypass — puede gestionar a cualquier miembro de su org sin depender del árbol */
    if ($ctx['role'] === 'owner') {
        $target = db_one(
            'SELECT role FROM memberships WHERE org_id=? AND user_id=? AND active=1',
            [$ctx['orgId'], $targetUserId]
        );
        if (!$target) json_error('Usuario no encontrado en la organización', 404);
        /* Owner no puede gestionar a otro owner */
        if ($target['role'] === 'owner') {
            json_error('No puedes gestionar a otro propietario', 403);
        }
        return;
    }
    /* Para admin y supervisor: verificar árbol jerárquico */
    $visible = get_visible_user_ids($ctx['orgId'], $ctx['userId'], $ctx['role']);
    if (!in_array($targetUserId, $visible, true)) {
        json_error('No tienes permisos para gestionar este usuario', 403);
    }
    /* No puede gestionar usuarios de igual o mayor rango */
    $target = db_one(
        'SELECT role FROM memberships WHERE org_id=? AND user_id=? AND active=1',
        [$ctx['orgId'], $targetUserId]
    );
    if (!$target) json_error('Usuario no encontrado en la organización', 404);
    $order = ['rep'=>0,'supervisor'=>1,'admin'=>2,'owner'=>3];
    $myLevel     = $order[$ctx['role']]      ?? 0;
    $targetLevel = $order[$target['role']]   ?? 0;
    if ($myLevel <= $targetLevel) {
        json_error('No puedes gestionar usuarios de igual o mayor rango', 403);
    }
}

/**
 * ¿Puede el usuario del contexto actuar sobre un recurso (ruta/stop)?
 * Los recursos no tienen "dueño" jerárquico — pertenecen a la org.
 * La regla es: supervisor solo puede modificar recursos que él creó.
 * Admin y owner pueden modificar cualquier recurso de la org.
 */
function assert_can_manage_resource(array $ctx, string $createdBy): void {
    /* God bypass */
    if (($ctx['pRole'] ?? null) === 'god') return;
    $order = ['rep'=>0,'supervisor'=>1,'admin'=>2,'owner'=>3];
    $myLevel = $order[$ctx['role']] ?? 0;
    /* Rep: sin acceso a crear/editar recursos */
    if ($myLevel < 1) {
        json_error('Permisos insuficientes', 403);
    }
    /* Supervisor: solo puede modificar recursos que él mismo creó */
    if ($ctx['role'] === 'supervisor' && $createdBy !== $ctx['userId']) {
        json_error('Solo puedes modificar recursos que tú mismo creaste', 403);
    }
    /* Admin y owner: acceso total a recursos de su org */
}

/**
 * ¿Puede el usuario asignar un schedule al target?
 * Solo puede asignar a reps que están en su árbol descendiente.
 */
function assert_can_schedule_for(array $ctx, string $targetUserId): void {
    if ($ctx['userId'] === $targetUserId) return;
    if (($ctx['pRole'] ?? null) === 'god') return; /* God bypass */
    $visible = get_visible_user_ids($ctx['orgId'], $ctx['userId'], $ctx['role']);
    if (!in_array($targetUserId, $visible, true)) {
        json_error('No puedes planificar para este usuario', 403);
    }
}
