<?php
header('Content-Type: application/json');
echo json_encode(['version' => '2.24.7', 'php' => PHP_VERSION, 'ok' => true]);
