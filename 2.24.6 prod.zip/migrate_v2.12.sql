-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración v2.12.0
-- Ejecutar en cPanel → phpMyAdmin → cqvkelal_gestorrutas
-- ═══════════════════════════════════════════════════════════

-- ── Tabla registration_requests ──────────────────────────
-- Almacena solicitudes de registro pendientes de aprobación.
-- Los datos de usuario/org se guardan aquí hasta que god aprueba.
-- Al aprobar se crean usuario + org + membership de golpe.

CREATE TABLE IF NOT EXISTS `registration_requests` (
  `id`           VARCHAR(36)  NOT NULL PRIMARY KEY,
  `email`        VARCHAR(254) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `name`         VARCHAR(100) NOT NULL DEFAULT '',
  `org_name`     VARCHAR(200) NOT NULL DEFAULT 'Mi equipo',
  `status`       ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `rejected_reason` VARCHAR(300) DEFAULT NULL,
  `reviewed_by`  VARCHAR(36)  DEFAULT NULL,
  `reviewed_at`  DATETIME     DEFAULT NULL,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_rr_status  (status),
  KEY idx_rr_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'Migración v2.12.0 completada' AS resultado;
SELECT COUNT(*) AS solicitudes_pendientes FROM registration_requests WHERE status='pending';
