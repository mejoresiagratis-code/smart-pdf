-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración v2.21 (fix columnas faltantes)
-- Añade de forma segura todas las columnas que pueden causar
-- error 500 si no existen: settings, manager_id, targets
-- Es IDEMPOTENTE: se puede ejecutar aunque ya estén aplicadas
-- Ejecutar en phpMyAdmin → cqvkelal_gestorrutas
-- ═══════════════════════════════════════════════════════════

-- ── 1. platform_roles (v2.9) ────────────────────────────────
CREATE TABLE IF NOT EXISTS `platform_roles` (
  `id`         VARCHAR(36) NOT NULL PRIMARY KEY,
  `user_id`    VARCHAR(36) NOT NULL UNIQUE,
  `role`       ENUM('platform_admin','god') NOT NULL DEFAULT 'platform_admin',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_pr_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── 2. registration_requests (v2.12) ────────────────────────
CREATE TABLE IF NOT EXISTS `registration_requests` (
  `id`              VARCHAR(36)  NOT NULL PRIMARY KEY,
  `email`           VARCHAR(254) NOT NULL UNIQUE,
  `password_hash`   VARCHAR(255) NOT NULL,
  `name`            VARCHAR(100) NOT NULL DEFAULT '',
  `org_name`        VARCHAR(100) NOT NULL DEFAULT 'Mi equipo',
  `status`          ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `rejected_reason` TEXT         DEFAULT NULL,
  `reviewed_by`     VARCHAR(36)  DEFAULT NULL,
  `reviewed_at`     DATETIME     DEFAULT NULL,
  `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `idx_rr_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── 3. users.settings (v2.17) ───────────────────────────────
ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `settings` JSON DEFAULT NULL AFTER `avatar_url`;

UPDATE `users` SET `settings` = '{}' WHERE `settings` IS NULL;

-- ── 4. memberships.manager_id (v2.18) ───────────────────────
ALTER TABLE `memberships`
  ADD COLUMN IF NOT EXISTS `manager_id` VARCHAR(36) DEFAULT NULL AFTER `role`;

-- Añadir índice solo si no existe
SET @idx_exists = (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE table_schema = DATABASE()
    AND table_name   = 'memberships'
    AND index_name   = 'idx_mem_manager'
);
SET @sql = IF(@idx_exists = 0,
  'ALTER TABLE memberships ADD KEY idx_mem_manager (manager_id)',
  'SELECT "idx_mem_manager ya existe"'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Inferir manager_id inicial: admin/supervisor/rep sin manager → owner de su org
UPDATE `memberships` m
JOIN (
  SELECT org_id, user_id AS owner_id
  FROM memberships
  WHERE role = 'owner' AND active = 1
) owners ON owners.org_id = m.org_id
SET m.manager_id = owners.owner_id
WHERE m.manager_id IS NULL
  AND m.role != 'owner'
  AND m.active = 1;

-- ── 5. memberships.targets (v2.21 nuevo) ────────────────────
ALTER TABLE `memberships`
  ADD COLUMN IF NOT EXISTS `targets` JSON DEFAULT NULL AFTER `zone_ids`;

-- ── 6. selector en refresh_tokens (v2.5) ────────────────────
ALTER TABLE `refresh_tokens`
  ADD COLUMN IF NOT EXISTS `selector`   VARCHAR(32)  DEFAULT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `device_hint` VARCHAR(100) DEFAULT NULL AFTER `expires_at`;

-- Índice único en selector si no existe
SET @idx2 = (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE table_schema = DATABASE()
    AND table_name   = 'refresh_tokens'
    AND index_name   = 'uq_rt_selector'
);
SET @sql2 = IF(@idx2 = 0,
  'ALTER TABLE refresh_tokens ADD UNIQUE KEY uq_rt_selector (selector)',
  'SELECT "uq_rt_selector ya existe"'
);
PREPARE stmt2 FROM @sql2; EXECUTE stmt2; DEALLOCATE PREPARE stmt2;

-- ── Verificación final ───────────────────────────────────────
SELECT
  'users.settings'       AS columna, COUNT(*) AS existe
  FROM information_schema.COLUMNS
  WHERE table_schema=DATABASE() AND table_name='users' AND column_name='settings'
UNION ALL
SELECT 'memberships.manager_id', COUNT(*)
  FROM information_schema.COLUMNS
  WHERE table_schema=DATABASE() AND table_name='memberships' AND column_name='manager_id'
UNION ALL
SELECT 'memberships.targets', COUNT(*)
  FROM information_schema.COLUMNS
  WHERE table_schema=DATABASE() AND table_name='memberships' AND column_name='targets'
UNION ALL
SELECT 'platform_roles (tabla)', COUNT(*)
  FROM information_schema.TABLES
  WHERE table_schema=DATABASE() AND table_name='platform_roles'
UNION ALL
SELECT 'registration_requests (tabla)', COUNT(*)
  FROM information_schema.TABLES
  WHERE table_schema=DATABASE() AND table_name='registration_requests';

SELECT 'Migración v2.21 completada — login debería funcionar' AS resultado;
