-- ═══════════════════════════════════════════════════════════
-- GESTOR DE RUTAS — Migración v2.20
-- Dashboards robustos + tracking GPS por visita
-- ═══════════════════════════════════════════════════════════

-- 1. GPS en visitas: posición de check-in y check-out
ALTER TABLE visits
  ADD COLUMN IF NOT EXISTS `lat_in`  DECIMAL(10,7) DEFAULT NULL AFTER `check_in_at`,
  ADD COLUMN IF NOT EXISTS `lng_in`  DECIMAL(10,7) DEFAULT NULL AFTER `lat_in`,
  ADD COLUMN IF NOT EXISTS `lat_out` DECIMAL(10,7) DEFAULT NULL AFTER `check_out_at`,
  ADD COLUMN IF NOT EXISTS `lng_out` DECIMAL(10,7) DEFAULT NULL AFTER `lat_out`;

-- 2. Distancia total en sesión (ya existe distance_km ✅)
--    Añadir campo de pausa para calcular tiempo efectivo
ALTER TABLE sessions
  ADD COLUMN IF NOT EXISTS `paused_s` INT(11) NOT NULL DEFAULT 0 AFTER `elapsed_s`;

-- 3. Tabla de stats diarias precalculadas (para dashboards rápidos sin recalcular)
CREATE TABLE IF NOT EXISTS `daily_stats` (
  `id`           VARCHAR(36)  NOT NULL PRIMARY KEY,
  `org_id`       VARCHAR(36)  NOT NULL,
  `user_id`      VARCHAR(36)  NOT NULL,
  `date`         DATE         NOT NULL,
  `visits_total` INT(11)      NOT NULL DEFAULT 0,
  `visits_ok`    INT(11)      NOT NULL DEFAULT 0,
  `stops_total`  INT(11)      NOT NULL DEFAULT 0,
  `distance_km`  DECIMAL(8,3) NOT NULL DEFAULT 0,
  `elapsed_s`    INT(11)      NOT NULL DEFAULT 0,
  `coverage_pct` DECIMAL(5,2) NOT NULL DEFAULT 0,
  `route_id`     VARCHAR(36)  DEFAULT NULL,
  `calculated_at` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_daily_stats` (`org_id`, `user_id`, `date`),
  KEY `idx_ds_org_date` (`org_id`, `date`),
  KEY `idx_ds_user_date` (`user_id`, `date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Índices para queries de dashboard
ALTER TABLE sessions
  ADD INDEX IF NOT EXISTS `idx_sess_org_date` (`org_id`, `date`),
  ADD INDEX IF NOT EXISTS `idx_sess_user_date` (`user_id`, `date`),
  ADD INDEX IF NOT EXISTS `idx_sess_state` (`org_id`, `state`);

ALTER TABLE visits
  ADD INDEX IF NOT EXISTS `idx_vis_org_created` (`org_id`, `created_at`),
  ADD INDEX IF NOT EXISTS `idx_vis_user_date` (`user_id`, `check_in_at`),
  ADD INDEX IF NOT EXISTS `idx_vis_stop` (`stop_id`, `created_at`);

ALTER TABLE schedules
  ADD INDEX IF NOT EXISTS `idx_sched_assigned_date` (`assigned_to`, `date`);

SELECT 'Migración v2.20 completada' AS resultado;

-- CRÍTICO: índice único en schedules para evitar duplicados
-- Un rep solo puede tener una ruta asignada por día
ALTER TABLE schedules
  ADD UNIQUE KEY IF NOT EXISTS `uq_sched_rep_date` (`org_id`, `assigned_to`, `date`);

SELECT 'Índice único en schedules añadido' AS resultado;
