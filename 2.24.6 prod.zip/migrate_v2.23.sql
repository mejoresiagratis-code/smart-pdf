-- ══════════════════════════════════════════════════════════
-- MIGRACIÓN v2.23 — Índices para stats por rol
-- Sin cambios de esquema, solo optimización de queries
-- Seguro ejecutar más de una vez (IF NOT EXISTS)
-- ══════════════════════════════════════════════════════════

-- 1. sessions: queries de stats por rep en periodo
--    WHERE org_id=? AND user_id=? AND date BETWEEN ? AND ?
--    Ejecutada N veces (una por rep) en _rep_summary
--    Sustituye a idx_sess_user_date (user_id,date) que no filtra por org
CREATE INDEX IF NOT EXISTS idx_sess_org_user_date
  ON sessions (org_id, user_id, date);

-- 2. sessions: jornadas activas en tiempo real
--    WHERE org_id=? AND user_id IN (...) AND date=CURDATE() AND state='running'
--    Ejecutada por _active_sessions_for para todos los roles
CREATE INDEX IF NOT EXISTS idx_sess_org_state_date
  ON sessions (org_id, state, date);

-- 3. visits: conteo de visitas por rep en periodo
--    WHERE org_id=? AND user_id=? AND DATE(created_at) BETWEEN ? AND ?
--    Ejecutada N veces en _rep_summary y _period_comparison
--    Nota: DATE(created_at) no usa índice directamente — añadir created_at
CREATE INDEX IF NOT EXISTS idx_vis_org_user_created
  ON visits (org_id, user_id, created_at);

-- 4. memberships: _get_direct_report_ids
--    WHERE org_id=? AND manager_id=? AND active=1
--    Ejecutada (N supervisores + N admins) veces en cada llamada a stats
--    idx_mem_manager solo indexa manager_id sin org_id ni active
CREATE INDEX IF NOT EXISTS idx_mem_org_manager_active
  ON memberships (org_id, manager_id, active);

