plugins {
    alias(libs.plugins.kotlin.jvm)
}

// Módulo deliberadamente sin el plugin de Android: el dominio no debe
// poder importar nada de android.* por accidente. Así se cumple "Domain ·
// Kotlin puro (sin Android SDK, testeable con JUnit)" del informe de
// arquitectura sin depender de disciplina manual — el propio build falla
// si alguien intenta usar Context, Bitmap, etc. aquí.

dependencies {
    implementation(libs.kotlinx.coroutines.core) // solo por Flow/suspend; sin dependencias de plataforma Android
    implementation(libs.javax.inject) // @Inject en los UseCase sin acoplar el dominio a Hilt/Android
    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.turbine)
    testImplementation(libs.mockk)
}

// Java y Kotlin deben apuntar al MISMO bytecode target para evitar el
// desajuste "compileJava vs compileKotlin". Fijamos ambos a 17 sin exigir
// un JDK 17 concreto instalado (el CI usa JDK 17; en local vale cualquier
// JDK >= 17).
java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}
