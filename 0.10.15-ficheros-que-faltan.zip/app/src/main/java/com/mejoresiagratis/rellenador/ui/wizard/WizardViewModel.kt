package com.mejoresiagratis.rellenador.ui.wizard

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import dagger.hilt.android.qualifiers.ApplicationContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mejoresiagratis.rellenador.data.model.AiProvider
import com.mejoresiagratis.rellenador.data.model.ContractFields
import com.mejoresiagratis.rellenador.data.model.DateAutofill
import com.mejoresiagratis.rellenador.data.model.FieldResolver
import android.graphics.Bitmap
import androidx.core.graphics.scale
import com.mejoresiagratis.rellenador.data.model.SignatureData
import com.mejoresiagratis.rellenador.data.model.SignatureStamp
import com.mejoresiagratis.rellenador.data.pdf.DocumentLoader
import com.mejoresiagratis.rellenador.data.pdf.DocumentTypeDetector
import com.mejoresiagratis.rellenador.data.pdf.PdfExporter
import com.mejoresiagratis.rellenador.data.pdf.SignatureProcessor
import com.mejoresiagratis.rellenador.data.pdf.TemplateMapper
import com.mejoresiagratis.rellenador.data.pdf.AcroFormFiller
import com.mejoresiagratis.rellenador.data.pdf.SignaturePageDetector
import com.mejoresiagratis.rellenador.data.pdf.PdfPageRenderer
import com.mejoresiagratis.rellenador.data.model.ContractProfile
import com.mejoresiagratis.rellenador.data.model.TemplateFingerprint
import com.mejoresiagratis.rellenador.data.remote.SignatureLocator
import android.util.Base64
import java.io.ByteArrayOutputStream
import com.mejoresiagratis.rellenador.data.remote.MultiAiExtractor
import com.mejoresiagratis.rellenador.data.remote.ProxyApi
import com.mejoresiagratis.rellenador.data.repository.PrefsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.mejoresiagratis.rellenador.data.repository.applyTo
import com.mejoresiagratis.rellenador.data.repository.toPersisted
import javax.inject.Inject

@HiltViewModel
class WizardViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val extractor: MultiAiExtractor,
    private val loader: DocumentLoader,
    private val api: ProxyApi,
    private val prefs: PrefsRepository,
    private val locator: SignatureLocator,
    private val sigProcessor: SignatureProcessor,
    private val exporter: PdfExporter,
    private val templateMapper: TemplateMapper,
    private val filler: AcroFormFiller,
    private val pageDetector: SignaturePageDetector,
    private val docStore: com.mejoresiagratis.rellenador.data.pdf.DocumentStore,
    // Tanda 5·4 — el asistente construye su propio `FormSchema` al elegir contrato, en vez de
    // depender de que el PDF haya pasado antes por Ajustes › «Analizar y etiquetar». Los dos
    // colaboradores ya viven en el grafo (los usa `LabelEditorViewModel`), así que engancharlos
    // aquí es cero configuración de Hilt.
    private val pdfInspector: com.mejoresiagratis.rellenador.data.pdf.PdfFieldInspector,
    private val schemaBuilder: com.mejoresiagratis.rellenador.data.pdf.FormSchemaBuilder,
) : ViewModel() {

    private var previewRenderer: PdfPageRenderer? = null
    private val _state = MutableStateFlow(WizardUiState())
    val state: StateFlow<WizardUiState> = _state.asStateFlow()

    /**
     * Nombre de archivo REAL de un content:// (p. ej. "CERTIFICADO_DE_SITUACION_CENSAL.PDF").
     * `uri.lastPathSegment` en un content:// devuelve el ID crudo del proveedor SAF
     * ("document:17077"), NO el nombre — por eso hay que consultar OpenableColumns.DISPLAY_NAME.
     * Se pasa tal cual a la IA como `docNames` (el prompt hace pattern-matching sobre el
     * nombre de archivo); la traducción a nombre de tipo legible se hace aparte, solo en la UI.
     */
    private fun resolveDisplayName(uri: Uri): String =
        runCatching {
            if (uri.scheme == "content") {
                context.contentResolver.query(
                    uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) c.getString(idx)?.takeIf { it.isNotBlank() } else null
                    } else null
                }
            } else null
        }.getOrNull()
            ?: uri.lastPathSegment?.substringAfterLast('/')
                // Las copias locales (v0.8.7) llevan un prefijo "<millis>_" para evitar
                // colisiones de nombre; se quita para mostrar y para mandar a la IA el
                // nombre real del fichero.
                ?.replace(Regex("^\\d{10,}_"), "")
            ?: "documento"

    /**
     * Tipo del documento DETECTADO POR CONTENIDO para mostrar en la UI ("Certificado de
     * situación censal", "Tarjeta CIF/NIF"…). Solo PDFs con capa de texto; imágenes/fotos
     * o escaneos sin texto → "Documento" (sin OCR no hay contenido que leer). El nombre de
     * archivo NO influye. Defensivo: cualquier fallo → "Documento".
     */
    private fun detectDocType(uri: Uri, displayName: String): String {
        val mime = runCatching { context.contentResolver.getType(uri) }.getOrNull().orEmpty()
        val isPdf = mime.contains("pdf", ignoreCase = true) ||
            displayName.endsWith(".pdf", ignoreCase = true)
        if (!isPdf) return "Documento"
        val text = loader.firstPagesText(uri).orEmpty()
        return DocumentTypeDetector.fromContent(text)
    }

    /** Aviso al usuario si algún URI persistido ya no es accesible tras la restauración
     *  (SAF/Storage Access Framework revoca los permisos cuando el proceso muere si no
     *  se llamó a takePersistableUriPermission). null = sin aviso. */
    private val _restoreWarning = MutableStateFlow<String?>(null)
    val restoreWarning: StateFlow<String?> = _restoreWarning.asStateFlow()

    init {
        probeProviders()
        loadPersistedSettings()
        restoreSessionIfAny()
        observeStateForAutosave()
    }

    /** Al arrancar, si hay sesión guardada, la restaura sobre el state por defecto —
     *  se llama tras probeProviders/loadPersistedSettings para que los providers y el
     *  responsable no se pisen. Silencioso si no hay sesión o si está corrupta. */
    private fun restoreSessionIfAny() {
        viewModelScope.launch {
            val persisted = runCatching { prefs.loadWizardSession() }.getOrNull() ?: return@launch
            // Copiamos sobre el state actual (que ya trae providers/responsable/perfil)
            val restored = persisted.applyTo(_state.value)
            _state.value = restored
            // Tanda 5·4 — rehidratar `activeSchema`. La persistencia no lo guarda a propósito
            // (vive en `schemas_v1` bajo la huella), y al restaurar hay dos casos:
            //   1) Si el DTO trae `templateFingerprint` no vacía y hay esquema guardado con esa
            //      huella, lo cargamos: es el caso de un PDF ajeno inspeccionado ya antes.
            //   2) Si el DTO trae un URI de contrato del usuario cuyo AcroForm contiene los
            //      nombres firma de un `BUILTIN`, resolvemos ahí sin abrir el PDF — la huella no
            //      es necesaria para eso, y el `recognize()` sobre los nombres persistidos basta.
            //   3) Si no, `activeSchema` sigue null y `WizardScreen` cae a `canonFillSections()`
            //      con `FieldKeys.IDENTITY` — el comportamiento previo a la 5·4, sin regresión.
            //
            // Se hace después del `applyTo` para no bloquear la restauración: si algo falla al
            // leer `schemas_v1`, la sesión se restaura igual, sólo pinta con la red de seguridad.
            runCatching {
                val recognizedId = com.mejoresiagratis.rellenador.data.model.BuiltinSchemas
                    .recognize(restored.userFieldNames)
                val schema = when (recognizedId) {
                    com.mejoresiagratis.rellenador.data.model.BuiltinSchemas.ORANGE_DISTRIBUTION_ID ->
                        com.mejoresiagratis.rellenador.data.model.BuiltinSchemas
                            .orangeDistribution(restored.templateFingerprint)
                    else -> restored.templateFingerprint
                        .takeIf { it.isNotBlank() }
                        ?.let { prefs.findSchema(it) }
                }
                if (schema != null) {
                    _state.value = _state.value.copy(activeSchema = schema)
                }
            }
            // Comprueba accesibilidad real de los URIs restaurados. Si alguno ya no es
            // válido, avisamos al usuario para que sepa qué documentos volver a subir.
            val invalid = mutableListOf<String>()
            restored.docUris.forEach { uri ->
                val ok = runCatching {
                    context.contentResolver.openInputStream(uri)?.use { true } ?: false
                }.getOrDefault(false)
                if (!ok) invalid.add(uri.lastPathSegment?.substringAfterLast('/') ?: uri.toString())
            }
            if (invalid.isNotEmpty()) {
                _restoreWarning.value = "Algunos documentos ya no son accesibles y deberás " +
                    "volver a añadirlos: ${invalid.joinToString(", ").take(120)}"
                // Retirar los URIs inválidos del state para que no salgan zombis en la UI
                val validUris = restored.docUris.filter { u ->
                    runCatching { context.contentResolver.openInputStream(u)?.use { true } ?: false }
                        .getOrDefault(false)
                }
                _state.value = _state.value.copy(docUris = validUris)
            }
        }
    }

    /** Observa el state y guarda a disco cada cambio "de progreso" (evitando ruido
     *  durante extracciones vivas con `busy`). Usa distinctUntilChanged por el flag
     *  step+contractSource+... implícito en toPersisted() para no escribir cada tick. */
    private fun observeStateForAutosave() {
        viewModelScope.launch {
            _state
                .map { it.toPersisted() }
                .distinctUntilChanged()
                .collect { snapshot ->
                    runCatching { prefs.saveWizardSession(snapshot) }
                }
        }
    }

    /** Borra el snapshot persistido y vuelve al estado inicial. La sesión reset
     *  respeta providers, responsable y proxy (recargándolos como en el init). */
    fun resetSession() {
        viewModelScope.launch {
            runCatching { prefs.clearWizardSession() }
        }
        // Borra las copias locales de los documentos del contrato anterior: si no, se
        // acumularían indefinidamente en el almacenamiento de la app.
        docStore.clear()
        previewRenderer?.close()
        previewRenderer = null
        _restoreWarning.value = null
        _state.value = WizardUiState()  // vuelta al Paso 1
        // Recarga los valores por defecto (responsable, proxy, providers) para no
        // dejar la app con esos campos vacíos justo después de un reset.
        loadPersistedSettings()
        probeProviders()
    }

    /** Descarta el aviso de URIs inválidos tras leerlo. */
    fun dismissRestoreWarning() {
        _restoreWarning.value = null
    }

    private fun loadPersistedSettings() {
        viewModelScope.launch {
            val name = runCatching { prefs.responsableComercial.first() }
                .getOrDefault(ContractFields.RESPONSABLE_VALUE)
            _state.value = _state.value.copy(responsableComercial = name)
        }
        viewModelScope.launch {
            val url = runCatching { prefs.proxyBaseUrlOverride.first() }.getOrDefault("")
            _state.value = _state.value.copy(proxyBaseUrlOverride = url)
        }
        // Privacidad (v0.9.1). El consentimiento recordado y el filtro solo-UE sobreviven
        // a «Empezar otro contrato»: son decisiones del usuario sobre sus datos, no
        // estado de un contrato concreto.
        viewModelScope.launch {
            val consent = runCatching { prefs.consentRemembered.first() }.getOrDefault(false)
            val eu = runCatching { prefs.euOnly.first() }.getOrDefault(false)
            _state.value = _state.value.copy(
                consentRemembered = consent,
                euOnly = eu,
                enabledProviders = if (eu) _state.value.enabledProviders.filter { it.eu }.toSet()
                                   else _state.value.enabledProviders,
            )
        }
    }

    /** GET al proxy: qué motores tienen clave en servidor. */
    private fun probeProviders() {
        viewModelScope.launch {
            val resp = runCatching { api.providers() }.getOrNull()
            val available = resp?.providers.orEmpty()
                .filterValues { it }.keys
                .mapNotNull { AiProvider.fromId(it) }
            // Si el usuario ya eligió motores en Ajustes, respetar esa selección
            // (solo los que además sigan disponibles en el servidor).
            val persisted = runCatching { prefs.enabledProviders.first() }.getOrNull()
            val enabled = if (!persisted.isNullOrEmpty()) persisted.filter { it in available }.toSet()
                          else available.toSet()
            _state.value = _state.value.copy(
                availableProviders = available,
                enabledProviders = enabled.ifEmpty { available.toSet() }
            )
        }
    }

    // ---- Paso 1: contrato ----
    fun chooseDefaultContract() {
        _state.value = _state.value.copy(
            contractSource = ContractSource.DEFAULT,
            userContractUri = null,
            // Tanda 5·4 — el asistente se dibuja desde el `FormSchema` activo. Con el contrato
            // por defecto (el de Orange en `assets/contrato-base.pdf`) ese esquema es siempre el
            // `BUILTIN` de siempre; sin fingerprint porque no se calcula sobre el asset.
            activeSchema = com.mejoresiagratis.rellenador.data.model.BuiltinSchemas.orangeDistribution(),
        )
        detectSignaturePages()
    }
    fun chooseUserContract(uri: Uri) {
        _state.value = _state.value.copy(
            contractSource = ContractSource.USER,
            userContractUri = uri,
            // El nombre del fichero, no el id opaco del URI. Se resuelve aquí y no en la UI
            // porque hace falta el `ContentResolver` y porque el mismo nombre sirve de título
            // del `FormSchema` que se construye abajo.
            userContractName = runCatching { resolveDisplayName(uri) }.getOrNull(),
        )
        // Leer los nombres reales de campo del PDF del usuario y auto-mapear.
        viewModelScope.launch {
            // Tanda 5·4 — el asistente construye su propio `FormSchema` para cualquier PDF, sin
            // pasar por Ajustes › «Analizar y etiquetar». Tres cosas en una pasada por I/O
            // (campos + páginas + geometría), y las tres se resuelven aquí mismo para no abrir el
            // PDF varias veces (el mismo antipatrón que arrastra `LabelEditorViewModel`).
            data class Inspected(
                val fieldNames: List<String>,
                val inspected: List<com.mejoresiagratis.rellenador.data.pdf.PdfFieldInspector.Field>,
                val pageCount: Int,
            )
            val insp = withContext(Dispatchers.IO) {
                runCatching {
                    val cr = context.contentResolver
                    val fieldNames = cr.openInputStream(uri)!!.use { filler.listFields(it) }
                    val inspected = cr.openInputStream(uri)!!.use { pdfInspector.inspect(it) }
                    val pageCount = cr.openInputStream(uri)!!.use { pdfInspector.pageCount(it) }
                    Inspected(fieldNames, inspected, pageCount)
                }.getOrElse { Inspected(emptyList(), emptyList(), 0) }
            }
            val fields = insp.fieldNames
            if (fields.isEmpty()) {
                _state.value = _state.value.copy(
                    userFieldNames = emptyList(),
                    needsMapping = false,
                    activeSchema = null,
                )
                return@launch
            }
            val suggestions = templateMapper.suggest(fields)
            val mapping = suggestions.mapNotNull { sug ->
                sug.canonicalKey?.let { it to sug.realField }
            }.toMap()

            // Huella con el número real de páginas — la que usa el editor. La huella provisional
            // que había aquí (`fields.size` en lugar de `pageCount`) hacía que la huella del
            // asistente y la del editor no casaran nunca: un PDF etiquetado en Ajustes salía como
            // «no encontrado» cuando volvía a este flujo. La corrección es la 5·4 la que la
            // necesita, y sirve además a lo que había: `findTemplate(fp)` sigue funcionando
            // porque el mapeo se guarda con la huella con la que se buscó, no con otra.
            val fp = TemplateFingerprint.of(insp.pageCount, fields)
            val saved = runCatching { prefs.findTemplate(fp) }.getOrNull()

            // Esquema del PDF:
            //   1) si es reconocible por nombres de campo, se resuelve al `BUILTIN`
            //      correspondiente (hoy: contrato de Orange, contrato de empresas de Aire);
            //   2) si no, se busca uno guardado por huella (creado por el editor o por una
            //      apertura anterior);
            //   3) si no hay, se construye con `FormSchemaBuilder` y se persiste — con eso, la
            //      siguiente apertura del mismo PDF ya lo reencuentra por huella.
            val recognizedId = com.mejoresiagratis.rellenador.data.model.BuiltinSchemas.recognize(fields)
            val schema = when (recognizedId) {
                com.mejoresiagratis.rellenador.data.model.BuiltinSchemas.ORANGE_DISTRIBUTION_ID ->
                    com.mejoresiagratis.rellenador.data.model.BuiltinSchemas.orangeDistribution(fp)
                else -> {
                    val existing = runCatching { prefs.findSchema(fp) }.getOrNull()
                    val built = existing
                        ?: schemaBuilder.build(
                            insp.inspected, fp, insp.pageCount,
                            // El nombre del fichero como título de partida, igual que hace el
                            // editor de Ajustes: "Contrato_empresas.pdf" identifica el formulario
                            // mucho mejor que "Formulario", y es editable después.
                            title = _state.value.userContractName ?: "Formulario",
                        )
                    if (existing == null) {
                        runCatching { prefs.saveSchema(built) }
                    }
                    built
                }
            }

            _state.value = _state.value.copy(
                userFieldNames = fields,
                fieldMapping = saved ?: mapping,
                needsMapping = saved == null,   // si ya había plantilla guardada, no hace falta revisar
                templateFingerprint = fp,
                activeSchema = schema,
            )
            detectSignaturePages()
        }
    }

    /**
     * El usuario ha revisado las etiquetas del PDF en el paso 1 (0.10.12) y confirma.
     *
     * El panel de revisión es el mismo de Ajustes y lo mueve [LabelEditorViewModel], que es quien
     * guarda el esquema por huella. Aquí sólo se **adopta** el resultado para que `FillStep` y el
     * mapeo dibujen lo que el usuario acaba de confirmar, sin esperar a releerlo de disco.
     *
     * `needsMapping` se apaga porque ya se ha revisado, pero eso ya no decide si el botón del paso
     * 1 ofrece revisar: desde la 0.10.12 se ofrece siempre que haya un PDF propio con campos.
     */
    fun adoptSchema(schema: com.mejoresiagratis.rellenador.data.model.FormSchema) {
        _state.value = _state.value.copy(activeSchema = schema, needsMapping = false)
    }

    /**
     * Casillas de cabecera propias del contrato reconocido, con el estado que debe llevar el PDF
     * final. Tanda 5·4 §6.3.
     *
     * Del contrato de Aire (`Contrato_empresas.pdf`, 481 campos) se sabe algo que no está en
     * ningún analísis y que sí se ve al abrir el PDF con `pypdf`: las tres casillas de la
     * cabecera CLIENTE — `Casilla de verificación 56` (ALTA NUEVA), `57` (MODIFICACIÓN) y `58`
     * (PORTABILIDAD) — vienen del PDF **marcadas de fábrica** con `/V = /Sí`. El §6.3 del plan
     * pedía «marcar ALTA NUEVA y nada más», y con casillas marcadas de fábrica «nada más»
     * exige `desmarcar` las otras dos, no dejarlas.
     *
     * Con Orange no hay nada que añadir aquí (sus tres casillas son las de tipo de
     * identificación, que ya viajan por `checkboxStateFor(tipoIdentificacion)`).
     */
    private fun altaCheckboxes(): Map<String, String> {
        val schema = _state.value.activeSchema ?: return emptyMap()
        return when (schema.id) {
            com.mejoresiagratis.rellenador.data.model.BuiltinSchemas.AIRE_CONTRATO_EMPRESAS_ID -> mapOf(
                "Casilla de verificación 56" to com.mejoresiagratis.rellenador.data.model.ContractFields.CHECKBOX_ON,
                "Casilla de verificación 57" to com.mejoresiagratis.rellenador.data.model.ContractFields.CHECKBOX_OFF,
                "Casilla de verificación 58" to com.mejoresiagratis.rellenador.data.model.ContractFields.CHECKBOX_OFF,
            )
            else -> emptyMap()
        }
    }

    /**
     * Tanda 5·4d — reparte `fieldValues` entre el mapa de texto y el de botones según el
     * `FieldKind` del esquema activo (ver `ValueRouting.kt`).
     *
     * Los mapas fijos se aplican DESPUÉS y ganan: `checkboxStateFor()` (tipo de identificación)
     * y `altaCheckboxes()` (cabecera ALTA NUEVA) son política de la app, no dato del usuario.
     * Sin esquema activo o con un esquema `BUILTIN` todo `TEXT` (Orange), el resultado es
     * idéntico al de la 5·4c.
     */
    private fun routeValues(s: WizardUiState) =
        com.mejoresiagratis.rellenador.data.model.routeFieldValues(s.fieldValues, s.activeSchema)

    /**
     * Traductor `clave de CANON -> nombre real` del PDF que se está rellenando.
     *
     * Tanda 5·4 — la fuente es ahora el `FormSchema` activo cuando existe: cada
     * `FormField.canonical` que apunta a una clave transversal se traduce a su `name` real. Esto
     * cubre los dos casos:
     *  - Orange: cada `FormField.name` **es** la clave de `CANON`, y las canónicas apuntan a las
     *    claves transversales; el mapa resultante es una identidad respecto a `CANON` y
     *    `FieldKeys` se comporta como antes de esta tanda.
     *  - PDF ajeno: los canónicos que el esquema ya haya enganchado (por reconocimiento o por
     *    edición manual) definen el mapeo real; los que no, no se traducen y el sitio que lo
     *    necesitaba lo verá con la clave original — el mismo comportamiento que había con
     *    `fieldMapping` vacío.
     *
     * Con la fuente aquí, la 5·3 y todos sus consumidores (`FieldValidator`, `AutoFillPolicy`…)
     * dejan de depender del `fieldMapping` heredado del editor de mapeo, que a partir de la 5·4
     * es un sitio más para conservar coherencia y no la fuente de verdad.
     */
    fun fieldKeys(): com.mejoresiagratis.rellenador.data.model.FieldKeys {
        val schema = _state.value.activeSchema
        val fromSchema: Map<String, String> = schema?.let {
            // Recorre `CANON` para preservar el orden canónico habitual: si dos campos del PDF
            // apuntan a la misma canónica (no debería pasar, pero es defensivo), gana el primero.
            val byCanonical = it.allFields()
                .filter { f -> f.canonical != null }
                .groupBy { f -> f.canonical!! }
                .mapValues { (_, fs) -> fs.first().name }
            com.mejoresiagratis.rellenador.data.model.ContractFields.CANON
                .mapNotNull { c ->
                    val canonicalKey = com.mejoresiagratis.rellenador.data.model.BuiltinSchemas
                        .canonicalFor(c.key) ?: return@mapNotNull null
                    val realName = byCanonical[canonicalKey] ?: return@mapNotNull null
                    c.key to realName
                }.toMap()
        } ?: emptyMap()
        // El `fieldMapping` clásico gana sobre lo derivado del esquema — el usuario puede haber
        // corregido a mano en `MappingEditor` un enganche que el esquema no tenía.
        val merged = fromSchema + _state.value.fieldMapping
        return com.mejoresiagratis.rellenador.data.model.FieldKeys(merged)
    }

    /** Persiste el mapeo actual bajo la huella de la plantilla, para reaplicarlo la próxima vez. */
    fun rememberTemplateMapping() {
        val s = _state.value
        if (s.templateFingerprint.isBlank() || s.fieldMapping.isEmpty()) return
        viewModelScope.launch { prefs.saveTemplate(s.templateFingerprint, s.fieldMapping) }
    }

    // ---- Perfiles e historial (Tanda F) ----
    private fun buildProfile(label: String): ContractProfile = ContractProfile(
        label = label,
        guardado = java.time.Instant.now().toString(),
        fingerprint = _state.value.templateFingerprint,
        // Tanda 5·3 — `fieldValues` ya está por nombre real, así que el perfil nace en la
        // versión nueva. `fieldMapping` se sigue guardando: es lo que permite migrar los perfiles
        // ANTIGUOS al leerlos, y sirve de constancia de con qué PDF se hizo.
        campos = _state.value.fieldValues.filterValues { it.isNotBlank() },
        fieldMapping = _state.value.fieldMapping,
        version = ContractProfile.VERSION,
    )

    fun exportProfileJson(label: String): String = prefs.exportProfileJson(buildProfile(label))

    fun saveCurrentToHistory(label: String) {
        viewModelScope.launch { prefs.saveToHistory(buildProfile(label)) }
    }

    fun loadHistoryList(onLoaded: (List<Pair<String, ContractProfile>>) -> Unit) {
        viewModelScope.launch { onLoaded(prefs.listHistory()) }
    }

    fun deleteHistoryEntry(id: String) {
        viewModelScope.launch { prefs.deleteFromHistory(id) }
    }

    /** Aplica un perfil (de historial o importado) sobre los campos actuales. */
    fun applyProfile(profile: ContractProfile) {
        _state.value = _state.value.copy(
            fieldValues = _state.value.fieldValues + profile.campos
        )
    }

    fun importProfileFromJson(raw: String): Boolean {
        val profile = prefs.importProfileJson(raw) ?: return false
        // Un perfil importado de un fichero puede venir de una versión anterior de la app.
        applyProfile(profile.migrated())
        return true
    }

    /** Ajuste manual de una asignación canónica -> real en el editor de mapeo. */
    fun setMapping(canonicalKey: String, realField: String?) {
        val m = _state.value.fieldMapping.toMutableMap()
        if (realField == null) m.remove(canonicalKey) else m[canonicalKey] = realField
        _state.value = _state.value.copy(fieldMapping = m)
    }

    // ---- Paso 2: documentación ----
    /**
     * Añade documentos copiándolos a almacenamiento propio de la app (v0.8.7). El permiso
     * de lectura de un `content://` del selector es efímero: si Android mata el proceso en
     * segundo plano, al volver ya no se puede abrir. Con la copia local, la sesión se
     * restaura completa.
     *
     * Se muestran de inmediato (para que la UI responda al instante) y se sustituyen por
     * la copia en cuanto termina, que es cuestión de milisegundos.
     */
    fun addDocuments(uris: List<Uri>) {
        _state.value = _state.value.copy(docUris = (_state.value.docUris + uris).distinct())
        viewModelScope.launch {
            val persisted = docStore.persist(uris)
            val replacement = uris.zip(persisted).toMap()
            _state.value = _state.value.copy(
                docUris = _state.value.docUris.map { replacement[it] ?: it }.distinct()
            )
        }
    }
    fun removeDocument(uri: Uri) {
        _state.value = _state.value.copy(docUris = _state.value.docUris - uri)
        docStore.delete(uri)   // no dejar copias huérfanas ocupando espacio
    }
    fun toggleProvider(p: AiProvider) {
        // Con el filtro solo-UE activo, un motor de fuera no puede encenderse.
        if (_state.value.euOnly && !p.eu) return
        val cur = _state.value.enabledProviders.toMutableSet()
        if (!cur.add(p)) cur.remove(p)
        _state.value = _state.value.copy(enabledProviders = cur)
        viewModelScope.launch { prefs.setEnabled(cur.toList()) }
    }

    /** Lanza la extracción multi-motor y avanza a Revisión. */
    /**
     * Punto de entrada desde el botón «Analizar con IA» (v0.9.1). Si el usuario no ha
     * marcado «no volver a preguntar», muestra primero el aviso: los documentos llevan
     * datos personales de terceros y algunos motores procesan fuera de la UE.
     */
    fun requestExtraction() {
        val s = _state.value
        if (!s.canAdvanceFromDocs) return
        if (s.consentRemembered) runExtraction()
        else _state.value = s.copy(showConsent = true)
    }

    /** El usuario aceptó el aviso. [remember] = no volver a preguntar en este dispositivo. */
    fun acceptConsent(remember: Boolean) {
        _state.value = _state.value.copy(showConsent = false, consentRemembered = remember)
        if (remember) viewModelScope.launch { prefs.setConsentRemembered(true) }
        runExtraction()
    }

    fun dismissConsent() {
        _state.value = _state.value.copy(showConsent = false)
    }

    /**
     * Solo motores que procesan en la UE. Al activarlo se desactivan los que no lo son:
     * dejarlos marcados pero inertes haría creer que siguen participando.
     */
    fun setEuOnly(value: Boolean) {
        val cur = _state.value.enabledProviders
        val kept = if (value) cur.filter { it.eu }.toSet() else cur
        _state.value = _state.value.copy(euOnly = value, enabledProviders = kept)
        viewModelScope.launch {
            prefs.setEuOnly(value)
            if (kept != cur) prefs.setEnabled(kept.toList())
        }
    }

    fun runExtraction() {
        val s = _state.value
        if (!s.canAdvanceFromDocs) return
        viewModelScope.launch {
            _state.value = s.copy(
                busy = true, busyMsg = "Preparando documentos…", error = null,
                activeProvider = null, finishedProviders = emptySet(),
                activeDocLabel = null, progressCurrent = 0, progressTotal = 0
            )
            // Construye los payloads AGRUPADOS POR ARCHIVO (jul 2026): antes se aplanaba
            // todo a una lista de páginas sueltas y MultiAiExtractor hacía una llamada
            // por página — para un PDF de 13 páginas, hasta 13x más peticiones de red
            // por motor que la app web (que manda el PDF entero como un único "doc" por
            // llamada, confirmado auditando su código real). Ahora cada archivo viaja
            // como UN grupo (todas sus páginas juntas en una sola llamada por motor);
            // MultiAiExtractor trocea internamente solo si un archivo excede su límite
            // de páginas por llamada.
            val loadedPerUri = withContext(Dispatchers.IO) {
                s.docUris.map { uri ->
                    val displayName = resolveDisplayName(uri)
                    val pages = runCatching { loader.load(uri) }.getOrElse { emptyList() }
                    // Tipo del documento DETECTADO POR CONTENIDO (no por el nombre): se lee
                    // el texto del PDF y se busca la frase-firma del tipo. Fotos / escaneos
                    // sin texto → "Documento". Se hace aquí (IO) para no bloquear la UI.
                    val docType = runCatching { detectDocType(uri, displayName) }.getOrElse { "Documento" }
                    Triple(pages, displayName, docType)
                }
            }
            val kept = loadedPerUri.filter { it.first.isNotEmpty() }
            val docGroups = kept.map { it.first }
            // A la IA le va el NOMBRE DE ARCHIVO real (el prompt hace pattern-matching sobre
            // patrones de nombre); la UI mostrará el tipo detectado por contenido.
            val docNames = kept.map { it.second }
            // Tipo por documento: lo detectado en local (PDFs con texto). Los que quedaron
            // como "Documento" (fotos / escaneos sin texto) los completará la IA vía
            // onDocTypeDetected — por eso es mutable.
            val docTypeByName = kept.associate { it.second to it.third }.toMutableMap()
            if (docGroups.isEmpty()) {
                _state.value = _state.value.copy(busy = false, error = "No se pudieron leer los documentos.")
                return@launch
            }
            _state.value = _state.value.copy(busyMsg = "Analizando con IA…")
            val result = runCatching {
                extractor.extract(
                    docGroups, s.enabledProviders.toList(), docNames = docNames,
                    // v0.9.3 — se mandan los campos que el PDF tiene DE VERDAD, no una
                    // lista fija transcrita a mano. Si el usuario cargó su propio
                    // contrato, `userFieldNames` son sus nombres reales y `fieldMapping`
                    // traduce cada uno a su significado canónico para que la IA no
                    // devuelva claves inexistentes.
                    fieldNames = s.userFieldNames.takeIf { it.isNotEmpty() }
                        ?: ContractFields.CANON.map { it.key },
                    fieldMapping = s.fieldMapping,
                    // Tanda 2 — el motor activo se refleja en vivo en el chip/indicador;
                    // al terminar un motor se marca como completado (queda con el tick
                    // aunque otro empiece justo después, por eso se añade sin quitar).
                    onProviderStart = { docLabel, p ->
                        // La IA recibió el nombre de archivo real (docLabel); la UI muestra el
                        // TIPO detectado por contenido ("Certificado de situación censal"…),
                        // o "Documento" si aún no se pudo tipificar (foto/escaneo sin texto,
                        // que la IA completará al responder). El sufijo "(parte X/Y)" de los
                        // archivos troceados se normaliza al nombre base.
                        val base = docLabel.substringBefore(" (parte ").trim()
                        _state.value = _state.value.copy(
                            activeProvider = p,
                            activeDocLabel = docTypeByName[base] ?: "Documento"
                        )
                    },
                    onDocTypeDetected = { docLabel, tipo ->
                        // La detección local (texto del PDF) manda: es determinista y ya está
                        // confirmada. La IA solo rellena los huecos — fotos de DNI/NIE y
                        // escaneos-imagen, que en local salen como "Documento". Si un motor
                        // se equivoca con un PDF que ya tipificamos bien, no lo pisa.
                        // El nombre puede venir con sufijo "(parte X/Y)" si el archivo se
                        // troceó: se normaliza al nombre base para casar con el mapa.
                        val base = docLabel.substringBefore(" (parte ").trim()
                        if (docTypeByName[base].isNullOrBlank() || docTypeByName[base] == "Documento") {
                            docTypeByName[base] = tipo
                            if (_state.value.activeDocLabel == "Documento") {
                                _state.value = _state.value.copy(activeDocLabel = tipo)
                            }
                        }
                    },
                    onProviderFinish = { p ->
                        _state.value = _state.value.copy(
                            finishedProviders = _state.value.finishedProviders + p
                        )
                    },
                    onProgress = { current, total ->
                        _state.value = _state.value.copy(progressCurrent = current, progressTotal = total)
                    }
                )
            }.getOrElse {
                _state.value = _state.value.copy(
                    busy = false, error = it.message,
                    activeProvider = null, finishedProviders = emptySet(),
                    activeDocLabel = null, progressCurrent = 0, progressTotal = 0
                )
                return@launch
            }
            // Prerelleno inicial: valor de mayor consenso por campo.
            val prefill = result.proposals.associate { fp ->
                fp.fieldKey to (fp.candidates.firstOrNull()?.value ?: "")
            }.toMutableMap()
            // Tanda 5·3 — estos dos valores los pone la app, no salen de ningún documento, así
            // que hay que escribirlos bajo el NOMBRE REAL del campo en el PDF actual. Antes se
            // metían con la clave de Orange incluso con un PDF ajeno: con `fieldMapping` acertaban
            // al rellenar (por la traducción de `AcroFormFiller`) pero contaminaban `fieldValues`
            // con claves que no eran del PDF, y era la mitad del fallo que esta tanda arregla.
            // `realIfPresent` además NO los escribe si el formulario no tiene ese campo — el
            // mismo problema que la 5·0 arregló para el responsable, que seguía vivo en las fechas.
            val keys = fieldKeys()
            val known = _state.value.userFieldNames
            keys.realIfPresent(ContractFields.RESPONSABLE_KEY, known)?.let { realKey ->
                prefill[realKey] = _state.value.responsableComercial
            }
            // La fecha del contrato es la de HOY (día de la firma), nunca la que aparezca
            // en los documentos aportados. La IA extraía la fecha del censal o del 036
            // (p. ej. "23 de julio de 2026") y, como el campo ya venía con valor, el
            // autorrelleno lo respetaba y el contrato salía fechado en el pasado.
            val fechaKeys = ContractFields.DATE_KEYS.associateWith { keys.realIfPresent(it, known) }
            fechaKeys.values.filterNotNull().forEach { prefill.remove(it) }
            val fechaValues = DateAutofill.values(
                ContractFields.DATE_KEYS.associateWith { canonKey ->
                    fechaKeys[canonKey]?.let { prefill[it] } ?: ""
                }
            )
            fechaValues.forEach { (canonKey, value) ->
                fechaKeys[canonKey]?.let { prefill[it] = value }
            }

            // v0.8.0: la extracción va DIRECTA a Relleno (ya no existe Revisión IA).
            // Aquí se decide qué se autorrellena y qué queda marcado para decisión.
            val resolved = FieldResolver.resolve(
                proposals = result.proposals,
                packages = result.packages,
                alreadyFilled = prefill,
                keys = keys,
            )
            prefill.putAll(resolved.autoValues)

            _state.value = _state.value.copy(
                busy = false, step = Step.RELLENO,
                proposals = result.proposals, packages = result.packages,
                tipoIdentificacion = result.tipoIdentificacion, enginesOk = result.enginesOk,
                fieldValues = prefill,
                fieldStates = resolved.states,
                fieldOrigins = resolved.origins,
                fieldCandidates = resolved.candidates,
                undoStack = emptyList(),
                // NO se rellena `error` aquí a propósito: los fallos por motor ya se
                // ven en el panel colapsable "Ver motores no disponibles" (engineErrors).
                // Duplicarlos en el banner rojo genérico era redundante y aparecía
                // siempre visible aunque el usuario no quisiera verlo.
                engineErrors = result.errors,
                engineIssues = result.issues,
                activeProvider = null, finishedProviders = emptySet(),
                activeDocLabel = null, progressCurrent = 0, progressTotal = 0
            )
        }
    }

    // ---- Paso 3: revisión / relleno ----
    fun setFieldValue(key: String, value: String) {
        pushUndo(labelOf(key), mapOf(key to value), FieldState.USER)
    }
    fun clearField(key: String) {
        pushUndo(labelOf(key), mapOf(key to ""), FieldState.EMPTY)
    }

    // ── Relleno unificado (v0.8.0) ───────────────────────────────────────────

    /** Etiqueta legible del campo. Tanda 5·3 — `key` es el nombre real, así que la resuelve
     *  `FieldKeys` (nombre real -> clave de `CANON` -> etiqueta) en vez de buscarla en `CANON`. */
    private fun labelOf(key: String): String = fieldKeys().labelOf(key)

    /**
     * Aplica un cambio de campos registrando el estado ANTERIOR para poder deshacerlo.
     * Es el único punto que escribe en `fieldValues` desde la UI, así que todo cambio
     * del usuario es reversible.
     */
    private fun pushUndo(label: String, delta: Map<String, String>, newState: FieldState) {
        val s = _state.value
        val prevValues = delta.keys.associateWith { s.fieldValues[it] }
        val prevStates = delta.keys.associateWith { s.fieldStates[it] }
        val prevOrigins = delta.keys.associateWith { s.fieldOrigins[it] }
        val values = s.fieldValues.toMutableMap()
        val states = s.fieldStates.toMutableMap()
        delta.forEach { (k, v) ->
            if (v.isBlank()) { values.remove(k); states[k] = FieldState.EMPTY }
            else { values[k] = v; states[k] = newState }
        }
        _state.value = s.copy(
            fieldValues = values,
            fieldStates = states,
            undoStack = (s.undoStack + UndoEntry(label, prevValues, prevStates, prevOrigins)).takeLast(20),
        )
    }

    /**
     * Elige uno de los candidatos de un campo en conflicto o dudoso. Aplica también los
     * campos enlazados (CP/Población/Provincia de una dirección) en una sola acción
     * deshacible, para que elegir una dirección no deje media dirección de otra.
     */
    fun chooseCandidate(key: String, candidate: FieldCandidate) {
        val s = _state.value
        val delta = mapOf(key to candidate.value) + candidate.linked
        val prevValues = delta.keys.associateWith { s.fieldValues[it] }
        val prevStates = delta.keys.associateWith { s.fieldStates[it] }
        val prevOrigins = delta.keys.associateWith { s.fieldOrigins[it] }
        val values = s.fieldValues.toMutableMap().apply { putAll(delta) }
        val states = s.fieldStates.toMutableMap().apply {
            delta.keys.forEach { this[it] = FieldState.USER }
        }
        val origins = s.fieldOrigins.toMutableMap().apply {
            delta.keys.forEach { this[it] = candidate.origin }
        }
        _state.value = s.copy(
            fieldValues = values, fieldStates = states, fieldOrigins = origins,
            undoStack = (s.undoStack + UndoEntry(labelOf(key), prevValues, prevStates, prevOrigins))
                .takeLast(20),
        )
    }

    /** Marca un campo dudoso/conflictivo como "lo relleno a mano": deja de bloquear. */
    /**
     * "Dejar en blanco · lo relleno a mano": vacía el campo, quita su procedencia y deja
     * de bloquear el avance.
     *
     * Antes solo cambiaba el estado a EMPTY pero **conservaba el valor y el origen**, así
     * que el campo seguía mostrando el dato que el usuario acababa de rechazar. Si además
     * el campo estaba autorrellenado, no había forma de vaciarlo desde la hoja.
     */
    fun dismissField(key: String) {
        val s = _state.value
        _state.value = s.copy(
            fieldValues = s.fieldValues - key,
            fieldStates = s.fieldStates + (key to FieldState.EMPTY),
            fieldOrigins = s.fieldOrigins - key,
            undoStack = (s.undoStack + UndoEntry(
                labelOf(key),
                mapOf(key to s.fieldValues[key]),
                mapOf(key to s.fieldStates[key]),
                mapOf(key to s.fieldOrigins[key]),
            )).takeLast(20),
        )
    }

    /** Deshace la última acción del paso de Relleno. */
    fun undoLast() {
        val s = _state.value
        val last = s.undoStack.lastOrNull() ?: return
        val values = s.fieldValues.toMutableMap()
        val states = s.fieldStates.toMutableMap()
        val origins = s.fieldOrigins.toMutableMap()
        last.previousValues.forEach { (k, v) -> if (v == null) values.remove(k) else values[k] = v }
        last.previousStates.forEach { (k, v) -> if (v == null) states.remove(k) else states[k] = v }
        last.previousOrigins.forEach { (k, v) -> if (v == null) origins.remove(k) else origins[k] = v }
        _state.value = s.copy(
            fieldValues = values, fieldStates = states, fieldOrigins = origins,
            undoStack = s.undoStack.dropLast(1),
        )
    }

    /**
     * Tanda 3 — corrección manual del tipo de identificación (CIF/NIF/NIE).
     * Hasta ahora `tipoIdentificacion` solo lo fijaba la IA en la extracción y no
     * había forma de corregirlo si se equivocaba — un error aquí determina qué
     * casilla del PDF se marca (NIF vs CIF) y no era detectable hasta la firma.
     */
    fun setTipoIdentificacion(tipo: String) {
        _state.value = _state.value.copy(tipoIdentificacion = tipo)
    }

    /**
     * Tanda 3 — copia los 4 campos de la dirección fiscal al bloque de comercio
     * (_2) de un toque. Caso de uso frecuente: mismo domicilio fiscal y comercial.
     * No sobrescribe con vacío: si el campo fiscal no está relleno, no toca el _2.
     */
    fun copyFiscalToComercio() {
        val s = _state.value
        // Tanda 5·2b — los pares fiscal→comercio se resuelven por canónica en vez de
        // concatenar "_2" al nombre (docs/PLAN_FASE_5.md, hallazgo 2.6).
        // Tanda 5·3 — los dos extremos del par se traducen al nombre real del PDF actual.
        val keys = fieldKeys()
        val delta = com.mejoresiagratis.rellenador.data.model.BuiltinSchemas
            .fiscalToComercioKeyPairs()
            .mapNotNull { (fromCanon, toCanon) ->
                val from = keys.real(fromCanon)
                val to = keys.realIfPresent(toCanon, s.userFieldNames) ?: return@mapNotNull null
                s.fieldValues[from]?.takeIf { it.isNotBlank() }?.let { to to it }
            }.toMap()
        if (delta.isNotEmpty()) {
            _state.value = s.copy(fieldValues = s.fieldValues + delta)
        }
    }

    /** Aplica un paquete en bloque (dirección/empresa/persona/banco).
     *  Para direcciones, targetBlock2=true lo manda al bloque de comercio (_2). */


    /** Abre el contrato activo (por defecto o del usuario) para leerlo. */
    private fun openContract(): java.io.InputStream =
        _state.value.userContractUri?.let { context.contentResolver.openInputStream(it)!! }
            ?: context.assets.open("contrato-base.pdf")

    /**
     * Coordenadas calibradas contra `contrato-relleno-a1.pdf` (contrato real ya firmado).
     * Medidas con pdfplumber: para cada página se localizó el rótulo "EL DISTRIBUIDOR" y
     * la imagen de firma inmediatamente asociada a él (más cercana en Y, alineada en X),
     * y se convirtió su posición a CENTRO relativo (xRel/yRel esperan centro, no esquina —
     * ver AcroFormFiller). Esto reemplaza el valor fijo anterior (0.30/0.82 para todas)
     * que colocaba la firma a un lado en vez de justo debajo y centrada al rótulo.
     *
     * Nota importante: el rótulo "EL DISTRIBUIDOR" NO está siempre a la izquierda de la
     * página. En las páginas 30 y 33 el bloque del distribuidor está a la DERECHA (Xfera
     * a la izquierda, distribuidor a la derecha); en 24, 45 y 54 está a la izquierda.
     *
     * heightRel (0.114 ≈ 90/792) es la caja MÁXIMA disponible en el hueco real del
     * contrato — la firma se escala para caber dentro de widthRel×heightRel sin
     * deformarse (letterbox), en vez de forzar su altura a partir del aspect ratio
     * de la imagen de origen (eso causaba el recorte/ampliación en exceso del PDF final).
     *
     * Índice = página 0-based. Valores: (xRel centro, yRel centro, widthRel, heightRel).
     */
    private data class Calib(val x: Float, val y: Float, val w: Float, val h: Float)
    private val calibratedStamps: Map<Int, Calib> = mapOf(
        23 to Calib(0.275f, 0.463f, 0.256f, 0.114f),   // Página 24 — izquierda
        29 to Calib(0.722f, 0.261f, 0.256f, 0.114f),   // Página 30 — derecha
        32 to Calib(0.220f, 0.940f, 0.256f, 0.114f),   // Página 33 — izquierda, muy abajo
        44 to Calib(0.222f, 0.853f, 0.256f, 0.114f),   // Página 45 — izquierda
        53 to Calib(0.183f, 0.886f, 0.256f, 0.114f)    // Página 54 — izquierda
    )

    /** Devuelve el stamp para una página: usa calibración si existe, si no cae al ancla detectada. */
    private fun stampFor(pageIdx: Int, anchors: Map<Int, Float>): SignatureStamp {
        calibratedStamps[pageIdx]?.let { c ->
            return SignatureStamp(pageIndex = pageIdx, xRel = c.x, yRel = c.y, widthRel = c.w, heightRel = c.h)
        }
        val yr = anchors[pageIdx]?.let { (it + 0.06f).coerceAtMost(0.95f) } ?: 0.82f
        return SignatureStamp(pageIndex = pageIdx, xRel = 0.30f, yRel = yr, widthRel = 0.28f, heightRel = 0.114f)
    }

    /** Detecta las páginas de firma del contrato activo (Tanda B). */
    fun detectSignaturePages() {
        viewModelScope.launch {
            _state.value = _state.value.copy(detectingStructure = true)
            val det = withContext(Dispatchers.IO) {
                runCatching { openContract().use { pageDetector.detect(it) } }.getOrNull()
            }
            if (det == null) {
                _state.value = _state.value.copy(detectingStructure = false)
                return@launch
            }
            // Colocación por defecto en cada página detectada (calibrada si existe).
            val stamps = det.signPages.map { pageIdx -> stampFor(pageIdx, det.anchors) }
            _state.value = _state.value.copy(
                signPages = det.signPages,
                signAnchors = det.anchors,
                stamps = if (_state.value.signature != null) stamps else _state.value.stamps,
                // Página total del contrato elegido — se usa en el resumen "Estructura
                // detectada" del Paso 1 (Contrato), para dar el mismo feedback inmediato
                // que ya tenía la app web al elegir/subir un contrato.
                totalPages = det.totalPages,
                detectingStructure = false
            )
        }
    }

    /** Añade una página de firma manualmente (1-based desde la UI). */
    fun addSignPage(pageOneBased: Int) {
        val idx = pageOneBased - 1
        if (idx < 0) return
        if (idx in _state.value.signPages) return
        _state.value = _state.value.copy(signPages = (_state.value.signPages + idx).sorted())
    }

    /** Quita una página de firma. */
    fun removeSignPage(pageIdx: Int) {
        _state.value = _state.value.copy(
            signPages = _state.value.signPages - pageIdx,
            stamps = _state.value.stamps.filterNot { it.pageIndex == pageIdx }
        )
    }

    /** Estampado MASIVO: coloca la firma en TODAS las páginas de firma a la vez,
     *  usando la calibración real por página si existe (fiel a bulkStamps de la web). */
    fun stampAllPages() {
        val sig = _state.value.signature ?: return
        val stamps = _state.value.signPages.map { pageIdx -> stampFor(pageIdx, _state.value.signAnchors) }
        _state.value = _state.value.copy(stamps = stamps)
    }

    /** Estampado en UNA página concreta (modo una a una). */
    fun stampOnePage(pageIdx: Int) {
        val sig = _state.value.signature ?: return
        val others = _state.value.stamps.filterNot { it.pageIndex == pageIdx }
        _state.value = _state.value.copy(
            stamps = others + stampFor(pageIdx, _state.value.signAnchors)
        )
    }

    // ---- Paso 5: firma ----
    /** Firma dibujada en el lienzo: bitmap -> PNG transparente. */
    /** Bitmap "crudo" (antes de tintar) de la última firma preparada, para poder
     *  reprocesar en vivo al cambiar color/fondo sin volver a llamar a la IA de
     *  localización. isPhoto indica qué pipeline usar al reprocesar. */
    private var rawSignatureBitmap: Bitmap? = null
    private var rawSignatureIsPhoto: Boolean = false

    fun setDrawnSignature(bmp: Bitmap) {
        rawSignatureBitmap = bmp
        rawSignatureIsPhoto = false
        // Trazo dibujado: tintar (color elegido) sobre transparente con Otsu.
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val thr = sigProcessor.otsuThreshold(px)
        val processed = sigProcessor.processInk(bmp, thr, _state.value.inkColor, _state.value.sigBackground)
            ?: bmp
        val data = sigProcessor.toSignatureData(processed)
        // Colocación por defecto en la página de firma del distribuidor (pág. 24).
        _state.value = _state.value.copy(signature = data)
        // Colocar en todas las páginas de firma detectadas (o la 24 por defecto).
        if (_state.value.signPages.isNotEmpty()) stampAllPages()
        else _state.value = _state.value.copy(stamps = listOf(defaultStamp()))
    }

    /** Firma extraída de una foto: localiza con IA, recorta y limpia. */
    /** Guarda la última foto elegida en "Extraer de foto", para poder recortarla de
     *  nuevo sin tener que volver a seleccionarla. */
    private var lastPickedPhoto: Bitmap? = null

    fun rememberPickedPhoto(bmp: Bitmap) { lastPickedPhoto = bmp }
    fun lastPickedPhotoOrNull(): Bitmap? = lastPickedPhoto

    /**
     * "Refrescar" — vuelve a llamar a la IA de localización sobre la ÚLTIMA foto
     * elegida. Los modelos de visión no son perfectamente deterministas: una segunda
     * pasada puede acertar una caja distinta (más ajustada, sin colar una línea
     * impresa cercana) aunque la foto sea la misma. No cambia nada del recorte manual
     * si el usuario lo hizo — solo tiene sentido si se llegó aquí vía "Extraer de
     * foto" con IA activada.
     */
    fun retryAiExtraction() {
        val bmp = lastPickedPhoto ?: return
        extractSignatureFromPhoto(bmp)
    }

    /**
     * Recorte MANUAL confirmado por el usuario: NO pasa por la IA de localización —
     * el usuario ya decidió la región exacta arrastrando el dedo. Se ejecuta
     * directamente el pipeline de tinta (aplanar + Otsu + recorte a bounding-box)
     * sobre esa región, igual que cuando el locator sí acierta.
     */
    fun useManualSignatureCrop(cropped: Bitmap) {
        val processed = sigProcessor.fromPhoto(cropped, _state.value.inkColor, _state.value.sigBackground)
            ?: cropped
        rawSignatureBitmap = cropped
        rawSignatureIsPhoto = true
        val data = sigProcessor.toSignatureData(processed)
        _state.value = _state.value.copy(signature = data, error = null)
        if (_state.value.signPages.isNotEmpty()) stampAllPages()
        else _state.value = _state.value.copy(stamps = listOf(defaultStamp()))
    }

    /**
     * "Foto completa": el usuario decide EXPLÍCITAMENTE no recortar nada — la foto
     * entera es la región a procesar, tal cual. A diferencia de
     * `extractSignatureFromPhoto()`, esta función NUNCA llama a la IA de localización:
     * si lo hiciera, una caja devuelta más pequeña que el 100% (habitual cuando la foto
     * ya es un recorte ajustado casi sin margen, como suele pasar tras usar la cámara o
     * subir una foto ya recortada) volvería a recortar por encima de la decisión del
     * usuario, cortando trazos de la firma — justo el bug real reportado: "al elegir
     * foto completa sale recortada". Mismo pipeline que `useManualSignatureCrop`, solo
     * que sin pasar primero por `sigProcessor.crop()` con una caja de la IA.
     */
    fun useWholePhotoAsSignature(bmp: Bitmap) {
        val processed = sigProcessor.fromPhoto(bmp, _state.value.inkColor, _state.value.sigBackground)
            ?: bmp
        rawSignatureBitmap = bmp
        rawSignatureIsPhoto = true
        val data = sigProcessor.toSignatureData(processed)
        _state.value = _state.value.copy(signature = data, error = null)
        if (_state.value.signPages.isNotEmpty()) stampAllPages()
        else _state.value = _state.value.copy(stamps = listOf(defaultStamp()))
    }

    fun extractSignatureFromPhoto(bmp: Bitmap) {
        lastPickedPhoto = bmp
        viewModelScope.launch {
            _state.value = _state.value.copy(locatingSignature = true, error = null)
            // Redimensionar antes de mandar a locate_signature (mismo motivo que en
            // DocumentLoader: fotos a resolución completa provocan 400/500 en las IAs).
            val forLocate = withContext(Dispatchers.Default) {
                val longSide = maxOf(bmp.width, bmp.height)
                if (longSide > 2000) {
                    val scale = 2000f / longSide
                    bmp.scale((bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1))
                } else bmp
            }
            val b64 = withContext(Dispatchers.IO) {
                val jpg = ByteArrayOutputStream().also { forLocate.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
                Base64.encodeToString(jpg, Base64.NO_WRAP)
            }
            val box = runCatching {
                locator.locate(b64, _state.value.availableProviders)
            }.getOrNull()
            // Fallback razonable (0.2.0): si ningún motor localiza la firma, NO se aplica
            // processInk a la foto ENTERA (eso sacaba resultados basura: cualquier sombra
            // o arruga se colaba como "trazo"). Se ofrece la foto original tal cual y se
            // avisa al usuario, en vez de forzar un procesado ciego. Tampoco se guarda como
            // "bitmap crudo reprocesable": cambiar color/fondo no tendría sentido sobre una
            // foto sin recortar ni tintar.
            val data: com.mejoresiagratis.rellenador.data.model.SignatureData
            if (box != null) {
                val cropped = sigProcessor.crop(bmp, box)
                // El recorte a bounding-box SIGUE activo aunque el locator ya recorte:
                // el riesgo de "desviarse a una esquina" (0.2.0) solo aplica a fotos
                // COMPLETAS sin recortar (ese caso ya no se procesa en absoluto, ver
                // fallback abajo). Sobre una región ya acotada por el locator, recortar
                // de nuevo al trazo real es seguro y necesario: sin esto, una caja del
                // locator floja (con margen vacío) produce un lienzo grande casi en
                // blanco que luego se amplía/recorta mal al encajarlo en el hueco del
                // contrato (letterbox).
                val processed = sigProcessor.fromPhoto(
                    cropped, _state.value.inkColor, _state.value.sigBackground
                ) ?: cropped
                rawSignatureBitmap = cropped
                rawSignatureIsPhoto = true
                data = sigProcessor.toSignatureData(processed)
            } else {
                // Sin caja fiable del locator: en vez de dejar la foto cruda sin
                // procesar (que no se ve como una firma limpia), se aplica el MISMO
                // pipeline completo (aplanado + Otsu + recorte a bounding-box) a la
                // foto entera. Funciona muy bien si la foto ya es solo la firma
                // aislada sobre fondo claro (caso frecuente), y es un mejor punto de
                // partida que la foto sin tocar incluso si hay más contenido alrededor.
                val processedWhole = sigProcessor.fromPhoto(bmp, _state.value.inkColor, _state.value.sigBackground)
                if (processedWhole != null) {
                    rawSignatureBitmap = bmp
                    rawSignatureIsPhoto = true
                    data = sigProcessor.toSignatureData(processedWhole)
                } else {
                    // Ni siquiera se detectó tinta en toda la foto: ofrecer tal cual.
                    rawSignatureBitmap = null
                    data = sigProcessor.toSignatureData(bmp)
                }
            }
            _state.value = _state.value.copy(
                locatingSignature = false, signature = data,
                error = if (box == null) "No se localizó automáticamente el área exacta; se procesó la imagen completa." else null
            )
            if (_state.value.signPages.isNotEmpty()) stampAllPages()
            else _state.value = _state.value.copy(stamps = listOf(defaultStamp()))
        }
    }

    private fun defaultStamp() = SignatureStamp(
        pageIndex = 23,       // página 24 (bloque EL DISTRIBUIDOR)
        // Coordenadas calibradas contra contrato-relleno-a1.pdf (centro real)
        xRel = 0.275f, yRel = 0.463f, widthRel = 0.256f, heightRel = 0.114f
    )

    /** Ajuste manual de la colocación (posición/tamaño relativos). Mantiene heightRel
     *  proporcional al ancho para que el slider de "Tamaño" siga escalando la caja
     *  completa (no solo el ancho) y no vuelva a producir deformación. */
    fun updateStamp(xRel: Float, yRel: Float, widthRel: Float) {
        val prevStamp = _state.value.stamps.firstOrNull()
        // Mantiene la proporción ancho/alto de la caja calibrada al reescalar con el slider.
        val ratio = if (prevStamp != null && prevStamp.widthRel > 0f)
            prevStamp.heightRel / prevStamp.widthRel else 0.114f / 0.256f
        _state.value = _state.value.copy(
            stamps = listOf(SignatureStamp(23, xRel, yRel, widthRel, widthRel * ratio))
        )
    }

    fun clearSignature() {
        _state.value = _state.value.copy(signature = null, stamps = emptyList())
        rawSignatureBitmap = null
    }

    /**
     * Aplica una firma retocada a mano (tras borrar partes de fondo no deseadas con
     * el editor de "Retocar firma"). El bitmap que llega YA está en su forma final
     * (tintado, con alpha graduado, con las zonas borradas puestas transparentes) —
     * no es una foto cruda que se pueda re-procesar con Otsu.
     *
     * Por eso se pone `rawSignatureBitmap = null`: si no lo hiciéramos, un cambio
     * posterior de color de tinta o de fondo (`setInkColor`/`setSigBackground`)
     * volvería a `reprocessSignatureFromRaw()`, que reprocesaría el bitmap CRUDO
     * original (sin el retoque) y el usuario perdería su borrado sin ningún aviso.
     * Es mejor que esos ajustes queden inactivos tras retocar a mano — no rompen
     * nada, simplemente no tienen bitmap crudo sobre el que aplicarse — que perder
     * el trabajo de borrado en silencio.
     */
    fun applyErasedSignature(bmp: Bitmap) {
        rawSignatureBitmap = null
        _state.value = _state.value.copy(signature = sigProcessor.toSignatureData(bmp))
    }

    /** Genera el PDF final (relleno + firmado) a fichero interno. */
    fun generatePdf(onReady: (java.io.File) -> Unit = {}) {
        val s = _state.value
        val routed = routeValues(s)
        viewModelScope.launch {
            _state.value = s.copy(busy = true, busyMsg = "Generando PDF final…", error = null)
            val file = runCatching {
                withContext(Dispatchers.IO) {
                    exporter.generateToFile(
                        userContractUri = s.userContractUri,
                        // Tanda 5·4d — el reparto entre el mapa de texto y el de botones lo
                        // decide el `FieldKind` del esquema, no la pantalla. Ver
                        // `ValueRouting.kt`: un radio de Aire con `setValue("On")` escribe un
                        // estado que no existe y no se ve hasta abrir el PDF generado.
                        values = routed.text,
                        signature = s.signature,
                        stamps = s.stamps,
                        // Tanda 5·3 — las casillas también van por nombre real, y `fieldMapping`
                        // ya NO se pasa: `values` y `checkboxes` llegan con la clave definitiva,
                        // así que `AcroFormFiller` no tiene nada que traducir. Es lo que el plan
                        // llamaba «dejar de necesitar la capa de traducción».
                        // Tanda 5·4 §6.3 — a las casillas de tipo de identificación se suman las
                        // de cabecera del contrato reconocido (ALTA NUEVA en el contrato de Aire,
                        // con MODIFICACIÓN y PORTABILIDAD desmarcadas de propina).
                        checkboxes = routed.buttons + fieldKeys().reindex(
                            com.mejoresiagratis.rellenador.data.model.ContractFields
                                .checkboxStateFor(s.tipoIdentificacion)
                        ) + altaCheckboxes()
                    )
                }
            }.getOrElse {
                _state.value = _state.value.copy(busy = false, error = "No se pudo generar el PDF: ${it.message}")
                return@launch
            }
            _state.value = _state.value.copy(busy = false, outputFile = file, outputReady = true)
            onReady(file)
        }
    }

    fun shareIntentFor(file: java.io.File) = exporter.shareIntent(file)
    fun uriFor(file: java.io.File) = exporter.uriFor(file)

    /** Genera el PDF de preview y abre el renderer bajo demanda. */
    fun buildPreview() {
        viewModelScope.launch { rebuildPreviewNow() }
    }

    /**
     * Versión awaitable de la reconstrucción de previsualización — a diferencia de
     * `buildPreview()` (fire-and-forget, para el botón "Actualizar previsualización"),
     * esta se puede llamar con `await`/dentro de un `launch` propio de la UI para
     * garantizar que la previsualización YA refleja el estampado antes de hacer scroll
     * a la página firmada. Sin esto, el scroll llegaba antes de que la firma nueva
     * apareciera dibujada en la página — el usuario veía la página "en blanco" un
     * instante y podía pensar que no se había estampado.
     */
    suspend fun rebuildPreviewNow() {
        val s = _state.value
        val routed = routeValues(s)
        _state.value = s.copy(busy = true, busyMsg = "Preparando previsualización…", error = null)
        val result = runCatching {
            withContext(Dispatchers.IO) {
                val file = exporter.generatePreview(
                    userContractUri = s.userContractUri,
                    // Tanda 5·4d — ver la nota de `generatePdf`.
                    values = routed.text,
                    signature = s.signature,
                    stamps = s.stamps,
                    // Tanda 5·3 — ver la nota de `generatePdf`.
                    // Tanda 5·4 §6.3 — igual que en `generatePdf`, con las casillas de cabecera
                    // del contrato reconocido (ALTA NUEVA en el contrato de Aire).
                    checkboxes = routed.buttons + fieldKeys().reindex(
                        com.mejoresiagratis.rellenador.data.model.ContractFields
                            .checkboxStateFor(s.tipoIdentificacion)
                    ) + altaCheckboxes()
                )
                previewRenderer?.close()
                PdfPageRenderer(file)
            }
        }.getOrElse {
            _state.value = _state.value.copy(busy = false, error = "No se pudo previsualizar: ${it.message}")
            return
        }
        previewRenderer = result
        _state.value = _state.value.copy(busy = false, totalPages = result.pageCount, previewReady = true)
    }

    fun renderer(): PdfPageRenderer? = previewRenderer

    /** Mueve la firma de una página a una posición relativa (por arrastre/toque). */
    fun moveStamp(pageIdx: Int, xRel: Float, yRel: Float) {
        val cur = _state.value.stamps.firstOrNull { it.pageIndex == pageIdx }
        val width = cur?.widthRel ?: 0.256f
        val height = cur?.heightRel ?: 0.114f
        val others = _state.value.stamps.filterNot { it.pageIndex == pageIdx }
        _state.value = _state.value.copy(
            stamps = others + com.mejoresiagratis.rellenador.data.model.SignatureStamp(
                pageIdx, xRel.coerceIn(0f, 1f), yRel.coerceIn(0f, 1f), width, height
            )
        )
    }

    /** Cambia el color de la tinta de la firma (re-procesa si hay firma cruda). */
    /** Cambia el color de la tinta y reprocesa en vivo desde el bitmap crudo (sin
     *  volver a llamar a la IA de localización). */
    fun setInkColor(color: Int) {
        _state.value = _state.value.copy(inkColor = color)
        reprocessSignatureFromRaw()
    }
    fun setSigBackground(bg: com.mejoresiagratis.rellenador.data.pdf.SignatureProcessor.Background) {
        _state.value = _state.value.copy(sigBackground = bg)
        reprocessSignatureFromRaw()
    }

    private fun reprocessSignatureFromRaw() {
        val raw = rawSignatureBitmap ?: return
        val processed = if (rawSignatureIsPhoto) {
            sigProcessor.fromPhoto(raw, _state.value.inkColor, _state.value.sigBackground) ?: raw
        } else {
            val px = IntArray(raw.width * raw.height)
            raw.getPixels(px, 0, raw.width, 0, 0, raw.width, raw.height)
            val thr = sigProcessor.otsuThreshold(px)
            sigProcessor.processInk(raw, thr, _state.value.inkColor, _state.value.sigBackground) ?: raw
        }
        _state.value = _state.value.copy(signature = sigProcessor.toSignatureData(processed))
    }

    /** Guarda la firma actual para reutilizarla (persistida en PrefsRepository). */
    fun saveCurrentSignature(name: String) {
        val sig = _state.value.signature ?: return
        viewModelScope.launch {
            val b64 = android.util.Base64.encodeToString(sig.pngBytes, android.util.Base64.NO_WRAP)
            prefs.saveSignature(name, b64, sig.aspectRatio)
            refreshSavedSignatures()
        }
    }
    fun refreshSavedSignatures() {
        viewModelScope.launch {
            _state.value = _state.value.copy(savedSignatures = prefs.listSignatures())
        }
    }
    fun useSavedSignature(name: String) {
        viewModelScope.launch {
            val saved = prefs.getSignature(name) ?: return@launch
            val bytes = android.util.Base64.decode(saved.first, android.util.Base64.NO_WRAP)
            _state.value = _state.value.copy(
                signature = com.mejoresiagratis.rellenador.data.model.SignatureData(bytes, saved.second)
            )
            if (_state.value.signPages.isNotEmpty()) stampAllPages()
            else _state.value = _state.value.copy(stamps = listOf(defaultStamp()))
        }
    }

    // ---- Ajustes (perfil comercial, URL proxy) ----
    fun setResponsableComercial(name: String) {
        _state.value = _state.value.copy(responsableComercial = name)
        viewModelScope.launch { prefs.setResponsableComercial(name) }
    }

    fun setProxyBaseUrlOverride(url: String) {
        _state.value = _state.value.copy(proxyBaseUrlOverride = url)
        viewModelScope.launch { prefs.setProxyBaseUrlOverride(url) }
    }

    // ---- Navegación ----
    fun goTo(step: Step) { _state.value = _state.value.copy(step = step) }
    fun next() {
        val cur = _state.value.step
        val nextIdx = (cur.index + 1).coerceAtMost(Step.entries.last().index)
        _state.value = _state.value.copy(step = Step.entries[nextIdx])
    }
    fun back() {
        val cur = _state.value.step
        val prevIdx = (cur.index - 1).coerceAtLeast(0)
        _state.value = _state.value.copy(step = Step.entries[prevIdx])
    }
    fun dismissError() { _state.value = _state.value.copy(error = null) }

    override fun onCleared() {
        previewRenderer?.close(); previewRenderer = null
        super.onCleared()
    }
}
