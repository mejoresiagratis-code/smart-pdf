<?php
/**
 * ai-proxy.php — Proxy multi-IA del Rellenador de Contratos PdV (F6)
 * Hosting compartido (cPanel, PHP >= 8.0, ext: curl, gd, json).
 *
 * GET  -> {"ok":true,"providers":{"claude":true,"gemini":false,...}}   (qué motores tienen clave en servidor)
 * POST -> {"provider":"claude","prompt":"...","docs":[{"mime":"...","b64":"..."}],"task":"extract"|"locate_signature","max_tokens":1000}
 *      <- {"ok":true,"text":"<respuesta cruda del modelo>"}            (el front conserva su parseAIJson/mergeResults)
 *
 * Seguridad: claves SOLO aquí (config fuera del webroot si es posible), whitelist de
 * proveedores/modelos, límite de tamaño, reducción de imágenes en servidor (GD),
 * rate-limit por IP en ficheros temporales, CORS restringido al propio dominio.
 */
declare(strict_types=1);

// Refuerzo: garantiza tiempo suficiente para esperar a Gemini (CURLOPT_TIMEOUT=120s
// más abajo) SIN depender solo de max_execution_time global de cPanel — si esa
// config del hosting vuelve a ser demasiado corta (p.ej. tras una actualización),
// este script se protege solo. Si tu hosting tiene deshabilitada esta función
// (raro, pero posible en shared hosting muy restrictivo), no hace nada (no rompe).
@set_time_limit(240);

/* ── Config: busca primero FUERA del webroot, si no, junto al script ── */
$cfgPaths = [
    dirname(__DIR__, 2) . '/ai-proxy.config.php',   // p.ej. /home/usuario/ai-proxy.config.php
    __DIR__ . '/ai-proxy.config.php',
];
$CFG = null;
foreach ($cfgPaths as $p) { if (is_readable($p)) { $CFG = require $p; break; } }
if (!is_array($CFG)) {
    http_response_code(500);
    header('Content-Type: application/json');
    exit(json_encode(['ok' => false, 'error' => 'Falta ai-proxy.config.php (copia ai-proxy.config.sample.php y pon tus claves).']));
}

/* ── Constantes operativas ── */
const MAX_BODY      = 20 * 1024 * 1024;  // 20 MB de JSON entrante
const MAX_DOCS      = 12;
const MAX_IMG_SIDE  = 2000;              // reducción server-side: lado mayor
const JPEG_QUALITY  = 85;
const RATE_MAX      = 60;                // peticiones…
const RATE_WINDOW   = 600;               // …por 10 min e IP

const PROVIDERS = [
    'claude'  => ['model' => 'claude-sonnet-5',          'pdf' => true ], // actualizado (gen. anterior: sonnet-4-6)
    'gemini'  => ['model' => 'gemini-3.5-flash (+3.1-flash-lite fallback)', 'pdf' => true ],
    'groq'    => ['model' => 'openai/gpt-oss-120b',       'pdf' => false], // llama-3.3-70b deprecado 17-jun-2026; PDFs llegan como texto
    'grok'    => ['model' => 'grok-4.3',                 'pdf' => false], // actualizado (Grok 2 muy antiguo; 4.3 es el flagship vigente, con visión)
    'mistral' => ['model' => 'mistral-small-latest',     'pdf' => false], // 🇪🇺 UE (Francia) · visión + texto
    'scaleway'=> ['model' => 'mistral-small-3.2-24b-instruct-2506', 'pdf' => false], // 🇪🇺 UE (Francia, grupo Iliad)
    'ovh'     => ['model' => 'Mistral-Small-3.2-24B-Instruct-2506', 'pdf' => false], // 🇪🇺 UE (Francia)
    'nebius'  => ['model' => 'mistralai/Mistral-Small-3.1-24B-Instruct', 'pdf' => false], // 🇪🇺 UE
    'eurouter'=> ['model' => 'mistral-small-4',          'pdf' => false], // 🇪🇺 pasarela UE (jul 2026: 'mistral-small-latest' no es un slug válido del catálogo propio de EUrouter — usan nombres cortos propios, no el naming directo de Mistral)
];
/* Proveedores compatibles con la API de OpenAI (chat/completions). El endpoint y el
   modelo se pueden sobrescribir en el config (['endpoints'][id] y ['models'][id]),
   porque los identificadores de modelo de cada proveedor cambian con el tiempo. */
const OPENAI_COMPAT = [
    'grok'     => ['url' => 'https://api.x.ai/v1/chat/completions',                         'label' => 'Grok'],
    'mistral'  => ['url' => 'https://api.mistral.ai/v1/chat/completions',                   'label' => 'Mistral'],
    'scaleway' => ['url' => 'https://api.scaleway.ai/v1/chat/completions',                  'label' => 'Scaleway'],
    'ovh'      => ['url' => 'https://oai.endpoints.kepler.ai.cloud.ovh.net/v1/chat/completions', 'label' => 'OVHcloud'],
    'nebius'   => ['url' => 'https://api.studio.nebius.com/v1/chat/completions',            'label' => 'Nebius'],
    'eurouter' => ['url' => 'https://api.eurouter.ai/api/v1/chat/completions',              'label' => 'EUrouter'], // docs: todos los endpoints van prefijados con /api
];
/* Modelos ALTERNATIVOS a probar, en orden, si el modelo principal de PROVIDERS falla
 * con un código que sugiere problema DE MODELO (no de cuota general): 400 (argumento
 * inválido, a veces "modelo no reconocido"), 403 (bloqueado a nivel de proyecto/cuenta),
 * 404 (modelo no encontrado). Esto da robustez ante nombres de modelo que un proveedor
 * cambia, bloquea, o deja de reconocer sin previo aviso — en vez de fallar directamente,
 * el proxy prueba el siguiente de la lista antes de rendirse con ese motor.
 * Puedes ampliar esta lista según lo que vayas viendo fallar en producción. */
const ALT_MODELS = [
    // EUrouter (jul 2026): catálogo propio con slugs cortos (ej. "mistral-small-4",
    // "mistral-large-2"), verificados contra su documentación pública real — NO usar
    // el naming directo de Mistral ("mistral-small-latest") ni nombres estilo
    // HuggingFace ("mistralai/Mistral-Small-..."), que no existen en su catálogo y
    // dieron 404 en producción. Fallback a un modelo más grande si small-4 fallara.
    'eurouter' => ['mistral-large-2'],
    // Grok: si el flagship 4.3 da problema de cuenta/cuota, probar el "fast" (más barato,
    // también con visión) antes de rendirse.
    'grok'     => ['grok-4.1-fast'],
    // Mistral: si mistral-small-latest fallara con un error de cuenta/modelo (no el caso
    // habitual, que suele ser alucinación del propio modelo, no un fallo de nombre),
    // probar el siguiente escalón.
    'mistral'  => ['mistral-medium-latest'],
];

/* Gemini (jul 2026): Google retiró gemini-2.5-flash Y gemini-2.5-flash-lite de golpe
   el 9-jul-2026 (404 "no longer available"), adelantándose sin aviso a la fecha oficial
   de baja que su propia página de deprecaciones anunciaba (16-oct-2026 para 2.5-flash).
   Confirmado con reportes activos en el foro oficial de Google de esas mismas fechas —
   no es un fallo de este proxy, es un cambio unilateral de Google. Por eso TODA la
   familia 2.5 se ha retirado de aquí: ya no sirve ni como fallback. Reemplazo: 3.5 Flash
   (GA estable, sin fecha de baja anunciada) y 3.1 Flash-Lite (GA estable, baja prevista
   07-may-2027, multimodal: texto/imagen/PDF) como fallback ligero.
   El modo "alt" alterna estos dos por documento. (Gemini 2.0 fue retirado: 404 desde
   01-jun-2026.) */
const GEMINI_MODELS = ['gemini-3.5-flash', 'gemini-3.1-flash-lite'];
/* Llama 3.3 70B no tiene visión: las imágenes en Groq se enrutan a Llama 4 Scout. */
const GROQ_VISION_MODEL = 'qwen/qwen3.6-27b'; // llama-4-scout deprecado 17-jun-2026; único modelo con visión real que queda en Groq (nota: preview, no GA)
const MAX_DOC_TEXT      = 60000; // caracteres de texto de PDF por documento

/* ── Helpers ── */
function jout(array $o, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    exit(json_encode($o, JSON_UNESCAPED_UNICODE));
}
function clientIp(): string {
    return preg_replace('/[^0-9a-fA-F:.]/', '', $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}
function rateLimit(): void {
    $f = sys_get_temp_dir() . '/aiproxy_' . md5(clientIp());
    $now = time();
    $hits = is_readable($f) ? array_filter(
        array_map('intval', explode(',', (string)file_get_contents($f))),
        fn(int $t): bool => $now - $t < RATE_WINDOW
    ) : [];
    if (count($hits) >= RATE_MAX) {
        jout(['ok' => false, 'error' => 'Demasiadas peticiones; espera unos minutos.'], 429);
    }
    $hits[] = $now;
    @file_put_contents($f, implode(',', $hits), LOCK_EX);
}
/** Reduce imágenes con GD (resuelve memoria con fotos grandes). PDFs pasan tal cual. */
function shrinkImage(string $mime, string $b64): array {
    if (!str_starts_with($mime, 'image/') || !function_exists('imagecreatefromstring')) {
        return [$mime, $b64];
    }
    $raw = base64_decode($b64, true);
    if ($raw === false) return [$mime, $b64];
    $im = @imagecreatefromstring($raw);
    if ($im === false) return [$mime, $b64];
    $w = imagesx($im); $h = imagesy($im);
    $k = min(1.0, MAX_IMG_SIDE / max($w, $h));
    if ($k < 1.0) {
        $nw = max(1, (int)round($w * $k)); $nh = max(1, (int)round($h * $k));
        $dst = imagecreatetruecolor($nw, $nh);
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255)); // PNG transparente -> blanco
        imagecopyresampled($dst, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
        imagedestroy($im); $im = $dst;
    }
    ob_start(); imagejpeg($im, null, JPEG_QUALITY); $jpg = (string)ob_get_clean();
    imagedestroy($im);
    return ['image/jpeg', base64_encode($jpg)];
}
/** POST JSON genérico con curl. Devuelve [arrayDecodificado, httpCode]. */
function httpJson(string $url, array $headers, array $body): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => array_merge(['Content-Type: application/json'], $headers),
        CURLOPT_POSTFIELDS     => json_encode($body, JSON_UNESCAPED_UNICODE),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 180,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $res  = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($res === false) jout(['ok' => false, 'error' => 'Conexión con el proveedor: ' . $err], 502);
    $j = json_decode((string)$res, true);
    return [is_array($j) ? $j : ['raw' => $res], $code];
}

/* ── Adaptadores (espejo de callClaude / callGemini / callOpenAICompat del front) ── */
function callClaudeSrv(string $key, string $prompt, array $docs, int $maxTokens): string {
    $content = [['type' => 'text', 'text' => $prompt]];
    foreach ($docs as $d) {
        $content[] = str_starts_with($d['mime'], 'image/')
            ? ['type' => 'image',    'source' => ['type' => 'base64', 'media_type' => $d['mime'], 'data' => $d['b64']]]
            : ['type' => 'document', 'source' => ['type' => 'base64', 'media_type' => 'application/pdf', 'data' => $d['b64']]];
    }
    [$j, $code] = httpJson('https://api.anthropic.com/v1/messages',
        ['x-api-key: ' . $key, 'anthropic-version: 2023-06-01'],
        ['model' => PROVIDERS['claude']['model'], 'max_tokens' => $maxTokens,
         'messages' => [['role' => 'user', 'content' => $content]]]);
    if (isset($j['error'])) jout(['ok' => false, 'error' => 'Claude: ' . ($j['error']['message'] ?? 'error')], $code ?: 502);
    $txt = '';
    foreach (($j['content'] ?? []) as $c) if (($c['type'] ?? '') === 'text') $txt .= $c['text'];
    return $txt;
}
function callGeminiSrv(string $key, string $prompt, array $docs, int $maxTokens, int $seq, string $mode = 'g35'): string {
    $parts = [['text' => $prompt]];
    foreach ($docs as $d) {
        if (!empty($d['text'])) $parts[0]['text'] .= "\n\n=== TEXTO DEL DOCUMENTO ===\n" . $d['text'];
        else $parts[] = ['inline_data' => ['mime_type' => $d['mime'], 'data' => $d['b64']]];
    }
    // systemInstruction (jul 2026) — reforzamos el rol y la regla anti-invención en un
    // campo con más peso en la atención del modelo que el prompt de usuario. Es un
    // refuerzo DUPLICADO a propósito: no quitamos nada del $prompt (que también se manda
    // a Claude/Groq/Mistral/EUrouter/Scaleway; cambiar allí obligaría a refactor multi-
    // motor). Aquí solo Gemini lo ve dos veces, y en su caso ayuda por cómo pondera este
    // campo. Sugerencia real de Gemini Pro tras auditoría del prompt.
    $systemInstruction = [
        'parts' => [[ 'text' =>
            "Eres un asistente meticuloso de back-office que rellena un contrato de " .
            "distribución de telecomunicaciones en España. REGLA DE ORO: no inventes ni " .
            "deduzcas datos — transcribe SOLO valores que aparezcan LITERALMENTE en el " .
            "documento; si no aparece, omite el campo. Extrae únicamente datos del " .
            "DISTRIBUIDOR / punto de venta; ignora datos de terceros (operador, banco, " .
            "notaría, gestoría, testigos). Devuelve exclusivamente JSON válido según las " .
            "claves y reglas descritas en el mensaje del usuario."
        ]]
    ];
    // safetySettings en BLOCK_NONE — evita falsos positivos que bloquean la extracción
    // en documentos legales legítimos (nombres extranjeros, referencias a menores en
    // escrituras familiares, cláusulas de responsabilidad, etc.). No hay contenido
    // dañino real que estemos generando: solo pedimos transcribir campos. Recomendación
    // explícita de Gemini Pro para contratos.
    $safetySettings = [
        ['category' => 'HARM_CATEGORY_HARASSMENT',        'threshold' => 'BLOCK_NONE'],
        ['category' => 'HARM_CATEGORY_HATE_SPEECH',       'threshold' => 'BLOCK_NONE'],
        ['category' => 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold' => 'BLOCK_NONE'],
        ['category' => 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold' => 'BLOCK_NONE'],
    ];
    $order = match ($mode) {
        // 3.5 primero; cae a 3.1 Flash-Lite si hay cuota/429/503 (2.5-flash retirado
        // por Google el 9-jul-2026, ya no es una alternativa válida — ver comentario
        // en GEMINI_MODELS).
        'g35'   => ['gemini-3.5-flash', 'gemini-3.1-flash-lite'],
        'flash' => ['gemini-3.5-flash'],
        'lite'  => ['gemini-3.1-flash-lite'],
        default => ($seq % 2 === 0) ? GEMINI_MODELS : array_reverse(GEMINI_MODELS),  // 'alt'
    };
    $lastErr = 'error'; $lastCode = 502;
    foreach ($order as $model) {
        /* los modelos 3.x traen "thinking" activo: lo bajamos a "low" y subimos el budget
           para que el JSON no salga vacío/cortado. En 2.x no se manda thinkingConfig.
           OJO: el suelo tiene que ser MAYOR que lo que suele mandar el cliente (4096),
           si no max(cliente, suelo) no sube nada — visto en producción: JSON cortado a
           mitad de un valor ("VALENC" en vez de "VALENCIA") porque el thinking interno
           se comía casi todo el presupuesto de salida antes de llegar al texto visible. */
        $genCfg = [
            'maxOutputTokens' => $maxTokens,
            // responseMimeType (jul 2026): fuerza a Gemini a devolver JSON puro, sin
            // markdown envolvente ni prosa extra. NO usamos responseSchema todavía —
            // supondría refactorizar el formato de "sugerencias"/"paquetes" (hoy con
            // claves dinámicas, mal encaje con JSON Schema estricto) y romper la
            // simetría con los otros motores que devuelven ese formato. Este mimeType
            // solo aporta robustez de parseo, sin cambiar la forma del JSON.
            'responseMimeType' => 'application/json',
        ];
        if (str_starts_with($model, 'gemini-3')) {
            $genCfg['maxOutputTokens'] = max($maxTokens, 8192);
            $genCfg['thinkingConfig'] = ['thinkingLevel' => 'low'];
        }
        [$j, $code] = httpJson(
            'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent?key=' . urlencode($key),
            [], [
                'contents' => [['parts' => $parts]],
                'systemInstruction' => $systemInstruction,
                'safetySettings' => $safetySettings,
                'generationConfig' => $genCfg,
            ]);
        if (!isset($j['error'])) {
            $txt = '';
            foreach (($j['candidates'][0]['content']['parts'] ?? []) as $p) $txt .= $p['text'] ?? '';
            if ($txt !== '') return $txt;
            $lastErr = 'respuesta vacía'; $lastCode = 502;
        } else {
            $lastErr  = $j['error']['message'] ?? 'error';
            $lastCode = $code ?: 502;
            $retriable = in_array($code, [429, 503], true) || stripos($lastErr, 'quota') !== false || stripos($lastErr, 'exhausted') !== false;
            if (!$retriable) break;   // error no recuperable: no insistir con el otro modelo
        }
    }
    jout(['ok' => false, 'error' => 'Gemini: ' . $lastErr], $lastCode);
}
/** Groq: imágenes → Llama 4 Scout (visión); texto de PDF (docs[].text) → Llama 3.3 70B. */
function callGroqSrv(string $key, string $prompt, array $docs, int $maxTokens): string {
    $imgs = array_values(array_filter($docs, fn(array $d): bool => str_starts_with($d['mime'] ?? '', 'image/') && !empty($d['b64'])));
    if ($imgs) {
        // qwen/qwen3.6-27b en Groq tiene un TPM (tokens/minuto) muy ajustado (8000,
        // entrada+salida combinadas) frente a otros motores — una imagen ya consume
        // varios miles de tokens de entrada, así que hay que pedir MENOS de salida
        // aquí que en el resto de motores para no superar el límite (visto: 8225/8000).
        $groqVisionMaxTokens = min($maxTokens, 1500);
        return callOpenAICompatSrv('https://api.groq.com/openai/v1/chat/completions',
            GROQ_VISION_MODEL, $key, $prompt, $imgs, $groqVisionMaxTokens, 'Groq');
    }
    foreach ($docs as $d) {
        if (!empty($d['text'])) $prompt .= "\n\n=== TEXTO DEL DOCUMENTO ===\n" . $d['text'];
    }
    [$j, $code] = httpJson('https://api.groq.com/openai/v1/chat/completions',
        ['Authorization: Bearer ' . $key],
        ['model' => PROVIDERS['groq']['model'], 'max_tokens' => $maxTokens,
         'messages' => [['role' => 'user', 'content' => $prompt]]]);
    if (isset($j['error'])) {
        $msg = is_array($j['error']) ? ($j['error']['message'] ?? 'error') : (string)$j['error'];
        jout(['ok' => false, 'error' => 'Groq: ' . $msg], $code ?: 502);
    }
    return (string)($j['choices'][0]['message']['content'] ?? '');
}
function callOpenAICompatSrv(string $url, string $model, string $key, string $prompt, array $docs, int $maxTokens, string $lbl, string $providerId = ''): string {
    $imgs = array_values(array_filter($docs, fn(array $d): bool => str_starts_with($d['mime'] ?? '', 'image/') && !empty($d['b64'])));
    $txt = '';
    foreach ($docs as $d) { if (!empty($d['text'])) $txt .= "\n\n=== TEXTO DEL DOCUMENTO ===\n" . $d['text']; }
    if (!$imgs && $txt === '') jout(['ok' => false, 'error' => $lbl . ': no hay contenido (imagen o texto) que analizar.'], 422);
    if ($imgs) {
        $content = [['type' => 'text', 'text' => $prompt . $txt]];
        foreach ($imgs as $d) $content[] = ['type' => 'image_url', 'image_url' => ['url' => "data:{$d['mime']};base64,{$d['b64']}"]];
        $messages = [['role' => 'user', 'content' => $content]];
    } else {
        $messages = [['role' => 'user', 'content' => $prompt . $txt]];
    }

    // Prueba el modelo principal y, si falla con un código de "problema de modelo"
    // (400/403/404 — nombre no reconocido, bloqueado, deprecado…), los alternativos
    // configurados en ALT_MODELS, en orden, antes de rendirse con este motor.
    $candidates = array_merge([$model], ALT_MODELS[$providerId] ?? []);
    $lastMsg = 'error'; $lastCode = 502;
    foreach ($candidates as $tryModel) {
        for ($attempt = 0; $attempt < 2; $attempt++) {   // hasta 2 intentos por modelo
            [$j, $code] = httpJson($url, ['Authorization: Bearer ' . $key],
                ['model' => $tryModel, 'max_tokens' => $maxTokens, 'messages' => $messages]);
            if (isset($j['error'])) {
                $lastMsg = is_array($j['error']) ? ($j['error']['message'] ?? 'error') : (string)$j['error'];
                $lastCode = $code ?: 502;
                break;   // error real de API: no reintentar aquí, pasar al siguiente modelo
            }
            $out = (string)($j['choices'][0]['message']['content'] ?? '');
            // Detecta alucinación: el modelo dice "no hay documento/imagen" pese a que
            // SÍ se mandó una imagen (visto en producción con Mistral) — reintentar una
            // vez suele bastar, porque no es determinista (muestreo distinto cada vez).
            $soundsLikeNoDoc = $imgs && preg_match(
                '/no\s+(se\s+ha\s+proporcionado|hay|se\s+proporcion[oó])|no\s+document|sin\s+documento/i', $out);
            if (!$soundsLikeNoDoc || $attempt === 1) return $out;
        }
        $modelIssue = in_array($lastCode, [400, 403, 404], true);
        if (!$modelIssue) break;   // 429/503/otros: no es cosa del NOMBRE del modelo, no insistir con otro
    }
    jout(['ok' => false, 'error' => $lbl . ': ' . $lastMsg], $lastCode);
}

/* ── CORS (mismo dominio por defecto; orígenes extra en config) ── */
$origin  = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = $CFG['allowed_origins'] ?? [];
$self    = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '');
if ($origin !== '' && ($origin === $self || in_array($origin, $allowed, true))) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }

/* ── GET: descubrimiento de motores disponibles ── */
$keys = $CFG['keys'] ?? [];
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    $av = [];
    foreach (PROVIDERS as $id => $_) $av[$id] = !empty($keys[$id]);
    jout(['ok' => true, 'proxy' => 'rellenador-pdv', 'version' => 1, 'providers' => $av]);
}

/* ── POST ── */
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') jout(['ok' => false, 'error' => 'Método no permitido'], 405);
rateLimit();

$rawBody = file_get_contents('php://input', length: MAX_BODY + 1);
if ($rawBody === false || strlen($rawBody) > MAX_BODY) jout(['ok' => false, 'error' => 'Petición demasiado grande (>20 MB).'], 413);
$in = json_decode($rawBody, true);
if (!is_array($in)) jout(['ok' => false, 'error' => 'JSON inválido.'], 400);

$provider  = (string)($in['provider'] ?? '');
$prompt    = (string)($in['prompt'] ?? '');
$task      = (string)($in['task'] ?? 'extract');
$seq       = max(0, (int)($in['seq'] ?? 0));   // índice del documento (subida 1 a 1) — alterna Gemini
$gemModeRaw = $in['gemini_mode'] ?? 'g35';
$gemMode    = in_array($gemModeRaw, ['g35','alt','flash','lite'], true) ? $gemModeRaw : 'g35';
$maxTokens = min(8192, max(256, (int)($in['max_tokens'] ?? 2048)));
$docsIn    = is_array($in['docs'] ?? null) ? array_slice($in['docs'], 0, MAX_DOCS) : [];

if (!isset(PROVIDERS[$provider]))            jout(['ok' => false, 'error' => 'Proveedor no permitido.'], 400);
if ($prompt === '' || strlen($prompt) > 40000) jout(['ok' => false, 'error' => 'Prompt vacío o excesivo.'], 400);
if (!in_array($task, ['extract', 'locate_signature'], true)) jout(['ok' => false, 'error' => 'Tarea no permitida.'], 400);
if (empty($keys[$provider]))                 jout(['ok' => false, 'error' => "Sin clave de servidor para «{$provider}»."], 403);

/* Trunca a N "caracteres" aproximados sin requerir ext-mbstring.
   Usa mb_substr si está disponible; si no, corta por bytes respetando fronteras UTF-8. */
function utf8_clip(string $s, int $max): string {
    if (function_exists('mb_substr')) return mb_substr($s, 0, $max);
    if (strlen($s) <= $max) return $s;                 // ASCII o ya corto: a salvo
    $cut = substr($s, 0, $max);
    // retrocede si quedó a mitad de un carácter multibyte
    $i = strlen($cut) - 1;
    while ($i >= 0 && (ord($cut[$i]) & 0xC0) === 0x80) $i--;
    return $i >= 0 ? substr($cut, 0, $i) : $cut;
}

$docs = [];
foreach ($docsIn as $d) {
    if (!is_array($d)) continue;
    /* Texto de PDF extraído en el front (pdf.js) — para motores sin visión/PDF como Groq */
    if (isset($d['text']) && is_string($d['text']) && trim($d['text']) !== '') {
        $docs[] = ['mime' => 'text/plain', 'b64' => '', 'text' => utf8_clip($d['text'], MAX_DOC_TEXT)];
        continue;
    }
    $mime = (string)($d['mime'] ?? '');
    $b64  = (string)($d['b64'] ?? '');
    if (!preg_match('#^(application/pdf|image/(jpeg|png|webp|gif))$#', $mime)) continue;
    if ($b64 === '' || base64_decode($b64, true) === false) continue;
    if ($mime === 'application/pdf' && !PROVIDERS[$provider]['pdf']) continue;  // motor solo-imagen/texto
    [$mime, $b64] = shrinkImage($mime, $b64);                                    // ← reducción server-side
    $docs[] = ['mime' => $mime, 'b64' => $b64];
}
if (!$docs && $task !== 'extract') jout(['ok' => false, 'error' => 'La tarea requiere al menos una imagen.'], 422);

$key  = (string)$keys[$provider];
$text = match (true) {
    $provider === 'claude'  => callClaudeSrv($key, $prompt, $docs, $maxTokens),
    $provider === 'gemini'  => callGeminiSrv($key, $prompt, $docs, $maxTokens, $seq, $gemMode),
    $provider === 'groq'    => callGroqSrv($key, $prompt, $docs, $maxTokens),
    isset(OPENAI_COMPAT[$provider]) => callOpenAICompatSrv(
        (string)($CFG['endpoints'][$provider] ?? OPENAI_COMPAT[$provider]['url']),
        (string)($CFG['models'][$provider] ?? PROVIDERS[$provider]['model']),
        $key, $prompt, $docs, $maxTokens, OPENAI_COMPAT[$provider]['label'], $provider),
    default => jout(['ok' => false, 'error' => 'Proveedor no enrutable.'], 400),
};
jout(['ok' => true, 'provider' => $provider, 'text' => $text]);
