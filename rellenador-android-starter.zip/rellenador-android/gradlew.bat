@gradle %*
